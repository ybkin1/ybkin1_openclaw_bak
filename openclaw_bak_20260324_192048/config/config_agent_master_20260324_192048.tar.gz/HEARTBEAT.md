# HEARTBEAT.md - Master Agent Task Memory System

## Daily Tasks (Execute at 23:50 daily)
1. **Session Summary**: For each active user, summarize today's conversations and update short-term memory
2. **Task Progress Update**: Check all active tasks and update progress status using task metadata schema
3. **Cleanup Check**: Identify completed tasks older than 3 days using completion_date field and prepare deletion inquiries
4. **Memory Consolidation**: Move relevant short-term learnings to long-term memory
5. **Task Completion Verification**: For recently completed tasks, verify completion status with user if not already confirmed
6. **Task Confirmation Check**: Check for tasks with completion_confirmed=false and send confirmation requests
7. **Thinking Principles Review**: Audit all agents' recent task handling for compliance with `memory/config/agent-thinking-principles.md`; flag deviations and suggest corrections

## Task Progress Monitoring (Execute every 10 minutes during active tasks)
- **1/3 Progress Check**: For any task with estimated duration > 30 minutes, check if 1/3 of time has passed
- **Progress Report**: If 1/3 threshold met, generate progress report and notify user
- **Risk Assessment**: Evaluate if task is on track or needs intervention

## New Session Recovery Workflow
When a new session starts:
1. **User Identification**: Map incoming channel ID to user UUID
2. **Memory Loading**: Load short-term memory (last 10 messages) and active tasks
3. **Context Generation**: Create summary of yesterday's tasks and current status
4. **User Confirmation**: Present context to user: "Yesterday you had X active tasks: [list]. Is my understanding correct?"

## Task Recognition Rules
Automatically identify as tasks any request containing:
- Configuration/setup/setting
- Upgrade/update/install/deploy  
- Backup/restore/archive
- Maintenance/monitoring/troubleshooting
- Any action requiring system changes or persistent tracking

## Learning Integration
- All task completions contribute to long-term memory
- User feedback improves task recognition accuracy
- System continuously evolves based on interaction patterns

## Memory Structure Validation
Ensure the following directory structure exists:
memory/master/
├── users/
├── short_term/  
├── long_term/
└── tasks/
    ├── active/
    ├── completed/
    └── archived/