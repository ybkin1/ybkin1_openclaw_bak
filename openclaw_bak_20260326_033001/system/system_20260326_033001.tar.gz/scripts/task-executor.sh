#!/bin/bash
# task-executor.sh - 任务执行器
# 每 5 分钟检查一次，执行活跃任务

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
TASKS_ACTIVE_DIR="$BASE_DIR/tasks/active"
LOG_FILE="$BASE_DIR/logs/task-executor.log"
EXECUTOR_STATE_FILE="$BASE_DIR/memory/master/executor-state.json"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保目录存在
mkdir -p "$BASE_DIR/logs"
mkdir -p "$BASE_DIR/memory/master"

# 更新任务心跳
update_heartbeat() {
    local task_file="$1"
    local progress="$2"
    local current_step="$3"
    
    local timestamp=$(date -Iseconds)
    
    # 更新状态文件
    jq --arg time "$timestamp" \
       --argjson prog "$progress" \
       --arg step "$current_step" \
       '.lastActivity = $time | .progress = $prog | .currentStep = $step' \
       "$task_file" > "${task_file}.tmp"
    
    if [ $? -eq 0 ]; then
        mv "${task_file}.tmp" "$task_file"
        
        # 添加检查点
        local checkpoint_file="${task_file%.json}.checkpoint"
        echo "{\"timestamp\": \"$timestamp\", \"progress\": $progress, \"step\": \"$current_step\"}" >> "$checkpoint_file"
        
        log_info "✓ 心跳更新：$(basename $task_file) (进度：$progress%)"
    else
        log_error "心跳更新失败：$(basename $task_file)"
        rm -f "${task_file}.tmp"
    fi
}

# 检查任务超时
check_timeout() {
    local task_file="$1"
    
    local started_at=$(jq -r '.startedAt // empty' "$task_file")
    local expected_duration=$(jq -r '.expectedDuration' "$task_file")
    
    if [ -z "$started_at" ] || [ "$started_at" = "null" ]; then
        return 0  # 未开始，不检查
    fi
    
    local start_ts=$(date -d "$started_at" +%s 2>/dev/null || echo "0")
    local current_ts=$(date +%s)
    local elapsed=$((current_ts - start_ts))
    
    # 超过预计时间 2 倍
    if [ $elapsed -gt $((expected_duration * 2)) ]; then
        log_warn "任务超时：$(basename $task_file) (已运行 ${elapsed}s, 预计 ${expected_duration}s)"
        
        # 标记为超时
        jq --arg time "$(date -Iseconds)" \
           '.status = "stuck" | .stuckReason = "timeout" | .stuckAt = $time' \
           "$task_file" > "${task_file}.tmp"
        
        mv "${task_file}.tmp" "$task_file"
        
        # 发送告警
        log_warn "发送超时告警..."
        # TODO: 发送飞书告警
        
        return 1
    fi
    
    return 0
}

# 执行任务步骤
execute_task_step() {
    local task_file="$1"
    local task_id=$(jq -r '.taskId' "$task_file")
    local current_step=$(jq -r '.currentStep' "$task_file")
    local progress=$(jq -r '.progress' "$task_file")
    
    log_info "执行任务：$task_id (当前步骤：$current_step)"
    
    # 根据步骤类型执行不同操作
    case "$current_step" in
        "设计"*)
            # 设计阶段 - 创建文档
            log_info "执行设计阶段"
            # TODO: 调用 AI 生成设计文档
            new_progress=$((progress + 20))
            new_step="编写实现脚本"
            ;;
        "编写"*)
            # 实现阶段 - 编写脚本
            log_info "执行实现阶段"
            # TODO: 调用 AI 编写脚本
            new_progress=$((progress + 40))
            new_step="测试验证"
            ;;
        "测试"*)
            # 测试阶段
            log_info "执行测试阶段"
            # TODO: 运行测试脚本
            new_progress=$((progress + 70))
            new_step="文档完善"
            ;;
        "观察"*)
            # 观察阶段
            log_info "执行观察阶段"
            new_progress=$((progress + 10))
            new_step="继续观察"
            ;;
        "文档"*)
            # 文档阶段
            log_info "执行文档阶段"
            new_progress=$((progress + 90))
            new_step="任务验证"
            ;;
        "任务验证"*)
            # 验证阶段
            log_info "执行验证阶段"
            new_progress=100
            new_step="任务完成"
            
            # 标记为完成
            jq '.status = "completed" | .completedAt = "'$(date -Iseconds)'"' \
               "$task_file" > "${task_file}.tmp"
            mv "${task_file}.tmp" "$task_file"
            
            # 移动到 completed 目录
            mv "$task_file" "$BASE_DIR/tasks/completed/"
            
            log_info "✓ 任务完成：$task_id"
            return 0
            ;;
        *)
            # 未知步骤
            log_warn "未知步骤：$current_step"
            new_progress=$((progress + 10))
            new_step="等待指示"
            ;;
    esac
    
    # 更新进度
    update_heartbeat "$task_file" "$new_progress" "$new_step"
    
    log_info "✓ 任务进度更新：$task_id (新进度：$new_progress%)"
}

# 主程序
main() {
    log_info "=========================================="
    log_info "开始任务执行"
    log_info "=========================================="
    
    # 检查任务目录
    if [ ! -d "$TASKS_ACTIVE_DIR" ]; then
        log_warn "任务目录不存在：$TASKS_ACTIVE_DIR"
        exit 0
    fi
    
    local executed_count=0
    
    # 遍历所有活跃任务
    for task_file in "$TASKS_ACTIVE_DIR"/*.json; do
        if [ ! -f "$task_file" ]; then
            continue
        fi
        
        local task_id=$(jq -r '.taskId' "$task_file")
        local status=$(jq -r '.status' "$task_file")
        
        log_info "检查任务：$task_id (状态：$status)"
        
        # 跳过非进行中的任务
        if [ "$status" != "in_progress" ] && [ "$status" != "pending" ]; then
            log_info "跳过任务：$task_id (状态：$status)"
            continue
        fi
        
        # 检查超时
        if ! check_timeout "$task_file"; then
            continue  # 超时任务，跳过
        fi
        
        # 如果是 pending，标记为 in_progress
        if [ "$status" = "pending" ]; then
            local start_time=$(date -Iseconds)
            jq --arg time "$start_time" \
               '.status = "in_progress" | .startedAt = $time' \
               "$task_file" > "${task_file}.tmp"
            mv "${task_file}.tmp" "$task_file"
            
            log_info "任务启动：$task_id"
        fi
        
        # 执行任务步骤
        execute_task_step "$task_file"
        
        executed_count=$((executed_count + 1))
    done
    
    log_info "=========================================="
    log_info "任务执行完成：执行 $executed_count 个任务"
    log_info "=========================================="
}

# 运行主程序
main "$@"
