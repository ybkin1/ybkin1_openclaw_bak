# Agent Heartbeat

## Daily Tasks
- Process pending tasks from queue
- Update domain knowledge base
- Clean up temporary files
- Report status to master agent

## Collaboration
- Coordinate with other L3/L4 agents as needed
- Use task queue for inter-agent communication
- Log all collaboration activities
