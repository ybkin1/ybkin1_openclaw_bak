# 跨天任务持久化机制（Cross-Session Task Persistence）

**版本**: 1.0  
**创建时间**: 2026-03-25  
**参考项目**: GSD-2 + DeerFlow 2.0 + MetaGPT

---

## 🎯 目标

解决以下问题：
1. **模型资源不足** - 长任务超出上下文窗口或 token 限制
2. **会话刷新** - 用户关闭对话后重新打开，任务状态丢失
3. **系统挂掉** - Gateway 重启或服务器宕机导致任务中断
4. **跨天执行** - 任务执行超过 24 小时，会话自然过期

---

## 🏗️ 架构设计

### 1. 三级任务分解（GSD-2）

```
Milestone (里程碑) → Slice (切片) → Task (任务)
    ↓                    ↓           ↓
 项目阶段            功能模块      原子操作
 (数天 - 数周)        (数小时)      (分钟级)
```

**分解规则**:

| 层级 | 持续时间 | 输出 | 持久化要求 |
|------|---------|------|-----------|
| Milestone | 数天 - 数周 | `milestone_*.md` | 必须持久化 |
| Slice | 数小时 | `slice_*.md` | 必须持久化 |
| Task | 分钟级 | `task_*.json` | 必须持久化 + 心跳 |

---

### 2. 状态机驱动（GSD-2）

```
pending → in_progress → reviewing → completed
                ↓
              failed → retry → in_progress
                ↓
              paused (跨天暂停)
```

**状态文件位置**:
```
/root/.openclaw/workspace/agents/master/memory/tasks/
├── active/       # 进行中任务
├── paused/       # 跨天暂停任务
├── completed/    # 已完成任务
└── failed/       # 失败任务
```

---

### 3. 心跳机制（融合 MetaGPT Observe-Think-Act）

**心跳更新时机**:
```
每次 Agent 执行 Action 后 → 更新心跳
每 5 分钟（长任务） → 强制更新心跳
任务状态变更时 → 立即更新心跳
```

**心跳文件内容**:
```json
{
  "taskId": "task_20260325_180000_xxx",
  "lastActivity": "2026-03-25T18:43:00+08:00",
  "status": "in_progress",
  "progress": 45,
  "currentStep": "正在执行：数据分析",
  "nextStep": "下一步：生成报告",
  "checkpoints": [
    {
      "timestamp": "2026-03-25T18:30:00+08:00",
      "progress": 20,
      "step": "完成数据收集"
    },
    {
      "timestamp": "2026-03-25T18:40:00+08:00",
      "progress": 45,
      "step": "完成数据分析"
    }
  ],
  "estimatedCompletion": "2026-03-25T20:00:00+08:00",
  "crossSessionSupport": true
}
```

---

### 4. 跨天任务处理流程

#### 阶段 1: 任务暂停（每天 23:00）

```bash
# 1. 检测活跃任务
for task in tasks/active/*.json; do
    state=$(cat "$task")
    
    # 2. 检查是否接近下班时间
    if [ $(date +%H) -ge 23 ]; then
        # 3. 标记为跨天暂停
        jq '.status = "paused" | .pauseReason = "cross_day"' "$task" > "${task}.tmp"
        mv "${task}.tmp" "$task"
        
        # 4. 移动到 paused 目录
        mv "$task" tasks/paused/
        
        # 5. 发送通知
        send_notification "任务暂停" "任务 $(basename $task) 已暂停，明日继续"
    fi
done
```

#### 阶段 2: 任务恢复（次日 08:30）

```bash
# 1. 检查暂停任务
for task in tasks/paused/*.json; do
    state=$(cat "$task")
    
    # 2. 检查是否超过暂停时间（23:00-08:30）
    if [ $(date +%H) -ge 8 ] && [ $(date +%H) -lt 9 ]; then
        # 3. 恢复任务状态
        jq '.status = "in_progress" | del(.pauseReason)' "$task" > "${task}.tmp"
        mv "${task}.tmp" "$task"
        
        # 4. 移动回 active 目录
        mv "$task" tasks/active/
        
        # 5. 发送通知
        send_notification "任务恢复" "任务 $(basename $task) 已恢复执行"
    fi
done
```

---

### 5. 任务切片策略（防止资源不足）

**自动切片规则**:

| 触发条件 | 动作 | 说明 |
|---------|------|------|
| Token 使用 > 80% | 自动切片 | 当前上下文窗口剩余 20% 时 |
| 执行时间 > 30 分钟 | 自动切片 | 防止单任务过长 |
| 用户无响应 > 10 分钟 | 暂停任务 | 等待用户确认 |
| 接近下班时间 | 暂停任务 | 跨天处理 |

**切片流程**:
```
1. 保存当前状态到 checkpoint
2. 生成切片摘要（供下一切片使用）
3. 清理当前上下文
4. 加载新切片
5. 从 checkpoint 恢复
```

---

### 6. 系统挂掉恢复

**启动时恢复流程**:
```bash
# 1. 检查 active 目录
for task in tasks/active/*.json; do
    state=$(cat "$task")
    last_activity=$(jq -r '.lastActivity' "$state")
    
    # 2. 计算时间差
    elapsed=$(($(date +%s) - $(date -d "$last_activity" +%s)))
    
    # 3. 超过 30 分钟无活动 → 标记为暂停
    if [ $elapsed -gt 1800 ]; then
        jq '.status = "paused" | .pauseReason = "system_crash"' "$task"
        mv "$task" tasks/paused/
        
        # 4. 发送通知
        send_notification "任务恢复" "检测到系统异常，任务 $(basename $task) 已暂停，请确认是否继续"
    fi
done
```

---

## 📁 文件结构

```
/root/.openclaw/workspace/agents/master/memory/tasks/
├── active/
│   ├── task_20260325_180000_xxx.json
│   └── task_20260325_180000_xxx.checkpoint  # 检查点
├── paused/
│   ├── task_20260324_230000_xxx.json
│   └── task_20260324_230000_xxx.summary     # 切片摘要
├── completed/
│   └── task_20260325_120000_xxx.json
└── failed/
    └── task_20260325_100000_xxx.json
```

---

## 🔧 实施步骤

### P0-1: 心跳机制（本周）

**文件**: `scripts/task-heartbeat.sh`

**功能**:
- 每 5 分钟更新任务心跳
- 写入检查点到 `.checkpoint` 文件
- 检测僵尸任务

**命令**:
```bash
# 添加到 crontab
*/5 * * * * /root/.openclaw/workspace/agents/master/scripts/task-heartbeat.sh
```

---

### P0-2: 跨天任务调度（本周）

**文件**: `scripts/cross-day-scheduler.sh`

**功能**:
- 每天 23:00 暂停活跃任务
- 次日 08:30 恢复暂停任务
- 发送通知

**命令**:
```bash
# 添加到 crontab
0 23 * * * /root/.openclaw/workspace/agents/master/scripts/cross-day-scheduler.sh pause
30 8 * * * /root/.openclaw/workspace/agents/master/scripts/cross-day-scheduler.sh resume
```

---

### P0-3: 僵尸任务检测（本周）

**文件**: `scripts/zombie-task-detector.sh`

**功能**:
- 每 10 分钟检查一次
- 超过 30 分钟无心跳 → 标记为僵尸
- 发送告警

**命令**:
```bash
# 添加到 crontab
*/10 * * * * /root/.openclaw/workspace/agents/master/scripts/zombie-task-detector.sh
```

---

## 📊 监控指标

| 指标 | 阈值 | 告警方式 |
|------|------|---------|
| 任务无心跳 > 30 分钟 | 警告 | 飞书通知 |
| 任务无心跳 > 1 小时 | 严重 | 飞书 + 邮件 |
| 跨天任务未恢复 > 2 小时 | 警告 | 飞书通知 |
| 单日任务失败率 > 20% | 警告 | 飞书通知 |

---

## 🧪 测试计划

### 测试 1: 心跳机制

```bash
# 1. 创建测试任务
echo '{"taskId": "test_001", "status": "in_progress"}' > tasks/active/test_001.json

# 2. 运行心跳脚本
./scripts/task-heartbeat.sh

# 3. 验证心跳更新
cat tasks/active/test_001.json.checkpoint

# 4. 检查 lastActivity 是否更新
```

### 测试 2: 跨天暂停

```bash
# 1. 模拟 23:00
date -s "2026-03-25 23:00:00"

# 2. 运行暂停脚本
./scripts/cross-day-scheduler.sh pause

# 3. 验证任务移动到 paused/
ls tasks/paused/
```

### 测试 3: 系统恢复

```bash
# 1. 修改心跳时间为 1 小时前
jq '.lastActivity = "2026-03-25T17:00:00+08:00"' tasks/active/test_001.json

# 2. 运行恢复脚本
./scripts/crash-recovery.sh

# 3. 验证任务标记为 paused
cat tasks/paused/test_001.json | jq '.status'
```

---

## 📝 使用示例

### 创建跨天任务

```bash
# 1. 使用模板创建任务
cat > tasks/active/task_$(date +%Y%m%d_%H%M%S)_xxx.json << 'EOF'
{
  "taskId": "task_20260325_180000_xxx",
  "title": "数据分析报告生成",
  "status": "in_progress",
  "createdAt": "2026-03-25T18:00:00+08:00",
  "lastActivity": "2026-03-25T18:00:00+08:00",
  "progress": 0,
  "estimatedDuration": 7200,
  "crossSessionSupport": true,
  "autoPauseAt": "23:00",
  "autoResumeAt": "08:30"
}
EOF

# 2. 创建初始检查点
echo '{"step": "任务启动", "timestamp": "2026-03-25T18:00:00+08:00"}' > tasks/active/task_20260325_180000_xxx.checkpoint
```

### 更新任务进度

```bash
# 1. 更新状态文件
jq '.progress = 45 | .lastActivity = "2026-03-25T18:30:00+08:00" | .currentStep = "数据分析中"' \
    tasks/active/task_20260325_180000_xxx.json > /tmp/task.tmp
mv /tmp/task.tmp tasks/active/task_20260325_180000_xxx.json

# 2. 追加检查点
echo '{"step": "数据分析", "progress": 45, "timestamp": "2026-03-25T18:30:00+08:00"}' \
    >> tasks/active/task_20260325_180000_xxx.checkpoint
```

---

## ⚠️ 注意事项

1. **心跳文件使用原子写入**（先写.tmp，再 mv）
2. **检查点文件追加模式**（保留历史）
3. **跨天暂停前必须发送通知**（给用户确认机会）
4. **恢复任务前检查系统状态**（确保 Gateway 正常）

---

## 🔄 持续改进

- [ ] 添加任务优先级队列
- [ ] 实现任务依赖关系
- [ ] 支持任务委派（转交其他 Agent）
- [ ] 添加任务成本追踪

---

**最后更新**: 2026-03-25  
**维护者**: Master Agent
