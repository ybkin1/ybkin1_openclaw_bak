# 自动化任务执行计划（P0-1 → P3-3）

**版本**: 1.0  
**创建时间**: 2026-03-25 19:01  
**参考框架**: GSD-2 + DeerFlow 2.0 + MetaGPT

---

## 🎯 目标

实现 P0-1 到 P3-3 共 12 个任务的**自动化执行**，同时解决以下问题：

1. **AI 幻觉** - 模型上下文不足导致编造信息
2. **任务中止** - 会话刷新/系统挂掉导致任务中断
3. **上下文超限** - 后续任务因 token 限制糊弄
4. **状态丢失** - 任务进度无法跨会话保持

---

## 🏗️ 核心架构

### 1. 任务分解策略（GSD-2）

```
总任务 (12 个) → Milestone (4 阶段) → Slice (每周) → Task (每日)
```

**Milestone 划分**:
| Milestone | 任务 | 周期 | 状态 |
|-----------|------|------|------|
| M1: P0 任务 | P0-1, P0-2, P0-3 | 第 1 周 | ✅ 已完成 |
| M2: P1 任务 | P1-1, P1-2, P1-3 | 第 2 周 | ⏳ 待执行 |
| M3: P2 任务 | P2-1, P2-2, P2-3 | 第 3 周 | ⏳ 待执行 |
| M4: P3 任务 | P3-1, P3-2, P3-3 | 第 4 周 | ⏳ 待执行 |

---

### 2. 防 AI 幻觉机制

#### 2.1 上下文管理

**问题**: 模型上下文窗口有限（200K），长任务会超限

**解决方案**:
```
每任务独立上下文 + 状态文件持久化 + 关键信息摘要
```

**实施规则**:
| 规则 | 说明 | 执行方式 |
|------|------|---------|
| **单任务上下文** | 每个 Task 使用新上下文 | 任务开始前 clear context |
| **状态文件** | 所有进度写入磁盘 | 每 5 分钟心跳更新 |
| **摘要传递** | Task 之间传递摘要而非全文 | 生成 200 字摘要供下一任务使用 |
| **强制验证** | 关键结论必须有数据支撑 | 验证脚本自动检查 |

#### 2.2 防幻觉检查清单

**每个 Task 执行前必须回答**:
```
□ 我理解用户的真实目标吗？（第一性原理）
□ 我是否先搜索了已有方案？（Search Before Building）
□ 我选择的方案是最优的吗？（最短路径）
□ 我的结论有数据/日志支撑吗？（防幻觉）
□ 是否需要和用户确认？（目标澄清）
```

**每个 Task 执行后必须验证**:
```
□ 结果是否符合预期？（自我验证）
□ 是否处理了边缘情况？（边缘猎杀）
□ 是否有安全隐患？（安全检查）
□ 是否需要更新文档？（文档验证）
```

---

### 3. 防任务中止机制

#### 3.1 状态持久化

**状态文件结构**:
```json
{
  "taskId": "P1-1-sop-enforcement",
  "milestone": "M2",
  "slice": "Week-2",
  "status": "in_progress",
  "progress": 45,
  "lastActivity": "2026-03-25T19:00:00+08:00",
  "currentStep": "编写 SOP 验证器脚本",
  "nextStep": "测试 SOP 拦截功能",
  "checkpoints": [
    {
      "timestamp": "2026-03-25T18:30:00+08:00",
      "progress": 20,
      "step": "完成 SOP 设计"
    }
  ],
  "context": {
    "summary": "SOP 具象化任务，需要将工作流程编码为强制约束",
    "dependencies": ["P0-1", "P0-2"],
    "blockers": []
  }
}
```

#### 3.2 跨会话恢复

**恢复流程**:
```
1. 会话启动 → 读取 tasks/active/*.json
2. 检查 lastActivity → 超过 30 分钟标记为 paused
3. 发送通知 → 用户确认是否继续
4. 恢复执行 → 从 checkpoint 继续
```

---

### 4. 防上下文超限机制

#### 4.1 任务切片策略

**自动切片触发条件**:
| 条件 | 阈值 | 动作 |
|------|------|------|
| Token 使用 | > 80% | 生成摘要，清理上下文 |
| 执行时间 | > 30 分钟 | 保存状态，切片继续 |
| 消息数量 | > 50 条 | 压缩历史消息 |
| 文件数量 | > 10 个 | 归档中间文件 |

#### 4.2 摘要生成规则

**每个 Task 完成后必须生成**:
```markdown
## 任务摘要（200 字内）

**任务 ID**: P1-1-sop-enforcement
**完成时间**: 2026-03-25 19:00
**主要成果**: 
- 创建 SOP 验证器脚本
- 添加 SOP 强制检查点
- 测试拦截功能

**关键数据**:
- SOP 检查点数量：5 个
- 拦截测试通过率：100%

**待继续工作**:
- 需要在 assistant agent 试点
- 观察一周后推广

**下一任务**: P1-2-cost-tracking
```

---

## 📋 详细任务计划

### M1: P0 任务（第 1 周）- ✅ 已完成

| 任务 ID | 任务名称 | 状态 | 完成时间 | 摘要文件 |
|--------|---------|------|---------|---------|
| P0-1 | 心跳机制 | ✅ 完成 | 2026-03-25 | `reports/p0-1-heartbeat-summary.md` |
| P0-2 | 状态验证 | ✅ 完成 | 2026-03-25 | `reports/p0-2-state-verification-summary.md` |
| P0-3 | 僵尸检测 | ✅ 完成 | 2026-03-25 | `reports/p0-3-zombie-detection-summary.md` |

---

### M2: P1 任务（第 2 周）- 2026-03-26 至 2026-04-01

#### P1-1: SOP 具象化

**任务描述**: 将工作流程编码为 Agent 的强制约束

**执行计划**:
```
Day 1 (2026-03-26): 设计 SOP 状态机
  - 定义状态转换规则
  - 创建 SOP 检查点模板
  - 输出：sop-state-machine.md

Day 2 (2026-03-27): 编写 SOP 验证器
  - 创建 sop-validator.sh
  - 实现状态转换拦截
  - 输出：sop-validator.sh

Day 3 (2026-03-28): 测试 SOP 功能
  - 在 assistant agent 试点
  - 记录拦截日志
  - 输出：sop-test-report.md

Day 4 (2026-03-29): 优化调整
  - 根据测试结果调整
  - 添加豁免机制
  - 输出：sop-optimization.md

Day 5 (2026-03-30): 文档完善
  - 更新 WORKFLOW.md
  - 添加使用示例
  - 输出：sop-documentation.md

Day 6-7: 观察期
  - 不执行新操作
  - 观察 SOP 运行效果
```

**防幻觉措施**:
- [ ] SOP 检查点必须有实际拦截案例支撑
- [ ] 测试报告必须包含成功/失败案例
- [ ] 优化建议必须有数据对比

**状态文件**: `tasks/active/P1-1-sop-enforcement.json`

---

#### P1-2: 成本追踪

**任务描述**: 集成 token 使用数据到任务状态文件

**执行计划**:
```
Day 1 (2026-03-27): 调研 OpenClaw 原生支持
  - 检查 session_status 命令
  - 查看 token 统计 API
  - 输出：cost-tracking-research.md

Day 2 (2026-03-28): 设计成本追踪格式
  - 定义 JSON 字段
  - 创建统计模板
  - 输出：cost-tracking-schema.md

Day 3 (2026-03-29): 实现追踪脚本
  - 创建 cost-tracker.sh
  - 集成到心跳脚本
  - 输出：cost-tracker.sh

Day 4 (2026-03-30): 添加告警机制
  - 设置成本阈值
  - 实现告警通知
  - 输出：cost-alert-config.md

Day 5 (2026-03-31): 测试验证
  - 模拟高成本任务
  - 验证告警触发
  - 输出：cost-tracking-test.md
```

**防幻觉措施**:
- [ ] 成本数据必须来自实际 API
- [ ] 阈值设置必须有历史数据支撑
- [ ] 告警测试必须有截图/日志

**状态文件**: `tasks/active/P1-2-cost-tracking.json`

---

#### P1-3: 消息驱动协作（高风险，延后到 P3）

**决策**: 因风险较高，延后到 P3 阶段执行

---

### M3: P2 任务（第 3 周）- 2026-04-01 至 2026-04-07

#### P2-1: 记忆清理策略（高风险）

**任务描述**: 实现记忆文件自动清理

**执行计划**:
```
Day 1 (2026-04-01): 设计清理策略
  - 定义 TTL 规则
  - 创建白名单
  - 输出：memory-cleanup-policy.md

Day 2 (2026-04-02): 编写清理脚本（只归档不删除）
  - 创建 memory-cleanup.sh
  - 实现归档功能
  - 输出：memory-cleanup.sh

Day 3-7 (2026-04-03-07): 观察期（阶段 1）
  - 只归档不删除
  - 观察一周效果
  - 输出：cleanup-observation-week1.md
```

**防幻觉措施**:
- [ ] 清理前必须备份
- [ ] 白名单必须用户确认
- [ ] 归档文件必须可恢复

**状态文件**: `tasks/active/P2-1-memory-cleanup.json`

---

#### P2-2: 日志轮转

**任务描述**: 实现日志文件自动轮转

**执行计划**:
```
Day 1 (2026-04-04): 配置 logrotate
  - 创建 logrotate 配置
  - 设置轮转规则
  - 输出：logrotate.conf

Day 2 (2026-04-05): 测试轮转
  - 手动触发轮转
  - 验证压缩效果
  - 输出：logrotate-test.md

Day 3 (2026-04-06): 监控告警
  - 添加日志大小监控
  - 设置告警阈值
  - 输出：log-monitor-config.md
```

**防幻觉措施**:
- [ ] 轮转配置必须经过测试
- [ ] 历史日志必须可检索
- [ ] 压缩文件必须可解压

**状态文件**: `tasks/active/P2-2-log-rotation.json`

---

#### P2-3: 用户反馈闭环

**任务描述**: 任务完成后收集满意度

**执行计划**:
```
Day 1 (2026-04-07): 设计反馈模板
  - 创建满意度调查表
  - 定义评分标准
  - 输出：feedback-template.md

Day 2 (2026-04-08): 实现反馈收集
  - 创建 feedback-collector.sh
  - 集成到任务完成流程
  - 输出：feedback-collector.sh

Day 3 (2026-04-09): 分析改进
  - 生成周反馈报告
  - 识别改进点
  - 输出：feedback-analysis-week1.md
```

**防幻觉措施**:
- [ ] 反馈数据必须真实收集
- [ ] 分析报告必须有统计支撑
- [ ] 改进建议必须可执行

**状态文件**: `tasks/active/P2-3-feedback-loop.json`

---

### M4: P3 任务（第 4 周）- 2026-04-08 至 2026-04-14

#### P3-1: 自适应重规划

**任务描述**: 根据执行情况动态调整任务计划

**执行计划**:
```
Day 1 (2026-04-08): 设计重规划算法
  - 定义偏差检测规则
  - 创建重规划触发条件
  - 输出：replan-algorithm.md

Day 2 (2026-04-09): 实现重规划脚本
  - 创建 auto-replan.sh
  - 集成到任务调度
  - 输出：auto-replan.sh

Day 3 (2026-04-10): 测试验证
  - 模拟进度偏差
  - 验证重规划触发
  - 输出：replan-test.md
```

**防幻觉措施**:
- [ ] 偏差计算必须有历史数据
- [ ] 重规划必须用户确认
- [ ] 测试结果必须有对比

**状态文件**: `tasks/active/P3-1-adaptive-replan.json`

---

#### P3-2: 技能按需加载

**任务描述**: 为专业 Agent 添加领域专用技能

**执行计划**:
```
Day 1 (2026-04-11): 技能需求分析
  - 分析各 Agent 职责
  - 识别技能缺口
  - 输出：skill-requirements.md

Day 2 (2026-04-12): 技能选型
  - 搜索 ClawHub 技能
  - 评估技能质量
  - 输出：skill-selection.md

Day 3 (2026-04-13): 试点安装（1-2 个技能）
  - 在 analysis agent 试点
  - 测试技能功能
  - 输出：skill-pilot-test.md

Day 4 (2026-04-14): 推广评估
  - 评估试点效果
  - 决定是否推广
  - 输出：skill-rollout-evaluation.md
```

**防幻觉措施**:
- [ ] 技能选型必须有对比分析
- [ ] 试点测试必须有实际案例
- [ ] 推广决定必须有数据支撑

**状态文件**: `tasks/active/P3-2-skill-loading.json`

---

#### P3-3: 磁盘空间监控

**任务描述**: 实现磁盘空间监控和自动清理

**执行计划**:
```
Day 1 (2026-04-15): 设计监控方案
  - 定义监控指标
  - 设置告警阈值
  - 输出：disk-monitor-design.md

Day 2 (2026-04-16): 实现监控脚本
  - 创建 disk-monitor.sh
  - 集成到 Health Guardian
  - 输出：disk-monitor.sh

Day 3 (2026-04-17): 测试验证
  - 模拟磁盘满场景
  - 验证告警触发
  - 输出：disk-monitor-test.md
```

**防幻觉措施**:
- [ ] 监控数据必须来自实际 df 命令
- [ ] 告警阈值必须有容量规划
- [ ] 清理操作必须安全可控

**状态文件**: `tasks/active/P3-3-disk-monitor.json`

---

## 🤖 自动化执行机制

### 1. 任务调度器

**文件**: `scripts/task-orchestrator.sh`

**功能**:
- 每日 08:00 检查当日任务
- 创建任务状态文件
- 发送任务开始通知
- 监控任务执行进度

**执行逻辑**:
```bash
#!/bin/bash
# task-orchestrator.sh - 任务编排器

# 1. 读取任务计划
task_plan="/root/.openclaw/workspace/agents/master/memory/config/task-plan-week-*.md"

# 2. 检查今日任务
today=$(date +%Y-%m-%d)
today_tasks=$(grep -A5 "Day.*($today)" "$task_plan")

# 3. 创建任务状态文件
for task in $today_tasks; do
    create_task_state "$task"
done

# 4. 发送通知
send_notification "今日任务" "今日有 $count 个任务待执行"

# 5. 监控进度
while [ $count -gt 0 ]; do
    check_task_progress
    sleep 300  # 每 5 分钟检查一次
done
```

---

### 2. 任务执行器

**文件**: `scripts/task-executor.sh`

**功能**:
- 读取任务状态文件
- 执行任务具体操作
- 更新任务进度
- 生成任务摘要

**执行逻辑**:
```bash
#!/bin/bash
# task-executor.sh - 任务执行器

task_id="$1"
state_file="tasks/active/${task_id}.json"

# 1. 读取任务状态
state=$(cat "$state_file")
current_step=$(jq -r '.currentStep' "$state")

# 2. 执行任务步骤
case "$current_step" in
    "设计"*)
        execute_design_phase "$task_id"
        ;;
    "编写"*)
        execute_implementation_phase "$task_id"
        ;;
    "测试"*)
        execute_test_phase "$task_id"
        ;;
    "观察"*)
        execute_observation_phase "$task_id"
        ;;
esac

# 3. 更新进度
update_progress "$task_id"

# 4. 生成摘要
generate_summary "$task_id"
```

---

### 3. 任务验证器

**文件**: `scripts/task-validator.sh`

**功能**:
- 验证任务完成质量
- 检查防幻觉措施
- 确认文档完整性
- 决定是否可归档

**验证清单**:
```bash
#!/bin/bash
# task-validator.sh - 任务验证器

validate_task() {
    local task_id="$1"
    
    # 1. 检查状态文件
    check_state_file "$task_id"
    
    # 2. 检查输出文件
    check_output_files "$task_id"
    
    # 3. 检查防幻觉措施
    check_anti-hallucination "$task_id"
    
    # 4. 检查文档
    check_documentation "$task_id"
    
    # 5. 生成验证报告
    generate_validation_report "$task_id"
}
```

---

### 4. 异常处理机制

#### 4.1 任务卡死检测

**检测逻辑**:
```bash
# 检查任务是否超过预计时间 2 倍
expected_duration=$(jq -r '.expectedDuration' "$state_file")
actual_duration=$(($(date +%s) - $(date -d "$(jq -r '.startedAt' "$state_file")" +%s)))

if [ $actual_duration -gt $((expected_duration * 2)) ]; then
    # 标记为异常
    jq '.status = "stuck" | .stuckReason = "timeout"' "$state_file"
    
    # 发送告警
    send_alert "任务卡死：$task_id"
    
    # 等待用户确认
    wait_for_user_confirmation
fi
```

#### 4.2 上下文超限处理

**处理逻辑**:
```bash
# 检查当前上下文 token 使用
token_usage=$(get_token_usage)

if [ $token_usage -gt 160000 ]; then  # 80% of 200K
    # 生成摘要
    generate_summary
    
    # 清理上下文
    clear_context
    
    # 从摘要恢复
    restore_from_summary
fi
```

#### 4.3 AI 幻觉检测

**检测逻辑**:
```bash
# 检查结论是否有数据支撑
conclusion=$(jq -r '.conclusion' "$state_file")
data_support=$(jq -r '.dataSupport' "$state_file")

if [ -z "$data_support" ] || [ "$data_support" = "null" ]; then
    # 标记为可能幻觉
    jq '.flagged = true | .flagReason = "no_data_support"' "$state_file"
    
    # 要求用户确认
    request_user_confirmation
fi
```

---

## 📊 进度监控

### 每日监控

**时间**: 每日 08:00, 12:00, 18:00, 23:00

**检查项**:
- [ ] 当日任务是否开始
- [ ] 任务进度是否正常
- [ ] 是否有异常告警
- [ ] 是否需要用户确认

**监控脚本**: `scripts/daily-monitor.sh`

---

### 每周审查

**时间**: 每周一 09:00

**审查内容**:
1. 上周任务完成情况
2. 任务质量评估
3. 异常情况回顾
4. 本周计划调整

**审查模板**: `templates/weekly-review.md`

---

### 里程碑评审

**时间**: 每个 Milestone 完成后

**评审内容**:
1. Milestone 目标达成情况
2. 任务质量评估
3. 经验教训总结
4. 下阶段计划调整

**评审模板**: `templates/milestone-review.md`

---

## 🛡️ 质量保障

### 1. 防 AI 幻觉检查

**每个任务必须通过**:
- [ ] 结论有数据支撑
- [ ] 方案有对比分析
- [ ] 测试有实际案例
- [ ] 文档有用户确认

### 2. 防任务中止检查

**每个任务必须满足**:
- [ ] 状态文件已创建
- [ ] 心跳机制正常工作
- [ ] 检查点已保存
- [ ] 恢复流程已测试

### 3. 防上下文超限检查

**每个任务必须执行**:
- [ ] 任务前清理上下文
- [ ] 任务后生成摘要
- [ ] 中间文件已归档
- [ ] Token 使用已记录

---

## 📁 文件结构

```
/root/.openclaw/workspace/agents/master/
├── memory/config/
│   ├── task-plan-week-*.md          # 周任务计划
│   └── task-execution-guide.md      # 执行指南（本文档）
├── tasks/
│   ├── active/                       # 活跃任务
│   │   ├── P1-1-sop-enforcement.json
│   │   ├── P1-2-cost-tracking.json
│   │   └── ...
│   ├── completed/                    # 已完成任务
│   └── failed/                       # 失败任务
├── scripts/
│   ├── task-orchestrator.sh         # 任务编排器
│   ├── task-executor.sh             # 任务执行器
│   ├── task-validator.sh            # 任务验证器
│   └── daily-monitor.sh             # 日常监控
├── reports/
│   ├── daily/                        # 日报
│   ├── weekly/                       # 周报
│   └── milestone/                    # 里程碑报告
└── templates/
    ├── daily-report.md
    ├── weekly-review.md
    └── milestone-review.md
```

---

## 🚀 启动流程

### 第一步：准备阶段（2026-03-25）

- [x] ✅ 创建任务执行指南（本文档）
- [ ] 创建任务编排器脚本
- [ ] 创建任务执行器脚本
- [ ] 创建任务验证器脚本
- [ ] 创建监控脚本
- [ ] 创建报告模板

### 第二步：启动 M2（2026-03-26 08:00）

- [ ] 运行任务编排器
- [ ] 创建 P1-1 任务状态文件
- [ ] 发送任务开始通知
- [ ] 开始执行 P1-1

### 第三步：每日监控

- [ ] 08:00 检查任务状态
- [ ] 12:00 检查任务进度
- [ ] 18:00 检查任务完成情况
- [ ] 23:00 跨天暂停（如有需要）

### 第四步：周审查（2026-04-01 09:00）

- [ ] 审查 M2 完成情况
- [ ] 准备 M3 任务计划
- [ ] 调整优化执行流程

---

## 📝 总结

本计划通过以下机制确保 P0-1 到 P3-3 所有任务的自动化执行：

1. **防 AI 幻觉** - 强制验证、数据支撑、用户确认
2. **防任务中止** - 状态持久化、心跳机制、自动恢复
3. **防上下文超限** - 任务切片、摘要传递、上下文清理
4. **自动化执行** - 编排器、执行器、验证器、监控器

**预期效果**:
- ✅ 任务完成率 > 95%
- ✅ AI 幻觉发生率 < 1%
- ✅ 任务中止恢复时间 < 5 分钟
- ✅ 上下文超限自动处理

**下次审查**: 2026-04-01 09:00（M2 完成后）

---

**文档生成时间**: 2026-03-25 19:01  
**维护者**: Master Agent  
**状态**: ✅ 已创建，待启动 M2
