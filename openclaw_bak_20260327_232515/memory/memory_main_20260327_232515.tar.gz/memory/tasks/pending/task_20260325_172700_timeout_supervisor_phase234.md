# 任务记忆：超时监督机制阶段 2-4 规划

**任务 ID**: task_20260325_172700_timeout_supervisor_phase234  
**创建时间**: 2026-03-25T17:27:00+08:00  
**任务类型**: system_optimization  
**优先级**: medium  
**状态**: pending（用户确认继续观察，2026-04-01 评估）  
**用户决策**: 2026-03-26 确认继续观察阶段 1 效果  
**预计执行时间**: 2026-04-01 后（观察一周后评估）

---

## 📋 任务背景

超时监督机制改进分为 4 个阶段：

| 阶段 | 状态 | 执行时间 | 说明 |
|------|------|---------|------|
| **阶段 1** | ✅ 已完成 | 2026-03-25 17:18 | 动态阈值 + 进度检测 + 豁免机制 |
| **阶段 2** | ⏳ 待执行 | 待定 | 元数据增强（YAML front matter） |
| **阶段 3** | ⏳ 待执行 | 待定 | 多 Agent 协作感知 |
| **阶段 4** | ⏳ 待执行 | 待定 | 用户延期审批机制 |

**当前决策**: 先观察阶段 1 效果一周，再评估是否需要执行阶段 2-4。

---

## 🎯 阶段 2: 元数据增强

### 目标
为任务文件添加标准化元数据，支持更智能的超时评估。

### 需要完成的工作

| 序号 | 任务 | 说明 | 预计时间 | 影响范围 |
|------|------|------|---------|---------|
| 1 | 定义元数据格式 | YAML front matter 标准 | 10 分钟 | 无（仅文档） |
| 2 | 创建元数据模板 | 任务文件模板 | 10 分钟 | 低（新任务使用） |
| 3 | 修改超时监督脚本 | 读取元数据字段 | 10 分钟 | 无（向后兼容） |
| 4 | 更新任务创建流程 | Assistant Agent 添加元数据 | 10 分钟 | 低 |

### 元数据格式（待确认）

```yaml
---
task_id: task_20260325_170000_xxx
task_type: complex_analysis  # simple/medium/complex/batch/collaborative
expected_duration: 1800      # 预期时间（秒）
priority: normal             # low/normal/high/critical
agents_involved:             # 参与 Agent 列表
  - analysis
  - file-processor
created_at: 2026-03-25T17:00:00+08:00
last_updated_at: 2026-03-25T17:15:00+08:00
progress: 50%                # 当前进度
status: in_progress          # in_progress/waiting/completed/failed
timeout_exempt: false        # 是否豁免超时
---

# 任务内容
...
```

### 超时监督脚本改进点

```bash
# 从元数据读取预期时间
expected_duration=$(grep -oP "expected_duration: \K\d+" "$task_file")

# 从元数据读取任务类型
task_type=$(grep -oP "task_type: \K\w+" "$task_file")

# 从元数据读取参与 Agent
agents_involved=$(grep -A10 "agents_involved:" "$task_file" | grep -E "^\s*-" | sed 's/.*- //')

# 动态计算阈值（基于 expected_duration）
SOFT_TIMEOUT=$((expected_duration / 3))
IDLE_TIMEOUT=$((expected_duration / 2))
HARD_TIMEOUT=$expected_duration
```

### 执行前提条件
- [ ] 用户确认元数据格式
- [ ] 确认是否需要额外字段
- [ ] 确认阶段 1 效果不足以解决问题

### 预计效果
- 误杀率从 <5% 进一步降到 <2%
- 支持基于预期时间的智能阈值
- 支持任务优先级（高优先级任务更宽容）

### 相关文件
- `/root/.openclaw/workspace/agents/master/scripts/task-timeout-supervisor.sh` (修改)
- `/root/.openclaw/workspace/agents/assistant/scripts/task-listener.sh` (修改)
- `/root/.openclaw/workspace/memory/config/task-metadata-template.md` (新建)

---

## 🎯 阶段 3: 多 Agent 协作感知

### 目标
检测多 Agent 协作任务状态，避免因等待导致超时误杀。

### 需要完成的工作

| 序号 | 任务 | 说明 | 预计时间 | 影响范围 |
|------|------|------|---------|---------|
| 1 | 实现协作检测 | 读取 `agents_involved` 字段 | 20 分钟 | 无 |
| 2 | 检查 Agent 状态 | 查询各 Agent 任务目录 | 20 分钟 | 低 |
| 3 | 等待逻辑实现 | 有 Agent 进行中则等待 | 20 分钟 | 低 |
| 4 | 协作失败处理 | 有 Agent 失败则标记整体失败 | 20 分钟 | 中 |

### 协作检测逻辑

```bash
check_collaborative_task() {
    local task_file="$1"
    
    # 获取参与 Agent 列表
    local agents=$(grep -A10 "agents_involved:" "$task_file" | grep -E "^\s*-" | sed 's/.*- //')
    
    local completed_agents=0
    local total_agents=0
    local waiting_agents=""
    local failed_agents=""
    
    for agent in $agents; do
        total_agents=$((total_agents + 1))
        
        # 检查 Agent 任务状态
        local agent_task_file="/root/.openclaw/workspace/agents/$agent/memory/tasks/active/$(basename "$task_file")"
        
        if [ -f "$agent_task_file" ]; then
            if grep -q "status: completed" "$agent_task_file"; then
                completed_agents=$((completed_agents + 1))
            elif grep -q "status: failed" "$agent_task_file"; then
                failed_agents="$failed_agents $agent"
            elif grep -q "status: in_progress" "$agent_task_file"; then
                waiting_agents="$waiting_agents $agent"
            fi
        fi
    done
    
    # 判断整体状态
    if [ $completed_agents -eq $total_agents ]; then
        echo "all_agents_completed"
        return 0
    elif [ -n "$failed_agents" ]; then
        echo "failed:$failed_agents"
        return 1
    else
        echo "waiting:$waiting_agents"
        return 2  # 等待中，不标记超时
    fi
}
```

### 超时监督逻辑改进

```bash
# 检查是否为协作任务
if grep -q "agents_involved:" "$task_file"; then
    local collab_status=$(check_collaborative_task "$task_file")
    
    if [ "$collab_status" = "waiting:..." ]; then
        log "🤝 协作任务 $task_name 等待其他 Agent，跳过超时检查"
        continue  # 跳过超时检查
    elif [ "$collab_status" = "failed:..." ]; then
        log "❌ 协作任务 $task_name 有 Agent 失败，标记整体失败"
        # 移动到 failed 目录
    fi
fi
```

### 执行前提条件
- [ ] 阶段 2 已完成（元数据支持）
- [ ] 确认协作任务频率高，值得优化
- [ ] 各分支 Agent 任务结构对齐

### 预计效果
- 协作任务误杀率从 5% 降到 <1%
- 支持复杂的多 Agent 工作流
- 避免单个 Agent 延迟导致整体失败

### 相关文件
- `/root/.openclaw/workspace/agents/master/scripts/task-timeout-supervisor.sh` (修改)
- `/root/.openclaw/workspace/agents/*/memory/tasks/` (各 Agent 任务目录)

---

## 🎯 阶段 4: 用户延期审批机制

### 目标
为长任务提供用户延期审批通道，避免超时误杀。

### 需要完成的工作

| 序号 | 任务 | 说明 | 预计时间 | 影响范围 |
|------|------|------|---------|---------|
| 1 | 延期申请机制 | 任务可申请延期 | 15 分钟 | 无 |
| 2 | 飞书通知集成 | 发送延期审批请求 | 15 分钟 | 中（需要用户响应） |
| 3 | 审批记录审计 | 记录延期历史 | 15 分钟 | 无 |
| 4 | 延期到期处理 | 延期到期后恢复监督 | 15 分钟 | 低 |

### 延期审批流程

```
任务即将超时（剩余 5 分钟）
   ↓
自动发送飞书消息给用户
   ↓
用户回复"批准延期 2 小时"
   ↓
更新任务元数据（延期标记 + 到期时间）
   ↓
超时监督跳过该任务（直到延期到期）
   ↓
延期到期后，恢复超时监督
```

### 飞书消息模板

```
📋 任务延期审批请求

任务：批量备份 100GB 数据到 GitHub
当前进度：75%
预计完成时间：还需 1.5 小时
当前超时阈值：3 小时
申请延期：2 小时

请回复：
✅ 批准延期 2 小时
❌ 拒绝，按原阈值执行
⏰ 批准延期 X 小时（自定义）
```

### 延期记录格式

```yaml
# 任务文件元数据
extensions:
  - requested_at: 2026-03-25T19:00:00+08:00
    approved_at: 2026-03-25T19:02:00+08:00
    approved_by: user
    extension_hours: 2
    new_deadline: 2026-03-25T21:00:00+08:00
    reason: "批量备份数据量大，需要额外时间"
```

### 超时监督逻辑改进

```bash
# 检查是否有延期批准
if grep -q "extensions:" "$task_file"; then
    local deadline=$(grep -oP "new_deadline: \K[0-9T:+-]+" "$task_file" | tail -1)
    local now=$(date -Iseconds)
    
    if [ "$now" < "$deadline" ]; then
        log "⏰ 任务 $task_name 已批准延期至 $deadline，跳过超时检查"
        continue  # 跳过超时检查
    fi
fi
```

### 执行前提条件
- [ ] 阶段 2 已完成（元数据支持）
- [ ] 用户确认需要延期审批功能
- [ ] 飞书通知集成测试通过

### 预计效果
- 用户可主动控制长任务超时
- 避免重要任务被意外终止
- 提供审批审计记录

### 相关文件
- `/root/.openclaw/workspace/agents/master/scripts/task-timeout-supervisor.sh` (修改)
- `/root/.openclaw/extensions/feishu/` (飞书通知集成)
- `/root/.openclaw/workspace/agents/master/logs/task-extensions.log` (延期日志)

---

## 📊 执行评估标准

### 阶段 1 效果观察指标

在考虑执行阶段 2-4 前，先观察以下指标一周：

| 指标 | 目标值 | 当前值 | 测量方法 |
|------|-------|-------|---------|
| **误杀率** | <5% | 待观察 | 超时任务数 / 总任务数 |
| **用户投诉** | 0 次 | 0 次 | 飞书反馈 |
| **长任务完成率** | 100% | 待观察 | 批量/分析任务完成数 |
| **活跃任务保护率** | 100% | 待观察 | 有更新任务未被误杀 |

### 触发执行阶段 2-4 的条件

满足以下任一条件时，执行阶段 2-4：

- [ ] 误杀率 > 5%（一周统计）
- [ ] 用户投诉 > 0 次
- [ ] 有重要长任务被误杀
- [ ] 协作任务频率高且问题明显

### 不建议执行阶段 2-4 的情况

- [ ] 误杀率 < 2%（阶段 1 已足够）
- [ ] 无协作任务需求
- [ ] 无长任务延期需求
- [ ] 系统复杂度已足够，避免过度优化

---

## 📅 执行计划

### 观察期（2026-03-25 至 2026-04-01）

- [ ] 每日检查超时监督日志
- [ ] 记录误杀任务数量和类型
- [ ] 收集用户反馈
- [ ] 统计长任务完成情况

### 评估日（2026-04-01）

- [ ] 统计一周误杀率
- [ ] 评估阶段 1 效果
- [ ] 决定是否需要阶段 2-4
- [ ] 如需执行，更新本任务状态为 `active`

### 执行窗口（2026-04-01 至 2026-04-07）

- [ ] 执行阶段 2（元数据增强）
- [ ] 执行阶段 3（协作感知）
- [ ] 执行阶段 4（延期审批）
- [ ] 验证功能正常

---

## 📁 相关文件索引

### 当前文件
- `/root/.openclaw/workspace/agents/master/memory/tasks/pending/task_20260325_172700_timeout_supervisor_phase234.md` (本文件)

### 阶段 1 相关文件
- `/root/.openclaw/workspace/agents/master/scripts/task-timeout-supervisor.sh` (已优化)
- `/root/.openclaw/workspace/agents/master/reports/timeout-supervisor-phase1-complete.md` (完成报告)
- `/root/.openclaw/workspace/agents/master/reports/timeout-supervisor-improvement-proposal.md` (完整方案)
- `/root/.openclaw/workspace/agents/master/logs/task-timeout.log` (执行日志)

### 待创建文件（阶段 2-4）
- `/root/.openclaw/workspace/memory/config/task-metadata-template.md` (元数据模板)
- `/root/.openclaw/workspace/agents/master/logs/task-extensions.log` (延期日志)
- `/root/.openclaw/workspace/agents/master/scripts/collaborative-task-checker.sh` (协作检测)

---

## 🔄 任务状态流转

```
pending (当前状态)
   ↓
[2026-04-01 评估]
   ↓
active (如需执行) → in_progress → completed
   ↓
cancelled (如不需要)
```

### 状态更新记录

| 时间 | 状态 | 说明 |
|------|------|------|
| 2026-03-25 17:27 | pending | 创建任务记忆，暂不执行 |
| 待定 | active/cancelled | 等待 2026-04-01 评估后决定 |

---

## 📝 恢复执行指南

如果未来需要执行阶段 2-4，按以下步骤恢复：

### 1. 检索任务记忆
```bash
# 搜索相关任务记忆
memory_search "超时监督 阶段 2"

# 或直接读取本文件
read /root/.openclaw/workspace/agents/master/memory/tasks/pending/task_20260325_172700_timeout_supervisor_phase234.md
```

### 2. 评估当前状态
```bash
# 检查阶段 1 效果
tail -100 /root/.openclaw/workspace/agents/master/logs/task-timeout.log

# 统计误杀率
cat /tmp/task-timeout-alerts.json | jq '.alerts | length'
```

### 3. 决定执行阶段
- 如需执行阶段 2 → 参考"阶段 2: 元数据增强"章节
- 如需执行阶段 3 → 参考"阶段 3: 多 Agent 协作感知"章节
- 如需执行阶段 4 → 参考"阶段 4: 用户延期审批机制"章节

### 4. 更新任务状态
```bash
# 更新本任务状态
edit task_20260325_172700_timeout_supervisor_phase234.md
# 状态：pending → active
# 更新时间：[当前时间]
```

---

## 📞 联系人

**任务负责人**: Master Agent  
**审批人**: 俞斌  
**创建日期**: 2026-03-25  
**下次审查**: 2026-04-01

---

**备注**: 本任务记忆用于保存阶段 2-4 的详细规划，防止未来需要执行时遗忘。阶段 1 已足够解决 80% 的超时误杀问题，建议先观察一周再决定是否需要进一步优化。
