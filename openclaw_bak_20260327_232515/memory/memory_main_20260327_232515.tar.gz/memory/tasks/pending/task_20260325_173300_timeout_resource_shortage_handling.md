# 任务记忆：模型资源不足导致的超时处理方案

**任务 ID**: task_20260325_173300_timeout_resource_shortage_handling  
**创建时间**: 2026-03-25T17:33:00+08:00  
**任务类型**: system_optimization  
**优先级**: medium  
**状态**: pending（需要评估和实施）  
**依赖**: 阶段 1 已完成，可与阶段 2-4 并行实施

---

## 📋 问题背景

当前超时监督机制无法区分：
- **任务复杂导致超时**（正常，应标记失败）
- **模型资源不足导致超时**（异常，应等待或降级）

**风险**:
- 模型 Rate Limit 时任务被误杀
- 模型队列拥堵时工作中断
- Fallback 链耗尽时任务失败

---

## 🔍 资源不足检测方案

### 方案 A: 日志分析检测（推荐）⭐

#### 原理
分析 Gateway 日志和任务日志，检测模型资源问题。

#### 检测指标

| 指标 | 检测方法 | 阈值 | 说明 |
|------|---------|------|------|
| **Rate Limit** | 检测 429 错误 | 5 分钟内>3 次 | API 限流 |
| **模型失败** | 检测 FailoverError | 连续>2 次 | 模型切换 |
| **响应时间** | 检测 API 耗时 | >30 秒 | 响应过慢 |
| **队列长度** | 检测 pending 任务数 | >10 个 | 队列拥堵 |

#### 实现代码

```bash
# 检测 Rate Limit
check_rate_limit() {
    local task_id="$1"
    local gateway_log="/root/.openclaw/logs/gateway.log"
    
    # 统计最近 5 分钟该任务的 429 错误
    local rate_limit_count=$(grep -c "429\|rate limit" "$gateway_log" 2>/dev/null || echo 0)
    
    if [ $rate_limit_count -gt 3 ]; then
        echo "rate_limit_detected"
        return 0
    fi
    
    echo "normal"
    return 1
}

# 检测模型失败
check_model_failures() {
    local task_id="$1"
    local gateway_log="/root/.openclaw/logs/gateway.log"
    
    # 统计最近 10 分钟 FailoverError
    local failover_count=$(grep -c "FailoverError" "$gateway_log" 2>/dev/null || echo 0)
    
    if [ $failover_count -gt 2 ]; then
        echo "model_failover_detected"
        return 0
    fi
    
    echo "normal"
    return 1
}

# 检测任务响应时间
check_response_time() {
    local task_file="$1"
    
    # 从任务日志中读取平均响应时间
    local avg_response_time=$(grep -oP "response_time: \K\d+" "$task_file" 2>/dev/null | tail -1 || echo "0")
    
    if [ $avg_response_time -gt 30000 ]; then  # 30 秒
        echo "slow_response_detected"
        return 0
    fi
    
    echo "normal"
    return 1
}
```

---

### 方案 B: 模型状态 API（需要开发）

#### 原理
创建模型状态监控 API，实时查询模型可用性。

#### 实现

```bash
# 创建模型状态检查脚本
cat > /root/.openclaw/scripts/check-model-status.sh << 'EOF'
#!/bin/bash
# 检查模型可用性

MODELS=(
    "qwencode/qwen3.5-plus"
    "qwencode/qwen3-max-2026-01-23"
    "openrouter/gpt-4o"
)

for model in "${MODELS[@]}"; do
    # 调用模型健康检查端点
    status=$(curl -s -o /dev/null -w "%{http_code}" \
        -H "Authorization: Bearer $OPENCLAW_TOKEN" \
        "http://127.0.0.1:15527/api/v1/models/$model/health")
    
    if [ "$status" = "200" ]; then
        echo "$model: ✅ available"
    elif [ "$status" = "429" ]; then
        echo "$model: ⚠️ rate_limited"
    else
        echo "$model: ❌ unavailable ($status)"
    fi
done
EOF
```

---

## 🎯 超时监督改进方案

### 改进 1: 资源不足时跳过超时检查

```bash
# 在超时监督脚本中添加
check_resource_shortage() {
    local task_file="$1"
    
    # 检测 Rate Limit
    local rate_limit_status=$(check_rate_limit)
    if [ "$rate_limit_status" = "rate_limit_detected" ]; then
        log "⚠️  检测到 Rate Limit，任务 $task_name 跳过超时检查"
        return 0  # 跳过
    fi
    
    # 检测模型失败
    local model_failure_status=$(check_model_failures)
    if [ "$model_failure_status" = "model_failover_detected" ]; then
        log "⚠️  检测到模型频繁切换，任务 $task_name 跳过超时检查"
        return 0  # 跳过
    fi
    
    # 检测响应时间
    local response_status=$(check_response_time "$task_file")
    if [ "$response_status" = "slow_response_detected" ]; then
        log "⚠️  检测到模型响应过慢，任务 $task_name 跳过超时检查"
        return 0  # 跳过
    fi
    
    return 1  # 正常，继续超时检查
}

# 主检查逻辑
if check_resource_shortage "$task_file"; then
    # 记录资源告警
    echo "{\"timestamp\":\"$(date -Iseconds)\",\"type\":\"resource_shortage\",\"task\":\"$task_name\"}" >> /tmp/resource-alerts.json
    continue  # 跳过超时检查
fi
```

---

### 改进 2: 资源不足时自动降级

```bash
# 检测到资源不足时，尝试降级策略
handle_resource_shortage() {
    local task_file="$1"
    
    # 读取当前使用的模型
    local current_model=$(grep -oP "model: \K[\w/.-]+" "$task_file" 2>/dev/null || echo "")
    
    # 如果当前模型不可用，切换到备用模型
    if [ "$current_model" = "qwencode/qwen3.5-plus" ]; then
        log "🔄 检测到主模型资源不足，降级到 qwen3-max"
        sed -i 's/model: qwencode\/qwen3.5-plus/model: qwencode\/qwen3-max-2026-01-23/' "$task_file"
        
        # 通知 Assistant Agent 重新调度
        echo "{\"action\":\"model_fallback\",\"task\":\"$task_name\",\"from\":\"qwen3.5-plus\",\"to\":\"qwen3-max\"}" >> /tmp/task-actions.json
    fi
}
```

---

### 改进 3: 资源不足时发送告警

```bash
# 发送资源告警到飞书
send_resource_alert() {
    local alert_type="$1"
    local task_name="$2"
    
    case "$alert_type" in
        "rate_limit")
            message="⚠️  模型 Rate Limit 告警\n\n任务：$task_name\n状态：API 调用被限流\n建议：等待 5 分钟后重试"
            ;;
        "model_failover")
            message="⚠️  模型频繁切换告警\n\n任务：$task_name\n状态：Fallback 链耗尽\n建议：检查模型配置"
            ;;
        "slow_response")
            message="⚠️  模型响应过慢告警\n\n任务：$task_name\n状态：平均响应时间>30 秒\n建议：切换到轻量模型"
            ;;
    esac
    
    # 发送飞书消息
    # (使用 feishu API)
    log "📱 已发送资源告警：$alert_type"
}
```

---

### 改进 4: 资源不足时暂停计时

```bash
# 在任务元数据中添加暂停标记
pause_timeout_timer() {
    local task_file="$1"
    local reason="$2"
    
    # 添加暂停标记
    cat >> "$task_file" << EOF

---
timeout_paused:
  paused_at: $(date -Iseconds)
  reason: $reason
  paused_by: timeout_supervisor
EOF
    
    log "⏸️  任务 $task_name 超时计时已暂停（原因：$reason）"
}

# 恢复超时计时
resume_timeout_timer() {
    local task_file="$1"
    
    # 移除暂停标记
    sed -i '/^timeout_paused:/,/^---$/d' "$task_file"
    
    log "▶️  任务 $task_name 超时计时已恢复"
}
```

---

## 📊 完整超时监督流程（含资源检测）

```
开始超时检查
   ↓
检查任务是否有进展（5 分钟内更新）
   ↓
有进展 → 跳过 ✅
   ↓
无进展
   ↓
检查是否资源不足
   ├─ Rate Limit 检测 → 检测到 → 跳过 + 告警 ⚠️
   ├─ 模型失败检测 → 检测到 → 跳过 + 告警 ⚠️
   ├─ 响应时间检测 → 检测到 → 跳过 + 告警 ⚠️
   ↓
资源正常
   ↓
获取动态阈值（阶段 1）
   ↓
检查是否超时
   ├─ SOFT → 记录日志 📝
   ├─ IDLE → 发送提醒 ⚠️
   └─ HARD → 标记失败 ❌
```

---

## 🎯 实施计划

### 阶段 1: 资源检测（预计 30 分钟）

| 任务 | 说明 | 预计时间 |
|------|------|---------|
| 1. 实现 Rate Limit 检测 | 分析 Gateway 日志 | 10 分钟 |
| 2. 实现模型失败检测 | 检测 FailoverError | 10 分钟 |
| 3. 实现响应时间检测 | 分析任务日志 | 10 分钟 |

### 阶段 2: 超时监督集成（预计 20 分钟）

| 任务 | 说明 | 预计时间 |
|------|------|---------|
| 1. 集成资源检测 | 添加到超时监督脚本 | 10 分钟 |
| 2. 添加跳过逻辑 | 资源不足时跳过检查 | 5 分钟 |
| 3. 添加告警逻辑 | 发送资源告警 | 5 分钟 |

### 阶段 3: 自动降级（预计 30 分钟）

| 任务 | 说明 | 预计时间 |
|------|------|---------|
| 1. 实现模型切换 | 检测不可用时切换 | 15 分钟 |
| 2. 实现暂停计时 | 资源不足时暂停 | 15 分钟 |

---

## 📋 测试场景

### 测试 1: Rate Limit 场景

```bash
# 模拟 429 错误
echo "429 Too Many Requests" >> /root/.openclaw/logs/gateway.log

# 运行超时监督
./task-timeout-supervisor.sh

# 预期结果
⚠️  检测到 Rate Limit，任务 xxx 跳过超时检查
```

### 测试 2: 模型失败场景

```bash
# 模拟 FailoverError
echo "FailoverError: No API key found" >> /root/.openclaw/logs/gateway.log

# 运行超时监督
./task-timeout-supervisor.sh

# 预期结果
⚠️  检测到模型频繁切换，任务 xxx 跳过超时检查
```

### 测试 3: 正常超时场景

```bash
# 无资源问题，任务确实超时

# 运行超时监督
./task-timeout-supervisor.sh

# 预期结果
❌ HARD TIMEOUT: xxx (正常标记失败)
```

---

## 📊 预期效果

| 指标 | 当前 | 实施后 | 改进 |
|------|------|-------|------|
| **Rate Limit 误杀率** | 100% | 0% | ✅ 100% |
| **模型失败误杀率** | 100% | 0% | ✅ 100% |
| **响应慢误杀率** | 50% | 0% | ✅ 100% |
| **资源告警及时性** | 无 | <1 分钟 | ✅ 新增 |
| **自动降级成功率** | 无 | >80% | ✅ 新增 |

---

## ⚠️ 注意事项

### 1. 避免滥用跳过机制

资源不足检测应该：
- 基于客观指标（429 错误、FailoverError）
- 有明确的阈值（5 分钟>3 次）
- 记录详细的跳过日志

### 2. 防止无限等待

即使检测到资源不足，也应该：
- 设置最大等待时间（如 2 小时）
- 超过最大等待时间后标记失败
- 发送告警通知用户

### 3. 降级策略谨慎使用

自动降级应该：
- 仅在同等级或更高级模型不可用时
- 记录降级历史
- 允许用户配置降级链

---

## 📁 相关文件

### 待修改文件
- `/root/.openclaw/workspace/agents/master/scripts/task-timeout-supervisor.sh` (添加资源检测)

### 待创建文件
- `/root/.openclaw/workspace/agents/master/scripts/check-model-status.sh` (模型状态检查)
- `/root/.openclaw/workspace/agents/master/scripts/resource-shortage-detector.sh` (资源检测)

### 日志文件
- `/root/.openclaw/logs/gateway.log` (分析对象)
- `/root/.openclaw/workspace/agents/master/logs/task-timeout.log` (超时日志)
- `/tmp/resource-alerts.json` (资源告警)

---

## 📅 执行建议

### 优先级评估

| 场景 | 频率 | 影响 | 优先级 |
|------|------|------|-------|
| Rate Limit | 低（偶尔） | 中（任务失败） | 🟡 中 |
| 模型失败 | 低（偶尔） | 高（工作中断） | 🟡 中 |
| 响应慢 | 中（常见） | 中（任务延迟） | 🟢 高 |

### 建议执行时间

- **立即执行**: 资源检测集成（阶段 1+2）
- **观察后执行**: 自动降级（阶段 3）

### 执行条件

满足以下任一条件时执行：
- [ ] 发生 1 次以上资源不足导致的误杀
- [ ] 用户反馈模型响应慢导致任务失败
- [ ] Gateway 日志中出现频繁 429 错误

---

**创建者**: Master Agent  
**创建日期**: 2026-03-25 17:33  
**状态**: pending（待评估执行）  
**下次审查**: 2026-04-01（与阶段 2-4 一起评估）
