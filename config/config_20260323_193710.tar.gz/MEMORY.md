# MEMORY.md - 长期记忆

_记录重要的决策、教训和上下文，确保会话间的连续性_

---

## 用户信息

- **姓名：** 俞斌
- **称呼：** 俞斌
- **时区：** GMT+8 (中国标准时间)
- **主要访问方式：** 腾讯云终端
- **Feishu 用户 ID：** `ou_b46467cc1563871aab03ac1d4f9216f0`

---

## 系统配置

### OpenClaw 配置要点

1. **gateway.bind 与 gateway.tailscale.mode 的关系**
   - `bind: "tailnet"` 表示 Gateway 监听 Tailscale IP
   - `tailscale.mode` 控制 Tailscale Serve/Funnel 功能（独立配置）
   - 两者必须同时配置，否则验证失败
   - 有效值：`bind` = loopback/lan/tailnet/auto/custom
   - 有效值：`tailscale.mode` = off/serve/funnel

2. **Tailscale 国内不可用**
   - 用户在中国境内，Tailscale 无法访问
   - 解决方案：使用 `bind: "lan"` + 防火墙 + token 认证

### 安全配置

| 组件 | 状态 | 说明 |
|------|------|------|
| firewalld | ✅ 运行中 | 端口规则已配置 |
| sshguard | ✅ 运行中 | 自动封禁 SSH 攻击者 |
| OOM 保护 | ✅ 已配置 | `oom_score_adj = -500` |
| Health Guardian | ✅ 运行中 | Gateway 健康监控 |

---

## 重要教训

### 1. 配置修改时序问题

**问题：** 在消息处理过程中执行 Gateway 重启，导致回复丢失

**教训：** 重启服务前应等待当前任务完成，或实现任务恢复机制

### 2. 手动编辑配置的风险

**问题：** 用户删除 `tailscale` 配置块导致 Gateway 无法启动

**教训：** 
- 配置项之间存在隐式依赖
- 删除配置前应了解其作用
- 建议通过 `openclaw configure` 向导修改配置

### 3. 服务重启导致消息中断

**问题：** 创建新服务触发 Gateway 重启，正在处理的回复丢失

**教训：** 
- 避免在用户消息处理过程中重启服务
- 考虑实现"优雅关闭"机制

---

## 服务和脚本位置

| 名称 | 路径 |
|------|------|
| OpenClaw 配置 | `/root/.openclaw/openclaw.json` |
| Health Guardian | `~/.openclaw/workspace/agents/master/health-guardian/scripts/health_guardian.sh` |
| Arch Guardian | `~/.openclaw/workspace/agents/master/guardian3.0/scripts/architectural_protection.sh` |
| OOM 配置 | `~/.config/systemd/user/openclaw-gateway.service.d/override.conf` |
| 日志目录 | `/root/.openclaw/logs/` |

---

## 待办事项

- [x] ~~决定是否保留 archguardian 服务~~ → 已禁用（功能与 health-guardian 重叠，且误报）
- [ ] 完成身份确认对话（IDENTITY.md）
- [ ] 考虑添加心跳检查任务

---

---

## 系统级变更记录

### Health Guardian 服务 (2026-03-23 新增)

**脚本位置：** `/root/.openclaw/workspace/agents/master/health-guardian/scripts/health_guardian.sh`

**systemd 服务：** `openclaw-health-guardian.service`

**功能：**
- Gateway 进程监控（systemctl is-active）
- 端口监听检测（netstat 18789）
- WebSocket 健康检查（curl /health）
- 配置有效性验证（jq 解析 openclaw.json）
- Feishu 连接状态检测
- 内存使用监控
- 自动修复（带 300 秒冷却期）
- 日志轮转（最大 10MB）
- 配置备份

**命令：**
```bash
# 守护模式
health_guardian.sh daemon

# 单次检查
health_guardian.sh check

# 查看状态
health_guardian.sh status

# 执行修复
health_guardian.sh fix

# 重置冷却期
health_guardian.sh reset-cooldown
```

**配置参数：**
- `MONITOR_INTERVAL=60` - 检查间隔
- `MAX_FAILURES=3` - 触发修复的失败次数
- `COOLDOWN_PERIOD=300` - 冷却期（秒）
- `LOG_MAX_SIZE=10485760` - 日志最大 10MB
- `AUTO_FIX=true` - 自动修复开关

**日志文件：** `/root/.openclaw/logs/health-guardian.log`

**状态文件：** `/root/.openclaw/health-guardian-state.json`

**备份目录：** `/root/.openclaw/backups/`

### OOM 保护配置 (2026-03-23 新增)

**配置文件：** `~/.config/systemd/user/openclaw-gateway.service.d/override.conf`

**配置内容：**
```ini
[Service]
OOMScoreAdjust=-500
```

**效果：** Gateway 进程的 oom_score_adj 从 100 降到 -500，内存压力时更不易被杀

### Arch Guardian 服务 (2026-03-23 禁用)

**原因：** 
- 功能与 health-guardian 重叠
- 误报 `/root/.openclaw/agents/` 为非法目录（实际是 OpenClaw 正常使用的路径）

**服务状态：** disabled, inactive

## 更新日志

- **2026-03-23：** 创建 MEMORY.md，记录 OpenClaw 配置修复和安全加固工作
- **2026-03-23：** 添加 Agent 架构规则（不可变更）

---

## Agent 架构规则（不可变更）

**生效日期**: 2026-03-23  
**状态**: ✅ **永久生效** - 未经用户明确同意，不得新增、删除、修改

### 架构定义

```
主控 agent (master) - 老板
    │
    ├── 助手 agent (assistant) - 秘书
    │       │
    │       └── 可调用所有分支 agent
    │
    ├── 分析 agent (analysis) - 分析部门
    ├── 备份 agent (backup) - 备份部门
    ├── 监控 agent (monitoring) - 监控部门
    ├── 服务器维护 agent (server-maintenance) - 运维部门
    ├── 客服 agent (customer-service) - 客服部门
    ├── 数据库管理 agent (database-manager) - 数据部门
    ├── 文件处理 agent (file-processor) - 文档部门
    ├── 记忆管理 agent (memory-manager) - 记忆部门
    └── 其他分支 agent - 按需扩展
```

### 调用规则

1. **主控 agent (master)**: 可以调用所有 agent
2. **助手 agent (assistant)**: 根据主控命令，可调用所有分支 agent
3. **分支 agent**: 
   - 只负责自己的专业领域（低内聚）
   - 需要其他能力时调用其他 agent（高耦合）
   - 都不符合时告知主控 agent

### 禁止事项

- ❌ 不得新增 agent 未经用户同意
- ❌ 不得删除 agent 未经用户同意
- ❌ 不得修改 agent 架构未经用户同意
- ❌ 不存在 "main" agent（workspace/main 是工作目录，不是 agent）
---

## gstack 安装记录 (2026-03-23)

**安装位置：** `~/.claude/skills/gstack/`

**安装命令：**
```bash
git clone https://github.com/garrytan/gstack.git ~/.claude/skills/gstack
cd ~/.claude/skills/gstack && ./setup
```

**映射配置：** `/root/.openclaw/workspace/memory/config/gstack-agent-mapping.md`

**设计哲学：** `/root/.openclaw/workspace/memory/config/builder-ethos.md`

**可用技能：** 26 个（office-hours, plan-ceo-review, review, qa, ship, retro 等）

---

## 消息队列配置 (2026-03-23 新增)

**配置位置：** `channels.feishu.accounts.default`

**配置内容：**
```json
{
  "debounceMs": 3000,
  "messageQueue": {
    "enabled": true,
    "mergeDelayMs": 3000,
    "maxBatchSize": 10
  }
}
```

**效果：**
- 3 秒内连续发送的消息合并为一条处理
- 超过 3 秒未收到新消息则开始处理
- 最多合并 10 条消息
