#!/bin/bash

# Enhanced Task Router for Master Agent
# 支持智能协作：master 与 assistant 共同处理复杂任务

# 配置
MASTER_QUEUE="/tmp/agent_queue.json"
ASSISTANT_QUEUE="/tmp/assistant_queue.json"
TASK_CLASSIFIER="/root/.openclaw/workspace/agents/master/scripts/task-classifier.sh"
MASTER_TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/master/tasks"
ASSISTANT_TASKS_DIR="/root/.openclaw/workspace/agents/assistant/memory/assistant/tasks"
RESULTS_QUEUE="/tmp/agent_results.json"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }
log_debug() { echo -e "${BLUE}[DEBUG]${NC} $1"; }

# 检查参数
if [ $# -lt 2 ]; then
    echo "Usage: $0 <task_description> <task_title> [task_metadata_json]"
    exit 1
fi

TASK_DESC="$1"
TASK_TITLE="$2"
TASK_METADATA="${3:-}"

# 生成任务ID和文件路径
generate_task_id() {
    local title_slug=$(echo "$1" | sed 's/[^a-zA-Z0-9]/_/g' | head -c 50)
    echo "task_$(date +%Y%m%d_%H%M%S)_${title_slug}"
}

# 创建任务文件（通用函数）
create_task_file() {
    local target_dir="$1"
    local task_id="$2"
    local title="$3"
    local desc="$4"
    local extra_content="$5"

    local task_file="${target_dir}/${task_id}.md"

    cat > "$task_file" <<EOF
# 任务 - $title

**创建时间**: $(date '+%Y-%m-%d %H:%M:%S')  
**任务ID**: $task_id  
**来源**: master agent (智能路由)  
**独有标识**: $(uuidgen 2>/dev/null || echo "UUID_UNAVAILABLE")

## 原始任务

**标题**: $title  
**描述**: $desc

## 元数据
EOF

    # 附加元数据（如果提供且为有效 JSON）
    if [ -n "$TASK_METADATA" ] && echo "$TASK_METADATA" | jq -e . >/dev/null 2>&1; then
        echo "\`\`\`json" >> "$task_file"
        echo "$TASK_METADATA" >> "$task_file"
        echo "\`\`\`" >> "$task_file"
    else
        echo "无附加元数据" >> "$task_file"
    fi

    # 附加额外内容（如子任务说明）
    if [ -n "$extra_content" ]; then
        echo "" >> "$task_file"
        echo "$extra_content" >> "$task_file"
    fi

    echo "$task_file"
}

# 计算 master 当前负载
calculate_master_load() {
    # 统计 master 正在处理的任务数
    local active_count=0
    if [ -d "${MASTER_TASKS_DIR}/active" ]; then
        active_count=$(find "${MASTER_TASKS_DIR}/active" -name "task_*.md" 2>/dev/null | wc -l)
    fi

    # 统计最近 1 小时内创建的任务
    local recent_count=0
    if [ -d "${MASTER_TASKS_DIR}" ]; then
        recent_count=$(find "${MASTER_TASKS_DIR}" -name "task_*.md" -mmin -60 2>/dev/null | wc -l)
    fi

    # 负载分数 (0-100)
    # active_count 权重 70%, recent_count 权重 30%
    local load_score=$(( active_count * 7 + recent_count * 3 ))

    # 上限 100
    if [ $load_score -gt 100 ]; then
        load_score=100
    fi

    echo "$load_score|active:$active_count|recent:$recent_count"
}

# 决定协作策略
decide_collaboration_strategy() {
    local complexity="$1"
    local load_score="$2"

    # 阈值配置
    local HIGH_LOAD_THRESHOLD=70
    local MEDIUM_LOAD_THRESHOLD=30

    if [ "$complexity" = "COMPLEX" ]; then
        if [ $load_score -ge $HIGH_LOAD_THRESHOLD ]; then
            # 高负载 + 复杂任务 → 全部转发
            echo "forward_all"
        elif [ $load_score -ge $MEDIUM_LOAD_THRESHOLD ]; then
            # 中等负载 + 复杂任务 → 协作模式
            echo "collaborate"
        else
            # 低负载 + 复杂任务 → 尝试自处理，但可部分转发
            echo "try_self_then_forward"
        fi
    else
        # 非复杂任务总是自处理（除非负载极高）
        if [ $load_score -ge $HIGH_LOAD_THRESHOLD ]; then
            echo "forward_if_possible"
        else
            echo "self_handle"
        fi
    fi
}

# 拆分协作任务（将复杂任务拆分为 master 和 assistant 子任务）
split_collaborative_task() {
    local task_id="$1"
    local title="$2"
    local desc="$3"

    log_info "开始拆分协作任务: $title"

    # 生成唯一标识
    local base_id="$task_id"
    local master_subtask_id="${base_id}_M"
    local assistant_subtask_id="${base_id}_A"
    local parent_task_id="$task_id"

    # 1. 提取任务中的可协作部分（基于关键字）
    # Master 擅长: 数据收集、状态检查、简单执行、文档整理、结果汇总
    # Assistant 擅长: 深度分析、复杂推理、代码生成、创意写作、多步骤规划

    # 这里使用关键词匹配，未来可用 LLM 更智能拆分
    local master_parts=()
    local assistant_parts=()
    local remaining_desc="$desc"

    # 简单启发式拆分（可扩展）
    if echo "$desc" | grep -qi "分析\|分析\|推理\|策略\|规划\|设计"; then
        # 分析型任务 → assistant 主导
        master_parts+=("收集相关数据和上下文信息")
        master_parts+=("整理初步结果并汇总")
        assistant_parts+=("执行深度分析和推理")
        assistant_parts+=("生成详细报告或方案")
    elif echo "$desc" | grep -qi "开发\|编码\|实现\|构建\|部署"; then
        # 开发型任务 → assistant 主导编码，master 负责环境准备
        master_parts+=("准备开发环境和依赖")
        master_parts+=("验证部署和测试")
        assistant_parts+=("编写核心代码")
        assistant_parts+=("实现功能模块")
    elif echo "$desc" | grep -qi "文档\|报告\|总结\|整理"; then
        # 文档型任务 → 可并行
        master_parts+=("收集原始材料和数据")
        assistant_parts+=("撰写文档内容")
        master_parts+=("格式化并发布文档")
    else
        # 默认协作模式
        master_parts+=("收集信息和前置准备")
        master_parts+=("执行初步检查和验证")
        assistant_parts+=("处理核心复杂逻辑")
        master_parts+=("汇总结果并反馈")
    fi

    # 2. 构建子任务描述
    local master_desc="协作任务 - Master 子任务\n\n**父任务**: $title\n\n**你的职责**:\n"
    for part in "${master_parts[@]}"; do
        master_desc+="- $part\n"
    done
    master_desc+="\n**完整父任务描述**: $desc"

    local assistant_desc="协作任务 - Assistant 子任务\n\n**父任务**: $title\n\n**你的职责**:\n"
    for part in "${assistant_parts[@]}"; do
        assistant_desc+="- $part\n"
    done
    assistant_desc+="\n**完整父任务描述**: $desc"

    # 3. 创建主任务跟踪文件（用于合并结果）
    local parent_task_file="${MASTER_TASKS_DIR}/collaborative/${parent_task_id}.md"
    mkdir -p "$(dirname "$parent_task_file")"

    cat > "$parent_task_file" <<EOF
# 协作主任务 - $title

**主任务ID**: $parent_task_id  
**创建时间**: $(date '+%Y-%m-%d %H:%M:%S')  
**协作模式**: master + assistant

## 子任务分配

- **Master 子任务**: ${master_subtask_id}
- **Assistant 子任务**: ${assistant_subtask_id}

## 子任务状态

| 子任务 | 状态 | 完成时间 | 结果 |
|--------|------|----------|------|
| Master | ⏳ 待处理 | - | - |
| Assistant | ⏳ 待处理 | - | - |

## 父任务描述

$desc

---
*此文件用于跟踪协作进度，完成后由 master 汇总*
EOF

    # 4. 创建 Master 子任务（自处理，放入 active 队列）
    local master_task_file
    master_task_file=$(create_task_file \
        "${MASTER_TASKS_DIR}/active" \
        "$master_subtask_id" \
        "[协作] $title (Master部分)" \
        "$master_desc" \
        "## 协作信息\n- 类型: master_subtask\n- 父任务ID: $parent_task_id\n- 协作伙伴: assistant\n- 期望输出: 初步数据/准备结果")

    log_info "Master 子任务已创建: $master_task_file"

    # 5. 创建 Assistant 子任务（转发给 assistant）
    local assistant_task_content="## 协作信息\n- 类型: assistant_subtask\n- 父任务ID: $parent_task_id\n- 协作伙伴: master\n- 期望输出: 深度分析/核心产出"

    local assistant_task_file
    assistant_task_file=$(create_task_file \
        "$ASSISTANT_TASKS_DIR" \
        "$assistant_subtask_id" \
        "[协作] $title (Assistant部分)" \
        "$assistant_desc" \
        "$assistant_task_content")

    log_info "Assistant 子任务已创建并转发: $assistant_task_file"

    # 6. 输出路由结果
    echo "COLLABORATION_MODE=true"
    echo "PARENT_TASK_ID=$parent_task_id"
    echo "MASTER_SUBTASK=$master_subtask_id"
    echo "MASTER_SUBTASK_FILE=$master_task_file"
    echo "ASSISTANT_SUBTASK=$assistant_subtask_id"
    echo "ASSISTANT_SUBTASK_FILE=$assistant_task_file"
    echo "ROUTED_TO=master"  # master 仍需要处理自己的子任务

    return 0
}

# 监控协作任务完成状态
monitor_collaboration() {
    local parent_task_id="$1"
    local parent_file="${MASTER_TASKS_DIR}/collaborative/${parent_task_id}.md"

    log_info "开始监控协作任务: $parent_task_id"

    local max_wait_minutes=60
    local check_interval=30
    local elapsed=0

    while [ $elapsed -lt $((max_wait_minutes * 60)) ]; do
        # 检查两个子任务是否都完成
        local master_done=false
        local assistant_done=false

        # 检查 master 子任务
        if find "${MASTER_TASKS_DIR}/completed" -name "${parent_task_id}_M*.md" 2>/dev/null | grep -q .; then
            master_done=true
        fi

        # 检查 assistant 子任务
        if find "${ASSISTANT_TASKS_DIR}/completed" -name "${parent_task_id}_A*.md" 2>/dev/null | grep -q .; then
            assistant_done=true
        fi

        if [ "$master_done" = true ] && [ "$assistant_done" = true ]; then
            log_info "协作任务全部完成: $parent_task_id"
            return 0
        fi

        sleep $check_interval
        elapsed=$((elapsed + check_interval))
    done

    log_warn "协作任务超时: $parent_task_id (等待 $max_wait_minutes 分钟)"
    return 1
}

# 汇总协作结果
aggregate_collaboration_results() {
    local parent_task_id="$1"
    local parent_file="${MASTER_TASKS_DIR}/collaborative/${parent_task_id}.md"

    log_info "汇总协作结果: $parent_task_id"

    # 查找子任务结果文件
    local master_result=$(find "${MASTER_TASKS_DIR}/completed" -name "${parent_task_id}_M*_result.md" 2>/dev/null | head -1)
    local assistant_result=$(find "${ASSISTANT_TASKS_DIR}/completed" -name "${parent_task_id}_A*_result.md" 2>/dev/null | head -1)

    if [ -z "$master_result" ] || [ -z "$assistant_result" ]; then
        log_error "缺少子任务结果文件"
        return 1
    fi

    # 提取摘要
    local master_summary=$(grep -A 10 "## 执行摘要" "$master_result" 2>/dev/null | tail -n +2 | head -5 | sed 's/^[[:space:]]*//')
    local assistant_summary=$(grep -A 10 "## 执行摘要" "$assistant_result" 2>/dev/null | tail -n +2 | head -5 | sed 's/^[[:space:]]*//')

    # 创建最终汇总结果
    local final_result="/tmp/agent_results_${parent_task_id}.json"

    cat > "$final_result" <<EOF
{
  "task_id": "$parent_task_id",
  "title": "协作任务 - $(basename "$parent_file" .md | sed 's/^task_//')",
  "status": "success",
  "completed_at": "$(date -Iseconds)",
  "collaboration": true,
  "master_summary": "$(echo "$master_summary" | tr '\n' ' ')",
  "assistant_summary": "$(echo "$assistant_summary" | tr '\n' ' ')",
  "master_result_file": "$master_result",
  "assistant_result_file": "$assistant_result"
}
EOF

    log_info "协作结果已汇总: $final_result"

    # 写入主结果队列
    if command -v jq &>/dev/null; then
        if [ ! -f "$RESULTS_QUEUE" ] || ! grep -q '"results"' "$RESULTS_QUEUE" 2>/dev/null; then
            echo '{"results":[]}' > "$RESULTS_QUEUE"
        fi

        if jq ".results += [$(cat "$final_result")]" "$RESULTS_QUEUE" > /tmp/queue.tmp 2>/dev/null; then
            mv /tmp/queue.tmp "$RESULTS_QUEUE"
            log_info "协作结果已写入主结果队列"
        fi
    fi

    return 0
}

# ============ 主逻辑 ============

log_info "增强任务路由器启动"
log_info "任务: $TASK_TITLE"

# 1. 评估当前负载
load_info=$(calculate_master_load)
load_score=$(echo "$load_info" | cut -d'|' -f1)
active_count=$(echo "$load_info" | grep -o 'active:[0-9]*' | cut -d: -f2)
recent_count=$(echo "$load_info" | grep -o 'recent:[0-9]*' | cut -d: -f2)

log_info "当前 Master 负载: $load_score/100 (active: $active_count, recent: $recent_count)"

# 2. 分类任务
log_info "分类任务..."
CLASSIFICATION_OUTPUT=$($TASK_CLASSIFIER "$TASK_DESC" "$TASK_TITLE")
if [ $? -ne 0 ]; then
    log_error "任务分类失败，默认由 Master 自处理"
    echo "ROUTED_TO=master"
    echo "COMPLEXITY=UNKNOWN"
    exit 1
fi

COMPLEXITY=$(echo "$CLASSIFICATION_OUTPUT" | jq -r '.complexity')
RECOMMENDED_AGENT=$(echo "$CLASSIFICATION_OUTPUT" | jq -r '.recommended_agent')
REASON=$(echo "$CLASSIFICATION_OUTPUT" | jq -r '.reason')

log_info "分类结果: $COMPLEXITY, 推荐: $RECOMMENDED_AGENT, 原因: $REASON"

# 3. 决定协作策略
strategy=$(decide_collaboration_strategy "$COMPLEXITY" "$load_score")
log_info "采用策略: $strategy"

# 4. 执行路由
case "$strategy" in
    "self_handle")
        log_info "Master 自行处理（低负载 + 非复杂任务）"
        echo "ROUTED_TO=master"
        echo "COMPLEXITY=$COMPLEXITY"
        echo "STRATEGY=$strategy"
        exit 1
        ;;

    "forward_if_possible")
        log_warn "负载较高，尝试转发..."
        # 仅当推荐 agent 是 assistant 时才转发
        if [ "$RECOMMENDED_AGENT" = "assistant" ]; then
            log_info "转发给 Assistant (单向)"
            # 创建任务文件直接转发
            task_id=$(generate_task_id "$TASK_TITLE")
            task_file=$(create_task_file "$ASSISTANT_TASKS_DIR" "$task_id" "$TASK_TITLE" "$TASK_DESC" "")
            echo "ROUTED_TO=assistant"
            echo "TASK_ID=$task_id"
            echo "TASK_FILE=$task_file"
            echo "STRATEGY=$strategy"
            exit 0
        else
            log_info "仍由 Master 处理（任务不适合转发）"
            echo "ROUTED_TO=master"
            echo "COMPLEXITY=$COMPLEXITY"
            echo "STRATEGY=$strategy"
            exit 1
        fi
        ;;

    "try_self_then_forward")
        log_info "Master 尝试自处理（低负载但复杂）"
        # 这里可以 implement：先尝试自处理，如果超时或失败再转发
        # 简化：转为协作模式
        task_id=$(generate_task_id "$TASK_TITLE")
        if split_collaborative_task "$task_id" "$TASK_TITLE" "$TASK_DESC"; then
            echo "ROUTED_TO=master"  # master 有子任务
            echo "COMPLEXITY=$COMPLEXITY"
            echo "STRATEGY=collaborate"
            echo "PARENT_TASK_ID=$task_id"
            exit 0
        else
            log_warn "协作模式创建失败，回退到单向转发"
            task_id=$(generate_task_id "$TASK_TITLE")
            task_file=$(create_task_file "$ASSISTANT_TASKS_DIR" "$task_id" "$TASK_TITLE" "$TASK_DESC" "")
            echo "ROUTED_TO=assistant"
            echo "TASK_ID=$task_id"
            echo "TASK_FILE=$task_file"
            exit 0
        fi
        ;;

    "collaborate")
        log_info "启动协作模式（Master + Assistant）"
        task_id=$(generate_task_id "$TASK_TITLE")
        if split_collaborative_task "$task_id" "$TASK_TITLE" "$TASK_DESC"; then
            echo "ROUTED_TO=master"  # master 有子任务
            echo "COMPLEXITY=$COMPLEXITY"
            echo "STRATEGY=collaborate"
            echo "PARENT_TASK_ID=$task_id"
            exit 0
        else
            log_error "协作任务创建失败"
            echo "ROUTED_TO=master"
            exit 1
        fi
        ;;

    "forward_all")
        log_warn "负载过高，全部转发给 Assistant"
        task_id=$(generate_task_id "$TASK_TITLE")
        task_file=$(create_task_file "$ASSISTANT_TASKS_DIR" "$task_id" "$TASK_TITLE" "$TASK_DESC" "")
        echo "ROUTED_TO=assistant"
        echo "TASK_ID=$task_id"
        echo "TASK_FILE=$task_file"
        echo "STRATEGY=forward_all"
        exit 0
        ;;

    *)
        log_warn "未知策略: $strategy，默认自处理"
        echo "ROUTED_TO=master"
        echo "COMPLEXITY=$COMPLEXITY"
        exit 1
        ;;
esac
