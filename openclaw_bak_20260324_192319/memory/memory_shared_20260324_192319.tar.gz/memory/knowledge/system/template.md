# 系统知识模板

## 元数据
- **类别**: system
- **重要性**: high/medium/low
- **创建时间**: YYYY-MM-DD
- **最后更新**: YYYY-MM-DD
- **相关任务**: task_id
- **关键词**: [keyword1, keyword2, keyword3]

## 内容
[知识内容]

## 关联
- **相关文档**: [file_path]
- **相关用户**: [user_id]
- **相关 Agent**: [agent_id]