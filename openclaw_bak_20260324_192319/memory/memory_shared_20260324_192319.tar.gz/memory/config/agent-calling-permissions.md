# Agent 调用权限矩阵

## 权限层级定义

### L1: 系统级 (System Level)
- **Agent**: master
- **权限**: 可以调用所有其他 agent
- **限制**: 无

### L2: 专业级 (Specialist Level)
- **Agent**: assistant
- **权限**: 可以调用 L3/L4 层级的所有 agent
- **限制**: 不能调用 master

### L3: 服务级 (Service Level)
- **Agents**: memory-manager, server-maintenance, customer-service, file-processor, database-manager
- **权限**: 可以调用其他 L3/L4 agent
- **限制**: 不能调用 master, assistant

### L4: 基础级 (Basic Level)
- **Agents**: monitoring, backup, analysis
- **权限**: 可以调用其他 L3/L4 agent
- **限制**: 不能调用 master, assistant

## 调用权限矩阵

| Caller \ Target | master | assistant | memory-mgr | server-maint | customer-svc | file-proc | db-mgr | monitoring | backup | analysis |
|----------------|--------|-----------|------------|--------------|--------------|-----------|--------|------------|--------|----------|
| **master**     | -      | ✅        | ✅         | ✅           | ✅           | ✅        | ✅     | ✅         | ✅     | ✅       |
| **assistant**  | ❌     | -         | ✅         | ✅           | ✅           | ✅        | ✅     | ✅         | ✅     | ✅       |
| **memory-mgr** | ❌     | ❌        | -          | ✅           | ✅           | ✅        | ✅     | ✅         | ✅     | ✅       |
| **server-maint**| ❌    | ❌        | ✅         | -            | ✅           | ✅        | ✅     | ✅         | ✅     | ✅       |
| **customer-svc**| ❌    | ❌        | ✅         | ✅           | -            | ✅        | ✅     | ✅         | ✅     | ✅       |
| **file-proc**  | ❌     | ❌        | ✅         | ✅           | ✅           | -         | ✅     | ✅         | ✅     | ✅       |
| **db-mgr**     | ❌     | ❌        | ✅         | ✅           | ✅           | ✅        | -      | ✅         | ✅     | ✅       |
| **monitoring** | ❌     | ❌        | ✅         | ✅           | ✅           | ✅        | ✅     | -          | ✅     | ✅       |
| **backup**     | ❌     | ❌        | ✅         | ✅           | ✅           | ✅        | ✅     | ✅         | -      | ✅       |
| **analysis**   | ❌     | ❌        | ✅         | ✅           | ✅           | ✅        | ✅     | ✅         | ✅     | -        |

## 调用验证机制

### 1. 调用前验证
```bash
# 伪代码示例
function validate_call() {
    caller=$1
    target=$2
    
    # 检查调用权限矩阵
    if ! permission_matrix[$caller][$target]; then
        log "ERROR: $caller cannot call $target"
        return 1
    fi
    
    # 特殊规则验证
    if [[ "$target" == "assistant" && "$caller" != "master" ]]; then
        log "ERROR: Only master can call assistant"
        return 1
    fi
    
    if [[ "$target" == "master" ]]; then
        log "ERROR: master cannot be called by other agents"
        return 1
    fi
    
    return 0
}
```

### 2. 调用流程
1. **发起调用**: caller agent 创建任务到任务队列
2. **权限验证**: 检查调用权限矩阵
3. **任务分发**: 验证通过后分发到 target agent
4. **执行监控**: 记录调用日志和结果
5. **结果返回**: target agent 返回结果给 caller

### 3. 违规处理
- **首次违规**: 记录警告日志
- **重复违规**: 暂停调用权限 24 小时
- **严重违规**: 上报 master agent 处理

## 调用日志格式
```json
{
  "timestamp": "2026-03-17T19:15:00+08:00",
  "caller": "customer-service",
  "target": "server-maintenance",
  "task_type": "fault_analysis",
  "status": "approved|denied",
  "reason": "权限验证通过|权限不足"
}
```

## 特殊规则

### 助手 agent 保护规则
- **仅 master 可调用**: assistant agent 只接受来自 master 的任务
- **资源隔离**: assistant 运行在独立资源环境中
- **静默模式**: 无任务时完全退出，不占用资源

### 主控 agent 保护规则
- **不可被调用**: master agent 不接受其他 agent 的任务调用
- **直接交互**: 仅与用户直接交互
- **任务分发**: 通过任务队列分发任务给其他 agent

### 数据库管理特殊规则
- **双重验证**: 所有数据库调用需要验证用户等级
- **权限拒绝**: 无权访问时必须明确告知原因
- **审计日志**: 所有数据库访问记录完整日志