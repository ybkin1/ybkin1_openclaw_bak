# 防重复回答规则

## 核心原则
1. **每个问题只回答一次**
2. **回答后必须更新任务状态**
3. **重复请求必须检测并避免重复回答**

## 实施机制

### 1. 问题哈希跟踪
- 对每个用户问题生成唯一哈希值
- 存储在 `memory/master/short_term/{user_id}/answered_questions.json`
- 检查哈希值避免重复处理

### 2. 任务状态管理
- 回答完成后立即更新任务状态文件
- 标记为 "completed" 或 "answered"
- 记录回答时间戳

### 3. 重复检测流程
```
if question_hash in answered_questions:
    if time_since_answer < 5_minutes:
        return "HEARTBEAT_OK"  # 静默处理
    else:
        return "之前已回答此问题，需要重新回答吗？"
else:
    process_question()
    add_to_answered_questions()
```

### 4. 异常处理
- 如果用户明确要求"重新回答"，则忽略重复检测
- 如果上下文发生重大变化，重新处理问题
- 定期清理 24 小时前的回答记录

## 监控指标
- 重复回答率 < 1%
- 用户满意度 > 95%
- 任务完成准确率 > 99%

## 违规处理
- 发现重复回答立即停止
- 记录错误到 `.learnings/ERRORS.md`
- 自动触发修复流程