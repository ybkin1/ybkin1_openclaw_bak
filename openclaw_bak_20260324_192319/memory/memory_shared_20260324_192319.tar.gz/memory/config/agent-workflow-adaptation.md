# Agent 工作流程适配方案

**创建时间**: 2026-03-24
**状态**: 待实施
**来源**: gstack + GSD-2 + DeerFlow 2.0

---

## 一、核心适配原则

### 1. 不变更 Agent 架构
- Agent 角色和能力范围不变
- 只优化工作流程、健壮性、效率

### 2. 三级任务分解（借鉴 GSD-2）
```
Milestone (里程碑) → Slice (切片) → Task (任务)
    ↓                    ↓           ↓
 项目阶段            功能模块      上下文窗口大小
```

### 3. 状态机驱动（借鉴 GSD-2）
- 使用磁盘文件驱动工作流
- 每个任务新上下文，避免污染
- 支持崩溃恢复

---

## 二、每个 Agent 的工作流程适配

### Master Agent（主控）

**已有能力:**
- gstack 技能映射完整
- 任务处理流程已定义

**需要添加:**
- [ ] Milestone/Slice 规划能力
- [ ] 成本追踪机制
- [ ] 超时监督（soft/idle/hard）

**工作流程:**
```
1. /office-hours → 理解需求
2. /plan-ceo-review → 定义愿景
3. Milestone 规划 → 分解为 Slice
4. 分配任务给分支 agent
5. 监控进度 → 每 1/3 汇报
6. /retro → 回顾总结
```

---

### Assistant Agent（秘书）

**已有能力:**
- 任务监听和接收
- 任务转发

**需要添加:**
- [ ] /plan-eng-review 技能调用
- [ ] Slice → Task 分解
- [ ] 任务状态文件管理

**工作流程:**
```
1. 接收 master 任务
2. 分解为 Task（每个任务一个上下文）
3. 分配给专业 agent
4. 监控执行状态
5. 汇报进度给 master
```

---

### Analysis Agent（分析部门）

**已有能力:**
- 日志分析
- 故障定位
- 数据报告

**需要添加:**
- [ ] /review, /qa, /browse 技能调用
- [ ] 状态机驱动分析流程
- [ ] 分析结果持久化

**工作流程:**
```
1. 接收分析任务
2. 创建分析状态文件
3. 执行分析（每个步骤独立上下文）
4. 生成报告
5. 更新状态 → completed
```

---

### Monitoring Agent（监控部门）

**已有能力:**
- 系统监控
- 告警触发

**需要添加:**
- [ ] /cso, /careful, /freeze 技能调用
- [ ] 安全审计工作流
- [ ] 危险操作拦截

**工作流程:**
```
1. 定期健康检查
2. 发现异常 → 创建状态文件
3. 执行 /careful 评估风险
4. 高风险 → /freeze 锁定
5. 通知 master
```

---

### Server-Maintenance Agent（运维部门）

**已有能力:**
- 服务器维护
- 部署操作

**需要添加:**
- [ ] /ship, /land-and-deploy 技能调用
- [ ] 发布工作流
- [ ] 回滚机制

**工作流程:**
```
1. 接收发布任务
2. 创建发布状态文件
3. 执行预发布检查
4. /ship 发布
5. 监控发布状态
6. 异常 → 回滚
```

---

### Memory-Manager Agent（记忆部门）

**已有能力:**
- 记忆管理
- 知识归档

**需要添加:**
- [ ] /retro 技能调用
- [ ] 任务回顾工作流
- [ ] 经验沉淀机制

**工作流程:**
```
1. 定期检查已完成任务
2. 调用 /retro 回顾
3. 提取经验教训
4. 更新长期记忆
5. 清理短期记忆
```

---

### 其他 Agent（backup, customer-service, database-manager, file-processor）

**通用适配:**
- [ ] 添加 AGENTS.md 规范
- [ ] 添加工作流程文档
- [ ] 添加状态文件管理
- [ ] 添加进度汇报机制

---

## 三、实施计划

### 阶段 1: 核心文档创建（预估 10 分钟）

| 任务 | 文件 | 负责人 |
|------|------|--------|
| 创建思考原则文档 | `agent-thinking-principles.md` | master |
| 更新任务处理流程 | `task-processing-workflow.md` | master |
| 创建状态文件规范 | `state-file-schema.md` | master |

### 阶段 2: Agent 配置更新（预估 20 分钟）

| Agent | 任务 | 预估时间 |
|-------|------|----------|
| assistant | 添加工作流程 + 技能调用 | 5 分钟 |
| analysis | 添加工作流程 + 技能调用 | 3 分钟 |
| monitoring | 添加工作流程 + 技能调用 | 3 分钟 |
| server-maintenance | 添加工作流程 + 技能调用 | 3 分钟 |
| memory-manager | 添加工作流程 + 技能调用 | 3 分钟 |
| 其他 4 个 agent | 通用配置 | 3 分钟 |

### 阶段 3: 验证和测试（预估 10 分钟）

- 测试状态机驱动
- 测试技能调用
- 测试进度汇报

---

## 四、状态文件规范

### 任务状态文件结构

```json
{
  "taskId": "task_20260324_001",
  "type": "milestone|slice|task",
  "status": "pending|in_progress|completed|failed",
  "parentId": null,
  "assignedAgent": "master",
  "createdAt": "2026-03-24T00:00:00Z",
  "updatedAt": "2026-03-24T00:00:00Z",
  "progress": 0,
  "checkpoints": [
    {"time": "...", "progress": 33, "message": "1/3 完成"}
  ],
  "timeout": {
    "soft": 600,
    "idle": 1800,
    "hard": 3600
  },
  "cost": {
    "inputTokens": 0,
    "outputTokens": 0,
    "totalCost": 0
  }
}
```

### 状态转换规则

```
pending → in_progress → completed
                ↓
              failed → retry → in_progress
```

---

## 五、超时监督机制

| 类型 | 触发条件 | 动作 |
|------|----------|------|
| soft timeout | 无响应 10 分钟 | 发送提醒 |
| idle timeout | 无响应 30 分钟 | 暂停任务，询问用户 |
| hard timeout | 执行超过 1 小时 | 强制终止，保存状态 |

---

## 六、成本追踪

- 每个任务记录 token 使用量
- 每日汇总成本
- 超过阈值告警

---

**下一步**: 等待确认后开始执行阶段 1