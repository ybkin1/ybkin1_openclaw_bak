# gstack 技能与 Agent 架构映射

## 映射原则

1. **战略层技能** → master（主控）
2. **设计层技能** → master 或 assistant
3. **执行层技能** → 对应职能 agent
4. **安全层技能** → monitoring（监控）
5. **发布层技能** → server-maintenance（运维）
6. **反馈层技能** → memory-manager（记忆）

## 详细映射表

| gstack 技能 | 角色 | 映射到 Agent | 调用权限 |
|-------------|------|--------------|----------|
| `/office-hours` | YC Office Hours | master | 仅主控 |
| `/plan-ceo-review` | CEO / Founder | master | 仅主控 |
| `/plan-eng-review` | Eng Manager | master, assistant | 主控和助手 |
| `/plan-design-review` | Senior Designer | master, assistant | 主控和助手 |
| `/design-consultation` | Design Partner | analysis | 分析部门 |
| `/review` | Staff Engineer | analysis | 分析部门 |
| `/investigate` | Debugger | analysis | 分析部门 |
| `/design-review` | Designer Who Codes | analysis | 分析部门 |
| `/qa` | QA Lead | analysis | 分析部门 |
| `/qa-only` | QA Reporter | analysis | 分析部门 |
| `/cso` | Chief Security Officer | monitoring | 监控部门 |
| `/careful` | Safety Guardrails | monitoring | 监控部门 |
| `/freeze` | Edit Lock | monitoring | 监控部门 |
| `/guard` | Full Safety | monitoring | 监控部门 |
| `/unfreeze` | Unlock | monitoring | 监控部门 |
| `/ship` | Release Engineer | server-maintenance | 运维部门 |
| `/land-and-deploy` | Release Engineer | server-maintenance | 运维部门 |
| `/canary` | SRE | monitoring | 监控部门 |
| `/benchmark` | Performance Engineer | analysis | 分析部门 |
| `/document-release` | Technical Writer | file-processor | 文档部门 |
| `/retro` | Eng Manager | memory-manager | 记忆部门 |
| `/browse` | QA Engineer | analysis | 分析部门 |
| `/setup-browser-cookies` | Session Manager | analysis | 分析部门 |
| `/codex` | Second Opinion | analysis | 分析部门 |
| `/autoplan` | Review Pipeline | master, assistant | 主控和助手 |
| `/gstack-upgrade` | Self-Updater | server-maintenance | 运维部门 |
| `/setup-deploy` | Deploy Configurator | server-maintenance | 运维部门 |

## 工作流程集成

### 标准任务流程

```
1. master 调用 /office-hours 理解需求
2. master 调用 /plan-ceo-review 定义产品愿景
3. assistant 调用 /plan-eng-review 锁定技术架构
4. 分支 agent 执行任务
5. analysis 调用 /review 代码审查
6. analysis 调用 /qa 测试
7. server-maintenance 调用 /ship 发布
8. memory-manager 调用 /retro 回顾
```

### Agent 调用规则

- **master** 可以调用所有 gstack 技能
- **assistant** 可调用 /plan-eng-review, /plan-design-review, /autoplan
- **analysis** 可调用 /review, /qa, /browse, /investigate, /benchmark
- **monitoring** 可调用 /cso, /careful, /freeze, /guard, /canary
- **server-maintenance** 可调用 /ship, /land-and-deploy, /setup-deploy
- **file-processor** 可调用 /document-release
- **memory-manager** 可调用 /retro
