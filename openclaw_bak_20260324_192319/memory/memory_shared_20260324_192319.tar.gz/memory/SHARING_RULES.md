# Memory Sharing Rules

## Architecture Overview

```
memory/
├── shared/              # ✅ All agents can read/write
│   ├── users/          # User profiles (shared)
│   ├── knowledge/      # Knowledge base (shared)
│   └── task_templates/ # Task templates (shared)
├── master/             # 🔒 Master agent only (read/write)
│   ├── short_term/
│   ├── long_term/
│   └── tasks/
├── monitoring/         # 🔒 Monitoring agent only + Master (read-only)
│   └── health_logs/
├── backup/            # 🔒 Backup agent only + Master (read-only)
│   └── backup_logs/
└── analysis/          # 🔒 Analysis agent only + Master (read-only)
    └── analysis_reports/
```

## Access Control Matrix

| Memory Location | Master | Monitoring | Backup | Analysis |
|----------------|--------|------------|--------|----------|
| `shared/*`     | RW     | RW         | RW     | RW       |
| `master/*`     | RW     | ❌         | ❌     | ❌       |
| `monitoring/*` | R      | RW         | ❌     | ❌       |
| `backup/*`     | R      | ❌         | RW     | ❌       |
| `analysis/*`   | R      | ❌         | ❌     | RW       |

**Legend**: RW=Read/Write, R=Read-only, ❌=No Access

## Shareable Content (Besides User Profiles)

### 1. Knowledge Base (`shared/knowledge/`)
- Technical documentation
- Best practices
- Troubleshooting guides
- API references

### 2. Task Templates (`shared/task_templates/`)
- Common task patterns
- Workflow definitions
- Agent coordination protocols

### 3. System State (`shared/state/`)
- Current active tasks
- Agent availability status
- Resource allocation

### 4. Logs Index (`shared/logs_index/`)
- Centralized log catalog
- Search indices
- Alert history

## Memory Access Protocol

### Master Agent Reading Sub-Agent Memory
```bash
# Example: Master reads monitoring health logs
cat /root/.openclaw/workspace/agents/monitoring/memory/health_logs/latest.log
```

### Sub-Agent Writing to Shared Memory
```bash
# Example: Monitoring agent writes health status
echo "Health check passed" >> /root/.openclaw/workspace/memory/shared/state/agent_health.json
```

### Sub-Agent Requesting Master Memory Access
```bash
# Sub-agent must request via task queue
echo '{"request":"memory_access","target":"master","reason":"task_context"}' > /tmp/agent_queue.json
```

## Security Rules

1. **Master Privacy**: Sub-agents cannot access `memory/master/` without explicit permission
2. **Isolation**: Sub-agents cannot access each other's private memories
3. **Shared Only**: All inter-agent communication goes through `memory/shared/` or task queues
4. **Audit Trail**: All cross-agent memory access is logged

## Implementation Notes

- Enforce via file permissions (chmod/chown)
- Log all access attempts
- Master agent has override capability
- Regular audits of access patterns