# 决策记录: 备份策略架构设计

**日期**: 2026-03-18  
**决策者**: 俞斌 (系统架构优化任务)  
**主题**: 统一备份策略与恢复能力建设

---

## 背景

用户要求：系统崩溃后能从 GitHub 恢复到几乎原状态

**当前状态**:
- backups-unified 存在但覆盖度仅 30%
- backups-repo 缺失（GitHub 同步完全失效）
- Agent 架构、记忆、学习记录未备份
- 技能库未备份

**恢复目标**: 95%+ 系统状态恢复能力

---

## 决策内容

### 1. 三级保留策略

```
backups-unified/
├── daily/      # 每日增量，保留 7 天
├── weekly/     # 每周全量，保留 4 周  
└── monthly/    # 月度归档，永久保留 + GitHub 同步
```

**理由**:
- 平衡存储成本与恢复粒度
- daily: 快速恢复最近状态
- weekly: 防止 daily 损坏
- monthly: 永久审计跟踪，GitHub 异地备份

### 2. 优先级分类 (P0/P1/P2)

**P0 - 系统恢复必须 (~700 文件)**:
- 全局配置: openclaw.json, MEMORY.md, SOUL.md, AGENTS.md, USER.md, HEARTBEAT.md
- Agent 架构: 10 个 Agent × (AGENT.md, .openclaw/agent.json)
- Agent 脚本: 所有 agents/*/scripts/
- Agent 记忆: long_term + short_term + tasks
- Agent 学习: .learnings/
- 共享记忆: memory/shared/ (knowledge, users, task_templates)
- 技能库: skills/ 全部 34 个技能

**P1 - 重要但不关键 (~200 文件)**:
- agents/*/reports/, agents/*/docs/
- workspace/scripts/
- workspace/config/

**P2 - 不备份**:
- logs/, tmp/, node_modules/, .cache/, dist/

### 3. GitHub 同步策略

**同步内容**: 仅 monthly/ 归档  
**保留周期**: 3 个月（自动清理 older than 90 days）  
**仓库结构**:
```
openclaw_git/
├── backups/monthly-archives/
├── backups/restore-scripts/
├── backups/manifest.json
└── README.md
```

**理由**: 减少同步流量、避免仓库过大、简化恢复流程

### 4. 备份管理器架构

**核心组件** (agents/backup/scripts/):
- `backup-manager.sh` - 主入口（CLI）
- `generate-manifest.js` - 生成清单（SHA256 校验和）
- `verify-backup.js` - 验证完整性
- `restore-from-backup.js` - 统一恢复工具
- `sync-backup-to-github.js` - GitHub 同步
- `backup-cleanup.sh` - 过期清理

**备份格式**: tar.gz + manifest.json

---

## 替代方案考虑

| 方案 | 优点 | 缺点 | 拒绝理由 |
|------|------|------|---------|
| 全量每日备份 | 恢复简单 | 存储爆炸、时间长 | 不经济 |
| 仅增量无归档 | 节省空间 | 无法审计历史 | 不符合永久保留要求 |
| GitHub 同步全部 | 最大安全性 | 仓库巨大、同步慢 | 仅月度足够 |
| 使用 commercial SaaS | 易用 | 成本、依赖外部 | 优先使用 GitHub 免费 |

**最终方案**: 三级保留 + 月度 GitHub 同步

---

## 实施影响

**存储成本**:
- 本地: ~1.5GB × 3 级 = 3-5GB（短期）
- GitHub: ~1GB × 3个月 = 3GB（免费额度内）

**时间成本**:
- 开发 backup-manager: 30 分钟
- 测试备份+恢复: 20 分钟
- 总计: ~1 小时

**恢复能力**:
- RTO (恢复时间目标): < 30 分钟
- RPO (恢复点目标): 每日一次 + 月度永久

---

## 后续行动

1. ✅ 完成备份清单精确扫描（786 文件）
2. ✅ 生成详细文档（backup-summary-2026-03-18.md）
3. ✅ 创建扫描脚本（generate-backup-filelist.sh）
4. ⏳ 待审批：确认时间窗口和 GitHub 配置
5. ⏳ 待实施：开发 backup-manager 核心脚本（30 分钟）

---

**决策状态**: ✅ 已批准，等待执行  
**相关文档**:
- `docs/backup-strategy-optimized-2026-03-18.md`
- `docs/backup-summary-2026-03-18.md`
- `docs/backup-filelist-precise-2026-03-18.txt`
