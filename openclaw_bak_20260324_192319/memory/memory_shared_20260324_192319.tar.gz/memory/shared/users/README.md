# 用户档案目录

## 结构
每个用户一个独立文件：`{user_id}.json`

## 内容
- user_id: 用户唯一标识
- channel_id: 渠道 ID (feishu, dingtalk, etc.)
- permission_level: 权限等级 (1-5)
- created_at: 创建时间
- last_active: 最后活跃时间

## 示例
```json
{
  "user_id": "usr_20260317_feishu_master",
  "channel_id": "ou_b46467cc1563871aab03ac1d4f9216f0",
  "permission_level": 1,
  "created_at": "2026-03-17T10:47:00+08:00",
  "last_active": "2026-03-17T21:11:00+08:00"
}
```
