# 任务清单 - {任务标题}

**任务ID**: {task_id}  
**创建时间**: {timestamp}  
**创建者**: {user_id}  
**执行 Agent**: {agent_id}  
**状态**: {status} (active/completed/archived)  
**完成询问**: {completion_asked} (true/false)

---

## 任务详情

### 基本信息
- **标题**: {title}
- **描述**: {description}
- **优先级**: {priority}
- **预计完成时间**: {estimated_completion}

### 状态跟踪
- **当前状态**: {current_status}
- **完成百分比**: {completion_percentage}%
- **最后更新**: {last_updated}
- **完成时间**: {completed_at} (如果已完成)

### 任务列表

#### ⏳ 任务1: {任务描述}
- **状态**: {status}
- **子任务**:
  - [ ] {子任务1}
  - [ ] {子任务2}
- **预计时间**: {time}
- **优先级**: {high/medium/low}

...

---

## 执行进度

| 阶段 | 任务数 | 完成数 | 进度 |
|------|--------|--------|------|
| **总计** | **{total}** | **{completed}** | **{percentage}%** |

---

## 执行日志

### {timestamp}
- {执行记录}

---

## 下一步行动
1. {next_action_1}
2. {next_action_2}

## 自动清理规则
- **完成3天后**: 自动标记为可删除，询问用户确认
- **归档条件**: 用户确认删除或超过30天未访问