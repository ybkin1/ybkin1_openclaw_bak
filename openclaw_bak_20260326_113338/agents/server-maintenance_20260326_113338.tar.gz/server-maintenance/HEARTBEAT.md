# Server Maintenance Agent Heartbeat

## Daily Tasks
- Monitor server health status
- Analyze recent fault logs
- Update knowledge base with new fault patterns
- Coordinate with file-processor for log parsing

## Integration
- Collaborate with customer-service for user-facing support
- Use database-manager for equipment information queries
- Report critical issues to master agent