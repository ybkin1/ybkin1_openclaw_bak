#!/usr/bin/env python3
"""
知识库优化脚本 - 新增知识条目

目标：新增 20+ 条高质量知识
"""

import sqlite3
import json
import sys

DB_PATH = "/root/.openclaw/workspace/agents/database-manager/data/customer-service.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def insert_knowledge(conn, category, subcategory, title, content, 
                    min_permission_level=1, tags=None, metadata=None):
    """插入知识库条目"""
    
    knowledge_id = f"kb_{category}_{title.replace(' ', '_')[:20]}"
    
    sql = """
        INSERT INTO knowledge_base 
        (knowledge_id, category, subcategory, title, content, 
         min_permission_level, tags, metadata, content_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'markdown')
        ON CONFLICT(knowledge_id) DO UPDATE SET
            title = excluded.title,
            content = excluded.content,
            tags = excluded.tags,
            metadata = excluded.metadata,
            updated_at = CURRENT_TIMESTAMP
    """
    
    cursor = conn.cursor()
    cursor.execute(sql, [
        knowledge_id,
        category,
        subcategory,
        title,
        content,
        min_permission_level,
        ','.join(tags or []),
        json.dumps(metadata or {})
    ])
    
    return knowledge_id

def add_advanced_fault_knowledge(conn):
    """添加高级故障知识"""
    
    print("🔧 添加高级故障知识...")
    
    # 内存故障
    insert_knowledge(conn,
        category="fault",
        subcategory="memory_issue",
        title="内存故障排查",
        content="""# 内存故障排查

## 故障现象
- 系统频繁蓝屏/死机
- 内存告警
- 训练任务异常中断

## 排查步骤
1. **检查内存状态**: `ipmitool sel list | grep -i memory`
2. **检查 ECC 错误**: `edac-util -v`
3. **运行内存测试**: `memtest86+`
4. **检查 dmesg**: `dmesg | grep -i memory`

## 常见问题
1. **内存条松动**: 重新插拔内存
2. **ECC 错误过多**: 更换内存条
3. **不兼容**: 使用同品牌同型号内存
4. **超频不稳定**: 恢复默认频率

## 解决方案
1. 重新插拔内存（断电操作）
2. 清洁金手指（橡皮擦）
3. 更换故障内存
4. 更新 BIOS

## 预防措施
- 使用 ECC 内存
- 定期检查内存健康
- 避免混用不同品牌内存
""",
        min_permission_level=1,
        tags=["内存", "故障处理", "ECC"],
        metadata={"fault_type": "memory_issue"}
    )
    
    # CPU 故障
    insert_knowledge(conn,
        category="fault",
        subcategory="cpu_issue",
        title="CPU 故障排查",
        content="""# CPU 故障排查

## 故障现象
- 系统无法开机
- CPU 温度过高
- 性能异常下降

## 排查步骤
1. **检查 CPU 温度**: `ipmitool sensor list | grep CPU`
2. **检查 CPU 频率**: `lscpu`
3. **检查错误日志**: `ipmitool sel list`
4. **检查散热**: 物理检查风扇和散热器

## 常见问题
1. **散热不良**: 清理散热器
2. **硅脂老化**: 更换硅脂
3. **CPU 降频**: 检查温度和功耗
4. **CPU 损坏**: 联系供应商

## 解决方案
1. 清理散热器
2. 更换高性能硅脂
3. 检查 BIOS 设置
4. 更换 CPU（如损坏）

## 预防措施
- 定期清理散热器
- 监控 CPU 温度
- 保持良好机房环境
""",
        min_permission_level=1,
        tags=["CPU", "故障处理", "散热"],
        metadata={"fault_type": "cpu_issue"}
    )
    
    # 系统启动故障
    insert_knowledge(conn,
        category="fault",
        subcategory="boot_issue",
        title="系统无法启动排查",
        content="""# 系统无法启动排查

## 故障现象
- 开机无显示
- 卡在 POST 界面
- 无法进入系统

## 排查步骤
1. **检查电源**: 确认电源正常供电
2. **检查指示灯**: 查看主板诊断灯
3. **检查 IPMI**: 远程查看启动日志
4. **检查硬件**: 内存、CPU、显卡

## 常见问题
1. **电源故障**: 更换电源
2. **内存故障**: 重新插拔或更换
3. **BIOS 设置**: 清除 CMOS
4. **硬盘故障**: 检查硬盘连接

## 解决方案
1. 检查电源连接
2. 重新插拔内存
3. 清除 CMOS（跳线或电池）
4. 最小化系统测试

## 诊断代码
- **00/FF**: CPU 问题
- **53/55**: 内存问题
- **99/9A**: 显卡问题
- **7F/77**: 硬盘问题
""",
        min_permission_level=1,
        tags=["启动", "故障处理", "BIOS"],
        metadata={"fault_type": "boot_issue"}
    )
    
    print("   ✅ 添加 3 条高级故障知识")

def add_maintenance_knowledge(conn):
    """添加维护知识"""
    
    print("🔧 添加维护知识...")
    
    # 季度维护
    insert_knowledge(conn,
        category="guideline",
        subcategory="maintenance",
        title="服务器季度维护清单",
        content="""# 服务器季度维护清单

## 硬件检查
- [ ] 清理内部灰尘
- [ ] 检查风扇运转
- [ ] 检查线缆连接
- [ ] 检查散热器
- [ ] 更换导热硅脂（如需要）

## 系统检查
- [ ] 更新 BIOS/BMC
- [ ] 更新固件（磁盘、网卡）
- [ ] 检查系统日志
- [ ] 检查硬件日志（IPMI SEL）
- [ ] 运行硬件诊断

## 性能检查
- [ ] CPU 性能测试
- [ ] 内存带宽测试
- [ ] 磁盘 IO 测试
- [ ] 网络带宽测试
- [ ] GPU 性能测试

## 安全检查
- [ ] 更新系统补丁
- [ ] 检查用户权限
- [ ] 检查防火墙规则
- [ ] 检查日志审计
- [ ] 备份关键数据

## 文档更新
- [ ] 更新资产清单
- [ ] 更新维护记录
- [ ] 更新故障记录
- [ ] 更新联系人列表
""",
        min_permission_level=1,
        tags=["维护", "季度检查", "清单"],
        metadata={"guide_type": "maintenance"}
    )
    
    # 备件管理
    insert_knowledge(conn,
        category="guideline",
        subcategory="spare_parts",
        title="备件管理指南",
        content="""# 备件管理指南

## 必备备件清单

### 关键备件（必须储备）
- 风扇 x 4
- 电源模块 x 1
- 内存条 x 2
- 磁盘 x 2
- 网线 x 5

### 重要备件（建议储备）
- 导热硅脂
- 螺丝套装
- 线缆扎带
- 压缩空气罐

### 可选备件
- 整机备用
- GPU 备用
- 主板备用

## 备件管理
1. **入库登记**: 记录 SN 号、购买日期
2. **定期检查**: 每季度检查备件状态
3. **轮换使用**: 避免备件老化
4. **及时补充**: 使用后及时采购

## 存储要求
- 防静电包装
- 干燥环境（湿度<60%）
- 温度适宜（15-25°C）
- 避免阳光直射
""",
        min_permission_level=1,
        tags=["备件", "管理", "库存"],
        metadata={"guide_type": "spare_parts"}
    )
    
    print("   ✅ 添加 2 条维护知识")

def add_product_knowledge(conn):
    """添加产品知识"""
    
    print("📦 添加产品知识...")
    
    # A800 GPU
    insert_knowledge(conn,
        category="product",
        subcategory="gpu_model",
        title="NVIDIA A800 GPU 规格",
        content="""# NVIDIA A800 GPU 规格

## 基本信息
- **型号**: A800 80GB
- **架构**: Ampere
- **发布时间**: 2022

## 核心规格
- **CUDA 核心**: 6912
- **显存**: 80GB HBM2e
- **显存带宽**: 2039 GB/s
- **TDP**: 400W

## 计算能力
- **FP32**: 19.5 TFLOPS
- **FP64**: 9.7 TFLOPS
- **FP16**: 312 TFLOPS (with sparsity)
- **INT8**: 624 TOPS (with sparsity)

## 互联
- **NVLink**: 600 GB/s
- **PCIe**: Gen4 x16

## 适用场景
- AI 训练
- 大规模推理
- 科学计算
""",
        min_permission_level=1,
        tags=["GPU", "A800", "规格", "NVIDIA"],
        metadata={"gpu_model": "A800"}
    )
    
    # H800 GPU
    insert_knowledge(conn,
        category="product",
        subcategory="gpu_model",
        title="NVIDIA H800 GPU 规格",
        content="""# NVIDIA H800 GPU 规格

## 基本信息
- **型号**: H800 80GB
- **架构**: Hopper
- **发布时间**: 2023

## 核心规格
- **CUDA 核心**: 13248
- **显存**: 80GB HBM3
- **显存带宽**: 3350 GB/s
- **TDP**: 700W

## 计算能力
- **FP32**: 67 TFLOPS
- **FP64**: 33.5 TFLOPS
- **FP16**: 1979 TFLOPS (with sparsity)
- **INT8**: 3958 TOPS (with sparsity)

## 互联
- **NVLink**: 900 GB/s
- **PCIe**: Gen5 x16

## 适用场景
- 超大模型训练
- 高性能推理
- 科学计算
""",
        min_permission_level=1,
        tags=["GPU", "H800", "规格", "NVIDIA"],
        metadata={"gpu_model": "H800"}
    )
    
    print("   ✅ 添加 2 条产品知识")

def add_emergency_knowledge(conn):
    """添加应急处理知识"""
    
    print("🚨 添加应急处理知识...")
    
    # 火灾应急
    insert_knowledge(conn,
        category="guideline",
        subcategory="emergency",
        title="机房火灾应急处理",
        content="""# 机房火灾应急处理

## 火警响应
1. **立即报警**: 拨打 119
2. **切断电源**: 紧急断电按钮
3. **启动灭火**: 气体灭火系统
4. **疏散人员**: 按逃生路线撤离

## 断电流程
1. 按下紧急断电按钮
2. 确认 UPS 切换到电池
3. 关闭主要负载
4. 关闭 UPS 输出

## 灭火系统
- **类型**: 七氟丙烷 (FM200)
- **启动方式**: 自动/手动
- **灭火时间**: <10 秒
- **安全时间**: 灭火后 30 分钟再进入

## 事后处理
1. 确认火源已完全扑灭
2. 检查设备损坏情况
3. 联系保险公司
4. 撰写事故报告

## 预防措施
- 定期检查消防设施
- 保持通道畅通
- 禁止明火
- 安装烟雾探测器
""",
        min_permission_level=1,
        tags=["应急", "火灾", "安全"],
        metadata={"guide_type": "emergency"}
    )
    
    # 漏水应急
    insert_knowledge(conn,
        category="guideline",
        subcategory="emergency",
        title="机房漏水应急处理",
        content="""# 机房漏水应急处理

## 漏水检测
- 漏水检测绳告警
- 地面有水迹
- 空调异常滴水
- 天花板渗水

## 应急响应
1. **定位漏点**: 检查漏水检测绳
2. **切断水源**: 关闭相关阀门
3. **保护设备**: 用防水布覆盖
4. **排水清理**: 使用吸水设备

## 设备保护
1. 立即关闭受影响设备
2. 用防水布覆盖未 affected 设备
3. 转移重要设备
4. 设置警示标志

## 事后处理
1. 彻底清理积水
2. 检查设备损坏
3. 修复漏点
4. 干燥环境（除湿机）

## 预防措施
- 定期检查空调管道
- 安装漏水检测系统
- 保持地面干燥
- 准备应急物资（防水布、吸水垫）
""",
        min_permission_level=1,
        tags=["应急", "漏水", "安全"],
        metadata={"guide_type": "emergency"}
    )
    
    print("   ✅ 添加 2 条应急知识")

def main():
    print("=" * 60)
    print("📚 知识库优化 - 新增知识条目")
    print("=" * 60)
    
    try:
        conn = get_connection()
        
        # 添加各类知识
        add_advanced_fault_knowledge(conn)
        add_maintenance_knowledge(conn)
        add_product_knowledge(conn)
        add_emergency_knowledge(conn)
        
        conn.commit()
        
        # 统计
        cursor = conn.cursor()
        cursor.execute("SELECT category, COUNT(*) as count FROM knowledge_base GROUP BY category")
        rows = cursor.fetchall()
        
        print("\n📊 知识库统计:")
        for row in rows:
            print(f"   - {row['category']}: {row['count']} 条")
        
        cursor.execute("SELECT COUNT(*) as total FROM knowledge_base")
        total = cursor.fetchone()['total']
        print(f"\n✅ 知识库优化完成！共 {total} 条知识")
        
        conn.close()
        
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ 错误：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
