-- ============================================================
-- 数据库记忆架构初始化脚本
-- 版本：v1.0
-- 创建日期：2026-04-01
-- 数据库：customer-service.db
-- ============================================================

-- 启用外键约束
PRAGMA foreign_keys = ON;

-- ============================================================
-- 1. 用户信息表 (users)
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    
    -- 基本信息
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    company TEXT,
    
    -- 权限控制
    user_type TEXT NOT NULL CHECK (user_type IN ('internal', 'maintenance', 'regular')),
    org_id TEXT,  -- 租户 ID（内部员工所属部门）
    permission_level INTEGER DEFAULT 1,  -- 1=普通，2=维保，3=内部
    
    -- 渠道信息
    channel TEXT NOT NULL CHECK (channel IN ('feishu', 'wecom')),
    channel_user_id TEXT NOT NULL,  -- 飞书/企业微信用户 ID
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active_at TIMESTAMP,
    
    -- 软删除
    deleted_at TIMESTAMP NULL,
    
    -- 索引
    UNIQUE(channel, channel_user_id)
);

CREATE INDEX IF NOT EXISTS idx_users_type ON users(user_type);
CREATE INDEX IF NOT EXISTS idx_users_org ON users(org_id);
CREATE INDEX IF NOT EXISTS idx_users_channel ON users(channel, channel_user_id);

-- ============================================================
-- 2. 会话记录表 (conversations)
-- ============================================================

CREATE TABLE IF NOT EXISTS conversations (
    conversation_id TEXT PRIMARY KEY,
    
    -- 关联信息
    user_id TEXT NOT NULL REFERENCES users(user_id),
    channel TEXT NOT NULL,
    
    -- 会话内容
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    
    -- 上下文
    parent_message_id TEXT,  -- 父消息 ID（用于对话树）
    thread_id TEXT,  -- 会话线程 ID
    
    -- 元数据
    metadata JSON DEFAULT '{}',  -- 结构化数据（如意图、实体）
    tokens_used INTEGER DEFAULT 0,
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 软删除
    deleted_at TIMESTAMP NULL
);

CREATE INDEX IF NOT EXISTS idx_conversations_user ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_channel ON conversations(channel);
CREATE INDEX IF NOT EXISTS idx_conversations_created ON conversations(created_at);
CREATE INDEX IF NOT EXISTS idx_conversations_thread ON conversations(thread_id);

-- ============================================================
-- 3. 工单表 (tickets)
-- ============================================================

CREATE TABLE IF NOT EXISTS tickets (
    ticket_id TEXT PRIMARY KEY,
    
    -- 关联信息
    user_id TEXT NOT NULL REFERENCES users(user_id),
    assigned_to TEXT,  -- 处理人 user_id
    
    -- 工单内容
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'pending' 
      CHECK (status IN ('pending', 'confirmed', 'in_progress', 'reviewing', 'completed', 'cancelled')),
    priority INTEGER DEFAULT 2 CHECK (priority BETWEEN 1 AND 5),  -- 1=紧急，5=低
    
    -- 分类
    category TEXT,  -- fault/consultation/upgrade/other
    subcategory TEXT,
    
    -- 处理过程
    solution TEXT,  -- 解决方案
    resolution_time INTEGER,  -- 解决时长（分钟）
    
    -- 元数据
    metadata JSON DEFAULT '{}',
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confirmed_at TIMESTAMP,  -- 用户确认时间
    started_at TIMESTAMP,    -- 开始处理时间
    completed_at TIMESTAMP,  -- 完成时间
    
    -- 软删除
    deleted_at TIMESTAMP NULL
);

CREATE INDEX IF NOT EXISTS idx_tickets_user ON tickets(user_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_created ON tickets(created_at);
CREATE INDEX IF NOT EXISTS idx_tickets_assigned ON tickets(assigned_to);

-- 工单评论表
CREATE TABLE IF NOT EXISTS ticket_comments (
    comment_id TEXT PRIMARY KEY,
    ticket_id TEXT NOT NULL REFERENCES tickets(ticket_id),
    user_id TEXT NOT NULL REFERENCES users(user_id),
    content TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT FALSE,  -- 内部备注（不对外显示）
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ticket_comments_ticket ON ticket_comments(ticket_id);

-- ============================================================
-- 4. 用户记忆表 (user_memories)
-- ============================================================

CREATE TABLE IF NOT EXISTS user_memories (
    memory_id TEXT PRIMARY KEY,
    
    -- 关联信息
    user_id TEXT NOT NULL REFERENCES users(user_id),
    
    -- 记忆内容
    memory_type TEXT NOT NULL CHECK (memory_type IN ('fact', 'preference', 'context', 'emotion')),
    subject TEXT NOT NULL,  -- 主题（如：server_preference, contact_info）
    predicate TEXT,  -- 关系（如：prefers, has, likes）
    object TEXT,  -- 内容（如：M4 servers, 13800000000）
    
    -- 置信度
    confidence REAL DEFAULT 1.0 CHECK (confidence BETWEEN 0 AND 1),
    
    -- 验证状态
    verified BOOLEAN DEFAULT FALSE,
    verified_by TEXT,  -- user_id 或 'system'
    verified_at TIMESTAMP,
    
    -- 来源
    source_conversation_id TEXT REFERENCES conversations(conversation_id),
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at TIMESTAMP,
    access_count INTEGER DEFAULT 0,
    
    -- 软删除
    deleted_at TIMESTAMP NULL
);

CREATE INDEX IF NOT EXISTS idx_memories_user ON user_memories(user_id);
CREATE INDEX IF NOT EXISTS idx_memories_type ON user_memories(memory_type);
CREATE INDEX IF NOT EXISTS idx_memories_subject ON user_memories(subject);

-- 记忆验证日志
CREATE TABLE IF NOT EXISTS memory_verification_log (
    log_id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL REFERENCES user_memories(memory_id),
    action TEXT NOT NULL CHECK (action IN ('created', 'verified', 'rejected', 'updated', 'deleted')),
    actor_id TEXT,  -- 执行者 user_id
    old_value TEXT,
    new_value TEXT,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_memory_log_memory ON memory_verification_log(memory_id);

-- ============================================================
-- 5. 知识库表 (knowledge_base)
-- ============================================================

CREATE TABLE IF NOT EXISTS knowledge_base (
    knowledge_id TEXT PRIMARY KEY,
    
    -- 分类
    category TEXT NOT NULL,  -- product/fault/case/guideline
    subcategory TEXT,
    
    -- 内容
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    content_type TEXT CHECK (content_type IN ('text', 'markdown', 'json')),
    
    -- 向量索引
    vector_id TEXT,  -- LanceDB 向量 ID
    
    -- 权限控制
    min_permission_level INTEGER DEFAULT 1,  -- 最小访问权限
    user_types TEXT,  -- JSON 数组：["internal", "maintenance"]
    
    -- 版本管理
    version INTEGER DEFAULT 1,
    parent_knowledge_id TEXT,  -- 父版本 ID
    
    -- 质量评分
    quality_score REAL DEFAULT 0.0,  -- 0-5 分
    usage_count INTEGER DEFAULT 0,
    
    -- 元数据
    metadata JSON DEFAULT '{}',
    tags TEXT,  -- 逗号分隔的标签
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 软删除
    deleted_at TIMESTAMP NULL
);

CREATE INDEX IF NOT EXISTS idx_knowledge_category ON knowledge_base(category, subcategory);
CREATE INDEX IF NOT EXISTS idx_knowledge_permission ON knowledge_base(min_permission_level);
CREATE INDEX IF NOT EXISTS idx_knowledge_tags ON knowledge_base(tags);

-- 知识库使用日志
CREATE TABLE IF NOT EXISTS knowledge_usage_log (
    log_id TEXT PRIMARY KEY,
    knowledge_id TEXT NOT NULL REFERENCES knowledge_base(knowledge_id),
    user_id TEXT NOT NULL REFERENCES users(user_id),
    action TEXT NOT NULL CHECK (action IN ('viewed', 'used', 'rated')),
    rating INTEGER,  -- 1-5 分
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_knowledge_usage_knowledge ON knowledge_usage_log(knowledge_id);

-- ============================================================
-- 6. 数据访问日志表 (access_logs)
-- ============================================================

CREATE TABLE IF NOT EXISTS access_logs (
    log_id TEXT PRIMARY KEY,
    
    -- 访问者
    user_id TEXT NOT NULL REFERENCES users(user_id),
    agent_id TEXT NOT NULL,  -- 调用 agent
    
    -- 访问对象
    table_name TEXT NOT NULL,
    record_id TEXT,
    action TEXT NOT NULL CHECK (action IN ('create', 'read', 'update', 'delete')),
    
    -- 访问结果
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    
    -- 审计信息
    ip_address TEXT,
    channel TEXT,
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_access_user ON access_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_access_table ON access_logs(table_name, record_id);
CREATE INDEX IF NOT EXISTS idx_access_created ON access_logs(created_at);

-- 自动清理：保留 90 天
CREATE TRIGGER IF NOT EXISTS cleanup_old_access_logs
AFTER INSERT ON access_logs
BEGIN
    DELETE FROM access_logs 
    WHERE created_at < datetime('now', '-90 days');
END;

-- ============================================================
-- 7. 视图（Views）
-- ============================================================

-- 用户完整信息视图
CREATE VIEW IF NOT EXISTS v_user_profile AS
SELECT 
  u.user_id,
  u.name,
  u.user_type,
  u.channel,
  u.created_at,
  u.last_active_at,
  COUNT(DISTINCT t.ticket_id) as total_tickets,
  COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.ticket_id END) as completed_tickets,
  COUNT(DISTINCT c.conversation_id) as total_conversations,
  COUNT(DISTINCT m.memory_id) as total_memories
FROM users u
LEFT JOIN tickets t ON u.user_id = t.user_id
LEFT JOIN conversations c ON u.user_id = c.user_id
LEFT JOIN user_memories m ON u.user_id = m.user_id AND m.deleted_at IS NULL
WHERE u.deleted_at IS NULL
GROUP BY u.user_id;

-- 活跃工单视图
CREATE VIEW IF NOT EXISTS v_active_tickets AS
SELECT 
  t.*,
  u.name as user_name,
  u.user_type,
  u.channel
FROM tickets t
JOIN users u ON t.user_id = u.user_id
WHERE t.status IN ('pending', 'confirmed', 'in_progress', 'reviewing')
  AND t.deleted_at IS NULL
ORDER BY t.priority ASC, t.created_at DESC;

-- 已验证记忆视图
CREATE VIEW IF NOT EXISTS v_verified_memories AS
SELECT 
  m.*,
  u.name as user_name
FROM user_memories m
JOIN users u ON m.user_id = u.user_id
WHERE m.verified = TRUE 
  AND m.deleted_at IS NULL
  AND m.confidence >= 0.8
ORDER BY m.verified_at DESC;

-- ============================================================
-- 8. 系统配置表
-- ============================================================

CREATE TABLE IF NOT EXISTS system_config (
    config_key TEXT PRIMARY KEY,
    config_value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by TEXT
);

-- 插入默认配置
INSERT OR IGNORE INTO system_config (config_key, config_value, description) VALUES
('schema_version', '1.0', '数据库 Schema 版本'),
('created_at', datetime('now'), '数据库创建时间'),
('last_migration', datetime('now'), '最后一次迁移时间');

-- ============================================================
-- 9. 初始化数据（可选）
-- ============================================================

-- 示例：创建系统管理员用户（根据需要修改）
-- INSERT OR IGNORE INTO users (user_id, name, user_type, permission_level, channel, channel_user_id)
-- VALUES ('system', 'System Admin', 'internal', 3, 'feishu', 'system');

-- ============================================================
-- 完成提示
-- ============================================================

SELECT '✅ 数据库初始化完成！' as status,
       COUNT(*) as table_count
FROM sqlite_master 
WHERE type = 'table' 
  AND name NOT LIKE 'sqlite_%';
