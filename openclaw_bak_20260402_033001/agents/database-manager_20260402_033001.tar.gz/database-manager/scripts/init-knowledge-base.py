#!/usr/bin/env python3
"""
知识库初始化脚本 - 导入产品知识和故障库

导入内容:
1. 产品知识（服务器型号、配置）
2. 故障库（常见故障及解决方案）
3. 案例库（历史典型案例）
4. 操作指南（维护规范）
"""

import sqlite3
import json
import sys

DB_PATH = "/root/.openclaw/workspace/agents/database-manager/data/customer-service.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def insert_knowledge(conn, category, subcategory, title, content, 
                    min_permission_level=1, tags=None, metadata=None):
    """插入知识库条目"""
    
    knowledge_id = f"kb_{category}_{title.replace(' ', '_')[:20]}"
    
    sql = """
        INSERT INTO knowledge_base 
        (knowledge_id, category, subcategory, title, content, 
         min_permission_level, tags, metadata, content_type)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'markdown')
        ON CONFLICT(knowledge_id) DO UPDATE SET
            title = excluded.title,
            content = excluded.content,
            tags = excluded.tags,
            metadata = excluded.metadata,
            updated_at = CURRENT_TIMESTAMP
    """
    
    cursor = conn.cursor()
    cursor.execute(sql, [
        knowledge_id,
        category,
        subcategory,
        title,
        content,
        min_permission_level,
        ','.join(tags or []),
        json.dumps(metadata or {})
    ])
    
    return knowledge_id

def init_product_knowledge(conn):
    """导入产品知识"""
    
    print("📦 导入产品知识...")
    
    # M4 服务器
    insert_knowledge(conn, 
        category="product",
        subcategory="server_model",
        title="M4 服务器规格",
        content="""# M4 服务器规格

## 基本信息
- **型号**: M4
- **用途**: AI 训练/推理
- **发布时间**: 2025

## 硬件配置
- **CPU**: 双路 Intel Xeon Platinum
- **GPU**: 8x NVIDIA A800/H800
- **内存**: 2TB DDR5
- **存储**: 30TB NVMe SSD

## 网络
- **网卡**: 双口 200Gb InfiniBand
- **管理**: IPMI 2.0

## 电源
- **功率**: 3000W
- **冗余**: 1+1 冗余电源

## 散热
- **风扇**: 8 个高性能风扇
- **散热方式**: 风冷

## 适用场景
- AI 模型训练
- 大规模推理
- 高性能计算
""",
        min_permission_level=1,
        tags=["M4", "服务器", "规格", "AI 训练"],
        metadata={"server_model": "M4"}
    )
    
    # M6 服务器
    insert_knowledge(conn,
        category="product",
        subcategory="server_model",
        title="M6 服务器规格",
        content="""# M6 服务器规格

## 基本信息
- **型号**: M6
- **用途**: AI 训练/推理（新一代）
- **发布时间**: 2026

## 硬件配置
- **CPU**: 双路 Intel Xeon Platinum Gen5
- **GPU**: 8x NVIDIA H100/H800
- **内存**: 4TB DDR5
- **存储**: 60TB NVMe SSD

## 网络
- **网卡**: 双口 400Gb InfiniBand
- **管理**: IPMI 2.0

## 电源
- **功率**: 5000W
- **冗余**: 2+2 冗余电源

## 散热
- **风扇**: 12 个高性能风扇
- **散热方式**: 液冷 + 风冷混合

## 适用场景
- 超大模型训练
- 分布式推理
- 超算中心
""",
        min_permission_level=1,
        tags=["M6", "服务器", "规格", "AI 训练"],
        metadata={"server_model": "M6"}
    )
    
    print("   ✅ 产品知识已导入（2 个型号）")

def init_fault_knowledge(conn):
    """导入故障库"""
    
    print("🔧 导入故障库...")
    
    # GPU 过热
    insert_knowledge(conn,
        category="fault",
        subcategory="gpu_overheat",
        title="GPU 温度过高解决方案",
        content="""# GPU 温度过高解决方案

## 故障现象
- GPU 温度超过 85°C
- 系统降频或关机
- 风扇噪音大

## 可能原因
1. 散热器积灰
2. 导热硅脂老化
3. 风扇故障
4. 机房温度过高
5. 负载过高

## 排查步骤
1. **检查温度**: `nvidia-smi` 查看 GPU 温度
2. **检查风扇**: 确认所有风扇正常转动
3. **检查散热片**: 清理积灰
4. **检查硅脂**: 如使用超过 2 年，更换硅脂
5. **检查机房**: 确认空调正常，温度<25°C

## 解决方案
1. **清理散热器**: 使用压缩空气清理
2. **更换硅脂**: 使用信越 7921 或类似高性能硅脂
3. **更换风扇**: 联系供应商更换
4. **优化负载**: 降低训练批次大小
5. **改善散热**: 增加机房空调

## 预防措施
- 每月清理一次散热器
- 每 2 年更换一次硅脂
- 监控温度告警（设置 80°C 告警）
- 保持机房温度 20-25°C

## 相关工具
- `nvidia-smi` - 查看 GPU 状态
- `nvtop` - 实时监控 GPU
- IPMI - 查看系统温度
""",
        min_permission_level=1,
        tags=["GPU", "过热", "温度", "散热", "故障处理"],
        metadata={"fault_type": "gpu_overheat", "severity": "high"}
    )
    
    # 网络故障
    insert_knowledge(conn,
        category="fault",
        subcategory="network_issue",
        title="InfiniBand 网络故障排查",
        content="""# InfiniBand 网络故障排查

## 故障现象
- 节点间通信失败
- 训练任务卡住
- 网络速度异常

## 排查步骤
1. **检查链路状态**: `ibstatus`
2. **检查连接**: `ibv_devinfo`
3. **检查路由**: `ibroute`
4. **检查性能**: `ib_write_bw`

## 常见问题
1. **线缆松动**: 重新插拔 InfiniBand 线缆
2. **交换机故障**: 检查交换机电源和状态
3. **配置错误**: 检查 Subnet Manager 配置
4. **驱动问题**: 更新 OFED 驱动

## 解决方案
1. 重启 Subnet Manager: `systemctl restart opensm`
2. 更新驱动：`ofed_driver_update`
3. 更换线缆
4. 联系网络管理员

## 预防措施
- 定期检查链路状态
- 保持驱动最新
- 备用品线缆
""",
        min_permission_level=1,
        tags=["网络", "InfiniBand", "IB", "故障处理"],
        metadata={"fault_type": "network_issue"}
    )
    
    # 磁盘故障
    insert_knowledge(conn,
        category="fault",
        subcategory="disk_issue",
        title="NVMe SSD 故障排查",
        content="""# NVMe SSD 故障排查

## 故障现象
- 读写速度慢
- IO 错误
- 磁盘不识别

## 排查步骤
1. **检查健康度**: `nvme smart-log /dev/nvme0`
2. **检查温度**: `nvme temperature`
3. **检查错误**: `dmesg | grep nvme`
4. **检查性能**: `fio` 测试

## 常见问题
1. **温度过高**: 改善散热
2. **寿命耗尽**: 更换磁盘
3. **固件问题**: 更新固件
4. **连接松动**: 重新插拔

## 解决方案
1. 更新固件
2. 更换散热片
3. 更换磁盘（联系供应商）
4. 数据备份

## 预防措施
- 监控磁盘健康度
- 定期备份数据
- 保持良好散热
""",
        min_permission_level=1,
        tags=["磁盘", "NVMe", "SSD", "故障处理"],
        metadata={"fault_type": "disk_issue"}
    )
    
    # 电源故障
    insert_knowledge(conn,
        category="fault",
        subcategory="power_issue",
        title="电源故障排查",
        content="""# 电源故障排查

## 故障现象
- 服务器突然关机
- 电源告警灯亮
- 无法开机

## 排查步骤
1. **检查电源状态**: IPMI 查看电源状态
2. **检查电压**: `ipmitool sensor list`
3. **检查日志**: `ipmitool sel list`
4. **检查连接**: 确认电源线连接

## 常见问题
1. **电源模块故障**: 更换电源模块
2. **电压不稳**: 检查 UPS
3. **过载**: 减少负载
4. **过热**: 改善散热

## 解决方案
1. 更换电源模块（热插拔）
2. 检查 UPS 和 PDU
3. 优化功耗配置
4. 联系供应商

## 预防措施
- 定期检查电源状态
- 使用 UPS
- 保持良好散热
- 备用电源模块
""",
        min_permission_level=1,
        tags=["电源", "故障处理", "UPS"],
        metadata={"fault_type": "power_issue"}
    )
    
    print("   ✅ 故障库已导入（4 个故障类型）")

def init_case_knowledge(conn):
    """导入案例库"""
    
    print("📚 导入案例库...")
    
    # 典型案例 1
    insert_knowledge(conn,
        category="case",
        subcategory="gpu_repair",
        title="M4 服务器 GPU 过热维修案例",
        content="""# M4 服务器 GPU 过热维修案例

## 背景
- **时间**: 2026-03
- **客户**: 某 AI 公司
- **设备**: M4 服务器
- **故障**: GPU 温度持续 90°C+

## 问题描述
客户报告 M4 服务器在训练时 GPU 温度超过 90°C，系统频繁降频。

## 排查过程
1. 远程查看 nvidia-smi，确认温度异常
2. 检查风扇转速，发现 2 个风扇转速偏低
3. 现场检查，发现散热器积灰严重

## 解决方案
1. 清理散热器（压缩空气）
2. 更换 2 个故障风扇
3. 更换导热硅脂（信越 7921）
4. 优化机房温度（从 28°C 降到 22°C）

## 结果
- GPU 温度降至 65-70°C
- 训练性能恢复
- 客户满意

## 经验总结
1. 定期清理散热器很重要
2. 监控风扇转速
3. 保持机房温度适宜
4. 备足常用配件（风扇、硅脂）
""",
        min_permission_level=1,
        tags=["案例", "GPU", "过热", "M4"],
        metadata={"case_type": "gpu_repair"}
    )
    
    print("   ✅ 案例库已导入（1 个案例）")

def init_guide_knowledge(conn):
    """导入操作指南"""
    
    print("📖 导入操作指南...")
    
    # 日常维护
    insert_knowledge(conn,
        category="guideline",
        subcategory="maintenance",
        title="服务器日常维护指南",
        content="""# 服务器日常维护指南

## 每日检查
- [ ] 检查 GPU 温度（<80°C）
- [ ] 检查风扇转速
- [ ] 检查系统日志
- [ ] 检查训练任务状态

## 每周检查
- [ ] 检查磁盘健康度
- [ ] 检查网络状态
- [ ] 检查电源状态
- [ ] 清理表面灰尘

## 每月检查
- [ ] 清理散热器
- [ ] 检查线缆连接
- [ ] 更新系统日志
- [ ] 备份重要数据

## 每季度检查
- [ ] 全面清理内部灰尘
- [ ] 检查导热硅脂
- [ ] 测试备用电源
- [ ] 更新固件和驱动

## 每年检查
- [ ] 更换导热硅脂
- [ ] 更换风扇（如需要）
- [ ] 全面检修
- [ ] 性能测试

## 工具清单
- 压缩空气罐
- 导热硅脂（信越 7921）
- 螺丝刀套装
- 万用表
- 防静电手环
""",
        min_permission_level=1,
        tags=["维护", "指南", "日常检查"],
        metadata={"guide_type": "maintenance"}
    )
    
    # 故障上报流程
    insert_knowledge(conn,
        category="guideline",
        subcategory="process",
        title="故障上报流程",
        content="""# 故障上报流程

## 故障分级
- **P0 紧急**: 系统宕机，业务中断
- **P1 严重**: 性能严重下降
- **P2 中等**: 部分功能异常
- **P3 轻微**: 不影响业务的小问题

## 上报流程

### P0/P1 故障
1. 立即电话联系运维（7x24 小时）
2. 创建工单（紧急级别）
3. 提供故障现象和日志
4. 等待运维响应（15 分钟内）

### P2/P3 故障
1. 创建工单（普通级别）
2. 描述故障现象
3. 上传相关日志
4. 等待处理（24 小时内）

## 工单信息
- 服务器 SN 号
- 故障现象描述
- 发生时间
- 影响范围
- 相关日志

## 联系方式
- **紧急电话**: 400-XXX-XXXX
- **工单系统**: https://support.example.com
- **邮箱**: support@example.com
""",
        min_permission_level=1,
        tags=["流程", "故障上报", "工单"],
        metadata={"guide_type": "process"}
    )
    
    print("   ✅ 操作指南已导入（2 个指南）")

def main():
    print("=" * 60)
    print("📚 知识库初始化")
    print("=" * 60)
    
    try:
        conn = get_connection()
        
        # 导入各类知识
        init_product_knowledge(conn)
        init_fault_knowledge(conn)
        init_case_knowledge(conn)
        init_guide_knowledge(conn)
        
        conn.commit()
        
        # 统计
        cursor = conn.cursor()
        cursor.execute("SELECT category, COUNT(*) as count FROM knowledge_base GROUP BY category")
        rows = cursor.fetchall()
        
        print("\n📊 知识库统计:")
        for row in rows:
            print(f"   - {row['category']}: {row['count']} 条")
        
        cursor.execute("SELECT COUNT(*) as total FROM knowledge_base")
        total = cursor.fetchone()['total']
        print(f"\n✅ 知识库初始化完成！共 {total} 条知识")
        
        conn.close()
        
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ 错误：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
