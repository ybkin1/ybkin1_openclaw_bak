#!/usr/bin/env python3
"""
知识库向量索引构建脚本

功能:
1. 从 SQLite 读取知识条目
2. 使用嵌入模型生成向量
3. 存储到 LanceDB
4. 支持增量更新
"""

import sqlite3
import json
import sys
import hashlib
from typing import List, Dict, Any

sys.path.insert(0, '/root/.openclaw/workspace/agents/database-manager/src')

try:
    from lancedb_client import LanceDBClient
except ImportError:
    print("❌ 无法导入 lancedb_client，请确保已安装 lancedb")
    sys.exit(1)

try:
    import numpy as np
except ImportError:
    print("❌ 无法导入 numpy，请安装：pip install numpy")
    sys.exit(1)

# 配置
SQLITE_DB = "/root/.openclaw/workspace/agents/database-manager/data/customer-service.db"
LANCEDB_URI = "/root/.openclaw/workspace/agents/database-manager/data/knowledge_vectors"
EMBEDDING_DIM = 384  # 使用较小的模型维度


def get_simple_embedding(text: str) -> List[float]:
    """
    简单的嵌入生成（用于演示）
    
    实际生产环境应使用:
    - sentence-transformers
    - text-embedding-ada-002
    - bge-large-zh
    """
    # 简单的哈希嵌入（仅用于演示，实际应使用真正的嵌入模型）
    hash_bytes = hashlib.md5(text.encode()).digest()
    # 扩展到 EMBEDDING_DIM 维
    vector = list(hash_bytes) * (EMBEDDING_DIM // 16 + 1)
    # 归一化到 -1 到 1
    vector = [(x - 128) / 128.0 for x in vector[:EMBEDDING_DIM]]
    return vector


def get_connection():
    """获取 SQLite 连接"""
    conn = sqlite3.connect(SQLITE_DB)
    conn.row_factory = sqlite3.Row
    return conn


def fetch_knowledge(conn) -> List[Dict[str, Any]]:
    """从 SQLite 获取知识条目"""
    cursor = conn.cursor()
    cursor.execute("""
        SELECT knowledge_id, title, content, category, subcategory, 
               tags, metadata, min_permission_level
        FROM knowledge_base
        WHERE deleted_at IS NULL
    """)
    
    rows = cursor.fetchall()
    return [dict(row) for row in rows]


def build_vectors(knowledge_list: List[Dict]) -> List[Dict]:
    """为知识条目生成向量"""
    
    vectors = []
    
    for kb in knowledge_list:
        # 组合文本（标题 + 内容）
        text = f"{kb['title']}\n\n{kb['content']}"
        
        # 生成向量
        vector = get_simple_embedding(text)
        
        # 构建记录
        record = {
            'id': kb['knowledge_id'],
            'vector': vector,
            'content': text,
            'metadata': json.dumps({
                'title': kb['title'],
                'category': kb['category'],
                'subcategory': kb['subcategory'],
                'tags': kb['tags'],
                'permission_level': kb['min_permission_level']
            }),
            'knowledge_id': kb['knowledge_id']
        }
        
        vectors.append(record)
    
    return vectors


def build_index(force_rebuild: bool = False):
    """构建向量索引"""
    
    print("=" * 60)
    print("🔧 构建知识库向量索引")
    print("=" * 60)
    
    # 1. 读取知识条目
    print("\n📖 读取知识条目...")
    conn = get_connection()
    knowledge_list = fetch_knowledge(conn)
    print(f"   📊 找到 {len(knowledge_list)} 条知识")
    
    if not knowledge_list:
        print("   ⚠️  知识库为空，请先导入知识")
        conn.close()
        return
    
    # 2. 生成向量
    print("\n🧮 生成向量嵌入...")
    vectors = build_vectors(knowledge_list)
    print(f"   ✅ 已生成 {len(vectors)} 个向量（维度：{EMBEDDING_DIM}）")
    
    # 3. 连接到 LanceDB
    print(f"\n🔗 连接到 LanceDB ({LANCEDB_URI})...")
    client = LanceDBClient(uri=LANCEDB_URI)
    client.connect()
    print("   ✅ 连接成功")
    
    # 4. 创建或打开表
    table_name = "knowledge_vectors"
    print(f"\n📋 打开向量表：{table_name}...")
    
    try:
        table = client.open_table(table_name)
        if force_rebuild:
            print("   ⚠️  强制重建，删除旧表...")
            client.db.drop_table(table_name)
            table = None
    except:
        table = None
    
    if table is None:
        print("   📝 创建新表...")
        import pyarrow as pa
        schema = pa.schema([
            pa.field('id', pa.string()),
            pa.field('vector', pa.list_(pa.float32(), EMBEDDING_DIM)),
            pa.field('content', pa.string()),
            pa.field('metadata', pa.string()),
            pa.field('knowledge_id', pa.string())
        ])
        table = client.create_table(table_name, schema=schema)
        print("   ✅ 表创建成功")
    else:
        print("   ✅ 使用已有表")
    
    # 5. 插入向量
    print(f"\n💾 插入 {len(vectors)} 个向量...")
    
    if len(vectors) > 0:
        # 转换为 PyArrow 表
        import pyarrow as pa
        
        ids = [v['id'] for v in vectors]
        vector_data = [v['vector'] for v in vectors]
        contents = [v['content'] for v in vectors]
        metadatas = [v['metadata'] for v in vectors]
        knowledge_ids = [v['knowledge_id'] for v in vectors]
        
        arrow_table = pa.table({
            'id': ids,
            'vector': vector_data,
            'content': contents,
            'metadata': metadatas,
            'knowledge_id': knowledge_ids
        })
        
        # 插入数据
        table.add(arrow_table)
        print("   ✅ 向量插入成功")
    
    # 6. 验证
    print("\n🔍 验证索引...")
    count = table.count_rows()
    print(f"   📊 向量总数：{count}")
    
    # 7. 测试检索
    print("\n🧪 测试检索...")
    test_query = "GPU 温度过高"
    test_vector = get_simple_embedding(test_query)
    
    results = table.search(test_vector).limit(3).to_pandas()
    
    if len(results) > 0:
        print(f"   ✅ 检索测试成功（找到 {len(results)} 条结果）")
        print(f"   示例结果:")
        for idx, row in results.iterrows():
            print(f"      - {row['id']}")
    else:
        print("   ⚠️  检索测试无结果")
    
    conn.close()
    
    print("\n" + "=" * 60)
    print("✅ 向量索引构建完成！")
    print("=" * 60)
    print(f"\n📊 统计:")
    print(f"   - 知识条目：{len(knowledge_list)}")
    print(f"   - 向量维度：{EMBEDDING_DIM}")
    print(f"   - LanceDB 路径：{LANCEDB_URI}")
    print("\n💡 提示:")
    print("   - 使用 search_knowledge_vector() 进行语义检索")
    print("   - 定期运行此脚本更新索引")


if __name__ == "__main__":
    force = "--force" in sys.argv or "-f" in sys.argv
    build_index(force_rebuild=force)
