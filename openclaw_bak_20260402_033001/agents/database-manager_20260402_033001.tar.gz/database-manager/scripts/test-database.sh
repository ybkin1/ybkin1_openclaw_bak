#!/bin/bash
# ============================================================
# 数据库记忆架构测试脚本
# 用途：验证 customer-service 数据库功能
# ============================================================

DB_PATH="/root/.openclaw/workspace/agents/database-manager/data/customer-service.db"

echo "📊 数据库记忆架构测试"
echo "============================================================"
echo ""

# 1. 检查数据库文件
echo "1️⃣ 检查数据库文件..."
if [ -f "$DB_PATH" ]; then
    echo "   ✅ 数据库文件存在：$DB_PATH"
    echo "   📦 文件大小：$(du -h $DB_PATH | cut -f1)"
else
    echo "   ❌ 数据库文件不存在！"
    exit 1
fi
echo ""

# 2. 检查表结构
echo "2️⃣ 检查表结构..."
TABLES=$(sqlite3 $DB_PATH ".tables" | wc -w)
echo "   📋 表数量：$TABLES"
sqlite3 $DB_PATH ".tables" | sed 's/^/      /'
echo ""

# 3. 测试用户 CRUD
echo "3️⃣ 测试用户 CRUD 操作..."

# 创建测试用户
sqlite3 $DB_PATH "INSERT OR REPLACE INTO users (user_id, name, user_type, permission_level, channel, channel_user_id) 
VALUES ('test_001', '测试用户', 'regular', 1, 'wecom', 'ou_test_001');"
echo "   ✅ 创建测试用户：test_001"

# 查询用户
USER=$(sqlite3 $DB_PATH "SELECT name, user_type, channel FROM users WHERE user_id = 'test_001';")
echo "   📖 查询用户：$USER"

# 更新用户
sqlite3 $DB_PATH "UPDATE users SET last_active_at = datetime('now') WHERE user_id = 'test_001';"
echo "   ✏️ 更新用户：last_active_at"

# 4. 测试会话记录
echo ""
echo "4️⃣ 测试会话记录..."

sqlite3 $DB_PATH "INSERT INTO conversations (conversation_id, user_id, channel, role, content, metadata) 
VALUES ('conv_test_001', 'test_001', 'wecom', 'user', '服务器报错了', '{\"intent\":\"fault_analysis\"}');"
echo "   ✅ 创建会话记录：conv_test_001"

CONV_COUNT=$(sqlite3 $DB_PATH "SELECT COUNT(*) FROM conversations WHERE user_id = 'test_001';")
echo "   📊 用户会话数：$CONV_COUNT"

# 5. 测试用户记忆
echo ""
echo "5️⃣ 测试用户记忆..."

sqlite3 $DB_PATH "INSERT INTO user_memories (memory_id, user_id, memory_type, subject, predicate, object, confidence) 
VALUES ('mem_test_001', 'test_001', 'fact', 'server_assets', 'owns', '3x M4 servers', 0.95);"
echo "   ✅ 创建用户记忆：mem_test_001"

MEMORIES=$(sqlite3 $DB_PATH "SELECT subject, object FROM user_memories WHERE user_id = 'test_001';")
echo "   📖 用户记忆：$MEMORIES"

# 6. 测试工单
echo ""
echo "6️⃣ 测试工单操作..."

sqlite3 $DB_PATH "INSERT INTO tickets (ticket_id, user_id, title, status, category, priority) 
VALUES ('ticket_test_001', 'test_001', '服务器故障分析', 'pending', 'fault', 2);"
echo "   ✅ 创建工单：ticket_test_001"

TICKET_STATUS=$(sqlite3 $DB_PATH "SELECT title, status FROM tickets WHERE ticket_id = 'ticket_test_001';")
echo "   📖 工单状态：$TICKET_STATUS"

# 7. 测试知识库
echo ""
echo "7️⃣ 测试知识库..."

sqlite3 $DB_PATH "INSERT INTO knowledge_base (knowledge_id, category, subcategory, title, content, min_permission_level) 
VALUES ('kb_test_001', 'fault', 'gpu_overheat', 'GPU 过热解决方案', '检查风扇和散热片', 1);"
echo "   ✅ 创建知识库条目：kb_test_001"

KB_COUNT=$(sqlite3 $DB_PATH "SELECT COUNT(*) FROM knowledge_base WHERE min_permission_level <= 1;")
echo "   📊 可访问知识库数：$KB_COUNT"

# 8. 测试视图
echo ""
echo "8️⃣ 测试视图..."

PROFILE=$(sqlite3 $DB_PATH "SELECT name, total_tickets, total_conversations, total_memories FROM v_user_profile WHERE user_id = 'test_001';")
echo "   📖 用户画像：$PROFILE"

# 9. 测试访问日志
echo ""
echo "9️⃣ 测试访问日志..."

sqlite3 $DB_PATH "INSERT INTO access_logs (log_id, user_id, agent_id, table_name, action, success) 
VALUES ('log_test_001', 'test_001', 'customer-service', 'users', 'create', 1);"
LOG_COUNT=$(sqlite3 $DB_PATH "SELECT COUNT(*) FROM access_logs WHERE user_id = 'test_001';")
echo "   📊 访问日志数：$LOG_COUNT"

# 10. 清理测试数据
echo ""
echo "🧹 清理测试数据..."
sqlite3 $DB_PATH "DELETE FROM access_logs WHERE user_id = 'test_001';"
sqlite3 $DB_PATH "DELETE FROM user_memories WHERE user_id = 'test_001';"
sqlite3 $DB_PATH "DELETE FROM conversations WHERE user_id = 'test_001';"
sqlite3 $DB_PATH "DELETE FROM tickets WHERE user_id = 'test_001';"
sqlite3 $DB_PATH "DELETE FROM knowledge_base WHERE knowledge_id = 'kb_test_001';"
sqlite3 $DB_PATH "DELETE FROM users WHERE user_id = 'test_001';"
echo "   ✅ 测试数据已清理"

# 11. 数据库完整性检查
echo ""
echo "🔍 数据库完整性检查..."
INTEGRITY=$(sqlite3 $DB_PATH "PRAGMA integrity_check;")
if [ "$INTEGRITY" = "ok" ]; then
    echo "   ✅ 数据库完整性：ok"
else
    echo "   ❌ 数据库完整性：$INTEGRITY"
fi

# 12. 统计信息
echo ""
echo "📊 数据库统计信息："
echo "   - users: $(sqlite3 $DB_PATH 'SELECT COUNT(*) FROM users;') 行"
echo "   - conversations: $(sqlite3 $DB_PATH 'SELECT COUNT(*) FROM conversations;') 行"
echo "   - user_memories: $(sqlite3 $DB_PATH 'SELECT COUNT(*) FROM user_memories;') 行"
echo "   - tickets: $(sqlite3 $DB_PATH 'SELECT COUNT(*) FROM tickets;') 行"
echo "   - knowledge_base: $(sqlite3 $DB_PATH 'SELECT COUNT(*) FROM knowledge_base;') 行"
echo "   - access_logs: $(sqlite3 $DB_PATH 'SELECT COUNT(*) FROM access_logs;') 行"

echo ""
echo "============================================================"
echo "✅ 所有测试通过！"
echo ""
