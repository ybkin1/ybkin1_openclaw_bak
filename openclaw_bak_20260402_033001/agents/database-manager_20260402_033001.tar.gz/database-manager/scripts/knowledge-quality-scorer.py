#!/usr/bin/env python3
"""
知识质量评分系统

评分维度:
1. 完整性（内容长度、结构）
2. 准确性（是否有代码/命令验证）
3. 实用性（阅读量、点赞数）
4. 时效性（更新时间）
5. 用户反馈（评分、评论）

综合评分 = 完整性*20% + 准确性*25% + 实用性*25% + 时效性*15% + 反馈*15%
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any

DB_PATH = "/root/.openclaw/workspace/agents/database-manager/data/customer-service.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def calculate_quality_score(knowledge: Dict) -> float:
    """
    计算知识条目质量评分（0-5 分）
    
    评分维度:
    1. 完整性 (20%): 内容长度、结构
    2. 准确性 (25%): 是否有代码/命令验证
    3. 实用性 (25%): 阅读量、使用次数
    4. 时效性 (15%): 更新时间
    5. 反馈 (15%): 用户评分
    """
    
    scores = {
        'completeness': 0.0,
        'accuracy': 0.0,
        'utility': 0.0,
        'timeliness': 0.0,
        'feedback': 0.0
    }
    
    # 1. 完整性评分 (20%)
    content = knowledge.get('content', '')
    content_length = len(content)
    
    if content_length >= 1000:
        scores['completeness'] = 5.0
    elif content_length >= 500:
        scores['completeness'] = 4.0
    elif content_length >= 200:
        scores['completeness'] = 3.0
    elif content_length >= 100:
        scores['completeness'] = 2.0
    else:
        scores['completeness'] = 1.0
    
    # 检查结构（标题、列表、代码块）
    structure_score = 0
    if '# ' in content or '## ' in content:
        structure_score += 2
    if '- ' in content or '* ' in content:
        structure_score += 1
    if '```' in content or '`' in content:
        structure_score += 2
    if '步骤' in content or '流程' in content:
        structure_score += 1
    
    scores['completeness'] = min(5.0, scores['completeness'] + structure_score * 0.2)
    
    # 2. 准确性评分 (25%)
    accuracy_indicators = 0
    
    # 检查是否有具体命令/代码
    if 'nvidia-smi' in content or 'ipmitool' in content:
        accuracy_indicators += 2
    if '```' in content:
        accuracy_indicators += 1
    if '检查' in content and '解决' in content:
        accuracy_indicators += 1
    if '原因' in content or '可能' in content:
        accuracy_indicators += 1
    
    scores['accuracy'] = min(5.0, accuracy_indicators)
    
    # 3. 实用性评分 (25%)
    usage_count = knowledge.get('usage_count', 0)
    
    if usage_count >= 100:
        scores['utility'] = 5.0
    elif usage_count >= 50:
        scores['utility'] = 4.0
    elif usage_count >= 20:
        scores['utility'] = 3.0
    elif usage_count >= 5:
        scores['utility'] = 2.0
    else:
        # 新知识默认 2.5 分
        scores['utility'] = 2.5
    
    # 4. 时效性评分 (15%)
    updated_at = knowledge.get('updated_at', knowledge.get('created_at', ''))
    
    if updated_at:
        try:
            # 解析时间（简化处理）
            update_date = datetime.fromisoformat(updated_at.replace('Z', '+00:00'))
            days_old = (datetime.now() - update_date).days
            
            if days_old <= 30:
                scores['timeliness'] = 5.0
            elif days_old <= 90:
                scores['timeliness'] = 4.0
            elif days_old <= 180:
                scores['timeliness'] = 3.0
            elif days_old <= 365:
                scores['timeliness'] = 2.0
            else:
                scores['timeliness'] = 1.0
        except:
            scores['timeliness'] = 3.0  # 无法解析时给平均分
    else:
        scores['timeliness'] = 3.0
    
    # 5. 反馈评分 (15%)
    # 从 knowledge_usage_log 中获取平均评分
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT AVG(rating) as avg_rating, COUNT(*) as rating_count
        FROM knowledge_usage_log
        WHERE knowledge_id = ? AND rating IS NOT NULL
    """, [knowledge['knowledge_id']])
    
    row = cursor.fetchone()
    conn.close()
    
    avg_rating = row['avg_rating'] if row['avg_rating'] else 0
    rating_count = row['rating_count'] if row['rating_count'] else 0
    
    if rating_count >= 10:
        scores['feedback'] = avg_rating if avg_rating else 3.0
    elif rating_count >= 5:
        scores['feedback'] = avg_rating if avg_rating else 3.0
    else:
        # 评分数量不足时，给平均分
        scores['feedback'] = 3.0
    
    # 计算加权总分
    weights = {
        'completeness': 0.20,
        'accuracy': 0.25,
        'utility': 0.25,
        'timeliness': 0.15,
        'feedback': 0.15
    }
    
    total_score = sum(scores[dim] * weights[dim] for dim in scores)
    
    # 四舍五入到 2 位小数
    return round(total_score, 2)

def update_all_quality_scores():
    """更新所有知识条目的质量评分"""
    
    print("=" * 60)
    print("📊 知识质量评分系统")
    print("=" * 60)
    
    conn = get_connection()
    cursor = conn.cursor()
    
    # 获取所有知识
    cursor.execute("""
        SELECT knowledge_id, title, content, usage_count, 
               created_at, updated_at, quality_score
        FROM knowledge_base
        WHERE deleted_at IS NULL
    """)
    
    knowledge_list = [dict(row) for row in cursor.fetchall()]
    
    print(f"\n📖 找到 {len(knowledge_list)} 条知识")
    print("\n🔍 计算质量评分...")
    
    updated_count = 0
    scores = []
    
    for kb in knowledge_list:
        # 计算新评分
        new_score = calculate_quality_score(kb)
        old_score = kb.get('quality_score', 0) or 0
        
        # 如果评分变化超过 0.1，更新数据库
        if abs(new_score - old_score) > 0.1:
            cursor.execute("""
                UPDATE knowledge_base
                SET quality_score = ?, updated_at = CURRENT_TIMESTAMP
                WHERE knowledge_id = ?
            """, [new_score, kb['knowledge_id']])
            updated_count += 1
        
        scores.append({
            'id': kb['knowledge_id'],
            'title': kb['title'][:30],
            'score': new_score,
            'change': new_score - old_score
        })
    
    conn.commit()
    conn.close()
    
    # 打印结果
    print(f"\n✅ 已更新 {updated_count} 条知识的评分")
    
    # 按评分排序
    scores.sort(key=lambda x: x['score'], reverse=True)
    
    print("\n📊 质量评分排行:")
    print("-" * 60)
    for i, s in enumerate(scores[:10], 1):
        change_str = f"({s['change']:+.2f})" if abs(s['change']) > 0.1 else ""
        print(f"{i:2d}. ⭐ {s['score']:.2f} {change_str:8s} - {s['title']}")
    
    # 统计分布
    excellent = sum(1 for s in scores if s['score'] >= 4.5)
    good = sum(1 for s in scores if 4.0 <= s['score'] < 4.5)
    average = sum(1 for s in scores if 3.0 <= s['score'] < 4.0)
    poor = sum(1 for s in scores if s['score'] < 3.0)
    
    print("\n📈 评分分布:")
    print(f"   优秀 (≥4.5): {excellent} 条")
    print(f"   良好 (4.0-4.5): {good} 条")
    print(f"   一般 (3.0-4.0): {average} 条")
    print(f"   待改进 (<3.0): {poor} 条")
    
    print("\n" + "=" * 60)
    
    return scores

def get_low_quality_knowledge(threshold: float = 3.0) -> List[Dict]:
    """获取低质量知识列表"""
    
    conn = get_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT knowledge_id, title, quality_score, usage_count
        FROM knowledge_base
        WHERE deleted_at IS NULL
        AND (quality_score < ? OR quality_score IS NULL)
        ORDER BY quality_score ASC
    """, [threshold])
    
    rows = cursor.fetchall()
    conn.close()
    
    return [dict(row) for row in rows]

if __name__ == "__main__":
    update_all_quality_scores()
    
    # 检查低质量知识
    print("\n⚠️  低质量知识（需要改进）:")
    low_quality = get_low_quality_knowledge(threshold=3.5)
    
    if low_quality:
        for kb in low_quality[:5]:
            print(f"   - {kb['title']} (评分：{kb['quality_score'] or 'N/A'})")
    else:
        print("   ✅ 没有低质量知识！")
