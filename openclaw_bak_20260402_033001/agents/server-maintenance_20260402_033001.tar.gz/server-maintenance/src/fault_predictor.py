#!/usr/bin/env python3
"""
故障趋势预测模块
功能：基于历史数据预测潜在故障
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger('fault_predictor')


class FaultPredictor:
    """故障预测器"""
    
    def __init__(self):
        self.history_dir = Path("/root/.openclaw/workspace/agents/server-maintenance/fault_history")
        self.history_dir.mkdir(parents=True, exist_ok=True)
        
        # 故障模式定义
        self.fault_patterns = {
            "gpu_fault_trend": {
                "description": "GPU 故障率趋势",
                "check_window_days": 7,
                "threshold_increase": 0.2  # 20% 增长
            },
            "disk_error_trend": {
                "description": "磁盘错误率趋势",
                "check_window_days": 7,
                "threshold_increase": 0.3  # 30% 增长
            },
            "temperature_trend": {
                "description": "温度上升趋势",
                "check_window_days": 3,
                "threshold_increase": 5  # 5°C 增长
            },
            "memory_leak_trend": {
                "description": "内存泄漏趋势",
                "check_window_days": 1,
                "threshold_increase": 0.1  # 10% 增长
            }
        }
    
    def predict_faults(self) -> List[Dict]:
        """预测潜在故障"""
        predictions = []
        
        for pattern_id, pattern_config in self.fault_patterns.items():
            prediction = self._analyze_pattern(pattern_id, pattern_config)
            if prediction:
                predictions.append(prediction)
        
        return predictions
    
    def _analyze_pattern(self, pattern_id: str, pattern_config: Dict) -> Optional[Dict]:
        """分析故障模式"""
        if pattern_id == "gpu_fault_trend":
            return self._analyze_gpu_fault_trend(pattern_config)
        
        elif pattern_id == "disk_error_trend":
            return self._analyze_disk_error_trend(pattern_config)
        
        elif pattern_id == "temperature_trend":
            return self._analyze_temperature_trend(pattern_config)
        
        elif pattern_id == "memory_leak_trend":
            return self._analyze_memory_leak_trend(pattern_config)
        
        return None
    
    def _analyze_gpu_fault_trend(self, config: Dict) -> Optional[Dict]:
        """分析 GPU 故障率趋势"""
        # TODO: 实现实际的历史数据分析
        # 这里使用模拟数据
        
        current_fault_rate = 0.05  # 5%
        previous_fault_rate = 0.03  # 3%
        
        increase_rate = (current_fault_rate - previous_fault_rate) / previous_fault_rate
        
        if increase_rate > config["threshold_increase"]:
            return {
                "type": "gpu_fault_trend",
                "severity": "high",
                "title": "⚠️ GPU 故障率上升",
                "description": f"GPU 故障率从 {previous_fault_rate*100:.1f}% 上升到 {current_fault_rate*100:.1f}%，增长 {increase_rate*100:.1f}%",
                "recommendation": """**建议**:
1. 检查 GPU 状态：`nvidia-smi`
2. 查看 GPU 日志：`dmesg | grep -i nvidia`
3. 检查 GPU 温度和功耗
4. 准备备件""",
                "confidence": 0.8
            }
        
        return None
    
    def _analyze_disk_error_trend(self, config: Dict) -> Optional[Dict]:
        """分析磁盘错误率趋势"""
        # TODO: 实现实际的历史数据分析
        
        current_error_rate = 0.02
        previous_error_rate = 0.01
        
        increase_rate = (current_error_rate - previous_error_rate) / previous_error_rate
        
        if increase_rate > config["threshold_increase"]:
            return {
                "type": "disk_error_trend",
                "severity": "medium",
                "title": "⚠️ 磁盘错误率上升",
                "description": f"磁盘错误率从 {previous_error_rate*100:.1f}% 上升到 {current_error_rate*100:.1f}%",
                "recommendation": """**建议**:
1. 检查磁盘健康：`smartctl -a /dev/sda`
2. 查看磁盘日志：`dmesg | grep -i error`
3. 备份重要数据
4. 准备更换磁盘""",
                "confidence": 0.7
            }
        
        return None
    
    def _analyze_temperature_trend(self, config: Dict) -> Optional[Dict]:
        """分析温度上升趋势"""
        import subprocess
        
        try:
            # 获取当前 GPU 温度
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=10
            )
            
            temperatures = [int(t.strip()) for t in result.stdout.strip().split('\n')]
            avg_temperature = sum(temperatures) / len(temperatures)
            
            # 读取历史温度
            history = self._load_temperature_history()
            
            if history:
                previous_avg = sum(history[-10:]) / min(10, len(history))
                
                if avg_temperature - previous_avg > config["threshold_increase"]:
                    return {
                        "type": "temperature_trend",
                        "severity": "medium",
                        "title": "⚠️ GPU 温度上升",
                        "description": f"GPU 平均温度从 {previous_avg:.1f}°C 上升到 {avg_temperature:.1f}°C",
                        "recommendation": """**建议**:
1. 检查散热器和风扇
2. 清理灰尘
3. 改善机房散热
4. 降低 GPU 负载""",
                        "confidence": 0.9
                    }
            
            # 保存当前温度
            self._save_temperature(avg_temperature)
        
        except Exception as e:
            logger.error(f"分析温度趋势失败：{e}")
        
        return None
    
    def _analyze_memory_leak_trend(self, config: Dict) -> Optional[Dict]:
        """分析内存泄漏趋势"""
        import subprocess
        
        try:
            # 获取当前内存使用率
            result = subprocess.run(
                ["free", "-m"],
                capture_output=True, text=True, timeout=10
            )
            
            mem_line = result.stdout.split('\n')[1]
            mem_parts = mem_line.split()
            total = float(mem_parts[1])
            used = float(mem_parts[2])
            current_usage = (used / total) * 100
            
            # 读取历史内存使用率
            history = self._load_memory_history()
            
            if history:
                previous_usage = history[-1] if history else current_usage
                
                if current_usage - previous_usage > config["threshold_increase"] * 100:
                    return {
                        "type": "memory_leak_trend",
                        "severity": "medium",
                        "title": "⚠️ 内存使用率持续上升",
                        "description": f"内存使用率从 {previous_usage:.1f}% 上升到 {current_usage:.1f}%",
                        "recommendation": """**建议**:
1. 检查内存占用进程：`top`
2. 清理缓存：`sync; echo 3 > /proc/sys/vm/drop_caches`
3. 检查内存泄漏
4. 重启服务""",
                        "confidence": 0.7
                    }
            
            # 保存当前内存使用率
            self._save_memory(current_usage)
        
        except Exception as e:
            logger.error(f"分析内存泄漏趋势失败：{e}")
        
        return None
    
    def _load_temperature_history(self) -> List[float]:
        """加载温度历史"""
        history_file = self.history_dir / "temperature_history.json"
        if history_file.exists():
            with open(history_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def _save_temperature(self, temperature: float):
        """保存温度"""
        history_file = self.history_dir / "temperature_history.json"
        
        history = self._load_temperature_history()
        history.append(temperature)
        
        # 保留最近 100 条记录
        history = history[-100:]
        
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f)
    
    def _load_memory_history(self) -> List[float]:
        """加载内存历史"""
        history_file = self.history_dir / "memory_history.json"
        if history_file.exists():
            with open(history_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def _save_memory(self, usage: float):
        """保存内存使用率"""
        history_file = self.history_dir / "memory_history.json"
        
        history = self._load_memory_history()
        history.append(usage)
        
        # 保留最近 100 条记录
        history = history[-100:]
        
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f)
    
    def generate_prediction_report(self) -> str:
        """生成预测报告"""
        predictions = self.predict_faults()
        
        report = f"""# 故障趋势预测报告

**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 预测结果

"""
        
        if predictions:
            for i, pred in enumerate(predictions, 1):
                report += f"""### {i}. {pred['title']}
- 严重性：{pred['severity']}
- 置信度：{pred['confidence']*100:.0f}%
- 描述：{pred['description']}
{pred['recommendation']}

"""
        else:
            report += "✅ 未检测到潜在故障趋势，系统运行正常。\n"
        
        return report


# 全局实例
fault_predictor = FaultPredictor()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python fault_predictor.py <command>")
        print("命令:")
        print("  predict - 预测故障")
        print("  report - 生成报告")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "predict":
        predictions = fault_predictor.predict_faults()
        if predictions:
            print(f"检测到 {len(predictions)} 个潜在故障:\n")
            for pred in predictions:
                print(f"{pred['title']}")
                print(f"  {pred['description']}\n")
        else:
            print("✅ 未检测到潜在故障")
    
    elif command == "report":
        report = fault_predictor.generate_prediction_report()
        print(report)
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
