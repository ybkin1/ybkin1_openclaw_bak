#!/usr/bin/env python3
"""
自动修复模块
功能：自动修复常见故障
"""

import json
import logging
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger('auto_fix')


class AutoFixManager:
    """自动修复管理器"""
    
    def __init__(self):
        self.fix_history_dir = Path("/root/.openclaw/workspace/agents/server-maintenance/fix_history")
        self.fix_history_dir.mkdir(parents=True, exist_ok=True)
        
        # 可自动修复的问题列表
        self.fixable_issues = {
            "gateway_stopped": {
                "check_command": "systemctl --user is-active openclaw-gateway",
                "fix_command": "systemctl --user restart openclaw-gateway",
                "description": "Gateway 服务停止",
                "auto_fix": True
            },
            "health_guardian_stopped": {
                "check_command": "systemctl --user is-active openclaw-health-guardian",
                "fix_command": "systemctl --user restart openclaw-health-guardian",
                "description": "Health Guardian 服务停止",
                "auto_fix": True
            },
            "disk_full_logs": {
                "check_command": "df -h / | awk 'NR==2 {print $5}' | tr -d '%'",
                "fix_command": "find /root/.openclaw/logs -mtime +7 -delete",
                "description": "磁盘满（日志过多）",
                "auto_fix": True
            },
            "memory_cache_full": {
                "check_command": "free -m | awk 'NR==2 {printf \"%.0f\", $3*100/$2}'",
                "fix_command": "sync; echo 3 > /proc/sys/vm/drop_caches",
                "description": "内存缓存满",
                "auto_fix": True
            },
            "docker_stopped": {
                "check_command": "systemctl is-active docker",
                "fix_command": "systemctl restart docker",
                "description": "Docker 服务停止",
                "auto_fix": True
            }
        }
    
    def check_and_fix(self) -> List[Dict]:
        """
        检查并自动修复问题
        
        Returns:
            修复结果列表
        """
        fixes = []
        
        for issue_id, issue_config in self.fixable_issues.items():
            result = self._check_issue(issue_id, issue_config)
            if result:
                fixes.append(result)
        
        return fixes
    
    def _check_issue(self, issue_id: str, issue_config: Dict) -> Optional[Dict]:
        """检查并修复单个问题"""
        try:
            # 检查问题
            check_result = self._run_command(issue_config["check_command"])
            
            # 判断是否有问题
            has_issue = self._evaluate_check_result(issue_id, check_result)
            
            if has_issue:
                logger.info(f"发现问题：{issue_id}")
                
                # 是否自动修复
                if issue_config.get("auto_fix", False):
                    fix_result = self._fix_issue(issue_id, issue_config)
                    self._record_fix(issue_id, fix_result)
                    return fix_result
                else:
                    return {
                        "issue_id": issue_id,
                        "description": issue_config["description"],
                        "auto_fix": False,
                        "message": f"发现问题：{issue_config['description']}，需要手动修复"
                    }
        
        except Exception as e:
            logger.error(f"检查问题 {issue_id} 失败：{e}")
            return None
        
        return None
    
    def _evaluate_check_result(self, issue_id: str, result: str) -> bool:
        """评估检查结果"""
        if issue_id == "gateway_stopped":
            return result.strip() != "active"
        
        elif issue_id == "health_guardian_stopped":
            return result.strip() != "active"
        
        elif issue_id == "disk_full_logs":
            try:
                usage = int(result.strip())
                return usage > 90
            except:
                return False
        
        elif issue_id == "memory_cache_full":
            try:
                usage = int(result.strip())
                return usage > 90
            except:
                return False
        
        elif issue_id == "docker_stopped":
            return result.strip() != "active"
        
        return False
    
    def _fix_issue(self, issue_id: str, issue_config: Dict) -> Dict:
        """修复问题"""
        try:
            logger.info(f"修复问题：{issue_id}")
            
            # 执行修复命令
            fix_result = self._run_command(issue_config["fix_command"])
            
            # 验证修复
            check_result = self._run_command(issue_config["check_command"])
            is_fixed = not self._evaluate_check_result(issue_id, check_result)
            
            return {
                "issue_id": issue_id,
                "description": issue_config["description"],
                "success": is_fixed,
                "auto_fix": True,
                "message": f"{'✅ 已自动修复' if is_fixed else '⚠️ 修复失败'}: {issue_config['description']}",
                "fix_command": issue_config["fix_command"],
                "timestamp": datetime.now().isoformat()
            }
        
        except Exception as e:
            logger.error(f"修复问题 {issue_id} 失败：{e}")
            return {
                "issue_id": issue_id,
                "description": issue_config["description"],
                "success": False,
                "auto_fix": True,
                "message": f"❌ 修复失败：{str(e)}",
                "timestamp": datetime.now().isoformat()
            }
    
    def _run_command(self, command: str) -> str:
        """执行命令"""
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        return result.stdout
    
    def _record_fix(self, issue_id: str, fix_result: Dict):
        """记录修复历史"""
        history_file = self.fix_history_dir / f"{datetime.now().strftime('%Y%m%d')}.json"
        
        history = []
        if history_file.exists():
            with open(history_file, 'r', encoding='utf-8') as f:
                history = json.load(f)
        
        history.append(fix_result)
        
        with open(history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    
    def get_fix_history(self, days: int = 7) -> List[Dict]:
        """获取修复历史"""
        history = []
        
        for i in range(days):
            date = datetime.now()
            date = date.replace(day=date.day - i)
            history_file = self.fix_history_dir / f"{date.strftime('%Y%m%d')}.json"
            
            if history_file.exists():
                with open(history_file, 'r', encoding='utf-8') as f:
                    history.extend(json.load(f))
        
        return history
    
    def generate_fix_report(self) -> str:
        """生成修复报告"""
        history = self.get_fix_history(30)
        
        report = f"""# 自动修复报告

**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**统计周期**: 最近 30 天

## 修复统计

- 总修复次数：{len(history)}
- 成功修复：{sum(1 for h in history if h.get('success', False))}
- 修复失败：{sum(1 for h in history if not h.get('success', False))}

## 问题分布

"""
        
        # 按问题类型统计
        issue_counts = {}
        for fix in history:
            issue_id = fix.get("issue_id", "unknown")
            issue_counts[issue_id] = issue_counts.get(issue_id, 0) + 1
        
        for issue_id, count in sorted(issue_counts.items(), key=lambda x: x[1], reverse=True):
            issue_config = self.fixable_issues.get(issue_id, {})
            report += f"- {issue_config.get('description', issue_id)}: {count} 次\n"
        
        report += "\n## 最近修复记录\n\n"
        
        for fix in history[-10:]:
            report += f"- {fix.get('timestamp', 'N/A')}: {fix.get('description', 'N/A')} - {'✅' if fix.get('success') else '❌'}\n"
        
        return report


# 全局实例
auto_fix_manager = AutoFixManager()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python auto_fix.py <command>")
        print("命令:")
        print("  check - 检查并修复")
        print("  history [days] - 查看历史")
        print("  report - 生成报告")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "check":
        fixes = auto_fix_manager.check_and_fix()
        if fixes:
            print("发现并修复的问题:")
            for fix in fixes:
                print(f"  - {fix['description']}: {fix['message']}")
        else:
            print("✅ 系统正常，无需修复")
    
    elif command == "history":
        days = int(sys.argv[2]) if len(sys.argv) > 2 else 7
        history = auto_fix_manager.get_fix_history(days)
        print(json.dumps(history, ensure_ascii=False, indent=2))
    
    elif command == "report":
        report = auto_fix_manager.generate_fix_report()
        print(report)
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
