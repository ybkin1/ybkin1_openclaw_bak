#!/usr/bin/env python3
"""
性能优化建议模块
功能：分析系统性能，提供优化建议
"""

import json
import logging
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger('performance_advisor')


class PerformanceAdvisor:
    """性能优化顾问"""
    
    def __init__(self):
        self.metrics_dir = Path("/root/.openclaw/workspace/agents/server-maintenance/metrics")
        self.metrics_dir.mkdir(parents=True, exist_ok=True)
        
        # 性能阈值
        self.thresholds = {
            "cpu_usage": 80,        # CPU 使用率阈值 (%)
            "memory_usage": 80,     # 内存使用率阈值 (%)
            "disk_usage": 80,       # 磁盘使用率阈值 (%)
            "gpu_temperature": 80,  # GPU 温度阈值 (°C)
            "gpu_memory_usage": 90, # GPU 显存使用率阈值 (%)
            "gpu_power_usage": 90   # GPU 功耗使用率阈值 (%)
        }
    
    def analyze_system_performance(self) -> Dict:
        """
        分析系统性能
        
        Returns:
            性能分析报告
        """
        metrics = self._collect_metrics()
        recommendations = self._analyze_metrics(metrics)
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "metrics": metrics,
            "recommendations": recommendations,
            "health_score": self._calculate_health_score(metrics)
        }
        
        # 保存指标
        self._save_metrics(metrics)
        
        return report
    
    def _collect_metrics(self) -> Dict:
        """收集系统指标"""
        metrics = {}
        
        # CPU 使用率
        try:
            result = subprocess.run(
                ["top", "-bn1"],
                capture_output=True, text=True, timeout=10
            )
            cpu_line = [line for line in result.stdout.split('\n') if 'Cpu(s)' in line]
            if cpu_line:
                cpu_parts = cpu_line[0].split(',')
                cpu_usage = float(cpu_parts[0].split(':')[1].strip().split()[0])
                metrics["cpu_usage"] = cpu_usage
        except Exception as e:
            logger.error(f"收集 CPU 指标失败：{e}")
            metrics["cpu_usage"] = None
        
        # 内存使用率
        try:
            result = subprocess.run(
                ["free", "-m"],
                capture_output=True, text=True, timeout=10
            )
            mem_line = result.stdout.split('\n')[1]
            mem_parts = mem_line.split()
            total = float(mem_parts[1])
            used = float(mem_parts[2])
            metrics["memory_usage"] = (used / total) * 100
            metrics["memory_total_mb"] = total
            metrics["memory_used_mb"] = used
        except Exception as e:
            logger.error(f"收集内存指标失败：{e}")
            metrics["memory_usage"] = None
        
        # 磁盘使用率
        try:
            result = subprocess.run(
                ["df", "-h", "/"],
                capture_output=True, text=True, timeout=10
            )
            disk_line = result.stdout.split('\n')[1]
            disk_parts = disk_line.split()
            disk_usage = float(disk_parts[4].replace('%', ''))
            metrics["disk_usage"] = disk_usage
            metrics["disk_total"] = disk_parts[1]
            metrics["disk_used"] = disk_parts[2]
            metrics["disk_available"] = disk_parts[3]
        except Exception as e:
            logger.error(f"收集磁盘指标失败：{e}")
            metrics["disk_usage"] = None
        
        # GPU 指标
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=temperature.gpu,utilization.gpu,utilization.memory,power.draw,power.limit",
                 "--format=csv,noheader"],
                capture_output=True, text=True, timeout=10
            )
            gpu_metrics = []
            for i, line in enumerate(result.stdout.strip().split('\n')):
                parts = [p.strip() for p in line.split(',')]
                gpu_metrics.append({
                    "gpu_id": i,
                    "temperature": int(parts[0].replace(' C', '')),
                    "gpu_utilization": int(parts[1].replace(' %', '')),
                    "memory_utilization": int(parts[2].replace(' %', '')),
                    "power_draw": float(parts[3].replace(' W', '')),
                    "power_limit": float(parts[4].replace(' W', ''))
                })
            metrics["gpus"] = gpu_metrics
        except Exception as e:
            logger.error(f"收集 GPU 指标失败：{e}")
            metrics["gpus"] = []
        
        return metrics
    
    def _analyze_metrics(self, metrics: Dict) -> List[Dict]:
        """分析指标，生成优化建议"""
        recommendations = []
        
        # CPU 分析
        if metrics.get("cpu_usage") and metrics["cpu_usage"] > self.thresholds["cpu_usage"]:
            recommendations.append({
                "type": "cpu",
                "severity": "high" if metrics["cpu_usage"] > 90 else "medium",
                "title": "CPU 使用率过高",
                "current": f"{metrics['cpu_usage']:.1f}%",
                "threshold": f"{self.thresholds['cpu_usage']}%",
                "recommendation": """**建议**:
1. 检查高 CPU 占用进程：`top`
2. 优化或终止不必要的进程
3. 考虑增加 CPU 核心数
4. 检查是否有死循环或资源泄漏""",
                "command": "top -bn1 | head -20"
            })
        
        # 内存分析
        if metrics.get("memory_usage") and metrics["memory_usage"] > self.thresholds["memory_usage"]:
            recommendations.append({
                "type": "memory",
                "severity": "high" if metrics["memory_usage"] > 90 else "medium",
                "title": "内存使用率过高",
                "current": f"{metrics['memory_usage']:.1f}%",
                "threshold": f"{self.thresholds['memory_usage']}%",
                "recommendation": """**建议**:
1. 检查内存占用进程：`free -m`
2. 清理缓存：`sync; echo 3 > /proc/sys/vm/drop_caches`
3. 检查内存泄漏
4. 考虑增加内存""",
                "command": "free -m"
            })
        
        # 磁盘分析
        if metrics.get("disk_usage") and metrics["disk_usage"] > self.thresholds["disk_usage"]:
            recommendations.append({
                "type": "disk",
                "severity": "high" if metrics["disk_usage"] > 90 else "medium",
                "title": "磁盘使用率过高",
                "current": f"{metrics['disk_usage']:.1f}%",
                "threshold": f"{self.thresholds['disk_usage']}%",
                "recommendation": """**建议**:
1. 查找大文件：`find / -type f -size +1G`
2. 清理旧日志：`find /var/log -mtime +30 -delete`
3. 清理包缓存：`yum clean all`
4. 考虑扩容磁盘""",
                "command": "df -h"
            })
        
        # GPU 分析
        for gpu in metrics.get("gpus", []):
            # GPU 温度
            if gpu["temperature"] > self.thresholds["gpu_temperature"]:
                recommendations.append({
                    "type": "gpu_temperature",
                    "severity": "high" if gpu["temperature"] > 85 else "medium",
                    "title": f"GPU {gpu['gpu_id']} 温度过高",
                    "current": f"{gpu['temperature']}°C",
                    "threshold": f"{self.thresholds['gpu_temperature']}°C",
                    "recommendation": """**建议**:
1. 检查散热器和风扇
2. 清理灰尘
3. 改善机房散热
4. 降低 GPU 负载""",
                    "command": f"nvidia-smi -i {gpu['gpu_id']} -q -d TEMPERATURE"
                })
            
            # GPU 显存使用率
            if gpu["memory_utilization"] > self.thresholds["gpu_memory_usage"]:
                recommendations.append({
                    "type": "gpu_memory",
                    "severity": "medium",
                    "title": f"GPU {gpu['gpu_id']} 显存使用率高",
                    "current": f"{gpu['memory_utilization']}%",
                    "threshold": f"{self.thresholds['gpu_memory_usage']}%",
                    "recommendation": """**建议**:
1. 检查显存占用进程
2. 优化模型大小
3. 使用梯度检查点
4. 考虑使用多 GPU""",
                    "command": f"nvidia-smi -i {gpu['gpu_id']} -q -d MEMORY"
                })
        
        return recommendations
    
    def _calculate_health_score(self, metrics: Dict) -> int:
        """计算健康分数（0-100）"""
        score = 100
        
        # CPU 扣分
        if metrics.get("cpu_usage"):
            if metrics["cpu_usage"] > 90:
                score -= 30
            elif metrics["cpu_usage"] > 80:
                score -= 15
        
        # 内存扣分
        if metrics.get("memory_usage"):
            if metrics["memory_usage"] > 90:
                score -= 30
            elif metrics["memory_usage"] > 80:
                score -= 15
        
        # 磁盘扣分
        if metrics.get("disk_usage"):
            if metrics["disk_usage"] > 90:
                score -= 30
            elif metrics["disk_usage"] > 80:
                score -= 15
        
        # GPU 扣分
        for gpu in metrics.get("gpus", []):
            if gpu["temperature"] > 85:
                score -= 10
            elif gpu["temperature"] > 80:
                score -= 5
        
        return max(0, min(100, score))
    
    def _save_metrics(self, metrics: Dict):
        """保存指标"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        metrics_file = self.metrics_dir / f"metrics_{timestamp}.json"
        
        with open(metrics_file, 'w', encoding='utf-8') as f:
            json.dump(metrics, f, ensure_ascii=False, indent=2)
    
    def generate_performance_report(self) -> str:
        """生成性能报告"""
        result = self.analyze_system_performance()
        
        report = f"""# 系统性能分析报告

**生成时间**: {result['timestamp']}
**健康分数**: {result['health_score']}/100

## 系统指标

### CPU
- 使用率：{result['metrics'].get('cpu_usage', 'N/A')}%

### 内存
- 使用率：{result['metrics'].get('memory_usage', 'N/A')}%
- 总计：{result['metrics'].get('memory_total_mb', 'N/A')} MB
- 已用：{result['metrics'].get('memory_used_mb', 'N/A')} MB

### 磁盘
- 使用率：{result['metrics'].get('disk_usage', 'N/A')}%
- 总计：{result['metrics'].get('disk_total', 'N/A')}
- 已用：{result['metrics'].get('disk_used', 'N/A')}
- 可用：{result['metrics'].get('disk_available', 'N/A')}

### GPU
"""
        
        for gpu in result['metrics'].get('gpus', []):
            report += f"""
#### GPU {gpu['gpu_id']}
- 温度：{gpu['temperature']}°C
- GPU 利用率：{gpu['gpu_utilization']}%
- 显存利用率：{gpu['memory_utilization']}%
- 功耗：{gpu['power_draw']}W / {gpu['power_limit']}W
"""
        
        if result['recommendations']:
            report += "\n## 优化建议\n\n"
            for i, rec in enumerate(result['recommendations'], 1):
                report += f"""### {i}. {rec['title']}
- 当前值：{rec['current']}
- 阈值：{rec['threshold']}
- 严重性：{rec['severity']}
{rec['recommendation']}

**诊断命令**:
```bash
{rec['command']}
```

"""
        else:
            report += "\n## 优化建议\n\n✅ 系统运行正常，无需优化。\n"
        
        return report


# 全局实例
performance_advisor = PerformanceAdvisor()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python performance_advisor.py <command>")
        print("命令:")
        print("  analyze - 分析性能")
        print("  report - 生成报告")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "analyze":
        result = performance_advisor.analyze_system_performance()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "report":
        report = performance_advisor.generate_performance_report()
        print(report)
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
