#!/bin/bash
# GPU 服务器完整诊断脚本
# 输出所有 GPU、模组、整机的 SN 信息

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="/root/.openclaw/logs/gpu-diagnostic"
REPORT_FILE="$LOG_DIR/gpu-diagnostic-$(date +%Y%m%d_%H%M%S).md"

mkdir -p "$LOG_DIR"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1" | tee -a "$REPORT_FILE"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1" | tee -a "$REPORT_FILE"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$REPORT_FILE"
}

log_section() {
    echo "" | tee -a "$REPORT_FILE"
    echo "========================================" | tee -a "$REPORT_FILE"
    echo "$1" | tee -a "$REPORT_FILE"
    echo "========================================" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
}

# 故障时间（首次发现时间，可通过参数传入或默认当前时间）
FAULT_TIME="${1:-$(date '+%Y-%m-%d %H:%M:%S')}"

# 开始诊断
log_section "GPU 服务器故障分析报告"
echo "**故障时间**: $FAULT_TIME" | tee -a "$REPORT_FILE"
echo "**分析时间**: $(date '+%Y-%m-%d %H:%M:%S')" | tee -a "$REPORT_FILE"
echo "**服务器**: $(hostname)" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# ========== 1. 整机 SN 信息 ==========
log_section "1. 整机 SN 信息"

echo "### 服务器基本信息" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# 整机 SN（通过 dmidecode）
if command -v dmidecode &> /dev/null; then
    CHASSIS_SN=$(dmidecode -t chassis | grep -i "serial number" | head -1 | awk -F: '{print $2}' | xargs)
    SYSTEM_SN=$(dmidecode -t system | grep -i "serial number" | head -1 | awk -F: '{print $2}' | xargs)
    BOARD_SN=$(dmidecode -t baseboard | grep -i "serial number" | head -1 | awk -F: '{print $2}' | xargs)
    
    echo "| 项目 | 序列号 |" | tee -a "$REPORT_FILE"
    echo "|------|--------|" | tee -a "$REPORT_FILE"
    echo "| 整机 SN | ${SYSTEM_SN:-无法获取} |" | tee -a "$REPORT_FILE"
    echo "| 机箱 SN | ${CHASSIS_SN:-无法获取} |" | tee -a "$REPORT_FILE"
    echo "| 主板 SN | ${BOARD_SN:-无法获取} |" | tee -a "$REPORT_FILE"
else
    log_warn "dmidecode 不可用，尝试其他方式..."
    
    # 尝试通过 ipmitool
    if command -v ipmitool &> /dev/null; then
        SYSTEM_SN=$(ipmitool fru | grep -i "product serial" | head -1 | awk -F: '{print $2}' | xargs)
        echo "整机 SN (IPMI): $SYSTEM_SN" | tee -a "$REPORT_FILE"
    else
        # 尝试读取 sysfs
        SYSTEM_SN=$(cat /sys/class/dmi/id/product_serial 2>/dev/null || echo "无法获取")
        echo "整机 SN (sysfs): $SYSTEM_SN" | tee -a "$REPORT_FILE"
    fi
fi

echo "" | tee -a "$REPORT_FILE"

# 服务器型号
if command -v dmidecode &> /dev/null; then
    SYSTEM_MODEL=$(dmidecode -t system | grep -i "product name" | head -1 | awk -F: '{print $2}' | xargs)
    SYSTEM_VENDOR=$(dmidecode -t system | grep -i "manufacturer" | head -1 | awk -F: '{print $2}' | xargs)
    echo "**服务器型号**: ${SYSTEM_VENDOR:-未知} ${SYSTEM_MODEL:-未知}" | tee -a "$REPORT_FILE"
fi

echo "" | tee -a "$REPORT_FILE"

# ========== 2. GPU SN 信息 ==========
log_section "2. GPU SN 信息（所有 GPU）"

echo "### GPU 列表与序列号" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# 检查 nvidia-smi
if ! command -v nvidia-smi &> /dev/null; then
    log_error "nvidia-smi 不可用，无法获取 GPU 信息"
    exit 1
fi

# GPU 数量
GPU_COUNT=$(nvidia-smi -L 2>/dev/null | wc -l)
log_info "检测到 $GPU_COUNT 张 GPU"

echo "| GPU ID | BDF | 序列号 (SN) | UUID | 状态 |" | tee -a "$REPORT_FILE"
echo "|--------|-----|-------------|------|------|" | tee -a "$REPORT_FILE"

# 遍历所有 GPU
for gpu_id in $(seq 0 $((GPU_COUNT - 1))); do
    # GPU 信息
    GPU_INFO=$(nvidia-smi -i $gpu_id -q 2>/dev/null)
    
    if [ $? -ne 0 ]; then
        echo "| GPU $gpu_id | - | 无法读取 | - | ❌ 掉线 |" | tee -a "$REPORT_FILE"
        continue
    fi
    
    # BDF
    BDF=$(nvidia-smi -i $gpu_id -q | grep "Bus Locations" | awk '{print $4}' | head -1)
    
    # 序列号
    SERIAL=$(echo "$GPU_INFO" | grep -i "serialnumber" | head -1 | awk -F: '{print $2}' | xargs)
    
    # UUID
    UUID=$(echo "$GPU_INFO" | grep -i "gpu uuid" | head -1 | awk -F: '{print $2}' | xargs)
    
    # 状态
    STATUS=$(echo "$GPU_INFO" | grep -i "overall health" | head -1 | awk -F: '{print $2}' | xargs)
    if [ -z "$STATUS" ]; then
        STATUS="✅ 正常"
    fi
    
    echo "| GPU $gpu_id | ${BDF:-N/A} | ${SERIAL:-无法获取} | ${UUID:0:20}... | $STATUS |" | tee -a "$REPORT_FILE"
done

echo "" | tee -a "$REPORT_FILE"

# GPU 汇总
echo "**GPU 总数**: $GPU_COUNT" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# ========== 3. GPU 模组 SN 信息 ==========
log_section "3. GPU 模组 SN 信息"

echo "### HGX/H100 模组信息" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# 检查是否是 HGX 系统
if nvidia-smi -q | grep -i "hgx" &> /dev/null; then
    log_info "检测到 HGX 系统"
    
    # HGX 模组 SN（通过 nvidia-smi）
    echo "| 模组 | 序列号 | 状态 |" | tee -a "$REPORT_FILE"
    echo "|------|--------|------|" | tee -a "$REPORT_FILE"
    
    # 尝试获取模组信息
    MODULE_INFO=$(nvidia-smi -q -d MODULE 2>/dev/null)
    
    if [ -n "$MODULE_INFO" ]; then
        # 解析模组信息
        echo "$MODULE_INFO" | grep -i "serial" | while read line; do
            MODULE_SN=$(echo "$line" | awk -F: '{print $2}' | xargs)
            echo "| HGX 模组 | ${MODULE_SN:-无法获取} | ✅ 正常 |" | tee -a "$REPORT_FILE"
        done
    else
        # 通过 dmidecode 获取
        if command -v dmidecode &> /dev/null; then
            MODULE_SN=$(dmidecode -t 2 | grep -i "serial" | head -1 | awk -F: '{print $2}' | xargs)
            echo "| HGX 模组 | ${MODULE_SN:-无法获取} | ✅ 正常 |" | tee -a "$REPORT_FILE"
        else
            echo "| HGX 模组 | 无法获取 | ⚠️ 未知 |" | tee -a "$REPORT_FILE"
        fi
    fi
else
    log_warn "非 HGX 系统，跳过模组检查"
    echo "当前系统不是 HGX 架构，无 GPU 模组 SN 信息" | tee -a "$REPORT_FILE"
fi

echo "" | tee -a "$REPORT_FILE"

# ========== 4. nvswitch SN 信息 ==========
log_section "4. nvswitch 状态与 SN"

echo "### nvswitch 信息" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# 检查 nvswitch
if nvidia-smi nvswitch -d &> /dev/null; then
    log_info "检测到 nvswitch"
    
    echo "#### nvswitch 状态" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
    nvidia-smi nvswitch -d 2>&1 | tee -a "$REPORT_FILE"
    
    echo "" | tee -a "$REPORT_FILE"
    echo "#### nvswitch 错误计数" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
    nvidia-smi nvswitch -d -ec 2>&1 | tee -a "$REPORT_FILE"
else
    log_warn "nvswitch 不可用或未配置"
    echo "当前系统无 nvswitch 或 nvswitch 不可访问" | tee -a "$REPORT_FILE"
fi

echo "" | tee -a "$REPORT_FILE"

# ========== 5. nvlink 状态 ==========
log_section "5. nvlink 状态"

echo "### nvlink 连接状态" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# 检查 nvlink
if nvidia-smi nvlink -s &> /dev/null; then
    log_info "检测到 nvlink"
    
    echo "#### nvlink 状态" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
    nvidia-smi nvlink -s 2>&1 | tee -a "$REPORT_FILE"
    
    echo "" | tee -a "$REPORT_FILE"
    echo "#### nvlink 错误计数" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
    nvidia-smi nvlink -ec 2>&1 | tee -a "$REPORT_FILE"
else
    log_warn "nvlink 不可用或未配置"
    echo "当前系统无 nvlink 或 nvlink 不可访问" | tee -a "$REPORT_FILE"
fi

echo "" | tee -a "$REPORT_FILE"

# ========== 6. GPU 拓扑 ==========
log_section "6. GPU 拓扑结构"

echo "### GPU 连接拓扑" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"
nvidia-smi topo -m 2>&1 | tee -a "$REPORT_FILE"

echo "" | tee -a "$REPORT_FILE"

# ========== 7. GPU 健康状态 ==========
log_section "7. GPU 健康状态"

echo "### 健康检查汇总" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# ECC 错误
echo "#### ECC 错误" | tee -a "$REPORT_FILE"
nvidia-smi -q -d ECC 2>&1 | grep -E "ECC Errors|Volatile|Aggregate" | head -20 | tee -a "$REPORT_FILE"

echo "" | tee -a "$REPORT_FILE"

# 温度
echo "#### 温度状态" | tee -a "$REPORT_FILE"
nvidia-smi -q -d TEMPERATURE 2>&1 | grep -E "GPU Current Temp|GPU Shutdown Temp" | head -10 | tee -a "$REPORT_FILE"

echo "" | tee -a "$REPORT_FILE"

# 功耗
echo "#### 功耗状态" | tee -a "$REPORT_FILE"
nvidia-smi -q -d POWER 2>&1 | grep -E "Power Readings|GPU Power" | head -10 | tee -a "$REPORT_FILE"

echo "" | tee -a "$REPORT_FILE"

# ========== 8. 完整 SN 汇总 ==========
log_section "8. 完整 SN 汇总"

echo "### 序列号汇总清单" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

echo "| 类型 | 数量 | 序列号 |" | tee -a "$REPORT_FILE"
echo "|------|------|--------|" | tee -a "$REPORT_FILE"

# 整机 SN
echo "| 整机 SN | 1 | ${SYSTEM_SN:-无法获取} |" | tee -a "$REPORT_FILE"

# GPU SN
for gpu_id in $(seq 0 $((GPU_COUNT - 1))); do
    GPU_SERIAL=$(nvidia-smi -i $gpu_id -q 2>/dev/null | grep -i "serialnumber" | head -1 | awk -F: '{print $2}' | xargs)
    echo "| GPU $gpu_id SN | 1 | ${GPU_SERIAL:-无法获取} |" | tee -a "$REPORT_FILE"
done

# 模组 SN（如果有）
if nvidia-smi -q | grep -i "hgx" &> /dev/null; then
    MODULE_SN=$(dmidecode -t 2 2>/dev/null | grep -i "serial" | head -1 | awk -F: '{print $2}' | xargs)
    echo "| HGX 模组 SN | 1 | ${MODULE_SN:-无法获取} |" | tee -a "$REPORT_FILE"
fi

echo "" | tee -a "$REPORT_FILE"

# ========== 9. 故障日志 ==========
log_section "9. 故障日志"

echo "### 故障日志详情" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# 收集系统日志中的 GPU 相关错误
echo "#### dmesg GPU 错误" | tee -a "$REPORT_FILE"
echo '```' | tee -a "$REPORT_FILE"
dmesg 2>/dev/null | grep -i "nvidia\|gpu\|error\|fail" | tail -50 | tee -a "$REPORT_FILE"
echo '```' | tee -a "$REPORT_FILE"

echo "" | tee -a "$REPORT_FILE"

echo "#### 系统日志 GPU 错误" | tee -a "$REPORT_FILE"
echo '```' | tee -a "$REPORT_FILE"
grep -i "nvidia\|gpu\|error" /var/log/syslog 2>/dev/null | tail -50 | tee -a "$REPORT_FILE"
echo '```' | tee -a "$REPORT_FILE"

echo "" | tee -a "$REPORT_FILE"

echo "#### NVIDIA 日志" | tee -a "$REPORT_FILE"
echo '```' | tee -a "$REPORT_FILE"
cat /var/log/nvidia*.log 2>/dev/null | tail -100 | tee -a "$REPORT_FILE"
echo '```' | tee -a "$REPORT_FILE"

echo "" | tee -a "$REPORT_FILE"

# ========== 10. 故障分析 ==========
log_section "10. 故障分析"

echo "### 故障根因分析" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

# 分析 GPU 掉线情况
if [ "$GPU_COUNT" -lt 8 ]; then
    echo "#### ⚠️ GPU 掉线分析" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
    echo "**检测到 GPU 数量**: $GPU_COUNT 张（预期 8 张）" | tee -a "$REPORT_FILE"
    echo "**可能原因**:" | tee -a "$REPORT_FILE"
    echo "1. GPU 硬件故障导致掉线" | tee -a "$REPORT_FILE"
    echo "2. PCIe 链路故障" | tee -a "$REPORT_FILE"
    echo "3. 电源供电不足" | tee -a "$REPORT_FILE"
    echo "4. GPU 过热保护" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
else
    echo "#### ✅ GPU 状态正常" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
    echo "**检测到 GPU 数量**: $GPU_COUNT 张" | tee -a "$REPORT_FILE"
    echo "**所有 GPU 运行正常**" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
fi

# 分析 ECC 错误
echo "#### ECC 错误分析" | tee -a "$REPORT_FILE"
ECC_ERRORS=$(nvidia-smi -q -d ECC 2>/dev/null | grep -c "Aggregate" || echo "0")
if [ "$ECC_ERRORS" -gt 0 ]; then
    echo "**发现 ECC 错误**，需要关注" | tee -a "$REPORT_FILE"
else
    echo "**无 ECC 错误**" | tee -a "$REPORT_FILE"
fi
echo "" | tee -a "$REPORT_FILE"

# 分析 nvswitch/nvlink
echo "#### nvswitch/nvlink 分析" | tee -a "$REPORT_FILE"
if nvidia-smi nvswitch -d &>/dev/null; then
    echo "**nvswitch**: 正常" | tee -a "$REPORT_FILE"
else
    echo "**nvswitch**: 未检测到或不可用" | tee -a "$REPORT_FILE"
fi

if nvidia-smi nvlink -s &>/dev/null; then
    echo "**nvlink**: 正常" | tee -a "$REPORT_FILE"
else
    echo "**nvlink**: 未检测到或不可用" | tee -a "$REPORT_FILE"
fi
echo "" | tee -a "$REPORT_FILE"

# ========== 11. 维修方案 ==========
log_section "11. 维修方案"

echo "### 故障处理建议" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

if [ "$GPU_COUNT" -lt 8 ]; then
    echo "#### 🔴 紧急处理" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
    echo "1. **重启服务器** - 尝试恢复掉线 GPU" | tee -a "$REPORT_FILE"
    echo "2. **检查 PCIe 链路** - 重新插拔 GPU" | tee -a "$REPORT_FILE"
    echo "3. **检查电源** - 确认电源供电正常" | tee -a "$REPORT_FILE"
    echo "4. **更换 GPU** - 如确认硬件故障" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
else
    echo "#### ✅ 系统健康" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
    echo "系统运行正常，无需维修" | tee -a "$REPORT_FILE"
    echo "" | tee -a "$REPORT_FILE"
fi

# ========== 12. 报告完成 ==========
log_section "报告完成"

echo "**故障时间**: $FAULT_TIME" | tee -a "$REPORT_FILE"
echo "**报告生成时间**: $(date '+%Y-%m-%d %H:%M:%S')" | tee -a "$REPORT_FILE"
echo "**报告位置**: $REPORT_FILE" | tee -a "$REPORT_FILE"
echo "" | tee -a "$REPORT_FILE"

log_info "诊断完成！报告已保存到：$REPORT_FILE"

# 返回报告路径
echo "$REPORT_FILE"
