#!/usr/bin/env python3
"""
意图识别模块
功能：检测用户意图，路由到相应的处理流程
"""

from typing import Dict

def detect_intent(message: str, has_file: bool) -> Dict:
    """
    检测用户意图
    
    Args:
        message: 用户消息
        has_file: 是否有文件上传
    
    Returns:
        {
            "intent": "fault_analysis" | "file_process" | "learning" | "archive" | "documentation" | "unknown",
            "confidence": 0.0-1.0,
            "needs_confirmation": True/False
        }
    """
    message_lower = message.lower()
    
    # 意图 1: 故障分析
    fault_keywords = [
        "分析", "诊断", "故障", "问题", "错误", "报错",
        "analyze", "diagnos", "fault", "error", "issue",
        "为什么", "怎么回事", "出了什么问题"
    ]
    
    if any(kw in message_lower for kw in fault_keywords):
        return {
            "intent": "fault_analysis",
            "confidence": 0.9,
            "needs_confirmation": False
        }
    
    # 意图 2: 文件处理
    process_keywords = [
        "处理", "转换", "提取", "解析", "解压", "打开",
        "process", "convert", "extract", "parse"
    ]
    
    if any(kw in message_lower for kw in process_keywords):
        return {
            "intent": "file_process",
            "confidence": 0.8,
            "needs_confirmation": False
        }
    
    # 意图 3: 学习/参考
    learning_keywords = [
        "学习", "参考", "模板", "示例", "怎么写", "如何写",
        "learn", "reference", "template", "example"
    ]
    
    if any(kw in message_lower for kw in learning_keywords):
        return {
            "intent": "learning",
            "confidence": 0.8,
            "needs_confirmation": False
        }
    
    # 意图 4: 存档/存储
    archive_keywords = [
        "存档", "保存", "存储", "备份",
        "archive", "save", "store", "backup"
    ]
    
    if any(kw in message_lower for kw in archive_keywords):
        return {
            "intent": "archive",
            "confidence": 0.8,
            "needs_confirmation": False
        }
    
    # 意图 5: 文档说明
    doc_keywords = [
        "说明", "文档", "手册", "指南", "硬件架构", "软件说明",
        "documentation", "manual", "guide"
    ]
    
    if any(kw in message_lower for kw in doc_keywords):
        return {
            "intent": "documentation",
            "confidence": 0.8,
            "needs_confirmation": False
        }
    
    # 意图 6: 未知/模糊
    return {
        "intent": "unknown",
        "confidence": 0.0,
        "needs_confirmation": True
    }


def get_intent_description(intent: str) -> str:
    """获取意图描述"""
    descriptions = {
        "fault_analysis": "故障分析（调用 server-maintenance 分析）",
        "file_process": "文件处理（解压/转换/提取内容）",
        "learning": "学习材料（保存为参考模板）",
        "archive": "存档（仅存储）",
        "documentation": "文档说明（提取内容）",
        "unknown": "未知意图"
    }
    return descriptions.get(intent, "未知意图")


# CLI 测试
if __name__ == "__main__":
    import sys
    
    test_cases = [
        ("分析故障", True),
        ("学习怎么写报告", True),
        ("这是硬件架构文档", True),
        ("存档这个文件", True),
        ("处理这个文件", True),
        ("这个文件", True),
        ("", True),  # 仅文件，无文字
    ]
    
    print("意图识别测试:\n")
    for message, has_file in test_cases:
        result = detect_intent(message, has_file)
        print(f"消息：'{message}' | 文件：{has_file}")
        print(f"  → 意图：{result['intent']} (confidence: {result['confidence']})")
        print(f"  → 需要确认：{result['needs_confirmation']}\n")
