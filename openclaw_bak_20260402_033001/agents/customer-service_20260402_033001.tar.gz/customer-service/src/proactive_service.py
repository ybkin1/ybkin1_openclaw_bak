#!/usr/bin/env python3
"""
主动服务模块
功能：定期检查用户状态，主动提供服务
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger('proactive_service')


class ProactiveServiceManager:
    """主动服务管理器"""
    
    def __init__(self):
        self.state_dir = Path("/root/.openclaw/workspace/agents/customer-service/state")
        self.state_dir.mkdir(parents=True, exist_ok=True)
        
        # 服务检查间隔（分钟）
        self.check_intervals = {
            "ticket_followup": 60,      # 工单跟进：60 分钟
            "user_care": 1440,          # 用户关怀：24 小时
            "system_health": 30,        # 系统健康：30 分钟
            "feedback_request": 1440    # 反馈请求：24 小时
        }
    
    def check_and_serve(self, user_id: str) -> List[Dict]:
        """
        检查用户状态，主动提供服务
        
        Args:
            user_id: 用户 ID
        
        Returns:
            需要发送的服务消息列表
        """
        services = []
        
        # 1. 检查工单状态
        ticket_service = self._check_ticket_status(user_id)
        if ticket_service:
            services.append(ticket_service)
        
        # 2. 检查用户关怀
        care_service = self._check_user_care(user_id)
        if care_service:
            services.append(care_service)
        
        # 3. 检查系统健康
        health_service = self._check_system_health(user_id)
        if health_service:
            services.append(health_service)
        
        # 4. 检查反馈请求
        feedback_service = self._check_feedback_request(user_id)
        if feedback_service:
            services.append(feedback_service)
        
        return services
    
    def _check_ticket_status(self, user_id: str) -> Optional[Dict]:
        """检查工单状态，主动跟进"""
        # 读取用户工单状态
        state_file = self.state_dir / f"{user_id}_tickets.json"
        
        if not state_file.exists():
            return None
        
        with open(state_file, 'r', encoding='utf-8') as f:
            tickets = json.load(f)
        
        # 检查是否有待跟进的工单
        pending_tickets = [t for t in tickets if t.get("status") == "pending_data"]
        
        if pending_tickets:
            ticket = pending_tickets[0]
            created_at = datetime.fromisoformat(ticket["created_at"])
            hours_passed = (datetime.now() - created_at).total_seconds() / 3600
            
            # 超过 1 小时未提供数据，主动跟进
            if hours_passed > 1:
                return {
                    "type": "ticket_followup",
                    "priority": "medium",
                    "message": f"""⏰ **工单跟进提醒**

工单号：{ticket['ticket_id']}
创建时间：{created_at.strftime('%m-%d %H:%M')}
任务类型：{ticket['task_type']}

您的工单已创建超过 1 小时，尚未提供数据。

**请尽快提供以下数据：**
{', '.join(ticket.get('task_data', {}).get('required_data', []))}

如有问题，请随时联系我。""",
                    "ticket_id": ticket['ticket_id']
                }
        
        return None
    
    def _check_user_care(self, user_id: str) -> Optional[Dict]:
        """检查用户关怀，定期问候"""
        # 读取上次关怀时间
        state_file = self.state_dir / f"{user_id}_care.json"
        
        last_care = None
        if state_file.exists():
            with open(state_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                last_care = data.get("last_care_at")
        
        # 检查是否需要关怀（24 小时未联系）
        if last_care:
            last_care_dt = datetime.fromisoformat(last_care)
            hours_passed = (datetime.now() - last_care_dt).total_seconds() / 3600
            
            if hours_passed < 24:
                return None
        
        # 更新关怀时间
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump({
                "last_care_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        
        return {
            "type": "user_care",
            "priority": "low",
            "message": """👋 **您好！**

我是您的智能客服助手。

**我可以帮助您：**
- 📊 分析 GPU 服务器故障
- 📁 处理日志文件和压缩包
- 📝 生成故障分析报告
- 📅 管理待办事项和日程
- 💬 查询企业微信消息

有任何问题，随时联系我！"""
        }
    
    def _check_system_health(self, user_id: str) -> Optional[Dict]:
        """检查系统健康，主动告警"""
        # 检查 Gateway 状态
        import subprocess
        
        try:
            result = subprocess.run(
                ["systemctl", "--user", "is-active", "openclaw-gateway"],
                capture_output=True, text=True
            )
            
            if result.stdout.strip() != "active":
                return {
                    "type": "system_alert",
                    "priority": "high",
                    "message": """⚠️ **系统告警**

检测到 Gateway 服务异常。

**状态**: 未运行

**建议操作**:
1. 重启 Gateway 服务
2. 检查系统日志
3. 联系系统管理员

如需帮助，请回复"重启 Gateway"。""",
                    "action": "restart_gateway"
                }
        except Exception as e:
            logger.error(f"检查系统健康失败：{e}")
        
        return None
    
    def _check_feedback_request(self, user_id: str) -> Optional[Dict]:
        """检查是否需要请求反馈"""
        # 读取用户工单完成情况
        state_file = self.state_dir / f"{user_id}_tickets.json"
        
        if not state_file.exists():
            return None
        
        with open(state_file, 'r', encoding='utf-8') as f:
            tickets = json.load(f)
        
        # 检查是否有刚完成的工单
        completed_tickets = [
            t for t in tickets 
            if t.get("status") == "completed" 
            and not t.get("feedback_requested")
        ]
        
        if completed_tickets:
            ticket = completed_tickets[0]
            ticket["feedback_requested"] = True
            
            # 更新工单状态
            with open(state_file, 'w', encoding='utf-8') as f:
                json.dump(tickets, f, ensure_ascii=False, indent=2)
            
            return {
                "type": "feedback_request",
                "priority": "low",
                "message": f"""⭐ **服务评价请求**

工单号：{ticket['ticket_id']}
任务类型：{ticket['task_type']}

**请对本次服务进行评价：**

⭐⭐⭐⭐⭐ 非常满意
⭐⭐⭐⭐ 满意
⭐⭐⭐ 一般
⭐⭐ 不满意
⭐ 非常不满意

**您的反馈将帮助我们改进服务！**

直接回复星级即可。""",
                "ticket_id": ticket['ticket_id']
            }
        
        return None
    
    def update_ticket_state(self, user_id: str, ticket: Dict):
        """更新工单状态"""
        state_file = self.state_dir / f"{user_id}_tickets.json"
        
        tickets = []
        if state_file.exists():
            with open(state_file, 'r', encoding='utf-8') as f:
                tickets = json.load(f)
        
        # 更新或添加工单
        existing = next((t for t in tickets if t["ticket_id"] == ticket["ticket_id"]), None)
        if existing:
            existing.update(ticket)
        else:
            tickets.append(ticket)
        
        with open(state_file, 'w', encoding='utf-8') as f:
            json.dump(tickets, f, ensure_ascii=False, indent=2)


# 全局实例
proactive_service = ProactiveServiceManager()


# CLI 测试
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python proactive_service.py <user_id>")
        sys.exit(1)
    
    user_id = sys.argv[1]
    services = proactive_service.check_and_serve(user_id)
    
    if services:
        print(f"检测到 {len(services)} 个主动服务:\n")
        for service in services:
            print(f"类型：{service['type']}")
            print(f"优先级：{service['priority']}")
            print(f"消息：{service['message'][:100]}...\n")
    else:
        print("暂无主动服务")
