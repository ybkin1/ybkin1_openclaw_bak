#!/usr/bin/env python3
"""
错误处理模块
功能：提供友好的错误提示和错误恢复机制
"""

from typing import Dict, Optional
import logging

logger = logging.getLogger('error_handler')

# 错误类型定义
ERROR_TYPES = {
    "file_not_found": {
        "user_message": "❌ **文件未找到**\n\n请确认文件路径正确，或重新上传文件。",
        "severity": "medium",
        "retryable": True
    },
    "file_too_large": {
        "user_message": "❌ **文件过大**\n\n文件大小超过限制（最大 {max_size}MB）。\n\n建议：\n1. 压缩文件后重新上传\n2. 分割成多个小文件\n3. 通过其他方式传输（如共享目录）",
        "severity": "medium",
        "retryable": False
    },
    "unsupported_format": {
        "user_message": "❌ **不支持的文件格式**\n\n当前文件格式：{file_format}\n\n支持的文件格式：\n- 日志文件：.log, .txt\n- 压缩包：.tar.gz, .zip, .rar, .7z\n- 文档：.pdf, .docx, .md",
        "severity": "low",
        "retryable": False
    },
    "agent_unavailable": {
        "user_message": "⚠️ **服务暂时不可用**\n\n处理该任务的 Agent 当前不可用。\n\n建议：\n1. 稍后重试\n2. 联系系统管理员",
        "severity": "high",
        "retryable": True
    },
    "timeout": {
        "user_message": "⏱️ **处理超时**\n\n任务处理时间过长，已自动终止。\n\n建议：\n1. 检查文件是否过大\n2. 分割文件后重新处理\n3. 联系系统管理员",
        "severity": "medium",
        "retryable": True
    },
    "permission_denied": {
        "user_message": "🔒 **权限不足**\n\n您没有权限执行此操作。\n\n如需帮助，请联系系统管理员。",
        "severity": "high",
        "retryable": False
    },
    "invalid_input": {
        "user_message": "❌ **输入无效**\n\n{details}\n\n请检查输入后重试。",
        "severity": "low",
        "retryable": True
    },
    "system_error": {
        "user_message": "⚠️ **系统错误**\n\n处理过程中发生未知错误。\n\n错误信息：{error}\n\n建议：\n1. 重试操作\n2. 如问题持续，请联系系统管理员",
        "severity": "high",
        "retryable": True
    }
}


def get_user_friendly_error(error_type: str, **kwargs) -> Dict:
    """
    获取用户友好的错误消息
    
    Args:
        error_type: 错误类型
        **kwargs: 错误消息参数
    
    Returns:
        {
            "user_message": "用户友好的错误消息",
            "severity": "low|medium|high",
            "retryable": True/False,
            "error_type": "错误类型"
        }
    """
    error_config = ERROR_TYPES.get(error_type, ERROR_TYPES["system_error"])
    
    user_message = error_config["user_message"]
    
    # 替换参数
    for key, value in kwargs.items():
        user_message = user_message.replace("{" + key + "}", str(value))
    
    return {
        "user_message": user_message,
        "severity": error_config["severity"],
        "retryable": error_config["retryable"],
        "error_type": error_type
    }


def handle_exception(e: Exception, context: str = "") -> Dict:
    """
    处理异常，返回友好的错误消息
    
    Args:
        e: 异常对象
        context: 上下文信息
    
    Returns:
        错误消息字典
    """
    error_message = str(e)
    logger.error(f"异常处理 - 上下文：{context}, 错误：{error_message}")
    
    # 根据异常类型匹配错误
    if "FileNotFoundError" in type(e).__name__ or "not found" in error_message.lower():
        return get_user_friendly_error("file_not_found")
    
    elif "too large" in error_message.lower() or "size" in error_message.lower():
        return get_user_friendly_error("file_too_large", max_size="500")
    
    elif "unsupported" in error_message.lower() or "format" in error_message.lower():
        return get_user_friendly_error("unsupported_format", file_format="未知")
    
    elif "timeout" in error_message.lower():
        return get_user_friendly_error("timeout")
    
    elif "permission" in error_message.lower() or "denied" in error_message.lower():
        return get_user_friendly_error("permission_denied")
    
    elif "unavailable" in error_message.lower() or "not found" in error_message.lower():
        return get_user_friendly_error("agent_unavailable")
    
    else:
        return get_user_friendly_error("system_error", error=error_message[:100])


def retry_on_failure(func, max_retries: int = 3, delay: int = 1):
    """
    失败重试装饰器
    
    Args:
        func: 要执行的函数
        max_retries: 最大重试次数
        delay: 重试间隔（秒）
    
    Returns:
        包装后的函数
    """
    import time
    from functools import wraps
    
    @wraps(func)
    def wrapper(*args, **kwargs):
        last_error = None
        
        for attempt in range(max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_error = e
                logger.warning(f"执行失败（尝试 {attempt + 1}/{max_retries}）: {e}")
                
                if attempt < max_retries - 1:
                    time.sleep(delay)
        
        # 所有重试失败
        return handle_exception(last_error, func.__name__)
    
    return wrapper


# CLI 测试
if __name__ == "__main__":
    print("错误处理模块测试:\n")
    
    # 测试各种错误类型
    test_errors = [
        ("file_not_found", {}),
        ("file_too_large", {"max_size": "500"}),
        ("unsupported_format", {"file_format": ".xyz"}),
        ("timeout", {}),
        ("system_error", {"error": "Unknown error occurred"}),
    ]
    
    for error_type, params in test_errors:
        result = get_user_friendly_error(error_type, **params)
        print(f"错误类型：{error_type}")
        print(f"  用户消息：{result['user_message'][:50]}...")
        print(f"  严重性：{result['severity']}")
        print(f"  可重试：{result['retryable']}\n")
