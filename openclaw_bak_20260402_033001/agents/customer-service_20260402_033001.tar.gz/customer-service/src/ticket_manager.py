#!/usr/bin/env python3
"""
工单管理器 - customer-service Agent 专用
功能：创建工单、更新状态、验证数据、调用分支 Agent
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import subprocess
import fcntl

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/root/.openclaw/logs/wecom-plugin.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('ticket_manager')


class TicketManager:
    """工单管理器"""
    
    def __init__(self):
        self.tickets_dir = Path("/root/.openclaw/workspace/agents/customer-service/tickets")
        self.tickets_dir.mkdir(parents=True, exist_ok=True)
        
        # 任务类型配置
        self.task_configs = {
            "fault_analysis": {
                "description": "GPU 服务器故障分析",
                "required_data": ["gpu_log", "nvidia_smi_output"],
                "assigned_agent": "server-maintenance",
                "script": "/root/.openclaw/workspace/agents/server-maintenance/scripts/gpu-diagnostic-full.sh"
            },
            "file_processing": {
                "description": "文件处理",
                "required_data": ["file_content"],
                "assigned_agent": "file-processor",
                "script": None
            },
            "data_query": {
                "description": "数据查询",
                "required_data": ["query_params"],
                "assigned_agent": "database-manager",
                "script": None
            }
        }
    
    def create_ticket(self, task_type: str, user_id: str, group_id: str = None, channel: str = "wecom") -> Dict:
        """创建工单（按会话隔离）"""
        # 获取会话 ID
        session_id = self._get_session_id(user_id, group_id)
        
        # 工单 ID 包含会话 ID
        ticket_id = f"TKT-{session_id}-{datetime.now().strftime('%Y%m%d')}-{self._get_next_number(session_id)}"
        
        config = self.task_configs.get(task_type, self.task_configs["fault_analysis"])
        
        ticket = {
            "ticket_id": ticket_id,
            "session_id": session_id,
            "task_type": task_type,
            "status": "pending_data",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "user_id": user_id,
            "group_id": group_id or "direct",
            "channel": channel,
            "task_data": {
                "description": config["description"],
                "required_data": config["required_data"],
                "assigned_agent": config["assigned_agent"],
                "script": config.get("script")
            },
            "state": {
                "current_step": "pending_data",
                "data_received": False,
                "user_confirmed": False,
                "analysis_completed": False
            },
            "data": {
                "user_input": None,
                "validation_result": None,
                "analysis_result": None
            },
            "history": [{
                "timestamp": datetime.now().isoformat(),
                "action": "ticket_created",
                "actor": "customer-service",
                "details": f"工单创建，任务类型：{task_type}"
            }]
        }
        
        self._save_ticket(ticket)
        logger.info(f"创建工单：{ticket_id}")
        
        return ticket
    
    def _get_session_id(self, user_id: str, group_id: str = None) -> str:
        """获取会话 ID（简化版本）"""
        import hashlib
        user_hash = hashlib.md5(user_id.encode()).hexdigest()[:8]
        group_hash = hashlib.md5(group_id.encode()).hexdigest()[:8] if group_id else "direct"
        return f"session_{user_hash}_{group_hash}"
    
    def _get_next_number(self, session_id: str) -> int:
        """获取下一个工单编号（按会话独立计数）"""
        session_ticket_dir = self.tickets_dir / session_id
        session_ticket_dir.mkdir(parents=True, exist_ok=True)
        
        existing = list(session_ticket_dir.glob(f"TKT-{session_id}-*.json"))
        return len(existing) + 1
    
    def _save_ticket(self, ticket: Dict):
        """保存工单（按会话隔离存储）"""
        session_id = ticket.get("session_id", "default")
        session_ticket_dir = self.tickets_dir / session_id
        session_ticket_dir.mkdir(parents=True, exist_ok=True)
        
        file_path = session_ticket_dir / f"{ticket['ticket_id']}.json"
        
        # 原子写入（带文件锁）
        lock_file = session_ticket_dir / ".lock"
        try:
            with open(lock_file, 'w') as lf:
                fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
                try:
                    temp_file = file_path.with_suffix('.tmp')
                    with open(temp_file, 'w', encoding='utf-8') as f:
                        json.dump(ticket, f, ensure_ascii=False, indent=2)
                    temp_file.rename(file_path)
                finally:
                    fcntl.flock(lf.fileno(), fcntl.LOCK_UN)
        except Exception as e:
            logger.error(f"保存工单失败：{e}")
            raise


# 全局实例
ticket_manager = TicketManager()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python ticket_manager.py <command> [args]")
        print("命令:")
        print("  create <task_type> <user_id> [group_id] - 创建工单")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "create":
        if len(sys.argv) < 4:
            print("用法：create <task_type> <user_id> [group_id]")
            sys.exit(1)
        task_type = sys.argv[2]
        user_id = sys.argv[3]
        group_id = sys.argv[4] if len(sys.argv) > 4 else None
        
        ticket = ticket_manager.create_ticket(task_type, user_id, group_id)
        print(json.dumps(ticket, ensure_ascii=False, indent=2))
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
