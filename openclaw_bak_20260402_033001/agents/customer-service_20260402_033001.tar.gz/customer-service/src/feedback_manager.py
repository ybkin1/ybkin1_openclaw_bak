#!/usr/bin/env python3
"""
服务评价模块
功能：收集和管理用户服务评价
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger('feedback')


class FeedbackManager:
    """服务评价管理器"""
    
    def __init__(self):
        self.feedback_dir = Path("/root/.openclaw/workspace/agents/customer-service/feedback")
        self.feedback_dir.mkdir(parents=True, exist_ok=True)
        
        # 评价等级
        self.ratings = {
            5: "非常满意",
            4: "满意",
            3: "一般",
            2: "不满意",
            1: "非常不满意"
        }
    
    def submit_feedback(self, user_id: str, ticket_id: str, rating: int, comment: str = "") -> Dict:
        """
        提交服务评价
        
        Args:
            user_id: 用户 ID
            ticket_id: 工单 ID
            rating: 评分（1-5）
            comment: 评价内容
        
        Returns:
            提交结果
        """
        if rating < 1 or rating > 5:
            return {
                "success": False,
                "message": "❌ 评分无效，请输入 1-5 星"
            }
        
        feedback = {
            "feedback_id": f"FB-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "user_id": user_id,
            "ticket_id": ticket_id,
            "rating": rating,
            "rating_text": self.ratings[rating],
            "comment": comment,
            "submitted_at": datetime.now().isoformat()
        }
        
        # 保存到文件
        feedback_file = self.feedback_dir / f"{user_id}_feedback.json"
        
        feedbacks = []
        if feedback_file.exists():
            with open(feedback_file, 'r', encoding='utf-8') as f:
                feedbacks = json.load(f)
        
        feedbacks.append(feedback)
        
        with open(feedback_file, 'w', encoding='utf-8') as f:
            json.dump(feedbacks, f, ensure_ascii=False, indent=2)
        
        logger.info(f"收到评价：user={user_id}, rating={rating}, ticket={ticket_id}")
        
        return {
            "success": True,
            "message": f"""✅ **感谢您的评价！**

评分：{'⭐' * rating} ({self.ratings[rating]})

**您的反馈将帮助我们改进服务！**

如有其他问题，随时联系我。""",
            "feedback_id": feedback["feedback_id"]
        }
    
    def get_user_feedback_stats(self, user_id: str) -> Dict:
        """获取用户评价统计"""
        feedback_file = self.feedback_dir / f"{user_id}_feedback.json"
        
        if not feedback_file.exists():
            return {
                "total": 0,
                "average_rating": 0,
                "rating_distribution": {}
            }
        
        with open(feedback_file, 'r', encoding='utf-8') as f:
            feedbacks = json.load(f)
        
        total = len(feedbacks)
        average = sum(f["rating"] for f in feedbacks) / total if total > 0 else 0
        
        distribution = {}
        for rating in range(1, 6):
            count = sum(1 for f in feedbacks if f["rating"] == rating)
            distribution[str(rating)] = count
        
        return {
            "total": total,
            "average_rating": round(average, 2),
            "rating_distribution": distribution
        }
    
    def get_all_feedback_stats(self) -> Dict:
        """获取所有评价统计"""
        all_feedbacks = []
        
        for feedback_file in self.feedback_dir.glob("*_feedback.json"):
            with open(feedback_file, 'r', encoding='utf-8') as f:
                feedbacks = json.load(f)
                all_feedbacks.extend(feedbacks)
        
        total = len(all_feedbacks)
        average = sum(f["rating"] for f in all_feedbacks) / total if total > 0 else 0
        
        distribution = {}
        for rating in range(1, 6):
            count = sum(1 for f in all_feedbacks if f["rating"] == rating)
            distribution[str(rating)] = count
        
        # 低分评价（1-2 星）
        low_ratings = [f for f in all_feedbacks if f["rating"] <= 2]
        
        return {
            "total": total,
            "average_rating": round(average, 2),
            "rating_distribution": distribution,
            "low_rating_count": len(low_ratings),
            "low_rating_percentage": round(len(low_ratings) / total * 100, 2) if total > 0 else 0
        }
    
    def generate_feedback_report(self) -> str:
        """生成评价报告"""
        stats = self.get_all_feedback_stats()
        
        report = f"""# 服务评价报告

**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 总体统计

| 指标 | 数值 |
|------|------|
| 总评价数 | {stats['total']} |
| 平均评分 | {'⭐' * int(stats['average_rating'])} ({stats['average_rating']}/5) |
| 低分评价 | {stats['low_rating_count']} ({stats['low_rating_percentage']}%) |

## 评分分布

| 评分 | 数量 | 占比 |
|------|------|------|
| ⭐⭐⭐⭐⭐ | {stats['rating_distribution'].get('5', 0)} | {stats['rating_distribution'].get('5', 0) / stats['total'] * 100 if stats['total'] > 0 else 0:.1f}% |
| ⭐⭐⭐⭐ | {stats['rating_distribution'].get('4', 0)} | {stats['rating_distribution'].get('4', 0) / stats['total'] * 100 if stats['total'] > 0 else 0:.1f}% |
| ⭐⭐⭐ | {stats['rating_distribution'].get('3', 0)} | {stats['rating_distribution'].get('3', 0) / stats['total'] * 100 if stats['total'] > 0 else 0:.1f}% |
| ⭐⭐ | {stats['rating_distribution'].get('2', 0)} | {stats['rating_distribution'].get('2', 0) / stats['total'] * 100 if stats['total'] > 0 else 0:.1f}% |
| ⭐ | {stats['rating_distribution'].get('1', 0)} | {stats['rating_distribution'].get('1', 0) / stats['total'] * 100 if stats['total'] > 0 else 0:.1f}% |

## 改进建议

"""
        if stats['low_rating_percentage'] > 10:
            report += "⚠️ **低分评价占比较高**，建议：\n1. 分析低分评价原因\n2. 改进服务质量\n3. 加强用户沟通\n\n"
        
        if stats['average_rating'] >= 4.5:
            report += "✅ **服务质量优秀**，继续保持！\n\n"
        elif stats['average_rating'] >= 4.0:
            report += "✅ **服务质量良好**，有提升空间。\n\n"
        else:
            report += "⚠️ **服务质量需改进**，建议加强培训。\n\n"
        
        return report


# 全局实例
feedback_manager = FeedbackManager()


# CLI 测试
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python feedback_manager.py <command> [args]")
        print("命令:")
        print("  submit <user_id> <ticket_id> <rating> [comment] - 提交评价")
        print("  stats [user_id] - 查看统计")
        print("  report - 生成报告")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "submit":
        if len(sys.argv) < 5:
            print("用法：submit <user_id> <ticket_id> <rating> [comment]")
            sys.exit(1)
        user_id = sys.argv[2]
        ticket_id = sys.argv[3]
        rating = int(sys.argv[4])
        comment = sys.argv[5] if len(sys.argv) > 5 else ""
        
        result = feedback_manager.submit_feedback(user_id, ticket_id, rating, comment)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "stats":
        user_id = sys.argv[2] if len(sys.argv) > 2 else None
        
        if user_id:
            stats = feedback_manager.get_user_feedback_stats(user_id)
        else:
            stats = feedback_manager.get_all_feedback_stats()
        
        print(json.dumps(stats, ensure_ascii=False, indent=2))
    
    elif command == "report":
        report = feedback_manager.generate_feedback_report()
        print(report)
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
