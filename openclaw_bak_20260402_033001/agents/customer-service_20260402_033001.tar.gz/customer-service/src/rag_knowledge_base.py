#!/usr/bin/env python3
"""
RAG 知识库模块
功能：检索常见问答，减少重复回答
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger('rag_knowledge')


class RAGKnowledgeBase:
    """RAG 知识库"""
    
    def __init__(self):
        self.kb_dir = Path("/root/.openclaw/workspace/agents/customer-service/knowledge")
        self.kb_dir.mkdir(parents=True, exist_ok=True)
        
        # 知识库文件
        self.faq_file = self.kb_dir / "faq.json"
        self.solutions_file = self.kb_dir / "solutions.json"
        self.documents_file = self.kb_dir / "documents.json"
        
        # 初始化知识库
        self._init_knowledge_base()
    
    def _init_knowledge_base(self):
        """初始化知识库"""
        # FAQ 知识库
        if not self.faq_file.exists():
            faqs = {
                "faqs": [
                    {
                        "id": "faq_001",
                        "question": "如何分析 GPU 故障？",
                        "answer": """分析 GPU 故障的步骤：

1. **收集日志**
   - 运行 nvidia-smi -q
   - 运行 nvidia-bug-report.sh
   - 收集 dmesg 日志

2. **上传日志**
   - 直接发送日志文件给我
   - 或发送压缩包（.tar.gz/.zip）

3. **等待分析**
   - 我会自动分析日志
   - 生成故障分析报告
   - 提供维修方案

**快捷命令**:
```bash
# 运行完整诊断
/root/.openclaw/workspace/agents/server-maintenance/scripts/gpu-diagnostic-full.sh
```""",
                        "keywords": ["GPU", "故障", "分析", "诊断"],
                        "category": "fault_analysis"
                    },
                    {
                        "id": "faq_002",
                        "question": "GPU 掉线怎么办？",
                        "answer": """GPU 掉线的处理步骤：

**紧急处理**:
1. 重启服务器
2. 检查 PCIe 链路
3. 重新插拔 GPU

**诊断步骤**:
1. 运行 nvidia-smi -L 检查 GPU 列表
2. 检查 dmesg 日志中的 GPU 错误
3. 检查 PCIe 链路状态

**可能原因**:
- GPU 硬件故障
- PCIe 链路故障
- 电源供电不足
- GPU 过热保护

**预防措施**:
- 定期检查 GPU 状态
- 保持良好散热
- 使用稳定电源""",
                        "keywords": ["GPU", "掉线", "掉卡", "消失"],
                        "category": "fault_analysis"
                    },
                    {
                        "id": "faq_003",
                        "question": "如何上传文件？",
                        "answer": """上传文件的方法：

**企业微信**:
1. 直接拖拽文件到聊天窗口
2. 或点击"文件"按钮选择文件
3. 支持的文件格式：
   - 日志文件：.log, .txt
   - 压缩包：.tar.gz, .zip, .rar
   - 文档：.pdf, .docx, .md

**文件大小限制**:
- 企业微信：最大 20MB
- 本地处理：最大 500MB

**大文件处理**:
- 分割成多个小文件
- 通过共享目录传输
- 使用 FTP/SFTP 上传""",
                        "keywords": ["上传", "文件", "发送"],
                        "category": "file_upload"
                    },
                    {
                        "id": "faq_004",
                        "question": "ECC 错误是什么？",
                        "answer": """ECC 错误说明：

**什么是 ECC**:
- ECC = Error Correction Code
- 内存错误纠正码
- 可以检测和纠正内存错误

**ECC 错误类型**:
1. **SBE (Single Bit Error)** - 单比特错误
   - 可以自动纠正
   - 通常不影响系统运行
   - 需要关注错误频率

2. **DBE (Double Bit Error)** - 双比特错误
   - 无法纠正
   - 可能导致系统崩溃
   - 需要立即处理

**处理方法**:
1. 监控 ECC 错误计数
2. 如果错误频繁，更换 GPU
3. 定期清理灰尘，保持散热

**查看 ECC 错误**:
```bash
nvidia-smi -q -d ECC
```""",
                        "keywords": ["ECC", "错误", "内存"],
                        "category": "fault_analysis"
                    },
                    {
                        "id": "faq_005",
                        "question": "如何生成故障分析报告？",
                        "answer": """生成故障分析报告：

**自动方式**:
1. 上传日志文件给我
2. 说"分析故障"
3. 我会自动生成报告

**手动方式**:
1. 运行诊断脚本
```bash
/root/.openclaw/workspace/agents/server-maintenance/scripts/gpu-diagnostic-full.sh
```
2. 获取诊断输出
3. 整理成报告格式

**报告内容**:
- 故障时间
- 整机 SN、GPU SN
- 故障日志
- 故障分析
- 维修方案
- 预防措施""",
                        "keywords": ["报告", "生成", "故障分析"],
                        "category": "report"
                    }
                ]
            }
            
            with open(self.faq_file, 'w', encoding='utf-8') as f:
                json.dump(faqs, f, ensure_ascii=False, indent=2)
        
        # 解决方案知识库
        if not self.solutions_file.exists():
            solutions = {
                "solutions": [
                    {
                        "id": "sol_001",
                        "problem": "GPU 温度过高",
                        "solution": """**问题**: GPU 温度过高（超过 80°C）

**原因分析**:
1. 散热器灰尘堆积
2. 风扇故障
3. 机房温度过高
4. GPU 负载过高

**解决方案**:
1. 清理散热器灰尘
2. 检查风扇运转
3. 改善机房散热
4. 降低 GPU 负载

**预防措施**:
- 定期清理灰尘
- 监控温度告警
- 保持机房温度 20-25°C""",
                        "keywords": ["温度", "过热", "散热"],
                        "category": "temperature"
                    },
                    {
                        "id": "sol_002",
                        "problem": "PCIe 链路错误",
                        "solution": """**问题**: PCIe 链路错误

**原因分析**:
1. GPU 接触不良
2. PCIe 插槽故障
3. 主板故障
4. 电源供电不足

**解决方案**:
1. 重新插拔 GPU
2. 更换 PCIe 插槽
3. 检查电源供电
4. 更换主板

**诊断命令**:
```bash
# 检查 PCIe 链路
nvidia-smi -q -d BOARD

# 检查 PCIe 错误
dmesg | grep -i pcie
```""",
                        "keywords": ["PCIe", "链路", "插槽"],
                        "category": "pcie"
                    }
                ]
            }
            
            with open(self.solutions_file, 'w', encoding='utf-8') as f:
                json.dump(solutions, f, ensure_ascii=False, indent=2)
        
        # 文档知识库
        if not self.documents_file.exists():
            documents = {
                "documents": []
            }
            
            with open(self.documents_file, 'w', encoding='utf-8') as f:
                json.dump(documents, f, ensure_ascii=False, indent=2)
        
        logger.info("知识库初始化完成")
    
    def search_faq(self, query: str, top_k: int = 3) -> List[Dict]:
        """
        搜索 FAQ
        
        Args:
            query: 搜索查询
            top_k: 返回结果数量
        
        Returns:
            匹配的 FAQ 列表
        """
        with open(self.faq_file, 'r', encoding='utf-8') as f:
            faqs = json.load(f)["faqs"]
        
        # 简单关键词匹配
        query_keywords = set(query.lower().split())
        
        scored_faqs = []
        for faq in faqs:
            # 计算关键词匹配度
            keywords = set(faq["keywords"])
            match_score = len(query_keywords & keywords)
            
            # 问题文本匹配
            if any(kw in faq["question"].lower() for kw in query_keywords):
                match_score += 2
            
            # 答案文本匹配
            if any(kw in faq["answer"].lower() for kw in query_keywords):
                match_score += 1
            
            if match_score > 0:
                scored_faqs.append({
                    "faq": faq,
                    "score": match_score
                })
        
        # 按分数排序
        scored_faqs.sort(key=lambda x: x["score"], reverse=True)
        
        # 返回前 top_k 个
        return [item["faq"] for item in scored_faqs[:top_k]]
    
    def search_solution(self, problem: str, top_k: int = 3) -> List[Dict]:
        """
        搜索解决方案
        
        Args:
            problem: 问题描述
            top_k: 返回结果数量
        
        Returns:
            匹配的解决方案列表
        """
        with open(self.solutions_file, 'r', encoding='utf-8') as f:
            solutions = json.load(f)["solutions"]
        
        # 简单关键词匹配
        problem_keywords = set(problem.lower().split())
        
        scored_solutions = []
        for solution in solutions:
            # 计算关键词匹配度
            keywords = set(solution["keywords"])
            match_score = len(problem_keywords & keywords)
            
            # 问题文本匹配
            if any(kw in solution["problem"].lower() for kw in problem_keywords):
                match_score += 2
            
            # 解决方案文本匹配
            if any(kw in solution["solution"].lower() for kw in problem_keywords):
                match_score += 1
            
            if match_score > 0:
                scored_solutions.append({
                    "solution": solution,
                    "score": match_score
                })
        
        # 按分数排序
        scored_solutions.sort(key=lambda x: x["score"], reverse=True)
        
        # 返回前 top_k 个
        return [item["solution"] for item in scored_solutions[:top_k]]
    
    def add_faq(self, question: str, answer: str, keywords: List[str], category: str) -> Dict:
        """
        添加 FAQ
        
        Args:
            question: 问题
            answer: 答案
            keywords: 关键词列表
            category: 分类
        
        Returns:
            添加结果
        """
        with open(self.faq_file, 'r', encoding='utf-8') as f:
            faqs = json.load(f)
        
        faq_id = f"faq_{len(faqs['faqs']) + 1:03d}"
        
        new_faq = {
            "id": faq_id,
            "question": question,
            "answer": answer,
            "keywords": keywords,
            "category": category
        }
        
        faqs["faqs"].append(new_faq)
        
        with open(self.faq_file, 'w', encoding='utf-8') as f:
            json.dump(faqs, f, ensure_ascii=False, indent=2)
        
        logger.info(f"添加 FAQ: {faq_id}")
        
        return {
            "success": True,
            "faq_id": faq_id,
            "message": f"FAQ 已添加：{faq_id}"
        }
    
    def get_knowledge_stats(self) -> Dict:
        """获取知识库统计"""
        with open(self.faq_file, 'r', encoding='utf-8') as f:
            faqs = json.load(f)
        
        with open(self.solutions_file, 'r', encoding='utf-8') as f:
            solutions = json.load(f)
        
        with open(self.documents_file, 'r', encoding='utf-8') as f:
            documents = json.load(f)
        
        return {
            "faq_count": len(faqs["faqs"]),
            "solution_count": len(solutions["solutions"]),
            "document_count": len(documents["documents"]),
            "categories": self._get_categories(faqs["faqs"])
        }
    
    def _get_categories(self, items: List[Dict]) -> Dict[str, int]:
        """获取分类统计"""
        categories = {}
        for item in items:
            category = item.get("category", "unknown")
            categories[category] = categories.get(category, 0) + 1
        return categories


# 全局实例
rag_knowledge_base = RAGKnowledgeBase()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python rag_knowledge_base.py <command> [args]")
        print("命令:")
        print("  search <query> - 搜索 FAQ")
        print("  solution <problem> - 搜索解决方案")
        print("  stats - 查看统计")
        print("  add <question> <answer> <keywords> <category> - 添加 FAQ")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "search":
        if len(sys.argv) < 3:
            print("用法：search <query>")
            sys.exit(1)
        query = sys.argv[2]
        results = rag_knowledge_base.search_faq(query)
        for result in results:
            print(f"问题：{result['question']}")
            print(f"答案：{result['answer'][:100]}...\n")
    
    elif command == "solution":
        if len(sys.argv) < 3:
            print("用法：solution <problem>")
            sys.exit(1)
        problem = sys.argv[2]
        results = rag_knowledge_base.search_solution(problem)
        for result in results:
            print(f"问题：{result['problem']}")
            print(f"解决方案：{result['solution'][:100]}...\n")
    
    elif command == "stats":
        stats = rag_knowledge_base.get_knowledge_stats()
        print(json.dumps(stats, ensure_ascii=False, indent=2))
    
    elif command == "add":
        if len(sys.argv) < 6:
            print("用法：add <question> <answer> <keywords> <category>")
            sys.exit(1)
        question = sys.argv[2]
        answer = sys.argv[3]
        keywords = sys.argv[4].split(",")
        category = sys.argv[5]
        result = rag_knowledge_base.add_faq(question, answer, keywords, category)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
