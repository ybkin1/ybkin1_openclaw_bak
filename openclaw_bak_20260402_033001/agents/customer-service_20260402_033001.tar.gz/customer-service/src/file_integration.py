#!/usr/bin/env python3
"""
文件处理集成模块
功能：将文件处理流程集成到 Agent 调用链
"""

import logging
import subprocess
from pathlib import Path
from typing import Dict

logger = logging.getLogger('file_integration')


class FileIntegrationManager:
    """文件集成管理器"""
    
    def __init__(self):
        self.file_handler_path = Path("/root/.openclaw/workspace/agents/customer-service/src/file_handler.py")
    
    def handle_file_upload(self, file_path: str, message: str = "") -> Dict:
        """
        处理文件上传
        
        Args:
            file_path: 文件路径
            message: 用户消息
        
        Returns:
            处理结果
        """
        logger.info(f"处理文件上传：{file_path}, 消息：{message}")
        
        # 1. 意图识别
        intent = self._detect_intent(message, file_path)
        logger.info(f"意图识别结果：{intent}")
        
        # 2. 根据意图调用相应 Agent
        if intent["intent"] == "fault_analysis":
            return self._handle_fault_analysis(file_path)
        
        elif intent["intent"] == "documentation":
            return self._handle_documentation(file_path)
        
        elif intent["intent"] == "learning":
            return self._handle_learning(file_path)
        
        else:
            # 默认：调用 file-processor 处理文件
            return self._handle_default(file_path)
    
    def _detect_intent(self, message: str, file_path: str) -> Dict:
        """意图识别"""
        # 关键词匹配
        fault_keywords = ["故障", "分析", "diagnos", "analyze", "bug", "error", "失败"]
        doc_keywords = ["文档", "说明", "手册", "guide", "manual"]
        learning_keywords = ["学习", "教程", "tutorial", "怎么写", "如何"]
        
        message_lower = message.lower() if message else ""
        file_name = Path(file_path).name.lower()
        
        # 检查故障分析意图
        if any(kw in message_lower for kw in fault_keywords) or \
           any(kw in file_name for kw in fault_keywords):
            return {
                "intent": "fault_analysis",
                "confidence": 0.9,
                "description": "故障分析"
            }
        
        # 检查文档意图
        if any(kw in message_lower for kw in doc_keywords) or \
           any(kw in file_name for kw in doc_keywords):
            return {
                "intent": "documentation",
                "confidence": 0.8,
                "description": "文档处理"
            }
        
        # 检查学习意图
        if any(kw in message_lower for kw in learning_keywords):
            return {
                "intent": "learning",
                "confidence": 0.8,
                "description": "学习指导"
            }
        
        # 默认意图
        return {
            "intent": "unknown",
            "confidence": 0.5,
            "description": "未知意图，默认处理"
        }
    
    def _handle_fault_analysis(self, file_path: str) -> Dict:
        """处理故障分析"""
        try:
            # 调用 file-processor 处理文件
            file_result = self._call_agent("file-processor", f"处理文件：{file_path}")
            
            # 调用 server-maintenance 分析故障
            analysis_result = self._call_agent("server-maintenance", f"分析故障：{file_result.get('content', '')}")
            
            return {
                "success": True,
                "intent": "fault_analysis",
                "message": "故障分析完成",
                "result": analysis_result
            }
        
        except Exception as e:
            logger.error(f"故障分析失败：{e}")
            return {
                "success": False,
                "intent": "fault_analysis",
                "message": f"故障分析失败：{str(e)}",
                "error": str(e)
            }
    
    def _handle_documentation(self, file_path: str) -> Dict:
        """处理文档"""
        try:
            # 调用 file-processor 处理文件
            file_result = self._call_agent("file-processor", f"处理文档：{file_path}")
            
            return {
                "success": True,
                "intent": "documentation",
                "message": "文档处理完成",
                "result": file_result
            }
        
        except Exception as e:
            logger.error(f"文档处理失败：{e}")
            return {
                "success": False,
                "intent": "documentation",
                "message": f"文档处理失败：{str(e)}",
                "error": str(e)
            }
    
    def _handle_learning(self, file_path: str) -> Dict:
        """处理学习请求"""
        try:
            # 调用 file-processor 处理文件
            file_result = self._call_agent("file-processor", f"处理文件：{file_path}")
            
            return {
                "success": True,
                "intent": "learning",
                "message": "文件已处理，请提出具体学习问题",
                "result": file_result
            }
        
        except Exception as e:
            logger.error(f"学习请求处理失败：{e}")
            return {
                "success": False,
                "intent": "learning",
                "message": f"学习请求处理失败：{str(e)}",
                "error": str(e)
            }
    
    def _handle_default(self, file_path: str) -> Dict:
        """默认处理"""
        try:
            # 调用 file-processor 处理文件
            file_result = self._call_agent("file-processor", f"处理文件：{file_path}")
            
            return {
                "success": True,
                "intent": "default",
                "message": "文件已接收并处理",
                "result": file_result
            }
        
        except Exception as e:
            logger.error(f"默认处理失败：{e}")
            return {
                "success": False,
                "intent": "default",
                "message": f"文件处理失败：{str(e)}",
                "error": str(e)
            }
    
    def _call_agent(self, agent_id: str, task: str) -> Dict:
        """调用 Agent"""
        # 使用 sessions_spawn 调用 Agent
        # 这里是简化实现，实际需要通过 OpenClaw API 调用
        
        logger.info(f"调用 Agent: {agent_id}, 任务：{task}")
        
        # TODO: 实现真实的 Agent 调用
        # 目前返回模拟结果
        
        return {
            "success": True,
            "content": f"Agent {agent_id} 处理结果",
            "agent_id": agent_id
        }
    
    def restart_gateway(self) -> Dict:
        """重启 Gateway"""
        try:
            result = subprocess.run(
                ["systemctl", "--user", "restart", "openclaw-gateway"],
                capture_output=True, text=True, timeout=30
            )
            
            if result.returncode == 0:
                logger.info("Gateway 重启成功")
                return {
                    "success": True,
                    "message": "Gateway 重启成功"
                }
            else:
                logger.error(f"Gateway 重启失败：{result.stderr}")
                return {
                    "success": False,
                    "message": f"Gateway 重启失败：{result.stderr}"
                }
        
        except Exception as e:
            logger.error(f"Gateway 重启失败：{e}")
            return {
                "success": False,
                "message": f"Gateway 重启失败：{str(e)}",
                "error": str(e)
            }


# 全局实例
file_integration_manager = FileIntegrationManager()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 3:
        print("用法：python file_integration.py <command> [args]")
        print("命令:")
        print("  handle <file_path> [message] - 处理文件上传")
        print("  restart - 重启 Gateway")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "handle":
        file_path = sys.argv[2]
        message = sys.argv[3] if len(sys.argv) > 3 else ""
        
        result = file_integration_manager.handle_file_upload(file_path, message)
        print(f"处理结果：{result}")
    
    elif command == "restart":
        result = file_integration_manager.restart_gateway()
        print(f"重启结果：{result}")
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
