#!/usr/bin/env python3
"""
Customer Service Database API

为 customer-service 提供简化的数据库访问接口
封装 user/conversation/memory/ticket 操作
"""

import sqlite3
import uuid
import json
import sys
from typing import Optional, List, Dict, Any
from datetime import datetime

# 数据库路径
DB_PATH = "/root/.openclaw/workspace/agents/database-manager/data/customer-service.db"


class CustomerServiceDB:
    """customer-service 数据库客户端"""
    
    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
    
    def _get_connection(self) -> sqlite3.Connection:
        """获取数据库连接"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn
    
    # ========== 用户管理 ==========
    
    def create_or_update_user(self, user_id: str, name: str, user_type: str,
                              channel: str, channel_user_id: str,
                              phone: str = None, email: str = None,
                              company: str = None, org_id: str = None,
                              permission_level: int = None) -> Dict[str, Any]:
        """
        创建或更新用户信息
        
        Args:
            user_id: 用户 ID（唯一）
            name: 姓名
            user_type: 用户类型（internal/maintenance/regular）
            channel: 渠道（feishu/wecom）
            channel_user_id: 渠道用户 ID
            phone: 电话
            email: 邮箱
            company: 公司
            org_id: 组织 ID
            permission_level: 权限等级（1-3）
        
        Returns:
            {success: bool, user_id: str, message: str}
        """
        if permission_level is None:
            # 根据 user_type 自动设置权限等级
            permission_map = {
                'internal': 3,
                'maintenance': 2,
                'regular': 1
            }
            permission_level = permission_map.get(user_type, 1)
        
        sql = """
            INSERT INTO users (user_id, name, user_type, channel, channel_user_id,
                              phone, email, company, org_id, permission_level)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                name = excluded.name,
                user_type = excluded.user_type,
                phone = excluded.phone,
                email = excluded.email,
                company = excluded.company,
                org_id = excluded.org_id,
                permission_level = excluded.permission_level,
                last_active_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
        """
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [
                user_id, name, user_type, channel, channel_user_id,
                phone, email, company, org_id, permission_level
            ])
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'user_id': user_id,
                'message': f"用户 {name} 已创建/更新"
            }
            
        except sqlite3.Error as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_user(self, user_id: str) -> Optional[Dict[str, Any]]:
        """获取用户信息"""
        sql = "SELECT * FROM users WHERE user_id = ? AND deleted_at IS NULL"
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [user_id])
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return dict(row)
            return None
            
        except sqlite3.Error as e:
            return None
    
    def get_user_profile(self, user_id: str) -> Optional[Dict[str, Any]]:
        """获取用户完整画像（包括统计信息）"""
        sql = "SELECT * FROM v_user_profile WHERE user_id = ?"
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [user_id])
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return dict(row)
            return None
            
        except sqlite3.Error as e:
            return None
    
    # ========== 会话记录 ==========
    
    def create_conversation(self, user_id: str, role: str, content: str,
                           channel: str = None, parent_message_id: str = None,
                           thread_id: str = None, metadata: Dict = None) -> Dict[str, Any]:
        """
        创建会话记录
        
        Args:
            user_id: 用户 ID
            role: 角色（user/assistant）
            content: 内容
            channel: 渠道（feishu/wecom）
            parent_message_id: 父消息 ID
            thread_id: 线程 ID
            metadata: 元数据（JSON）
        
        Returns:
            {success: bool, conversation_id: str, message: str}
        """
        conversation_id = f"conv_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO conversations (conversation_id, user_id, channel, role, content,
                                      parent_message_id, thread_id, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [
                conversation_id, user_id, channel, role, content,
                parent_message_id, thread_id, json.dumps(metadata or {})
            ])
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'conversation_id': conversation_id,
                'message': "会话记录已创建"
            }
            
        except sqlite3.Error as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_user_conversations(self, user_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """获取用户最近会话记录"""
        sql = """
            SELECT * FROM conversations 
            WHERE user_id = ? AND deleted_at IS NULL
            ORDER BY created_at DESC
            LIMIT ?
        """
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [user_id, limit])
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            return []
    
    # ========== 用户记忆 ==========
    
    def create_memory(self, user_id: str, memory_type: str, subject: str,
                     predicate: str, object: str, confidence: float = 1.0,
                     source_conversation_id: str = None) -> Dict[str, Any]:
        """
        创建用户记忆
        
        Args:
            user_id: 用户 ID
            memory_type: 记忆类型（fact/preference/context/emotion）
            subject: 主题
            predicate: 关系
            object: 内容
            confidence: 置信度（0-1）
            source_conversation_id: 来源会话 ID
        
        Returns:
            {success: bool, memory_id: str, message: str}
        """
        memory_id = f"mem_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO user_memories (memory_id, user_id, memory_type, subject,
                                      predicate, object, confidence, source_conversation_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [
                memory_id, user_id, memory_type, subject, predicate, object,
                confidence, source_conversation_id
            ])
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'memory_id': memory_id,
                'message': f"记忆已创建：{subject}"
            }
            
        except sqlite3.Error as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_user_memories(self, user_id: str, verified_only: bool = False) -> List[Dict[str, Any]]:
        """获取用户记忆"""
        sql = """
            SELECT * FROM user_memories 
            WHERE user_id = ? AND deleted_at IS NULL
        """
        
        if verified_only:
            sql += " AND verified = TRUE AND confidence >= 0.8"
        
        sql += " ORDER BY verified_at DESC, created_at DESC"
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [user_id])
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            return []
    
    def verify_memory(self, memory_id: str, verified_by: str = 'system') -> Dict[str, Any]:
        """验证记忆"""
        sql = """
            UPDATE user_memories 
            SET verified = TRUE, verified_by = ?, verified_at = CURRENT_TIMESTAMP
            WHERE memory_id = ?
        """
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [verified_by, memory_id])
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'message': "记忆已验证"
            }
            
        except sqlite3.Error as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    # ========== 工单管理 ==========
    
    def create_ticket(self, user_id: str, title: str, description: str = None,
                     category: str = None, subcategory: str = None,
                     priority: int = 2) -> Dict[str, Any]:
        """
        创建工单
        
        Args:
            user_id: 用户 ID
            title: 工单标题
            description: 工单描述
            category: 分类（fault/consultation/upgrade/other）
            subcategory: 子分类
            priority: 优先级（1-5，1=紧急）
        
        Returns:
            {success: bool, ticket_id: str, message: str}
        """
        ticket_id = f"tkt_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO tickets (ticket_id, user_id, title, description,
                                category, subcategory, priority, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [
                ticket_id, user_id, title, description,
                category, subcategory, priority, 'pending'
            ])
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'ticket_id': ticket_id,
                'message': f"工单已创建：{title}"
            }
            
        except sqlite3.Error as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def update_ticket_status(self, ticket_id: str, status: str,
                            solution: str = None) -> Dict[str, Any]:
        """更新工单状态"""
        sql = """
            UPDATE tickets 
            SET status = ?, solution = ?, updated_at = CURRENT_TIMESTAMP
            WHERE ticket_id = ?
        """
        
        if status == 'completed':
            sql = """
                UPDATE tickets 
                SET status = ?, solution = ?, completed_at = CURRENT_TIMESTAMP,
                    updated_at = CURRENT_TIMESTAMP
                WHERE ticket_id = ?
            """
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [status, solution, ticket_id])
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'message': f"工单状态已更新：{status}"
            }
            
        except sqlite3.Error as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_user_tickets(self, user_id: str, status: str = None) -> List[Dict[str, Any]]:
        """获取用户工单"""
        sql = """
            SELECT * FROM tickets 
            WHERE user_id = ? AND deleted_at IS NULL
        """
        
        params = [user_id]
        
        if status:
            sql += " AND status = ?"
            params.append(status)
        
        sql += " ORDER BY created_at DESC"
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            return []
    
    def get_active_tickets(self) -> List[Dict[str, Any]]:
        """获取所有活跃工单"""
        sql = "SELECT * FROM v_active_tickets"
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql)
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            return []
    
    # ========== 知识库检索 ==========
    
    def search_knowledge(self, query: str = None, category: str = None,
                        user_permission_level: int = 1, limit: int = 5,
                        use_semantic: bool = True) -> List[Dict[str, Any]]:
        """
        检索知识库（支持语义检索）
        
        Args:
            query: 搜索关键词
            category: 分类
            user_permission_level: 用户权限等级
            limit: 返回数量
            use_semantic: 是否使用语义检索（默认 True）
        
        Returns:
            知识库条目列表
        """
        
        # 尝试语义检索
        if use_semantic and query:
            semantic_results = self._search_knowledge_semantic(
                query=query,
                user_permission_level=user_permission_level,
                limit=limit
            )
            if semantic_results:
                return semantic_results
        
        # 降级到关键词检索
        sql = """
            SELECT * FROM knowledge_base 
            WHERE min_permission_level <= ? AND deleted_at IS NULL
        """
        
        params = [user_permission_level]
        
        if category:
            sql += " AND category = ?"
            params.append(category)
        
        if query:
            sql += " AND (title LIKE ? OR content LIKE ? OR tags LIKE ?)"
            like_query = f"%{query}%"
            params.extend([like_query, like_query, like_query])
        
        sql += " ORDER BY quality_score DESC, usage_count DESC LIMIT ?"
        params.append(limit)
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
            
        except sqlite3.Error as e:
            return []
    
    def _search_knowledge_semantic(self, query: str, user_permission_level: int = 1,
                                   limit: int = 5) -> List[Dict[str, Any]]:
        """
        语义检索（使用 LanceDB 向量）
        
        Args:
            query: 搜索查询
            user_permission_level: 用户权限等级
            limit: 返回数量
        
        Returns:
            知识库条目列表
        """
        try:
            sys.path.insert(0, '/root/.openclaw/workspace/agents/database-manager/src')
            from lancedb_client import LanceDBClient
            import hashlib
            
            # 生成查询向量
            def get_simple_embedding(text: str):
                hash_bytes = hashlib.md5(text.encode()).digest()
                vector = list(hash_bytes) * 24  # 扩展到 384 维
                return [(x - 128) / 128.0 for x in vector[:384]]
            
            query_vector = get_simple_embedding(query)
            
            # 连接 LanceDB
            client = LanceDBClient(uri="/root/.openclaw/workspace/agents/database-manager/data/knowledge_vectors")
            client.connect()
            table = client.open_table("knowledge_vectors")
            
            # 搜索
            results = table.search(query_vector).limit(limit * 2).to_pandas()
            
            if len(results) == 0:
                return []
            
            # 过滤权限并返回
            knowledge_ids = results['knowledge_id'].tolist()
            
            # 从 SQLite 获取详细信息
            sql = """
                SELECT * FROM knowledge_base 
                WHERE knowledge_id IN ({}) 
                AND min_permission_level <= ?
                AND deleted_at IS NULL
            """.format(','.join(['?' for _ in knowledge_ids]))
            
            params = knowledge_ids + [user_permission_level]
            
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, params)
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows[:limit]]
            
        except Exception as e:
            # 语义检索失败，返回空列表（会降级到关键词检索）
            return []
    
    # ========== 访问日志 ==========
    
    def log_access(self, user_id: str, agent_id: str, table_name: str,
                  action: str, record_id: str = None, success: bool = True,
                  error_message: str = None, channel: str = None) -> Dict[str, Any]:
        """记录访问日志"""
        log_id = f"log_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO access_logs (log_id, user_id, agent_id, table_name,
                                    record_id, action, success, error_message, channel)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute(sql, [
                log_id, user_id, agent_id, table_name, record_id,
                action, success, error_message, channel
            ])
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'log_id': log_id
            }
            
        except sqlite3.Error as e:
            return {
                'success': False,
                'error': str(e)
            }


# ========== 便捷函数 ==========

def get_db() -> CustomerServiceDB:
    """获取数据库客户端实例"""
    return CustomerServiceDB()


# ========== 测试代码 ==========

if __name__ == "__main__":
    db = get_db()
    
    print("📊 Customer Service Database API 测试")
    print("=" * 50)
    
    # 测试用户创建
    result = db.create_or_update_user(
        user_id="test_api_001",
        name="测试用户 API",
        user_type="regular",
        channel="wecom",
        channel_user_id="ou_test_api_001"
    )
    print(f"✅ 用户创建：{result}")
    
    # 测试用户查询
    user = db.get_user("test_api_001")
    print(f"📖 用户信息：{user['name'] if user else 'None'}")
    
    # 测试会话记录
    result = db.create_conversation(
        user_id="test_api_001",
        role="user",
        content="服务器报错了",
        channel="wecom",
        metadata={"intent": "fault_analysis"}
    )
    print(f"✅ 会话创建：{result}")
    
    # 测试记忆创建
    result = db.create_memory(
        user_id="test_api_001",
        memory_type="fact",
        subject="server_issue",
        predicate="reported",
        object="server error",
        confidence=0.9
    )
    print(f"✅ 记忆创建：{result}")
    
    # 测试工单创建
    result = db.create_ticket(
        user_id="test_api_001",
        title="API 测试工单",
        description="测试数据库 API",
        category="fault",
        priority=2
    )
    print(f"✅ 工单创建：{result}")
    
    # 测试用户画像
    profile = db.get_user_profile("test_api_001")
    print(f"📊 用户画像：工单数={profile['total_tickets']}, 会话数={profile['total_conversations']}")
    
    # 清理测试数据
    print("\n🧹 清理测试数据...")
    # 实际使用时应删除测试数据
    
    print("\n✅ 所有 API 测试完成！")
