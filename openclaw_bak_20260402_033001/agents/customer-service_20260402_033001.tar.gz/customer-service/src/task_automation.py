#!/usr/bin/env python3
"""
任务自动化规则模块
功能：设置和执行自动化任务
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger('task_automation')


class TaskAutomationManager:
    """任务自动化管理器"""
    
    def __init__(self):
        self.rules_dir = Path("/root/.openclaw/workspace/agents/customer-service/automation")
        self.rules_dir.mkdir(parents=True, exist_ok=True)
        
        self.rules_file = self.rules_dir / "rules.json"
        self._init_default_rules()
    
    def _init_default_rules(self):
        """初始化默认规则"""
        if not self.rules_file.exists():
            default_rules = {
                "rules": [
                    {
                        "id": "rule_001",
                        "name": "每日工单提醒",
                        "type": "schedule",
                        "schedule": "0 9 * * *",  # 每天 9 点
                        "action": "send_message",
                        "message": "⏰ **每日工单提醒**\n\n新的一天开始了！请检查待处理工单。",
                        "enabled": True
                    },
                    {
                        "id": "rule_002",
                        "name": "会议前提醒",
                        "type": "before_event",
                        "minutes_before": 15,
                        "action": "send_message",
                        "message": "⏰ **会议提醒**\n\n您有一个会议即将开始，请做好准备。",
                        "enabled": True
                    },
                    {
                        "id": "rule_003",
                        "name": "工单超时告警",
                        "type": "ticket_timeout",
                        "timeout_hours": 2,
                        "action": "send_alert",
                        "message": "⚠️ **工单超时告警**\n\n有工单已超过 2 小时未处理。",
                        "enabled": True
                    }
                ]
            }
            
            with open(self.rules_file, 'w', encoding='utf-8') as f:
                json.dump(default_rules, f, ensure_ascii=False, indent=2)
    
    def add_rule(self, rule: Dict) -> Dict:
        """添加自动化规则"""
        with open(self.rules_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        rule_id = f"rule_{len(data['rules']) + 1:03d}"
        rule["id"] = rule_id
        rule["created_at"] = datetime.now().isoformat()
        
        data["rules"].append(rule)
        
        with open(self.rules_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"添加规则：{rule_id}")
        
        return {
            "success": True,
            "rule_id": rule_id,
            "message": f"规则已添加：{rule_id}"
        }
    
    def remove_rule(self, rule_id: str) -> Dict:
        """删除规则"""
        with open(self.rules_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        data["rules"] = [r for r in data["rules"] if r["id"] != rule_id]
        
        with open(self.rules_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"删除规则：{rule_id}")
        
        return {
            "success": True,
            "message": f"规则已删除：{rule_id}"
        }
    
    def enable_rule(self, rule_id: str) -> Dict:
        """启用规则"""
        return self._update_rule(rule_id, {"enabled": True})
    
    def disable_rule(self, rule_id: str) -> Dict:
        """禁用规则"""
        return self._update_rule(rule_id, {"enabled": False})
    
    def _update_rule(self, rule_id: str, updates: Dict) -> Dict:
        """更新规则"""
        with open(self.rules_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        for rule in data["rules"]:
            if rule["id"] == rule_id:
                rule.update(updates)
                break
        
        with open(self.rules_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return {
            "success": True,
            "message": f"规则已更新：{rule_id}"
        }
    
    def get_rules(self) -> List[Dict]:
        """获取所有规则"""
        with open(self.rules_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return data["rules"]
    
    def get_enabled_rules(self) -> List[Dict]:
        """获取启用的规则"""
        return [r for r in self.get_rules() if r.get("enabled", True)]
    
    def check_and_execute(self) -> List[Dict]:
        """检查并执行到期的规则"""
        executed = []
        
        for rule in self.get_enabled_rules():
            if self._should_execute(rule):
                result = self._execute_rule(rule)
                executed.append(result)
        
        return executed
    
    def _should_execute(self, rule: Dict) -> bool:
        """判断是否应该执行规则"""
        rule_type = rule.get("type")
        
        if rule_type == "schedule":
            # TODO: 实现 cron 表达式解析
            return False
        
        elif rule_type == "ticket_timeout":
            # 检查是否有超时的工单
            return self._check_ticket_timeout(rule.get("timeout_hours", 2))
        
        elif rule_type == "before_event":
            # TODO: 检查日历事件
            return False
        
        return False
    
    def _check_ticket_timeout(self, timeout_hours: int) -> bool:
        """检查是否有超时的工单"""
        tickets_dir = Path("/root/.openclaw/workspace/agents/customer-service/tickets")
        if not tickets_dir.exists():
            return False
        
        timeout_threshold = datetime.now() - timedelta(hours=timeout_hours)
        
        for session_dir in tickets_dir.glob("session_*/"):
            for ticket_file in session_dir.glob("TKT-*.json"):
                try:
                    with open(ticket_file, 'r', encoding='utf-8') as f:
                        ticket = json.load(f)
                    
                    if ticket.get("status") == "pending_data":
                        created_at = datetime.fromisoformat(ticket["created_at"])
                        if created_at < timeout_threshold:
                            return True
                except:
                    pass
        
        return False
    
    def _execute_rule(self, rule: Dict) -> Dict:
        """执行规则"""
        action = rule.get("action")
        
        if action == "send_message":
            return {
                "rule_id": rule["id"],
                "action": "send_message",
                "message": rule.get("message"),
                "executed_at": datetime.now().isoformat()
            }
        
        elif action == "send_alert":
            return {
                "rule_id": rule["id"],
                "action": "send_alert",
                "message": rule.get("message"),
                "executed_at": datetime.now().isoformat()
            }
        
        return {
            "rule_id": rule["id"],
            "action": action,
            "executed_at": datetime.now().isoformat()
        }


# 全局实例
task_automation_manager = TaskAutomationManager()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python task_automation.py <command> [args]")
        print("命令:")
        print("  list - 列出规则")
        print("  add <name> <type> <action> - 添加规则")
        print("  enable <rule_id> - 启用规则")
        print("  disable <rule_id> - 禁用规则")
        print("  check - 检查并执行")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "list":
        rules = task_automation_manager.get_rules()
        for rule in rules:
            status = "✅" if rule.get("enabled", True) else "❌"
            print(f"{status} {rule['id']}: {rule['name']} ({rule['type']})")
    
    elif command == "check":
        executed = task_automation_manager.check_and_execute()
        if executed:
            print(f"执行了 {len(executed)} 个规则:")
            for result in executed:
                print(f"  - {result['rule_id']}: {result['action']}")
        else:
            print("暂无需要执行的规则")
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
