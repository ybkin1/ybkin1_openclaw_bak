#!/usr/bin/env python3
"""
工作汇报生成模块
功能：自动生成日报/周报
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List

logger = logging.getLogger('work_report')


class WorkReportGenerator:
    """工作汇报生成器"""
    
    def __init__(self):
        self.reports_dir = Path("/root/.openclaw/workspace/agents/customer-service/reports")
        self.reports_dir.mkdir(parents=True, exist_ok=True)
    
    def generate_daily_report(self, user_id: str) -> str:
        """生成日报"""
        today = datetime.now()
        yesterday = today - timedelta(days=1)
        
        # 获取今日工单
        tickets = self._get_tickets(user_id, yesterday, today)
        
        # 获取服务评价
        feedbacks = self._get_feedbacks(user_id, yesterday, today)
        
        report = f"""# 工作日报

**日期**: {yesterday.strftime('%Y-%m-%d')}
**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 今日工作统计

### 工单处理
- 总工单数：{len(tickets)}
- 已完成：{sum(1 for t in tickets if t.get('status') == 'completed')}
- 处理中：{sum(1 for t in tickets if t.get('status') == 'in_progress')}
- 待处理：{sum(1 for t in tickets if t.get('status') == 'pending_data')}

### 服务评价
- 总评价数：{len(feedbacks)}
- 平均评分：{self._calculate_average_rating(feedbacks):.1f}/5.0
- 好评率：{self._calculate_positive_rate(feedbacks):.1f}%

## 工单详情

"""
        
        for ticket in tickets[:10]:  # 最多显示 10 个
            report += f"""### {ticket.get('ticket_id', 'N/A')}
- 类型：{ticket.get('task_type', 'N/A')}
- 状态：{ticket.get('status', 'N/A')}
- 创建时间：{ticket.get('created_at', 'N/A')}

"""
        
        report += """## 明日计划

- 继续处理待处理工单
- 跟进用户反馈
- 优化服务质量

## 问题与建议

"""
        
        # 分析问题
        pending_count = sum(1 for t in tickets if t.get('status') == 'pending_data')
        if pending_count > 5:
            report += "- ⚠️ 待处理工单较多，建议增加人手\n"
        
        low_rating_count = sum(1 for f in feedbacks if f.get('rating', 5) <= 3)
        if low_rating_count > 0:
            report += f"- ⚠️ 收到 {low_rating_count} 个中差评，需要改进服务质量\n"
        
        return report
    
    def generate_weekly_report(self, user_id: str) -> str:
        """生成周报"""
        today = datetime.now()
        last_week = today - timedelta(days=7)
        
        # 获取本周工单
        tickets = self._get_tickets(user_id, last_week, today)
        
        # 获取本周评价
        feedbacks = self._get_feedbacks(user_id, last_week, today)
        
        report = f"""# 工作周报

**周期**: {last_week.strftime('%Y-%m-%d')} 至 {today.strftime('%Y-%m-%d')}
**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 本周工作统计

### 工单处理
- 总工单数：{len(tickets)}
- 日均工单：{len(tickets) / 7:.1f}
- 完成率：{self._calculate_completion_rate(tickets):.1f}%

### 服务评价
- 总评价数：{len(feedbacks)}
- 平均评分：{self._calculate_average_rating(feedbacks):.1f}/5.0
- 好评率：{self._calculate_positive_rate(feedbacks):.1f}%

## 工单类型分布

"""
        
        # 按类型统计
        type_counts = {}
        for ticket in tickets:
            task_type = ticket.get('task_type', 'unknown')
            type_counts[task_type] = type_counts.get(task_type, 0) + 1
        
        for task_type, count in sorted(type_counts.items(), key=lambda x: x[1], reverse=True):
            report += f"- {task_type}: {count} 个\n"
        
        report += f"""
## 趋势分析

"""
        
        # 与上周对比
        two_weeks_ago = last_week - timedelta(days=7)
        last_week_tickets = self._get_tickets(user_id, two_weeks_ago, last_week)
        
        ticket_change = len(tickets) - len(last_week_tickets)
        ticket_change_percent = (ticket_change / len(last_week_tickets) * 100) if last_week_tickets else 0
        
        if ticket_change > 0:
            report += f"- 工单数：↑ {ticket_change} ({ticket_change_percent:.1f}%)\n"
        elif ticket_change < 0:
            report += f"- 工单数：↓ {abs(ticket_change)} ({abs(ticket_change_percent):.1f}%)\n"
        else:
            report += "- 工单数：持平\n"
        
        report += """
## 下周计划

- 保持服务质量
- 提高响应速度
- 收集用户反馈

## 问题与建议

"""
        
        # 分析问题
        completion_rate = self._calculate_completion_rate(tickets)
        if completion_rate < 80:
            report += "- ⚠️ 工单完成率较低，需要改进\n"
        
        positive_rate = self._calculate_positive_rate(feedbacks)
        if positive_rate < 90:
            report += f"- ⚠️ 好评率 {positive_rate:.1f}%，需要提升服务质量\n"
        
        return report
    
    def _get_tickets(self, user_id: str, start_date: datetime, end_date: datetime) -> List[Dict]:
        """获取指定时间段的工单"""
        tickets = []
        
        tickets_dir = Path("/root/.openclaw/workspace/agents/customer-service/tickets")
        if not tickets_dir.exists():
            return tickets
        
        # 遍历所有会话目录
        for session_dir in tickets_dir.glob("session_*/"):
            for ticket_file in session_dir.glob("TKT-*.json"):
                try:
                    with open(ticket_file, 'r', encoding='utf-8') as f:
                        ticket = json.load(f)
                    
                    created_at = datetime.fromisoformat(ticket["created_at"])
                    if start_date <= created_at <= end_date:
                        tickets.append(ticket)
                except Exception as e:
                    logger.error(f"读取工单失败：{e}")
        
        return tickets
    
    def _get_feedbacks(self, user_id: str, start_date: datetime, end_date: datetime) -> List[Dict]:
        """获取指定时间段的反馈"""
        feedbacks = []
        
        feedback_dir = Path("/root/.openclaw/workspace/agents/customer-service/feedback")
        if not feedback_dir.exists():
            return feedbacks
        
        for feedback_file in feedback_dir.glob("*_feedback.json"):
            try:
                with open(feedback_file, 'r', encoding='utf-8') as f:
                    user_feedbacks = json.load(f)
                
                for feedback in user_feedbacks:
                    submitted_at = datetime.fromisoformat(feedback["submitted_at"])
                    if start_date <= submitted_at <= end_date:
                        feedbacks.append(feedback)
            except Exception as e:
                logger.error(f"读取反馈失败：{e}")
        
        return feedbacks
    
    def _calculate_average_rating(self, feedbacks: List[Dict]) -> float:
        """计算平均评分"""
        if not feedbacks:
            return 0.0
        
        total = sum(f.get("rating", 0) for f in feedbacks)
        return total / len(feedbacks)
    
    def _calculate_positive_rate(self, feedbacks: List[Dict]) -> float:
        """计算好评率（4-5 星为好评）"""
        if not feedbacks:
            return 100.0
        
        positive = sum(1 for f in feedbacks if f.get("rating", 0) >= 4)
        return (positive / len(feedbacks)) * 100
    
    def _calculate_completion_rate(self, tickets: List[Dict]) -> float:
        """计算完成率"""
        if not tickets:
            return 100.0
        
        completed = sum(1 for t in tickets if t.get("status") == "completed")
        return (completed / len(tickets)) * 100
    
    def save_report(self, report: str, report_type: str = "daily"):
        """保存报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = self.reports_dir / f"{report_type}_report_{timestamp}.md"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        logger.info(f"报告已保存：{report_file}")
        return str(report_file)


# 全局实例
work_report_generator = WorkReportGenerator()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python work_report_generator.py <command> [user_id]")
        print("命令:")
        print("  daily [user_id] - 生成日报")
        print("  weekly [user_id] - 生成周报")
        sys.exit(1)
    
    command = sys.argv[1]
    user_id = sys.argv[2] if len(sys.argv) > 2 else "default"
    
    if command == "daily":
        report = work_report_generator.generate_daily_report(user_id)
        print(report)
        report_file = work_report_generator.save_report(report, "daily")
        print(f"\n报告已保存：{report_file}")
    
    elif command == "weekly":
        report = work_report_generator.generate_weekly_report(user_id)
        print(report)
        report_file = work_report_generator.save_report(report, "weekly")
        print(f"\n报告已保存：{report_file}")
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
