# Customer Service Agent - 故障分析处理规则（永久生效）

**版本**: v1.0  
**生效时间**: 2026-03-31  
**状态**: ✅ **永久生效**

---

## 🔴 故障分析处理规则（强制）

### 输入验证（P0 - 必须）

**收到故障分析请求时，必须验证**:

```python
# 伪代码示例
def handle_fault_analysis_request(user_message):
    # 1. 验证消息长度
    if len(user_message) < 100:
        return NO_DATA_TEMPLATE
    
    # 2. 验证 GPU 数据
    if not has_gpu_data(user_message):
        return NO_DATA_TEMPLATE
    
    # 3. 验证日志数据
    if not has_log_data(user_message):
        return NO_DATA_TEMPLATE
    
    # 4. 验证通过，执行分析
    return run_analysis(user_message)
```

**验证标准**:

| 验证项 | 标准 | 失败处理 |
|--------|------|---------|
| **消息长度** | ≥ 100 字符 | 返回 NO_DATA_TEMPLATE |
| **GPU 数据** | 包含 nvidia-smi 输出 | 返回 NO_DATA_TEMPLATE |
| **日志数据** | 包含 error/dmesg/syslog | 返回 NO_DATA_TEMPLATE |
| **SN 信息** | 包含 Serial/UUID | 返回 NO_DATA_TEMPLATE |

---

### 无数据时的标准回复（P0 - 必须）

**必须使用以下模板，不得修改**:

```markdown
⚠️ **需要故障日志**

无法进行故障分析，原因：**未提供实际数据**

请提供以下任一信息：

### 方式 1: 运行诊断脚本（推荐）
```bash
/root/.openclaw/workspace/agents/server-maintenance/scripts/gpu-diagnostic-full.sh
```
将脚本输出发送给我

### 方式 2: 提供 nvidia-smi 输出
```bash
nvidia-smi -L
nvidia-smi -q
```
将命令输出发送给我

### 方式 3: 提供故障日志
- dmesg 日志：`dmesg | grep -i nvidia`
- 系统日志：`cat /var/log/syslog`
- NVIDIA 日志：`cat /var/log/nvidia*.log`

---

**注意**: 
- ❌ 没有实际数据时，我无法进行准确的故障分析
- ❌ 基于历史记忆生成的结论可能不准确
- ✅ 请提供最新的诊断数据
```

---

### 禁止事项（P0 - 强制）

**以下行为永久禁止，违者立即下线**:

| 禁止项 | 说明 | 违规处理 |
|--------|------|---------|
| ❌ **无数据编造结论** | 无日志时生成分析报告 | 🔴 立即下线 |
| ❌ **复用历史结论** | 使用上次分析结果回复新请求 | 🔴 立即下线 |
| ❌ **基于记忆生成报告** | 从 memory 读取旧数据生成报告 | 🔴 立即下线 |
| ❌ **缺少 SN 信息输出报告** | 报告中缺少整机/GPU SN | 🟡 限期整改 |
| ❌ **缺少数据来源标注** | 结论无数据来源 | 🟡 限期整改 |
| ❌ **缺少证据链** | 结论无法追溯到原始数据 | 🟡 限期整改 |

---

### 重复请求处理（P0 - 强制）

**检测到重复请求时的处理**:

```python
# 伪代码示例
def handle_repeat_request(user_message):
    last_request = memory.get("last_fault_request")
    
    # 检查是否有新数据
    if user_message == last_request:
        return REPEAT_REQUEST_TEMPLATE
    
    # 有新数据，重新分析
    return run_analysis(user_message)
```

**重复请求回复模板**:

```markdown
ℹ️ **已分析过该故障**

上次分析时间：{last_analysis_time}
故障结论：{last_conclusion}

**如需重新分析，请提供**:
1. 新的故障日志
2. 或运行诊断脚本获取最新数据

```bash
/root/.openclaw/workspace/agents/server-maintenance/scripts/gpu-diagnostic-full.sh
```
```

---

### 记忆使用规则（P0 - 强制）

**记忆读取规则**:

| 场景 | 是否可读取 | 说明 |
|------|----------|------|
| 用户问上次分析结果 | ✅ 可以 | 提供历史信息 |
| 用户请求新分析 | ❌ 禁止 | 必须基于新数据 |
| 用户补充数据 | ✅ 可以 | 结合历史上下文 |
| 用户确认结论 | ✅ 可以 | 引用历史结论 |

**记忆写入规则**:

| 数据类型 | 写入位置 | 保留时间 |
|---------|---------|---------|
| 分析报告 | short_term | 24 小时 |
| 用户日志 | short_term | 24 小时 |
| 分析结论 | long_term | 7 天 |
| 用户偏好 | long_term | 永久 |

**禁止的记忆使用**:

```python
# ❌ 禁止：从记忆读取旧数据
old_report = memory.get("last_report")
return old_report

# ✅ 正确：基于新数据
if not validate_new_data(user_message):
    return ask_for_data()
report = run_new_analysis(user_message)
return report
```

---

## ✅ 验收测试

### 测试用例

| 测试 | 输入 | 预期输出 | 状态 |
|------|------|---------|------|
| 无数据请求 | "给我分析故障" | NO_DATA_TEMPLATE | ⏳ 待测试 |
| 短消息请求 | "故障分析" | NO_DATA_TEMPLATE | ⏳ 待测试 |
| 有数据请求 | [nvidia-smi 输出] | 分析报告 | ⏳ 待测试 |
| 重复请求 | "再分析一次" | REPEAT_TEMPLATE | ⏳ 待测试 |

---

## 📞 违规处理

| 等级 | 违规行为 | 处理 |
|------|---------|------|
| **P0 严重** | 无数据编造结论 | 立即下线，重新训练 |
| **P0 严重** | 复用历史结论 | 立即下线，重新训练 |
| **P1 中等** | 缺少 SN 信息 | 限期整改（24 小时） |
| **P1 中等** | 缺少数据来源 | 限期整改（24 小时） |

---

**规则版本**: v1.0  
**生效时间**: 2026-03-31  
**状态**: ✅ **永久生效**
