# Customer Service Agent - 意图识别与路由方案

**版本**: v1.0  
**创建时间**: 2026-03-31  
**状态**: ✅ **立即实施**

---

## 📋 意图分类

### 意图 1: 故障分析

**触发关键词**:
- "分析"、"诊断"、"故障"、"问题"、"错误"、"报错"
- "analyze"、"diagnos"、"fault"、"error"、"issue"
- "为什么"、"怎么回事"、"出了什么问题"

**典型消息**:
- "分析故障"
- "这个日志有什么问题？"
- "诊断一下 GPU"
- "为什么报错了？"

**调用 Agent**:
```
file-processor → server-maintenance
```

---

### 意图 2: 文件处理（仅处理）

**触发关键词**:
- "处理"、"转换"、"提取"、"解析"
- "process"、"convert"、"extract"、"parse"
- "解压"、"打开"、"查看内容"

**典型消息**:
- "处理这个文件"
- "转换成 Markdown"
- "提取内容"
- "解压这个压缩包"
- "查看文件内容"

**调用 Agent**:
```
file-processor（仅处理，不调用 server-maintenance）
```

---

### 意图 3: 学习/参考

**触发关键词**:
- "学习"、"参考"、"模板"、"示例"
- "learn"、"reference"、"template"、"example"
- "怎么写"、"如何写"、"格式"

**典型消息**:
- "学习怎么写报告"
- "这是报告模板"
- "参考一下这个格式"
- "如何写故障分析报告？"

**调用 Agent**:
```
file-processor（仅处理）
→ 保存到学习材料
→ 不分析故障
```

---

### 意图 4: 存档/存储

**触发关键词**:
- "存档"、"保存"、"存储"、"备份"
- "archive"、"save"、"store"、"backup"

**典型消息**:
- "存档这个文件"
- "保存一下"
- "备份这个文档"

**调用 Agent**:
```
file-processor（仅存储）
→ 不分析、不处理
```

---

### 意图 5: 文档说明

**触发关键词**:
- "说明"、"文档"、"手册"、"指南"
- "documentation"、"manual"、"guide"
- "硬件架构"、"软件说明"、"官方文档"

**典型消息**:
- "这是硬件架构文档"
- "软件说明文档"
- "官方故障说明"
- "设备手册"

**调用 Agent**:
```
file-processor（仅处理/提取内容）
→ 不分析故障
```

---

### 意图 6: 未知/模糊

**触发条件**:
- 无明确关键词
- 仅上传文件，无文字说明
- 文字说明模糊

**典型消息**:
- [仅上传文件，无文字]
- "这个文件"
- "看一下"

**处理方式**:
```
询问用户意图 → 根据用户回复再调用
```

---

## 🔧 实现方案

### 方案 1: 关键词匹配 + 用户确认（推荐）

```python
def detect_intent(message: str, has_file: bool) -> dict:
    """
    检测用户意图
    
    Returns:
        {
            "intent": "fault_analysis" | "file_process" | "learning" | "archive" | "documentation" | "unknown",
            "confidence": 0.0-1.0,
            "needs_confirmation": True/False
        }
    """
    message_lower = message.lower()
    
    # 意图 1: 故障分析
    fault_keywords = ["分析", "诊断", "故障", "问题", "错误", "报错", 
                      "analyze", "diagnos", "fault", "error", "issue",
                      "为什么", "怎么回事", "出了什么问题"]
    
    if any(kw in message_lower for kw in fault_keywords):
        return {
            "intent": "fault_analysis",
            "confidence": 0.9,
            "needs_confirmation": False
        }
    
    # 意图 2: 文件处理
    process_keywords = ["处理", "转换", "提取", "解析", "解压", "打开",
                        "process", "convert", "extract", "parse"]
    
    if any(kw in message_lower for kw in process_keywords):
        return {
            "intent": "file_process",
            "confidence": 0.8,
            "needs_confirmation": False
        }
    
    # 意图 3: 学习/参考
    learning_keywords = ["学习", "参考", "模板", "示例", "怎么写", "如何写",
                         "learn", "reference", "template", "example"]
    
    if any(kw in message_lower for kw in learning_keywords):
        return {
            "intent": "learning",
            "confidence": 0.8,
            "needs_confirmation": False
        }
    
    # 意图 4: 存档/存储
    archive_keywords = ["存档", "保存", "存储", "备份",
                        "archive", "save", "store", "backup"]
    
    if any(kw in message_lower for kw in archive_keywords):
        return {
            "intent": "archive",
            "confidence": 0.8,
            "needs_confirmation": False
        }
    
    # 意图 5: 文档说明
    doc_keywords = ["说明", "文档", "手册", "指南", "硬件架构", "软件说明",
                    "documentation", "manual", "guide"]
    
    if any(kw in message_lower for kw in doc_keywords):
        return {
            "intent": "documentation",
            "confidence": 0.8,
            "needs_confirmation": False
        }
    
    # 意图 6: 未知/模糊
    return {
        "intent": "unknown",
        "confidence": 0.0,
        "needs_confirmation": True
    }


def handle_user_message(user_id, message, has_file=False, file_path=None):
    """处理用户消息"""
    
    # 1. 检测文件上传
    if has_file and file_path:
        # 2. 检测意图
        intent_result = detect_intent(message, has_file)
        
        # 3. 根据意图处理
        if intent_result["intent"] == "unknown" or intent_result["needs_confirmation"]:
            # 意图不明，询问用户
            return ask_user_intent(file_path)
        
        elif intent_result["intent"] == "fault_analysis":
            # 故障分析：调用 file-processor → server-maintenance
            return handle_fault_analysis(file_path, message)
        
        elif intent_result["intent"] == "file_process":
            # 文件处理：仅调用 file-processor
            return handle_file_process(file_path, message)
        
        elif intent_result["intent"] == "learning":
            # 学习材料：调用 file-processor，保存到学习材料
            return handle_learning_material(file_path, message)
        
        elif intent_result["intent"] == "archive":
            # 存档：仅存储
            return handle_archive(file_path, message)
        
        elif intent_result["intent"] == "documentation":
            # 文档说明：调用 file-processor 提取内容
            return handle_documentation(file_path, message)
    
    # 4. 无文件，普通对话
    else:
        return handle_normal_chat(message)


def ask_user_intent(file_path: str) -> str:
    """询问用户意图"""
    return f"""✅ **文件已接收**

文件：{file_path}

**请问您需要我做什么？**

**A)** 分析故障（调用 server-maintenance 分析）
**B)** 处理文件（解压/转换/提取内容）
**C)** 学习材料（保存为参考模板）
**D)** 存档（仅存储）
**E)** 查看内容（提取文本）

**回复"A"、"B"、"C"、"D"或"E"选择**"""


def handle_fault_analysis(file_path, message):
    """处理故障分析请求"""
    from openclaw import sessions_spawn
    
    # 1. 调用 file-processor 处理文件
    file_result = sessions_spawn(
        agent_id="file-processor",
        task=f"处理文件：{file_path}",
        mode="run"
    )
    
    if not file_result.get("success"):
        return f"❌ 文件处理失败：{file_result.get('error')}"
    
    # 2. 调用 server-maintenance 分析故障
    analysis_result = sessions_spawn(
        agent_id="server-maintenance",
        task=f"""分析故障：

日志内容：
{file_result.get('content', '')}

请输出完整的故障分析报告。""",
        mode="run"
    )
    
    if not analysis_result.get("success"):
        return f"❌ 故障分析失败：{analysis_result.get('error')}"
    
    return analysis_result.get("report")


def handle_file_process(file_path, message):
    """处理文件处理请求"""
    from openclaw import sessions_spawn
    
    # 仅调用 file-processor
    result = sessions_spawn(
        agent_id="file-processor",
        task=f"处理文件：{file_path}",
        mode="run"
    )
    
    if not result.get("success"):
        return f"❌ 文件处理失败：{result.get('error')}"
    
    return f"✅ 文件已处理\n\n{result.get('content', '')}"


def handle_learning_material(file_path, message):
    """处理学习材料"""
    from openclaw import sessions_spawn
    
    # 调用 file-processor 提取内容
    result = sessions_spawn(
        agent_id="file-processor",
        task=f"处理文件：{file_path}",
        mode="run"
    )
    
    if not result.get("success"):
        return f"❌ 文件处理失败：{result.get('error')}"
    
    # TODO: 保存到学习材料库
    # save_to_learning_materials(result['content'])
    
    return f"✅ 学习材料已保存\n\n后续写报告时可以参考此模板。"


def handle_archive(file_path, message):
    """处理存档请求"""
    # 仅存储，不处理
    return f"✅ 文件已存档\n\n文件路径：{file_path}"


def handle_documentation(file_path, message):
    """处理文档说明"""
    from openclaw import sessions_spawn
    
    # 调用 file-processor 提取内容
    result = sessions_spawn(
        agent_id="file-processor",
        task=f"处理文件：{file_path}",
        mode="run"
    )
    
    if not result.get("success"):
        return f"❌ 文件处理失败：{result.get('error')}"
    
    return f"✅ 文档已处理\n\n{result.get('content', '')}"
```

---

## 📊 完整流程图

```
用户上传文件 + 消息
    ↓
检测意图 (detect_intent)
    ↓
┌─────────────────────────────────────────────────────────┐
│ 意图分类                                                │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  故障分析 (关键词：分析、故障、诊断...)                  │
│     ↓                                                   │
│  调用 file-processor → server-maintenance               │
│                                                         │
│  文件处理 (关键词：处理、转换、提取...)                  │
│     ↓                                                   │
│  调用 file-processor (仅处理)                           │
│                                                         │
│  学习材料 (关键词：学习、模板、参考...)                  │
│     ↓                                                   │
│  调用 file-processor → 保存到学习材料                    │
│                                                         │
│  存档 (关键词：存档、保存、备份...)                      │
│     ↓                                                   │
│  仅存储                                                 │
│                                                         │
│  文档说明 (关键词：文档、手册、指南...)                  │
│     ↓                                                   │
│  调用 file-processor (提取内容)                         │
│                                                         │
│  未知/模糊 (无关键词/仅文件)                            │
│     ↓                                                   │
│  询问用户意图 (A/B/C/D/E)                               │
│     ↓                                                   │
│  根据用户选择调用相应 Agent                              │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 🧪 测试用例

### 测试 1: 故障分析

```
用户：[上传 nvidia-bug-report.log.tar.gz]
用户："分析故障"
    ↓
意图检测："fault_analysis" (confidence: 0.9)
    ↓
调用：file-processor → server-maintenance
    ↓
返回：故障分析报告
```

### 测试 2: 学习材料

```
用户：[上传 fault_report_template.docx]
用户："学习怎么写报告"
    ↓
意图检测："learning" (confidence: 0.8)
    ↓
调用：file-processor → 保存到学习材料
    ↓
返回："学习材料已保存，后续写报告时可以参考此模板。"
```

### 测试 3: 文档说明

```
用户：[上传 hardware_architecture.pdf]
用户："这是硬件架构文档"
    ↓
意图检测："documentation" (confidence: 0.8)
    ↓
调用：file-processor (提取内容)
    ↓
返回：文档内容
```

### 测试 4: 未知意图

```
用户：[上传 file.tar.gz]
用户："这个文件"
    ↓
意图检测："unknown" (confidence: 0.0)
    ↓
询问用户："请问您需要我做什么？A) 分析故障 B) 处理文件..."
    ↓
用户："A"
    ↓
调用：file-processor → server-maintenance
```

---

## ✅ 实施步骤

### 步骤 1: 创建意图识别模块

文件：`/root/.openclaw/workspace/agents/customer-service/src/intent_detector.py`

### 步骤 2: 更新 AGENT.md

添加意图识别和路由逻辑说明。

### 步骤 3: 测试

测试各种意图场景。

---

**文档版本**: v1.0  
**创建时间**: 2026-03-31  
**状态**: ✅ **待实施**
