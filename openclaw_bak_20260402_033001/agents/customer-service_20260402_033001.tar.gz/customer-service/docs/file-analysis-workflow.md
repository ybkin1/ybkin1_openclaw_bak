# Customer Service Agent - 文件处理与故障分析流程

**版本**: v1.0  
**创建时间**: 2026-03-31  
**状态**: ✅ **立即实施**

---

## 📋 文件处理流程

### 场景 1: 用户上传文件 + "分析故障"

```
用户上传：nvidia-bug-report.log.tar.gz
用户消息："分析故障"
    ↓
customer-service Agent 检测
    ↓
1. 检测文件上传 ✅
2. 检测任务意图："分析故障" ✅
    ↓
3. 调用 file-processor Agent
   - 输入：文件路径
   - 输出：文件内容/解压结果
    ↓
4. 调用 server-maintenance Agent
   - 输入：文件内容
   - 输出：故障分析报告
    ↓
5. 返回用户
```

---

## 🔧 实现方式

### 方式 1: 使用 sessions_spawn 调用

```python
# customer-service Agent 中实现
def handle_file_upload(user_id, file_path, message):
    # 1. 调用 file-processor
    file_result = sessions_spawn(
        agent_id="file-processor",
        task=f"处理文件：{file_path}"
    )
    
    # 2. 调用 server-maintenance
    analysis_result = sessions_spawn(
        agent_id="server-maintenance",
        task=f"分析故障：{file_result['content']}"
    )
    
    # 3. 返回结果
    return analysis_result
```

### 方式 2: 使用 MCP tool 调用

```markdown
## 使用 MCP tool 调用其他 Agent

### 调用 file-processor

```json
{
  "tool": "sessions_spawn",
  "params": {
    "agentId": "file-processor",
    "task": "处理文件：/path/to/file.tar.gz",
    "mode": "run"
  }
}
```

### 调用 server-maintenance

```json
{
  "tool": "sessions_spawn",
  "params": {
    "agentId": "server-maintenance",
    "task": "分析故障：[文件内容]",
    "mode": "run"
  }
}
```
```

---

## 📊 完整流程

### 流程图

```
┌─────────────────────────────────────────────────────────┐
│           customer-service Agent                        │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  1. 接收消息                                            │
│     - 检测文件上传                                      │
│     - 检测任务意图                                      │
│                                                         │
│     ↓                                                   │
│  2. 判断处理逻辑                                        │
│     - 有文件 + "分析故障" → 调用 file-processor         │
│     - 无文件 + "分析故障" → 请求用户提供日志            │
│     - 其他 → 普通对话                                   │
│                                                         │
│     ↓                                                   │
│  3. 调用 file-processor Agent                           │
│     - 上传文件                                          │
│     - 解压（如果是压缩包）                              │
│     - 提取内容                                          │
│                                                         │
│     ↓                                                   │
│  4. 调用 server-maintenance Agent                       │
│     - 传递文件内容                                      │
│     - 获取故障分析报告                                  │
│                                                         │
│     ↓                                                   │
│  5. 返回用户                                            │
│     - 格式化报告                                        │
│     - 发送结果                                          │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## ✅ 实施步骤

### 步骤 1: 更新 customer-service AGENT.md

添加文件处理流程说明。

### 步骤 2: 创建处理脚本

`/root/.openclaw/workspace/agents/customer-service/src/file_handler.py`

### 步骤 3: 测试

1. 上传文件测试
2. Agent 调用测试
3. 完整流程测试

---

**文档版本**: v1.0  
**创建时间**: 2026-03-31  
**状态**: ✅ **待实施**
