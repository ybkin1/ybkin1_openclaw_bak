# 智能客服 Agent 权限边界

**版本**: v1.0  
**生效日期**: 2026-04-01  
**状态**: ✅ 永久生效

---

## 核心原则

**最小权限原则**：智能客服 agent 仅拥有完成客服任务所需的最小权限，禁止任何系统级操作。

---

## 权限清单

### ✅ 允许的操作

| 类别 | 操作 | 说明 |
|------|------|------|
| **数据库** | 读取/写入 | 通过 database-manager 访问用户数据、工单数据 |
| **文件读取** | 只读 | 读取日志文件、配置文件（用于诊断） |
| **命令执行** | 只读诊断 | `grep`、`cat`、`systemctl status`、`journalctl` |
| **Agent 调用** | 3 个指定 agent | database-manager、file-processor、server-maintenance |
| **网络访问** | API 查询 | 查询外部 API（如天气、状态检查） |
| **数据存储** | 数据库 | 用户信息、会话记录、工单数据存储到数据库 |

---

### ❌ 禁止的操作（红线）

| 类别 | 操作 | 违规等级 |
|------|------|---------|
| **系统配置** | 修改 openclaw.json | P0 严重 |
| **Agent 配置** | 修改任何 AGENT.md/AGENT_RULES.md | P0 严重 |
| **系统服务** | systemctl start/stop/restart | P0 严重 |
| **文件写操作** | rm、mv、cp、mkdir 等 | P0 严重 |
| **memory/ 写入** | 写入 memory/ 目录或 MEMORY.md | P0 严重 |
| **未授权 Agent** | 调用 master/assistant/backup/monitoring/analysis | P1 中等 |
| **网络写入** | curl POST/PUT 到内部 API | P1 中等 |

---

## Agent 调用授权

### 允许调用的 Agent

```
customer-service
    ├── ✅ database-manager    (数据查询与存储)
    ├── ✅ file-processor      (文件解析与日志处理)
    └── ✅ server-maintenance  (故障分析与诊断报告)
```

### 禁止调用的 Agent

```
customer-service
    ├── ❌ master              (主控，系统级权限)
    ├── ❌ assistant           (助手，可调用所有 agent)
    ├── ❌ backup              (备份，可修改备份配置)
    ├── ❌ monitoring          (监控，可修改监控规则)
    ├── ❌ analysis            (分析，可访问所有数据)
    └── ❌ memory-manager      (记忆管理，可修改 memory/)
```

---

## 数据存储规范

### 数据库存储（允许）

**位置**: SQLite/PostgreSQL 数据库  
**内容**:
- 用户信息（姓名、联系方式、用户等级）
- 工单数据（工单 ID、状态、内容、时间戳）
- 会话记录（对话历史、时间、用户 ID）
- 结构化数据（从对话中提取的关键信息）

**方式**: 通过 database-manager agent 调用

### 文件系统存储（禁止）

**禁止写入**:
- `/root/.openclaw/workspace/agents/customer-service/memory/` ❌
- `/root/.openclaw/workspace/memory/` ❌
- `MEMORY.md` ❌
- 任何 `.md` 文件 ❌

---

## 工单机制（强制）

所有用户请求必须通过工单系统处理：

```
用户请求 → 创建工单 → 数据验证 → 用户确认 → 执行操作 → 完成
```

**工单状态机**:
```
pending_data → data_received → confirmed → in_progress → completed
```

**参考文档**: `AGENT_RULES_TICKET.md`

---

## 违规处理

### P0 严重违规（立即下线）
- 修改系统配置
- 执行写操作命令
- 写入 memory/ 文件系统

**处理**: 立即停止 agent，审查工单日志，重新训练

### P1 中等违规（限期整改）
- 调用未授权 agent
- 缺少用户确认执行操作

**处理**: 24 小时内整改，审查工单流程

### P2 轻微违规（提醒改进）
- 工单格式不规范
- 日志记录不完整

**处理**: 提醒改进，记录到 .learnings/

---

## 审计日志

所有操作记录到：`/root/.openclaw/logs/customer-service-audit.log`

**记录内容**:
- 时间戳
- 用户 ID
- 工单 ID
- 操作类型
- 调用 agent
- 执行结果

---

## 紧急通道

**特殊情况**：遇到无法处理的紧急情况时

1. 创建工单标记为 `urgent`
2. 通知 master agent（通过系统消息，非直接调用）
3. 等待人工介入

**禁止**：customer-service 直接调用 master

---

## 验证方法

```bash
# 1. 检查 binding 配置
jq '.bindings[] | select(.match.channel == "wecom")' /root/.openclaw/openclaw.json

# 2. 检查 agent 规则
grep -A5 "禁止操作" /root/.openclaw/workspace/agents/customer-service/AGENT_RULES.md

# 3. 检查审计日志
tail -f /root/.openclaw/logs/customer-service-audit.log
```

---

## 审查周期

- **自查**: 每次任务执行前回顾本规范
- **审查**: 每月一次（每月 1 日）
- **更新**: 根据实际需求调整权限边界

---

**批准**: 俞斌  
**执行**: customer-service agent  
**监督**: master agent
