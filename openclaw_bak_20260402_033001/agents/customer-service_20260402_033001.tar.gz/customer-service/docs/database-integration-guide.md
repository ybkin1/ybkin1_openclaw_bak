# Customer-Service 数据库集成指南

**版本**: v1.0  
**创建日期**: 2026-04-01  
**状态**: ✅ 就绪

---

## 🎯 集成目标

customer-service 通过 `customer_service_db.py` 访问数据库，实现：
1. 用户信息管理
2. 会话记录存储
3. 用户记忆提取
4. 工单自动创建
5. 知识库检索

---

## 📦 API 使用示例

### 1. 导入数据库客户端

```python
from customer_service_db import get_db

# 获取数据库客户端
db = get_db()
```

---

### 2. 用户管理

#### 创建/更新用户

```python
# 新用户注册
result = db.create_or_update_user(
    user_id="ou_b46467cc1563871aab03ac1d4f9216f0",
    name="张三",
    user_type="regular",  # internal/maintenance/regular
    channel="wecom",
    channel_user_id="ou_xxx"
)

if result['success']:
    print(f"✅ 用户已创建：{result['user_id']}")
else:
    print(f"❌ 错误：{result['error']}")
```

#### 查询用户信息

```python
# 获取用户基本信息
user = db.get_user("ou_xxx")
if user:
    print(f"姓名：{user['name']}")
    print(f"类型：{user['user_type']}")
    print(f"权限等级：{user['permission_level']}")

# 获取用户完整画像
profile = db.get_user_profile("ou_xxx")
if profile:
    print(f"总会话数：{profile['total_conversations']}")
    print(f"总工单数：{profile['total_tickets']}")
    print(f"总记忆数：{profile['total_memories']}")
```

---

### 3. 会话记录

#### 存储用户消息

```python
# 用户发送消息
result = db.create_conversation(
    user_id="ou_xxx",
    role="user",  # user 或 assistant
    content="服务器报错了，帮我看看",
    channel="wecom",
    metadata={
        "intent": "fault_analysis",
        "entities": {
            "server_model": "M4",
            "fault_type": "GPU_overheat"
        },
        "sentiment": "urgent"
    }
)

if result['success']:
    print(f"✅ 会话记录已保存：{result['conversation_id']}")
```

#### 存储 AI 回复

```python
# AI 回复用户
result = db.create_conversation(
    user_id="ou_xxx",
    role="assistant",
    content="好的，请提供服务器 SN 号和具体错误信息...",
    channel="wecom",
    parent_message_id="conv_xxx",  # 关联用户消息
    thread_id="thread_xxx"  # 会话线程 ID
)
```

#### 获取历史会话

```python
# 获取最近 10 条会话
conversations = db.get_user_conversations("ou_xxx", limit=10)

for conv in conversations:
    print(f"{conv['role']}: {conv['content'][:50]}...")
```

---

### 4. 用户记忆

#### 从对话中提取记忆

```python
# 用户说："我有 3 台 M4 服务器，主要用于 AI 训练"
result = db.create_memory(
    user_id="ou_xxx",
    memory_type="fact",  # fact/preference/context/emotion
    subject="server_assets",
    predicate="owns",
    object="3x M4 servers for AI training",
    confidence=0.95,  # 置信度 0-1
    source_conversation_id="conv_xxx"
)

if result['success']:
    print(f"✅ 记忆已保存：{result['memory_id']}")
```

#### 查询用户记忆

```python
# 获取所有记忆（包括未验证）
memories = db.get_user_memories("ou_xxx", verified_only=False)

for memory in memories:
    print(f"{memory['subject']}: {memory['object']} (置信度：{memory['confidence']})")

# 仅获取已验证记忆
verified_memories = db.get_user_memories("ou_xxx", verified_only=True)
```

#### 验证记忆

```python
# 人工或系统验证记忆
result = db.verify_memory(
    memory_id="mem_xxx",
    verified_by="system"  # 或 user_id
)
```

---

### 5. 工单管理

#### 自动创建工单

```python
# 检测到故障分析请求，自动创建工单
result = db.create_ticket(
    user_id="ou_xxx",
    title="M4 服务器 GPU 过热故障",
    description="用户报告服务器 GPU 温度过高",
    category="fault",  # fault/consultation/upgrade/other
    subcategory="gpu_overheat",
    priority=2  # 1=紧急，5=低
)

if result['success']:
    ticket_id = result['ticket_id']
    print(f"✅ 工单已创建：{ticket_id}")
    
    # 在对话中告知用户
    print(f"已为您创建工单 {ticket_id}，我们会尽快处理")
```

#### 更新工单状态

```python
# 工单状态流转
# pending → confirmed → in_progress → reviewing → completed

# 用户确认工单
result = db.update_ticket_status(
    ticket_id="tkt_xxx",
    status="confirmed"
)

# 开始处理
result = db.update_ticket_status(
    ticket_id="tkt_xxx",
    status="in_progress"
)

# 完成工单
result = db.update_ticket_status(
    ticket_id="tkt_xxx",
    status="completed",
    solution="更换了散热硅脂，温度恢复正常"
)
```

#### 查询用户工单

```python
# 获取所有工单
tickets = db.get_user_tickets("ou_xxx")

# 获取进行中的工单
active_tickets = db.get_user_tickets("ou_xxx", status="in_progress")

for ticket in tickets:
    print(f"{ticket['title']} - 状态：{ticket['status']}")
```

#### 获取活跃工单列表

```python
# 客服查看所有活跃工单
all_active = db.get_active_tickets()

for ticket in all_active:
    print(f"[{ticket['priority']}] {ticket['title']} - {ticket['user_name']}")
```

---

### 6. 知识库检索

#### 检索故障解决方案

```python
# 用户问："GPU 过热怎么处理？"
results = db.search_knowledge(
    query="GPU 过热",
    category="fault",
    user_permission_level=1,  # 根据用户类型
    limit=5
)

for kb in results:
    print(f"标题：{kb['title']}")
    print(f"内容：{kb['content'][:100]}...")
    print(f"质量评分：{kb['quality_score']}")
```

---

### 7. 访问日志

#### 记录数据库操作

```python
# 所有数据库操作都应记录审计日志
result = db.log_access(
    user_id="ou_xxx",
    agent_id="customer-service",
    table_name="users",
    action="create",
    record_id="ou_xxx",
    success=True,
    channel="wecom"
)
```

---

## 🔄 完整工作流程示例

### 场景：用户报告故障

```python
from customer_service_db import get_db

db = get_db()

# ========== 步骤 1: 识别用户 ==========
user_id = "ou_xxx"
user = db.get_user(user_id)

if not user:
    # 新用户，创建用户记录
    db.create_or_update_user(
        user_id=user_id,
        name="张三",
        user_type="regular",
        channel="wecom",
        channel_user_id=user_id
    )

# ========== 步骤 2: 存储用户消息 ==========
db.create_conversation(
    user_id=user_id,
    role="user",
    content="服务器报错了，GPU 温度过高",
    channel="wecom",
    metadata={"intent": "fault_analysis"}
)

# ========== 步骤 3: 提取用户记忆 ==========
db.create_memory(
    user_id=user_id,
    memory_type="fact",
    subject="server_issue",
    predicate="reported",
    object="GPU overheat",
    confidence=0.95
)

# ========== 步骤 4: 创建工单 ==========
ticket_result = db.create_ticket(
    user_id=user_id,
    title="GPU 温度过高故障",
    category="fault",
    subcategory="gpu_overheat",
    priority=2
)

ticket_id = ticket_result['ticket_id']

# ========== 步骤 5: 检索知识库 ==========
knowledge = db.search_knowledge(
    query="GPU 过热",
    category="fault",
    user_permission_level=1,
    limit=3
)

# ========== 步骤 6: 回复用户 ==========
response = f"您好，已为您创建工单 {ticket_id}。\n\n"
response += "GPU 过热的常见解决方案：\n"

for kb in knowledge:
    response += f"- {kb['title']}\n"

# 存储 AI 回复
db.create_conversation(
    user_id=user_id,
    role="assistant",
    content=response,
    channel="wecom"
)

# ========== 步骤 7: 记录审计日志 ==========
db.log_access(
    user_id=user_id,
    agent_id="customer-service",
    table_name="tickets",
    action="create",
    record_id=ticket_id,
    success=True,
    channel="wecom"
)

# 发送回复给用户
print(response)
```

---

## 📝 最佳实践

### 1. 事务处理

```python
# 多个相关操作应放在事务中
conn = db._get_connection()
try:
    cursor = conn.cursor()
    
    # 操作 1: 创建会话
    cursor.execute("INSERT INTO conversations ...")
    
    # 操作 2: 创建记忆
    cursor.execute("INSERT INTO user_memories ...")
    
    # 操作 3: 创建工单
    cursor.execute("INSERT INTO tickets ...")
    
    conn.commit()
except sqlite3.Error as e:
    conn.rollback()
    print(f"❌ 事务失败：{e}")
finally:
    conn.close()
```

### 2. 错误处理

```python
result = db.create_ticket(user_id="ou_xxx", title="测试")

if not result['success']:
    # 记录错误
    db.log_access(
        user_id="ou_xxx",
        agent_id="customer-service",
        table_name="tickets",
        action="create",
        success=False,
        error_message=result['error']
    )
    
    # 告知用户
    print(f"抱歉，工单创建失败：{result['error']}")
```

### 3. 性能优化

```python
# 批量查询时使用 LIMIT
conversations = db.get_user_conversations(user_id, limit=10)

# 只查询需要的字段（自定义 SQL）
# 避免 SELECT *
```

### 4. 数据验证

```python
# 验证用户类型
if user_type not in ['internal', 'maintenance', 'regular']:
    raise ValueError("无效的用户类型")

# 验证置信度
if not (0 <= confidence <= 1):
    raise ValueError("置信度必须在 0-1 之间")
```

---

## 🔍 调试工具

### 查看数据库内容

```bash
# 进入数据库
sqlite3 /root/.openclaw/workspace/agents/database-manager/data/customer-service.db

# 查看所有表
.tables

# 查看用户
SELECT * FROM users LIMIT 5;

# 查看最近会话
SELECT * FROM conversations ORDER BY created_at DESC LIMIT 10;

# 查看活跃工单
SELECT * FROM v_active_tickets;
```

### 运行测试脚本

```bash
# 测试 API
python3 /root/.openclaw/workspace/agents/customer-service/src/customer_service_db.py

# 测试数据库完整性
/root/.openclaw/workspace/agents/database-manager/scripts/test-database.sh
```

---

## 📊 监控指标

### 每日检查

```python
# 新增用户数
today_users = db.get_db().fetch_all('users', {'created_at >=': 'date("now")'})
print(f"今日新增用户：{len(today_users)}")

# 新增会话数
today_convs = db.get_db().fetch_all('conversations', {'created_at >=': 'date("now")'})
print(f"今日会话数：{len(today_convs)}")

# 活跃工单数
active_tickets = db.get_active_tickets()
print(f"活跃工单数：{len(active_tickets)}")
```

---

## 🚨 常见问题

### Q1: 数据库文件不存在？

**A**: 运行初始化脚本：
```bash
sqlite3 /root/.openclaw/workspace/agents/database-manager/data/customer-service.db \
  < /root/.openclaw/workspace/agents/database-manager/scripts/init-schema.sql
```

### Q2: 外键约束失败？

**A**: 确保先创建用户，再创建会话/工单：
```python
# 先创建用户
db.create_or_update_user(user_id="ou_xxx", ...)

# 再创建会话
db.create_conversation(user_id="ou_xxx", ...)
```

### Q3: 如何备份数据库？

**A**: 直接复制数据库文件：
```bash
cp customer-service.db customer-service.db.bak
```

---

## 📁 相关文件

| 文件 | 路径 |
|------|------|
| API 实现 | `/root/.openclaw/workspace/agents/customer-service/src/customer_service_db.py` |
| 数据库 Schema | `/root/.openclaw/workspace/agents/database-manager/scripts/init-schema.sql` |
| 架构文档 | `/root/.openclaw/workspace/agents/master/memory/config/database-memory-architecture.md` |
| 测试脚本 | `/root/.openclaw/workspace/agents/database-manager/scripts/test-database.sh` |

---

**批准**: 俞斌  
**设计**: master agent  
**执行**: customer-service + database-manager
