#!/usr/bin/env python3
"""
Customer-Service 端到端集成测试

模拟完整的用户对话流程：
1. 用户首次咨询
2. 故障分析
3. 工单创建
4. 记忆提取
5. 知识库检索
"""

import sys
sys.path.insert(0, '/root/.openclaw/workspace/agents/customer-service/src')

from customer_service_db import get_db

def test_end_to_end():
    """端到端测试"""
    
    print("=" * 60)
    print("🎬 Customer-Service 端到端集成测试")
    print("=" * 60)
    
    db = get_db()
    
    # 测试数据
    USER_ID = "ou_e2e_test_001"
    USER_NAME = "测试用户"
    
    try:
        # ========== 场景 1: 新用户首次咨询 ==========
        print("\n📍 场景 1: 新用户首次咨询")
        print("-" * 60)
        
        # 1.1 创建用户
        print("1️⃣ 创建用户...")
        user_result = db.create_or_update_user(
            user_id=USER_ID,
            name=USER_NAME,
            user_type="regular",
            channel="wecom",
            channel_user_id=USER_ID
        )
        assert user_result['success'], f"用户创建失败：{user_result['error']}"
        print(f"   ✅ 用户已创建：{USER_NAME} ({USER_ID})")
        
        # 1.2 用户发送第一条消息
        print("2️⃣ 用户发送消息...")
        conv1 = db.create_conversation(
            user_id=USER_ID,
            role="user",
            content="你好，我有台 M4 服务器出问题了",
            channel="wecom",
            metadata={"intent": "greeting"}
        )
        assert conv1['success']
        print(f"   ✅ 会话记录：{conv1['conversation_id']}")
        
        # 1.3 AI 回复
        print("3️⃣ AI 回复...")
        conv2 = db.create_conversation(
            user_id=USER_ID,
            role="assistant",
            content="您好！请问服务器具体出现了什么问题？",
            channel="wecom",
            parent_message_id=conv1['conversation_id']
        )
        assert conv2['success']
        print(f"   ✅ AI 回复：{conv2['conversation_id']}")
        
        # ========== 场景 2: 故障分析 ==========
        print("\n📍 场景 2: 故障分析")
        print("-" * 60)
        
        # 2.1 用户描述问题
        print("1️⃣ 用户描述故障...")
        conv3 = db.create_conversation(
            user_id=USER_ID,
            role="user",
            content="GPU 温度过高，超过 85 度，服务器型号是 M4",
            channel="wecom",
            metadata={
                "intent": "fault_analysis",
                "entities": {
                    "server_model": "M4",
                    "fault_type": "GPU_overheat",
                    "temperature": "85"
                }
            }
        )
        assert conv3['success']
        print(f"   ✅ 故障描述已记录")
        
        # 2.2 提取用户记忆
        print("2️⃣ 提取用户记忆...")
        mem1 = db.create_memory(
            user_id=USER_ID,
            memory_type="fact",
            subject="server_assets",
            predicate="owns",
            object="M4 server",
            confidence=0.9,
            source_conversation_id=conv3['conversation_id']
        )
        assert mem1['success']
        print(f"   ✅ 记忆已保存：{mem1['memory_id']}")
        
        mem2 = db.create_memory(
            user_id=USER_ID,
            memory_type="fact",
            subject="server_issue",
            predicate="reported",
            object="GPU overheat (>85°C)",
            confidence=0.95,
            source_conversation_id=conv3['conversation_id']
        )
        assert mem2['success']
        print(f"   ✅ 故障记忆已保存：{mem2['memory_id']}")
        
        # 2.3 检索知识库
        print("3️⃣ 检索知识库...")
        knowledge = db.search_knowledge(
            query="GPU 过热",
            category="fault",
            user_permission_level=1,
            limit=3
        )
        print(f"   📖 找到 {len(knowledge)} 条相关知识")
        for kb in knowledge[:2]:
            print(f"      - {kb['title']}")
        
        # ========== 场景 3: 工单创建 ==========
        print("\n📍 场景 3: 工单创建")
        print("-" * 60)
        
        # 3.1 自动创建工单
        print("1️⃣ 自动创建工单...")
        ticket = db.create_ticket(
            user_id=USER_ID,
            title="M4 服务器 GPU 温度过高",
            description="用户报告 GPU 温度超过 85 度",
            category="fault",
            subcategory="gpu_overheat",
            priority=2
        )
        assert ticket['success'], f"工单创建失败：{ticket['error']}"
        ticket_id = ticket['ticket_id']
        print(f"   ✅ 工单已创建：{ticket_id}")
        
        # 3.2 AI 告知用户工单号
        print("2️⃣ AI 告知用户工单号...")
        conv4 = db.create_conversation(
            user_id=USER_ID,
            role="assistant",
            content=f"已为您创建工单 {ticket_id}，我们会尽快处理。",
            channel="wecom",
            parent_message_id=conv3['conversation_id']
        )
        assert conv4['success']
        print(f"   ✅ 工单通知已发送")
        
        # 3.3 记录审计日志
        print("3️⃣ 记录审计日志...")
        log1 = db.log_access(
            user_id=USER_ID,
            agent_id="customer-service",
            table_name="tickets",
            action="create",
            record_id=ticket_id,
            success=True,
            channel="wecom"
        )
        assert log1['success']
        print(f"   ✅ 审计日志已记录：{log1['log_id']}")
        
        # ========== 场景 4: 工单处理 ==========
        print("\n📍 场景 4: 工单处理")
        print("-" * 60)
        
        # 4.1 查询用户工单
        print("1️⃣ 查询用户工单...")
        tickets = db.get_user_tickets(USER_ID)
        assert len(tickets) > 0
        print(f"   📖 用户有 {len(tickets)} 个工单")
        for t in tickets:
            print(f"      - {t['title']} (状态：{t['status']})")
        
        # 4.2 更新工单状态
        print("2️⃣ 更新工单状态...")
        status_result = db.update_ticket_status(
            ticket_id=ticket_id,
            status="in_progress"
        )
        assert status_result['success']
        print(f"   ✅ 工单状态：pending → in_progress")
        
        # 4.3 添加解决方案
        print("3️⃣ 添加解决方案...")
        status_result = db.update_ticket_status(
            ticket_id=ticket_id,
            status="completed",
            solution="清理了散热器，更换了导热硅脂"
        )
        assert status_result['success']
        print(f"   ✅ 工单状态：in_progress → completed")
        
        # ========== 场景 5: 用户画像 ==========
        print("\n📍 场景 5: 用户画像")
        print("-" * 60)
        
        # 5.1 获取用户完整画像
        print("1️⃣ 获取用户画像...")
        profile = db.get_user_profile(USER_ID)
        assert profile is not None
        print(f"   📊 用户：{profile['name']}")
        print(f"      - 会话数：{profile['total_conversations']}")
        print(f"      - 工单数：{profile['total_tickets']}")
        print(f"      - 记忆数：{profile['total_memories']}")
        print(f"      - 完成工单：{profile['completed_tickets']}")
        
        # 5.2 获取用户记忆
        print("2️⃣ 获取用户记忆...")
        memories = db.get_user_memories(USER_ID, verified_only=False)
        print(f"   📖 用户有 {len(memories)} 条记忆")
        for mem in memories:
            print(f"      - {mem['subject']}: {mem['object']}")
        
        # ========== 清理测试数据 ==========
        print("\n🧹 清理测试数据...")
        
        # 实际应该删除测试数据，这里仅展示
        print("   ℹ️  测试数据保留（用于验证）")
        print("   如需清理，执行:")
        print(f"   DELETE FROM users WHERE user_id = '{USER_ID}';")
        
        # ========== 测试总结 ==========
        print("\n" + "=" * 60)
        print("✅ 所有测试通过！")
        print("=" * 60)
        print("\n📊 测试统计:")
        print(f"   - 用户创建：1")
        print(f"   - 会话记录：4")
        print(f"   - 用户记忆：2")
        print(f"   - 工单创建：1")
        print(f"   - 知识库检索：1")
        print(f"   - 审计日志：1")
        print("\n🎯 功能验证:")
        print("   ✅ 用户管理")
        print("   ✅ 会话记录")
        print("   ✅ 记忆提取")
        print("   ✅ 工单流转")
        print("   ✅ 知识库检索")
        print("   ✅ 审计日志")
        print("=" * 60)
        
        return True
        
    except AssertionError as e:
        print(f"\n❌ 测试失败：{e}")
        return False
    except Exception as e:
        print(f"\n❌ 系统错误：{e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_end_to_end()
    sys.exit(0 if success else 1)
