# File Processor Agent - 通用文件处理基础设施

**Agent ID**: `file-processor`  
**定位**: 多格式文件处理与内容提取基础设施  
**特性**: 赛道无关、格式无关、权限感知

---

## 🎯 核心定位

File Processor 是**通用的文件处理基础设施**，为所有上层 Agent 提供：
- 📁 **文件上传**: 多格式文件接收与存储
- 🔍 **内容提取**: 文本/图片/视频/日志的内容解析
- 📊 **格式转换**: 文件格式转换与标准化
- 📝 **报告生成**: 基于模板的文档生成
- 🔐 **权限控制**: 文件访问权限管理

**不绑定具体业务场景**，仅关注：
- 文件类型 (image/document/video/log/archive/firmware...)
- 处理方式 (OCR/解析/转换/生成)
- 用户权限 (permission_level)
- 租户隔离 (org_id)
- 赛道上下文 (track_id)

---

## 🧩 能力架构

```
┌─────────────────────────────────────────────────────────────────┐
│                  File Processor Agent                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   文件接入层                             │   │
│  │  • 多格式上传 (图片/文档/视频/日志/压缩包/固件...)        │   │
│  │  • 权限验证 (用户是否有上传权限)                         │   │
│  │  • 病毒扫描 (可选)                                       │   │
│  │  • 格式验证 (MIME type, 文件扩展名)                       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                          ↓                                      │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┐    │
│  │  内容提取   │  格式转换   │  报告生成   │  文件管理   │    │
│  ├─────────────┼─────────────┼─────────────┼─────────────┤    │
│  │ • OCR 识别  │ • PDF→MD   │ • 故障报告  │ • 存储管理  │    │
│  │ • 日志解析  │ • MD→PDF   │ • 分析报告  │ • 版本控制  │    │
│  │ • 视频摘要  │ • DOCX→MD  │ • 总结报告  │ • 权限管理  │    │
│  │ • 压缩包解压│ • HTML→MD  │ • 自定义模板│ • 清理归档  │    │
│  └─────────────┴─────────────┴─────────────┴─────────────┘    │
│                          ↓                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   文件存储层                             │   │
│  │  • 本地文件系统：/root/.openclaw/files/{org_id}/{track_id}/ │   │
│  │  • 元数据索引：SQLite (file_metadata 表)                 │   │
│  │  • 向量索引：LanceDB (文件内容语义检索)                   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔧 核心能力

### 能力 1: 文件上传与验证

**通用文件上传接口**，支持多格式：

```python
file_upload(
    file: bytes,                    # 文件内容
    filename: str,                  # 文件名
    file_type: str = None,          # 文件类型 (自动检测)
    org_id: str,                    # 租户 ID
    track_id: str,                  # 赛道 ID
    owner_id: str,                  # 上传者 ID
    permission_level: int,          # 上传者权限
    related_record: dict = None,    # 关联记录 {table, record_id}
    permissions: dict = None,       # 访问权限配置
    metadata: dict = None           # 自定义元数据
) → {
    "file_id": "file_123",
    "file_path": "/root/.openclaw/files/org_456/track_789/file_123.dat",
    "file_size": 1024567,
    "mime_type": "image/png",
    "checksum": "sha256:abc123..."
}
```

**支持的文件类型**:
| 类型 | 扩展名 | MIME Type | 处理方式 |
|------|--------|-----------|---------|
| **image** | .jpg, .png, .gif, .webp | image/* | OCR、内容分析 |
| **document** | .pdf, .docx, .md, .txt | application/* | 文本提取 |
| **video** | .mp4, .avi, .mov | video/* | 帧提取、摘要 |
| **log** | .log, .txt | text/* | 日志解析、错误提取 |
| **archive** | .zip, .tar.gz, .rar | application/* | 解压、文件列表 |
| **firmware** | .bin, .img, .rom | application/* | 版本提取、校验 |
| **data** | .json, .yaml, .csv | application/* | 数据解析 |
| **other** | 其他 | * | 原样存储 |

**文件验证规则**:
```python
# 1. 文件扩展名验证
ALLOWED_EXTENSIONS = {
    'image': ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    'document': ['pdf', 'docx', 'md', 'txt'],
    'video': ['mp4', 'avi', 'mov'],
    'log': ['log', 'txt'],
    'archive': ['zip', 'tar.gz', 'rar'],
    'firmware': ['bin', 'img', 'rom'],
    'data': ['json', 'yaml', 'csv']
}

# 2. MIME Type 验证
def validate_mime_type(file_bytes, expected_type):
    detected = magic.from_buffer(file_bytes, mime=True)
    return detected.startswith(expected_type)

# 3. 文件大小限制
MAX_FILE_SIZE = {
    'image': 10 * 1024 * 1024,      # 10MB
    'document': 50 * 1024 * 1024,   # 50MB
    'video': 500 * 1024 * 1024,     # 500MB
    'log': 100 * 1024 * 1024,       # 100MB
    'archive': 200 * 1024 * 1024,   # 200MB
    'firmware': 100 * 1024 * 1024,  # 100MB
    'data': 50 * 1024 * 1024        # 50MB
}

# 4. 病毒扫描 (可选)
def scan_virus(file_path):
    # 集成 ClamAV 或其他杀毒引擎
    pass
```

---

### 能力 2: 内容提取

#### 2.1 OCR 识别 (图片)

```python
ocr_extract(
    file_id: str,
    language: str = 'chi_sim+eng',  # 中英文混合
    output_format: str = 'text'     # text/markdown/json
) → {
    "text": "识别的文本内容...",
    "confidence": 0.95,
    "blocks": [                     # 文本块位置 (可选)
        {"text": "第一行", "bbox": [x1, y1, x2, y2]},
        ...
    ]
}
```

**技术栈**: PaddleOCR / Tesseract

---

#### 2.2 日志解析

```python
log_parse(
    file_id: str,
    log_type: str = None,           # 自动检测或指定
    extract_errors: bool = True,    # 提取错误信息
    extract_warnings: bool = True,  # 提取警告信息
    time_range: dict = None         # 时间范围过滤
) → {
    "total_lines": 10000,
    "error_count": 15,
    "warning_count": 45,
    "errors": [
        {
            "timestamp": "2026-03-26T10:30:15",
            "level": "ERROR",
            "message": "GPU temperature exceeded 85°C",
            "source": "hardware_monitor.py:123",
            "context": "前后 5 行日志..."
        },
        ...
    ],
    "warnings": [...],
    "summary": "日志摘要：发现 15 个错误，主要涉及 GPU 温度过高...",
    "suggestions": ["检查 GPU 散热系统", "清理风扇灰尘..."]
}
```

**日志格式支持**:
- 通用日志格式 (timestamp + level + message)
- syslog 格式
- JSON 日志
- 自定义格式 (可配置)

---

#### 2.3 文档解析

```python
document_parse(
    file_id: str,
    extract_mode: str = 'markdown',  # markdown/text/html/json
    extract_images: bool = False,    # 是否提取图片
    extract_tables: bool = True      # 是否提取表格
) → {
    "content": "Markdown 格式的文档内容...",
    "metadata": {
        "title": "文档标题",
        "author": "作者",
        "created_date": "2026-03-26",
        "page_count": 10,
        "word_count": 5000
    },
    "tables": [                      # 提取的表格 (可选)
        {"headers": [...], "rows": [...]},
        ...
    ],
    "images": [                      # 提取的图片 (可选)
        {"file_id": "img_123", "caption": "图片说明"},
        ...
    ]
}
```

**支持的文档格式**:
- PDF (pdfplumber / PyMuPDF)
- DOCX (python-docx)
- Markdown (原生)
- HTML (BeautifulSoup)

---

#### 2.4 视频处理

```python
video_process(
    file_id: str,
    operation: str = 'summary',      # summary/frames/transcribe
    frame_interval: int = 60,        # 帧间隔 (秒)
    max_frames: int = 10             # 最大帧数
) → {
    "duration": 300,                 # 视频时长 (秒)
    "resolution": "1920x1080",
    "fps": 30,
    "summary": {                     # 视频摘要
        "key_frames": [
            {"file_id": "frame_1", "timestamp": 0, "description": "开场画面"},
            {"file_id": "frame_2", "timestamp": 60, "description": "主要内容..."},
            ...
        ],
        "description": "视频内容摘要..."
    },
    "transcription": {               # 语音转文字 (可选)
        "text": "语音识别结果...",
        "language": "zh-CN"
    }
}
```

---

#### 2.5 压缩包处理

```python
archive_extract(
    file_id: str,
    extract_path: str = None,        # 解压路径 (默认临时目录)
    password: str = None,            # 解压密码 (可选)
    file_filter: list = None         # 文件过滤 (如只解压*.log)
) → {
    "total_files": 50,
    "total_size": 1024567,
    "files": [
        {"path": "folder/file1.log", "size": 1024, "file_id": "file_123"},
        {"path": "folder/file2.txt", "size": 2048, "file_id": "file_124"},
        ...
    ],
    "extract_path": "/tmp/archive_123/"
}
```

---

#### 2.6 固件信息提取

```python
firmware_info(
    file_id: str
) → {
    "filename": "gpu_firmware_v2.3.1.bin",
    "file_size": 52428800,
    "checksum": "sha256:abc123...",
    "metadata": {
        "version": "2.3.1",
        "device_type": "GPU",
        "device_model": "NVIDIA A800",
        "release_date": "2026-03-01",
        "vendor": "NVIDIA",
        "compatible_systems": ["OpenCloudOS 9.4", "Ubuntu 22.04"]
    },
    "security_scan": {
        "signature_valid": true,
        "malware_detected": false
    }
}
```

---

### 能力 3: 格式转换

```python
file_convert(
    file_id: str,
    target_format: str,            # pdf/markdown/docx/html/txt...
    options: dict = None           # 转换选项
) → {
    "original_file_id": "file_123",
    "converted_file_id": "file_456",
    "original_format": "docx",
    "target_format": "markdown",
    "file_size": 50000,
    "conversion_time": 2.5
}
```

**支持的转换**:
| 源格式 | 目标格式 | 工具 |
|--------|---------|------|
| PDF | Markdown | pdfplumber |
| PDF | HTML | PyMuPDF |
| DOCX | Markdown | python-docx |
| DOCX | PDF | LibreOffice |
| Markdown | PDF | pandoc |
| Markdown | HTML | markdown |
| HTML | Markdown | beautifulsoup |
| 图片 | PDF | img2pdf |

---

### 能力 4: 报告生成

**基于模板的通用报告生成**:

```python
report_generate(
    template_id: str,              # 模板 ID
    data: dict,                    # 报告数据
    output_format: str = 'pdf',    # pdf/docx/markdown/html
    org_id: str = None,
    track_id: str = None
) → {
    "report_id": "report_123",
    "file_id": "file_456",
    "file_path": "/root/.openclaw/files/org_456/reports/report_123.pdf",
    "file_size": 1024567,
    "page_count": 10
}
```

**通用报告模板结构**:
```markdown
# {{report_title}}

**生成时间**: {{generated_at}}  
**租户**: {{org_name}}  
**赛道**: {{track_name}}

---

## 1. 概述

{{overview_content}}

## 2. 详细信息

{{detail_sections}}

## 3. 分析与建议

{{analysis_content}}

## 4. 附录

{{appendix_content}}

---

**报告版本**: {{version}}  
**生成 Agent**: {{generator_agent}}
```

**内置报告模板**:
| 模板 ID | 用途 | 赛道无关 |
|--------|------|---------|
| `generic_analysis` | 通用分析报告 | ✅ |
| `generic_summary` | 通用总结报告 | ✅ |
| `generic_ticket` | 通用工单报告 | ✅ |
| `data_export` | 数据导出报告 | ✅ |

**赛道特定模板** (由赛道配置定义):
- `server_maintenance/fault_analysis`: 故障分析报告
- `server_maintenance/maintenance_log`: 维护日志
- `consulting/project_report`: 项目报告
- `training/course_material`: 课程材料

---

### 能力 5: 文件管理

#### 5.1 文件存储结构

```
/root/.openclaw/files/
├── {org_id_1}/
│   ├── {track_id_1}/
│   │   ├── uploads/          # 上传的文件
│   │   ├── processed/        # 处理后的文件
│   │   ├── reports/          # 生成的报告
│   │   └── temp/             # 临时文件
│   │── {track_id_2}/
│   │   └── ...
│   └── shared/               # 共享文件 (跨赛道)
├── {org_id_2}/
│   └── ...
└── global/                   # 全局文件 (如模板)
    └── templates/
```

#### 5.2 文件权限控制

```python
file_set_permission(
    file_id: str,
    access_level: str,         # public/internal/restricted
    allowed_users: list = None,
    allowed_orgs: list = None,
    allowed_tracks: list = None,
    permission_level: int      # 操作者权限
) → success

file_check_permission(
    file_id: str,
    user_id: str,
    action: str                # read/write/delete
) → allowed: bool
```

#### 5.3 文件版本控制

```python
file_new_version(
    file_id: str,
    new_file: bytes,
    version_comment: str = None
) → {
    "original_file_id": "file_123",
    "new_file_id": "file_456",
    "version": 2,
    "version_history": [
        {"version": 1, "file_id": "file_123", "created_at": "..."},
        {"version": 2, "file_id": "file_456", "created_at": "..."}
    ]
}
```

#### 5.4 文件清理与归档

```python
# 清理临时文件
file_cleanup_temp(
    older_than_hours: int = 24
) → {
    "deleted_count": 50,
    "freed_space": 1024567
}

# 归档旧文件
file_archive(
    org_id: str,
    track_id: str,
    older_than_days: int = 90,
    archive_path: str = None
) → {
    "archived_count": 100,
    "archive_file": "/root/.openclaw/backups/files_archive_20260326.tar.gz",
    "archive_size": 10245678
}
```

---

## 🔐 权限模型

### 文件操作权限

| 操作 | 权限要求 | 说明 |
|------|---------|------|
| **上传自己的文件** | permission_level ≥ 1 | 普通用户 |
| **上传共享文件** | permission_level ≥ 2 | 成员级别 |
| **读取自己的文件** | permission_level ≥ 0 | 所有用户 |
| **读取他人文件** | permission_level ≥ 2 + 文件权限允许 | 同组织 + 文件权限 |
| **更新自己的文件** | permission_level ≥ 1 | 普通用户 |
| **更新他人文件** | permission_level ≥ 3 | 管理员 |
| **删除自己的文件** | permission_level ≥ 1 | 普通用户 |
| **删除他人文件** | permission_level ≥ 4 | 超级管理员 |

### 文件访问级别

| 级别 | 读取权限 | 写入权限 | 说明 |
|------|---------|---------|------|
| **public** | 0+ | 3+ | 公开文件，所有用户可读 |
| **internal** | 1+ | 2+ | 内部文件，同组织可读 |
| **restricted** | 3+ | 4+ | 受限文件，仅管理员 |

---

## 🛠️ 工具接口清单

### 文件上传工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `file_upload` | 上传文件 | ✅ |
| `file_upload_batch` | 批量上传 | ✅ |
| `file_upload_url` | 从 URL 下载上传 | ✅ |

### 内容提取工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `file_ocr` | OCR 识别 | ✅ |
| `file_parse_log` | 日志解析 | ✅ |
| `file_parse_document` | 文档解析 | ✅ |
| `file_parse_video` | 视频处理 | ✅ |
| `file_extract_archive` | 压缩包解压 | ✅ |
| `file_parse_firmware` | 固件信息提取 | ✅ |

### 格式转换工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `file_convert` | 格式转换 | ✅ |
| `file_convert_pdf_to_md` | PDF→Markdown | ✅ |
| `file_convert_md_to_pdf` | Markdown→PDF | ✅ |
| `file_convert_docx_to_md` | DOCX→Markdown | ✅ |

### 报告生成工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `report_generate` | 生成报告 | ✅ |
| `report_template_list` | 列出模板 | ❌ |
| `report_template_create` | 创建模板 | ✅ |

### 文件管理工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `file_get_info` | 获取文件信息 | ✅ |
| `file_update` | 更新文件 | ✅ |
| `file_delete` | 删除文件 | ✅ |
| `file_copy` | 复制文件 | ✅ |
| `file_move` | 移动文件 | ✅ |
| `file_set_permission` | 设置权限 | ✅ |
| `file_check_permission` | 检查权限 | ❌ |
| `file_new_version` | 新版本 | ✅ |
| `file_cleanup_temp` | 清理临时文件 | ✅ |
| `file_archive` | 归档文件 | ✅ |

---

## 📦 与 Database Manager 的集成

File Processor 专注于**文件内容处理**，Database Manager 专注于**文件元数据管理**：

```
┌─────────────────────────────────────────────────────────────────┐
│                     文件处理流程                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  用户上传文件                                                   │
│       ↓                                                         │
│  ┌─────────────────┐                                           │
│  │ File Processor  │                                           │
│  │ • 文件验证      │                                           │
│  │ • 内容提取      │                                           │
│  │ • 格式转换      │                                           │
│  └────────┬────────┘                                           │
│           ↓                                                     │
│  ┌─────────────────┐                                           │
│  │ Database Manager│                                           │
│  │ • 注册元数据    │                                           │
│  │ • 关联记录      │                                           │
│  │ • 权限设置      │                                           │
│  └────────┬────────┘                                           │
│           ↓                                                     │
│  文件可用 (通过 Database Manager 检索)                           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 集成示例

```python
# 场景：用户上传故障日志文件

# 1. File Processor: 上传文件
upload_result = file_upload(
    file=log_file_bytes,
    filename="gpu_error.log",
    org_id=current_org_id,
    track_id=current_track_id,
    owner_id=current_user_id,
    permission_level=user_permission_level
)
file_id = upload_result["file_id"]

# 2. File Processor: 解析日志
log_analysis = file_parse_log(
    file_id=file_id,
    extract_errors=True,
    extract_warnings=True
)

# 3. Database Manager: 注册文件元数据
db_create(
    table="files",
    data={
        "file_id": file_id,
        "filename": "gpu_error.log",
        "file_type": "log",
        "file_size": 1024567,
        "analysis_result": log_analysis  # 存储分析结果
    },
    org_id=current_org_id,
    track_id=current_track_id,
    permission_level=user_permission_level
)

# 4. Database Manager: 关联到工单
db_create(
    table="ticket_files",
    data={
        "ticket_id": ticket_id,
        "file_id": file_id,
        "file_type": "evidence"
    },
    org_id=current_org_id,
    track_id=current_track_id,
    permission_level=user_permission_level
)
```

---

## 📊 性能指标

| 指标 | 目标值 | 测量方式 |
|------|--------|---------|
| 文件上传延迟 | <1s (10MB 文件) | P95 |
| OCR 识别延迟 | <5s (A4 图片) | P95 |
| 日志解析延迟 | <2s (10MB 日志) | P95 |
| 文档解析延迟 | <3s (100 页 PDF) | P95 |
| 格式转换延迟 | <5s (100 页文档) | P95 |
| 报告生成延迟 | <3s (10 页报告) | P95 |

---

## 🚀 部署配置

### 资源需求

| 资源 | 最小配置 | 推荐配置 |
|------|---------|---------|
| CPU | 4 核 | 8 核 |
| 内存 | 8GB | 16GB |
| 存储 | 100GB | 500GB |
| GPU | 可选 (OCR 加速) | 推荐 (视频处理) |

### 依赖项

- Python 3.11+
- PaddleOCR / Tesseract (OCR)
- PyMuPDF / pdfplumber (PDF 解析)
- python-docx (DOCX 解析)
- ffmpeg (视频处理)
- python-magic (文件类型检测)
- clamav (病毒扫描，可选)

---

## 📝 版本历史

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| 1.0 | 2026-03-26 | 初始版本，通用化设计 |

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 设计完成，待开发
