# File Processor - 完整文件格式支持清单 v2.0

**版本**: v2.0  
**更新时间**: 2026-03-31  
**状态**: ✅ 永久生效

---

## 压缩文件格式（重点扩展）

| 格式 | 扩展名 | MIME Type | 处理方式 | 大小限制 | 优先级 |
|------|--------|-----------|---------|---------|--------|
| ZIP | .zip | application/zip | 解压、文件列表、提取 | 500MB | P0 |
| GZIP | .gz | application/gzip | 解压、提取 | 500MB | P0 |
| TAR | .tar | application/x-tar | 解压、文件列表 | 1GB | P0 |
| TAR.GZ | .tar.gz, .tgz | application/gzip | 解压、文件列表、提取 | 500MB | P0 |
| TAR.BZ2 | .tar.bz2, .tbz2 | application/x-bzip2 | 解压、文件列表、提取 | 500MB | P0 |
| TAR.XZ | .tar.xz, .txz | application/x-xz | 解压、文件列表、提取 | 500MB | P0 |
| BZIP2 | .bz2 | application/x-bzip2 | 解压、提取 | 500MB | P1 |
| XZ | .xz | application/x-xz | 解压、提取 | 500MB | P1 |
| 7-ZIP | .7z | application/x-7z-compressed | 解压、文件列表、提取 | 500MB | P1 |
| RAR | .rar | application/vnd.rar | 解压、文件列表、提取 | 500MB | P1 |
| LZMA | .lzma | application/x-lzma | 解压、提取 | 500MB | P2 |
| ZST | .zst, .zstd | application/zstd | 解压、提取 | 500MB | P2 |
| CAB | .cab | application/vnd.ms-cab-compressed | 解压、文件列表 | 500MB | P2 |
| ISO | .iso | application/x-iso9660-image | 挂载、文件列表、提取 | 1GB | P2 |

**处理工具**: zip/unzip, gzip/gunzip, tar, bzip2, xz, 7z, unrar, zstd

---

## 日志文件格式（服务器运维重点）

| 格式 | 扩展名 | 处理方式 | 优先级 |
|------|--------|---------|--------|
| 通用日志 | .log | 日志解析、错误提取 | P0 |
| 文本日志 | .txt | 文本提取、分析 | P0 |
| NVIDIA 诊断日志 | .nvidia-bug-report.log | GPU 故障解析 | P0 |
| NVIDIA 日志 | .nvidia.log | GPU 日志解析 | P0 |
| 内核日志 | .dmesg | 内核消息解析 | P0 |
| 内核消息 | .kmsg | 内核消息解析 | P1 |
| 系统日志 | .syslog | 系统日志解析 | P1 |
| 消息日志 | .messages | 系统消息解析 | P1 |
| 安全日志 | .secure | 安全事件解析 | P1 |
| 认证日志 | .auth.log | 认证事件解析 | P1 |
| Journal 日志 | .journal | systemd 日志解析 | P1 |
| Apache 日志 | .access.log, .error.log | Web 日志解析 | P1 |
| Nginx 日志 | .access.log, .error.log | Web 日志解析 | P1 |
| MySQL 日志 | .mysql.log, .slow.log | 数据库日志解析 | P1 |
| PostgreSQL 日志 | .postgresql.log | 数据库日志解析 | P1 |
| Docker 日志 | .docker.log | 容器日志解析 | P1 |

---

## 配置文件格式

| 格式 | 扩展名 | MIME Type | 处理方式 | 优先级 |
|------|--------|-----------|---------|--------|
| INI 配置 | .ini, .cfg, .conf | text/plain | 配置解析、对比 | P0 |
| YAML | .yaml, .yml | application/x-yaml | YAML 解析、验证 | P0 |
| JSON | .json | application/json | JSON 解析、验证 | P0 |
| TOML | .toml | application/x-toml | TOML 解析、验证 | P1 |
| XML | .xml | application/xml | XML 解析、验证 | P1 |
| Properties | .properties | text/plain | Java 属性解析 | P1 |
| ENV | .env | text/plain | 环境变量解析 | P1 |
| Systemd 单元 | .service, .target, .timer | text/plain | systemd 配置解析 | P1 |

---

## 脚本文件格式

| 格式 | 扩展名 | 处理方式 | 优先级 |
|------|--------|---------|--------|
| Shell 脚本 | .sh, .bash | 语法检查、说明生成 | P0 |
| Python 脚本 | .py, .pyw | 语法检查、说明生成 | P0 |
| Perl 脚本 | .pl, .pm | 语法检查、说明生成 | P1 |
| Ruby 脚本 | .rb | 语法检查、说明生成 | P1 |
| PowerShell | .ps1, .psm1 | 语法检查、说明生成 | P1 |
| Batch 脚本 | .bat, .cmd | 语法检查、说明生成 | P1 |
| SQL 脚本 | .sql | SQL 解析、格式化 | P1 |
| JavaScript | .js, .mjs | 语法检查、说明生成 | P2 |
| TypeScript | .ts, .tsx | 语法检查、说明生成 | P2 |
| PHP 脚本 | .php | 语法检查、说明生成 | P2 |

---

## 数据文件格式

| 格式 | 扩展名 | MIME Type | 处理方式 | 优先级 |
|------|--------|-----------|---------|--------|
| CSV | .csv | text/csv | 数据解析、转换 | P0 |
| TSV | .tsv | text/tab-separated-values | 数据解析、转换 | P0 |
| JSON | .json | application/json | JSON 解析、验证 | P0 |
| JSONL | .jsonl, .ndjson | application/x-jsonlines | JSONL 解析 | P1 |
| XML | .xml | application/xml | XML 解析、验证 | P1 |
| YAML | .yaml, .yml | application/x-yaml | YAML 解析、验证 | P1 |
| Parquet | .parquet | application/x-parquet | Parquet 解析 | P1 |
| SQLite | .db, .sqlite, .sqlite3 | application/x-sqlite3 | SQLite 查询 | P1 |
| Excel | .xls, .xlsx, .xlsm | application/vnd.ms-excel | Excel 解析 | P0 |

---

## 文档文件格式

| 格式 | 扩展名 | MIME Type | 处理方式 | 优先级 |
|------|--------|-----------|---------|--------|
| Markdown | .md, .markdown | text/markdown | Markdown 解析、转换 | P0 |
| PDF | .pdf | application/pdf | PDF 解析、文本提取 | P0 |
| Word | .doc, .docx | application/msword | Word 解析、文本提取 | P0 |
| PowerPoint | .ppt, .pptx | application/vnd.ms-powerpoint | PPT 解析、提取 | P1 |
| Excel | .xls, .xlsx, .xlsm | application/vnd.ms-excel | Excel 解析 | P0 |
| HTML | .html, .htm | text/html | HTML 解析、提取 | P0 |
| 纯文本 | .txt | text/plain | 文本提取 | P0 |
| EPUB | .epub | application/epub+zip | EPUB 解析、提取 | P1 |
| RTF | .rtf | application/rtf | RTF 解析 | P1 |

---

## 图片文件格式

| 格式 | 扩展名 | MIME Type | 处理方式 | 优先级 |
|------|--------|-----------|---------|--------|
| JPEG | .jpg, .jpeg | image/jpeg | OCR、内容分析 | P0 |
| PNG | .png | image/png | OCR、内容分析 | P0 |
| GIF | .gif | image/gif | OCR、动画分析 | P0 |
| WebP | .webp | image/webp | OCR、内容分析 | P0 |
| BMP | .bmp | image/bmp | OCR、内容分析 | P1 |
| TIFF | .tif, .tiff | image/tiff | OCR、内容分析 | P1 |
| SVG | .svg | image/svg+xml | SVG 解析、提取 | P1 |
| HEIC | .heic, .heif | image/heic | HEIC 解析、转换 | P1 |

---

## 视频文件格式

| 格式 | 扩展名 | MIME Type | 处理方式 | 优先级 |
|------|--------|-----------|---------|--------|
| MP4 | .mp4, .m4v | video/mp4 | 帧提取、摘要、转写 | P0 |
| AVI | .avi | video/x-msvideo | 帧提取、摘要 | P0 |
| MOV | .mov, .qt | video/quicktime | 帧提取、摘要 | P0 |
| MKV | .mkv | video/x-matroska | 帧提取、摘要 | P1 |
| WMV | .wmv | video/x-ms-wmv | 帧提取、摘要 | P1 |
| WebM | .webm | video/webm | 帧提取、摘要 | P1 |
| MPEG | .mpg, .mpeg | video/mpeg | 帧提取、摘要 | P1 |

---

## 音频文件格式

| 格式 | 扩展名 | MIME Type | 处理方式 | 优先级 |
|------|--------|-----------|---------|--------|
| MP3 | .mp3 | audio/mpeg | 语音转文字、分析 | P0 |
| WAV | .wav | audio/wav | 语音转文字、分析 | P0 |
| AAC | .aac, .m4a | audio/aac | 语音转文字、分析 | P1 |
| FLAC | .flac | audio/flac | 语音转文字、分析 | P1 |
| OGG | .ogg, .oga | audio/ogg | 语音转文字、分析 | P1 |
| AMR | .amr | audio/amr | 语音转文字（语音消息） | P1 |

---

## 系统文件格式

| 格式 | 扩展名 | MIME Type | 处理方式 | 优先级 |
|------|--------|-----------|---------|--------|
| 二进制可执行 | .bin | application/x-executable | 二进制分析 | P1 |
| 固件镜像 | .img, .rom | application/x-disk-image | 固件信息提取 | P0 |
| ISO 镜像 | .iso | application/x-iso9660-image | 挂载、文件列表 | P1 |
| 内核镜像 | .vmlinuz | application/x-executable | 内核信息提取 | P1 |
| DEB 包 | .deb | application/x-debian-package | DEB 包解析 | P1 |
| RPM 包 | .rpm | application/x-rpm | RPM 包解析 | P1 |
| 证书 | .pem, .crt, .cer | application/x-x509-ca-cert | 证书解析 | P1 |
| SSH 密钥 | id_rsa, id_ed25519 | application/x-pem-file | SSH 密钥信息 | P1 |

---

## 文件大小限制汇总

| 文件类型 | 最大大小 |
|---------|---------|
| 图片 | 10MB |
| 文档 | 50MB |
| 视频 | 500MB |
| 音频 | 100MB |
| 日志 | 100MB |
| 压缩包 | 500MB |
| 数据文件 | 50MB |
| 固件 | 100MB |
| 系统文件 | 1GB |
| 数据库 | 500MB |

---

## 处理工具依赖

### 压缩文件工具

```bash
# 基础压缩工具
apt-get install zip unzip gzip tar bzip2 xz-utils p7zip-full unrar

# 高级压缩工具
apt-get install zstd lzop lzma arj cabextract
```

### 日志解析工具

```bash
# 日志分析
apt-get install lnav multitail logrotate

# systemd 日志
apt-get install systemd
```

### 文档处理工具

```bash
# PDF 处理
apt-get install poppler-utils pdftk

# Office 文档
apt-get install libreoffice

# Markdown
pip install markdown
```

### 图片处理工具

```bash
# 图片转换
apt-get install imagemagick

# OCR
apt-get install tesseract-ocr tesseract-ocr-chi-sim

# 图片分析
pip install pillow opencv-python
```

### 视频处理工具

```bash
# 视频处理
apt-get install ffmpeg

# 视频分析
pip install opencv-python moviepy
```

### 音频处理工具

```bash
# 音频处理
apt-get install ffmpeg sox

# 语音转文字
pip install openai-whisper speechrecognition
```

---

## 实施优先级

### P0: 立即实施（核心格式）

- [x] ZIP (.zip)
- [x] GZIP (.gz)
- [x] TAR (.tar)
- [x] TAR.GZ (.tar.gz, .tgz)
- [x] 日志文件 (.log, .txt)
- [x] NVIDIA 诊断日志 (.nvidia-bug-report.log)
- [x] 内核日志 (.dmesg)
- [x] JSON (.json)
- [x] YAML (.yaml, .yml)
- [x] Markdown (.md)
- [x] PDF (.pdf)
- [x] Word (.doc, .docx)

### P1: 近期实施（常用格式）

- [ ] TAR.BZ2 (.tar.bz2, .tbz2)
- [ ] TAR.XZ (.tar.xz, .txz)
- [ ] BZIP2 (.bz2)
- [ ] XZ (.xz)
- [ ] 7-ZIP (.7z)
- [ ] RAR (.rar)
- [ ] 系统日志 (.syslog, .messages)
- [ ] 数据库日志 (.mysql.log, .postgresql.log)
- [ ] CSV (.csv)
- [ ] Excel (.xls, .xlsx)
- [ ] PowerPoint (.ppt, .pptx)

### P2: 远期实施（特殊格式）

- [ ] LZMA (.lzma)
- [ ] ZST (.zst, .zstd)
- [ ] CAB (.cab)
- [ ] ISO (.iso)
- [ ] 虚拟化格式 (.qcow2, .vmdk, .vhd)
- [ ] 数据库格式 (.db, .sqlite)
- [ ] 包管理格式 (.deb, .rpm)

---

**文档版本**: v2.0  
**更新时间**: 2026-03-31  
**下次审查**: 2026-06-30
