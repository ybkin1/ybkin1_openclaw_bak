# File Processor Agent - 永久生效规范

**版本**: 1.0  
**生效日期**: 2026-03-26  
**优先级**: 高于 AGENT.md，与 openclaw.json 同级

---

## 🔒 核心原则 (不可违背)

### 原则 1: 赛道无关性 (Track-Agnostic)

**规则**: 不得在代码或配置中硬编码任何具体赛道的文件类型或处理规则

```python
# ❌ 错误：硬编码赛道特定文件类型
def process_log(file_path):
    # 假设是服务器日志
    return parse_server_log(file_path)

# ✅ 正确：通用文件处理
def process_file(file_id, file_type):
    if file_type == 'log':
        return parse_log(file_id)
    elif file_type == 'image':
        return ocr_extract(file_id)
    # 赛道特定规则由配置文件定义
```

**违规检测**:
- 代码中出现 `server_log`, `fault_report` 等赛道特定类型 → 警告
- 应使用通用 `file_type` + 赛道配置 → 正确

---

### 原则 2: 文件类型安全 (File Type Safety)

**规则**: 所有上传文件必须验证扩展名、MIME Type、魔法数三重校验

```python
# ✅ 正确：三重验证
def validate_file(file_bytes, filename, expected_type):
    # 1. 扩展名验证
    ext = filename.split('.')[-1].lower()
    if ext not in ALLOWED_EXTENSIONS[expected_type]:
        raise ValidationError(f"不支持的文件扩展名：{ext}")
    
    # 2. MIME Type 验证
    mime = magic.from_buffer(file_bytes, mime=True)
    if not mime.startswith(expected_type):
        raise ValidationError(f"MIME 类型不匹配：{mime}")
    
    # 3. 魔法数验证 (关键文件类型)
    if expected_type in ['firmware', 'archive']:
        if not verify_magic_number(file_bytes):
            raise ValidationError("文件魔法数验证失败")
    
    return True

# ❌ 错误：仅验证扩展名
def validate_file(filename):
    ext = filename.split('.')[-1]
    if ext not in ['jpg', 'png']:  # 可伪造
        raise ValidationError("不支持的文件类型")
```

**支持的文件类型白名单**:
```python
ALLOWED_EXTENSIONS = {
    'image': ['jpg', 'jpeg', 'png', 'gif', 'webp'],
    'document': ['pdf', 'docx', 'md', 'txt'],
    'video': ['mp4', 'avi', 'mov'],
    'log': ['log', 'txt'],
    'archive': ['zip', 'tar.gz', 'rar'],
    'firmware': ['bin', 'img', 'rom'],
    'data': ['json', 'yaml', 'csv']
}
```

---

### 原则 3: 文件大小限制 (File Size Limit)

**规则**: 所有文件类型必须有大小限制，禁止无限制上传

```python
# ✅ 正确：大小限制
MAX_FILE_SIZE = {
    'image': 10 * 1024 * 1024,      # 10MB
    'document': 50 * 1024 * 1024,   # 50MB
    'video': 500 * 1024 * 1024,     # 500MB
    'log': 100 * 1024 * 1024,       # 100MB
    'archive': 200 * 1024 * 1024,   # 200MB
    'firmware': 100 * 1024 * 1024,  # 100MB
    'data': 50 * 1024 * 1024        # 50MB
}

def upload_file(file_bytes, file_type):
    if len(file_bytes) > MAX_FILE_SIZE[file_type]:
        raise ValidationError(
            f"文件大小超出限制：{len(file_bytes)} > {MAX_FILE_SIZE[file_type]}"
        )
```

**违规检测**:
- 上传接口无大小限制 → 严重错误
- 大小限制超过阈值 → 需要审批

---

### 原则 4: 病毒与安全扫描 (Security Scan)

**规则**: 所有上传文件必须经过病毒扫描，高风险文件类型必须签名验证

```python
# ✅ 正确：安全扫描
def upload_file(file_bytes, filename, file_type):
    # 1. 病毒扫描
    scan_result = clamav_scan(file_bytes)
    if scan_result['infected']:
        audit_log(
            action='virus_detected',
            filename=filename,
            virus_name=scan_result['virus_name']
        )
        raise SecurityError(f"检测到病毒：{scan_result['virus_name']}")
    
    # 2. 固件签名验证
    if file_type == 'firmware':
        if not verify_firmware_signature(file_bytes):
            raise SecurityError("固件签名验证失败")
    
    # 3. 存档恶意内容检测
    if file_type == 'archive':
        if check_archive_bomb(file_bytes):
            raise SecurityError("检测到压缩包炸弹")
    
    return True
```

**高风险文件类型**:
| 类型 | 风险 | 防护措施 |
|------|------|---------|
| firmware | 恶意固件 | 签名验证 + 哈希校验 |
| archive | 压缩包炸弹 | 解压比例检查 |
| document | 宏病毒 | 禁用宏 + 病毒扫描 |
| executable | 恶意程序 | 禁止上传 (白名单外) |

---

### 原则 5: 内容提取安全 (Content Extraction Safety)

**规则**: 所有文件内容提取必须在沙箱环境中进行，防止代码执行

```python
# ✅ 正确：沙箱环境
def extract_content(file_id, file_type):
    # 1. 创建临时沙箱目录
    sandbox_dir = create_sandbox()
    
    try:
        # 2. 复制文件到沙箱
        file_path = copy_to_sandbox(file_id, sandbox_dir)
        
        # 3. 在沙箱中执行提取
        if file_type == 'archive':
            # 限制解压大小和时间
            extract_archive(file_path, max_size=100*MB, timeout=60)
        
        elif file_type == 'document':
            # 禁用宏和脚本
            parse_document(file_path, disable_macros=True)
        
        # 4. 清理沙箱
        cleanup_sandbox(sandbox_dir)
        
    except Exception as e:
        cleanup_sandbox(sandbox_dir)
        raise
```

**沙箱配置**:
- `max_memory`: 512MB
- `max_cpu_time`: 60 秒
- `max_file_size`: 100MB
- `network_access`: 禁用
- `system_calls`: 白名单

---

### 原则 6: 文件存储隔离 (Storage Isolation)

**规则**: 不同租户、不同赛道的文件必须物理隔离存储

```python
# ✅ 正确：隔离存储
def get_file_path(org_id, track_id, file_id):
    return f'/root/.openclaw/files/{org_id}/{track_id}/{file_id}.dat'

# 文件目录结构
# /root/.openclaw/files/
# ├── org_001/
# │   ├── track_server_maintenance/
# │   │   ├── uploads/
# │   │   ├── processed/
# │   │   └── reports/
# │   └── track_consulting/
# │       └── ...
# ├── org_002/
# │   └── ...
# └── global/
#     └── templates/

# ❌ 错误：混合存储
def get_file_path(file_id):
    return f'/root/.openclaw/files/{file_id}.dat'  # 无隔离
```

**隔离级别**:
1. 租户级隔离：`{org_id}/`
2. 赛道级隔离：`{track_id}/`
3. 用途级隔离：`uploads/`, `processed/`, `reports/`

---

## 📋 操作规范 (必须遵循)

### 规范 1: 文件上传流程

```python
# ✅ 正确：完整上传流程
def upload_file(file_bytes, filename, user_id, org_id, track_id):
    # 1. 权限检查
    if not check_upload_permission(user_id, org_id):
        raise PermissionError("无上传权限")
    
    # 2. 文件类型检测
    file_type = detect_file_type(file_bytes, filename)
    
    # 3. 大小验证
    validate_file_size(file_bytes, file_type)
    
    # 4. 安全扫描
    security_scan(file_bytes, file_type)
    
    # 5. 生成文件 ID 和路径
    file_id = generate_file_id()
    file_path = get_file_path(org_id, track_id, file_id)
    
    # 6. 存储文件
    save_file(file_bytes, file_path)
    
    # 7. 计算 checksum
    checksum = sha256(file_bytes)
    
    # 8. 注册元数据
    register_file_metadata(
        file_id=file_id,
        filename=filename,
        file_type=file_type,
        file_path=file_path,
        file_size=len(file_bytes),
        checksum=checksum,
        org_id=org_id,
        track_id=track_id,
        owner_id=user_id
    )
    
    # 9. 审计日志
    audit_log(
        action='file_upload',
        file_id=file_id,
        filename=filename,
        user_id=user_id
    )
    
    return {
        'file_id': file_id,
        'file_path': file_path,
        'file_size': len(file_bytes),
        'checksum': checksum
    }
```

---

### 规范 2: 文件下载流程

```python
# ✅ 正确：完整下载流程
def download_file(file_id, user_id):
    # 1. 获取文件元数据
    file_meta = get_file_metadata(file_id)
    
    # 2. 权限检查
    if not check_download_permission(user_id, file_meta):
        raise PermissionError("无下载权限")
    
    # 3. 记录审计日志
    audit_log(
        action='file_download',
        file_id=file_id,
        user_id=user_id
    )
    
    # 4. 读取文件
    file_bytes = read_file(file_meta['file_path'])
    
    # 5. 验证完整性
    if sha256(file_bytes) != file_meta['checksum']:
        raise IntegrityError("文件完整性验证失败")
    
    return {
        'file_bytes': file_bytes,
        'filename': file_meta['filename'],
        'mime_type': file_meta['mime_type']
    }
```

---

### 规范 3: OCR 处理规范

```python
# ✅ 正确：OCR 处理
def ocr_extract(file_id, language='chi_sim+eng'):
    # 1. 获取文件
    file_meta = get_file_metadata(file_id)
    if file_meta['file_type'] != 'image':
        raise ValidationError("仅支持图片文件 OCR")
    
    # 2. 图片预处理
    image = load_image(file_meta['file_path'])
    image = preprocess_image(image)  # 去噪、增强对比度
    
    # 3. OCR 识别
    result = paddle_ocr(image, lang=language)
    
    # 4. 置信度检查
    if result['confidence'] < 0.6:
        audit_log(
            action='ocr_low_confidence',
            file_id=file_id,
            confidence=result['confidence']
        )
    
    # 5. 敏感信息脱敏
    text = result['text']
    text = desensitize_text(text)  # 脱敏手机号、身份证等
    
    return {
        'text': text,
        'confidence': result['confidence'],
        'blocks': result['blocks']
    }
```

**OCR 脱敏规则**:
- 手机号：`13812345678` → `138****5678`
- 身份证：`110101199001011234` → `110101********1234`
- 邮箱：`user@example.com` → `u**r@example.com`

---

### 规范 4: 日志解析规范

```python
# ✅ 正确：日志解析
def log_parse(file_id, extract_errors=True, extract_warnings=True):
    # 1. 获取文件
    file_meta = get_file_metadata(file_id)
    if file_meta['file_type'] not in ['log', 'text']:
        raise ValidationError("仅支持日志文件解析")
    
    # 2. 读取日志
    log_content = read_file(file_meta['file_path'])
    
    # 3. 解析日志行
    parsed_lines = []
    errors = []
    warnings = []
    
    for line in log_content.split('\n'):
        parsed = parse_log_line(line)
        if parsed:
            parsed_lines.append(parsed)
            
            if parsed['level'] == 'ERROR' and extract_errors:
                errors.append(parsed)
            elif parsed['level'] == 'WARNING' and extract_warnings:
                warnings.append(parsed)
    
    # 4. 生成摘要
    summary = generate_log_summary(parsed_lines, errors, warnings)
    
    # 5. 提取建议
    suggestions = generate_suggestions(errors)
    
    return {
        'total_lines': len(parsed_lines),
        'error_count': len(errors),
        'warning_count': len(warnings),
        'errors': errors[:100],  # 限制返回数量
        'warnings': warnings[:100],
        'summary': summary,
        'suggestions': suggestions
    }
```

---

### 规范 5: 报告生成规范

```python
# ✅ 正确：报告生成
def report_generate(template_id, data, user_id, org_id, track_id):
    # 1. 加载模板
    template = load_template(template_id)
    if not template:
        raise ValidationError(f"模板不存在：{template_id}")
    
    # 2. 检查模板权限
    if not check_template_permission(user_id, template):
        raise PermissionError("无权使用该模板")
    
    # 3. 验证数据
    if not validate_template_data(template, data):
        raise ValidationError("报告数据不完整")
    
    # 4. 渲染模板
    content = render_template(template, data)
    
    # 5. 生成文件
    file_id = generate_file_id()
    file_path = f'/root/.openclaw/files/{org_id}/{track_id}/reports/{file_id}.pdf'
    
    # 6. 导出 PDF
    export_pdf(content, file_path)
    
    # 7. 注册元数据
    register_file_metadata(
        file_id=file_id,
        filename=f'{template_id}_{datetime.now().strftime("%Y%m%d")}.pdf',
        file_type='document',
        file_path=file_path,
        org_id=org_id,
        track_id=track_id,
        owner_id=user_id,
        metadata={
            'template_id': template_id,
            'generated_at': datetime.now().isoformat(),
            'data_hash': sha256(json.dumps(data))
        }
    )
    
    return {
        'file_id': file_id,
        'file_path': file_path
    }
```

---

### 规范 6: 临时文件清理

```python
# ✅ 正确：定期清理
def cleanup_temp_files():
    temp_dir = '/root/.openclaw/files/temp/'
    max_age_hours = 24
    
    deleted_count = 0
    freed_space = 0
    
    for filename in os.listdir(temp_dir):
        file_path = os.path.join(temp_dir, filename)
        file_age = datetime.now() - datetime.fromtimestamp(os.path.getctime(file_path))
        
        if file_age.total_seconds() > max_age_hours * 3600:
            file_size = os.path.getsize(file_path)
            os.remove(file_path)
            deleted_count += 1
            freed_space += file_size
    
    audit_log(
        action='temp_cleanup',
        deleted_count=deleted_count,
        freed_space=freed_space
    )
    
    return {
        'deleted_count': deleted_count,
        'freed_space': freed_space
    }
```

**清理策略**:
- 临时文件：24 小时
- 处理中间文件：1 小时
- 失败任务文件：7 天
- 归档文件：90 天

---

## 🔐 安全规范 (红线)

### 红线 1: 禁止执行用户上传的内容

```python
# ❌ 严重错误：执行用户上传的代码
def process_script(file_id):
    code = read_file(file_id)
    exec(code)  # 绝对禁止！

# ✅ 正确：仅解析，不执行
def process_script(file_id):
    code = read_file(file_id)
    # 仅做语法分析或静态检查
    ast.parse(code)
```

**禁止的操作**:
- `exec()` 执行用户上传的代码
- `eval()` 执行用户上传的表达式
- `subprocess` 运行用户上传的脚本
- `import` 动态导入用户上传的模块

---

### 红线 2: 禁止未验证的文件类型

```python
# ❌ 严重错误：信任用户提供的文件类型
def upload_file(file_bytes, file_type):
    # 用户说这是图片，就当作图片处理
    if file_type == 'image':  # 可伪造
        process_image(file_bytes)

# ✅ 正确：自行检测
def upload_file(file_bytes, filename):
    # 通过魔法数检测真实类型
    file_type = magic.from_buffer(file_bytes)
    process_by_type(file_bytes, file_type)
```

---

### 红线 3: 禁止未扫描的文件存储

```python
# ❌ 严重错误：跳过病毒扫描
def upload_file(file_bytes):
    save_file(file_bytes)  # 未扫描

# ✅ 正确：必须先扫描
def upload_file(file_bytes):
    scan_result = clamav_scan(file_bytes)
    if scan_result['infected']:
        raise SecurityError("检测到病毒")
    save_file(file_bytes)
```

---

### 红线 4: 禁止未隔离的文件访问

```python
# ❌ 严重错误：任意文件读取
def download_file(file_path):
    return open(file_path).read()  # 路径遍历漏洞

# ✅ 正确：限制在文件目录内
def download_file(file_id):
    file_meta = get_file_metadata(file_id)
    file_path = file_meta['file_path']
    
    # 验证路径在合法目录内
    if not file_path.startswith('/root/.openclaw/files/'):
        raise SecurityError("非法文件路径")
    
    return open(file_path).read()
```

---

### 红线 5: 禁止未脱敏的日志记录

```python
# ❌ 严重错误：记录敏感信息
def log_file_access(user_id, file_path):
    log.info(f"用户{user_id}访问文件：{file_path}")  # 可能包含敏感路径

# ✅ 正确：脱敏处理
def log_file_access(user_id, file_id):
    log.info(f"用户{user_id}访问文件：{file_id}")  # 仅记录 file_id
```

---

## 📊 性能规范

### 规范 1: 大文件流式处理

```python
# ✅ 正确：流式处理大文件
def process_large_file(file_path, chunk_size=8192):
    with open(file_path, 'rb') as f:
        while chunk := f.read(chunk_size):
            process_chunk(chunk)

# ❌ 错误：一次性加载大文件
def process_large_file(file_path):
    content = open(file_path, 'rb').read()  # 可能 OOM
    process(content)
```

**流式处理阈值**:
- 文件 > 10MB → 必须流式处理
- 文件 > 100MB → 必须分片 + 断点续传
- 文件 > 1GB → 必须后台异步处理

---

### 规范 2: 并发控制

```python
# ✅ 正确：限制并发处理数
class FileProcessor:
    def __init__(self, max_concurrent=4):
        self.semaphore = asyncio.Semaphore(max_concurrent)
    
    async def process_file(self, file_id):
        async with self.semaphore:
            return await self._process(file_id)

# ❌ 错误：无并发限制
async def process_files(file_ids):
    await asyncio.gather(*[process_file(f) for f in file_ids])  # 可能耗尽资源
```

**并发限制**:
- OCR 处理：4 并发
- 日志解析：8 并发
- 格式转换：4 并发
- 视频处理：2 并发

---

### 规范 3: 超时控制

```python
# ✅ 正确：设置超时
def process_with_timeout(func, *args, timeout=60):
    try:
        return func(*args)
    except TimeoutError:
        audit_log(
            action='process_timeout',
            function=func.__name__,
            timeout=timeout
        )
        raise ProcessingError("处理超时")

# 各类处理超时限制
TIMEOUTS = {
    'ocr': 30,           # 30 秒
    'log_parse': 60,     # 60 秒
    'document_parse': 60, # 60 秒
    'video_process': 300, # 5 分钟
    'archive_extract': 120 # 2 分钟
}
```

---

## 📝 存储管理

### 规范 1: 文件目录结构

```
/root/.openclaw/files/
├── {org_id}/
│   ├── {track_id}/
│   │   ├── uploads/          # 原始上传文件
│   │   │   └── {YYYY-MM-DD}/ # 按日期分组
│   │   ├── processed/        # 处理后的文件
│   │   ├── reports/          # 生成的报告
│   │   └── temp/             # 临时文件
│   └── shared/               # 共享文件
└── global/
    └── templates/            # 报告模板
```

---

### 规范 2: 文件命名规则

```python
# ✅ 正确：规范化命名
def generate_filename(file_id, original_filename):
    ext = original_filename.split('.')[-1]
    return f'{file_id}.{ext}'

# file_id 格式
# file_{timestamp}_{random}
# 示例：file_20260326115500_a1b2c3d4
```

---

### 规范 3: 存储配额管理

```python
# ✅ 正确：配额检查
def check_storage_quota(org_id, file_size):
    quota = get_org_quota(org_id)  # 租户配额
    used = get_org_used_storage(org_id)
    
    if used + file_size > quota:
        raise QuotaError(f"存储空间不足：{used + file_size} > {quota}")
    
    return True

# 默认配额
DEFAULT_QUOTAS = {
    'storage': 10 * 1024 * 1024 * 1024,  # 10GB
    'file_count': 10000,                  # 1 万文件
    'daily_upload': 1024 * 1024 * 1024    # 1GB/天
}
```

---

## ✅ 合规检查清单

### 每次发布前必须检查

```markdown
□ 所有上传文件都经过三重验证 (扩展名、MIME、魔法数)
□ 所有文件都有大小限制
□ 所有文件都经过病毒扫描
□ 高风险文件类型有额外验证 (固件签名、存档炸弹检测)
□ 所有文件提取都在沙箱中进行
□ 不同租户/赛道的文件物理隔离存储
□ 所有操作都有审计日志
□ 所有权限检查都正确实现
□ 临时文件定期清理
□ 大文件使用流式处理
□ 所有处理都有超时控制
□ 并发处理有限制
□ 存储配额有检查
□ 敏感信息已脱敏
□ 无代码执行风险
```

---

## 🔧 违规处理

| 违规等级 | 处理方式 | 示例 |
|---------|---------|------|
| **严重** | 立即修复 + 审查 | 病毒文件入库、代码执行、路径遍历 |
| **警告** | 限期修复 | 缺少大小限制、无超时控制 |
| **建议** | 逐步优化 | 代码风格、注释完善 |

---

## 📈 监控指标

| 指标 | 警告阈值 | 严重阈值 |
|------|---------|---------|
| 文件上传失败率 | >5% | >10% |
| 病毒检测次数 | >10/天 | >50/天 |
| OCR 识别失败率 | >10% | >20% |
| 处理超时率 | >5% | >15% |
| 存储使用率 | >80% | >95% |
| 临时文件积压 | >1000 个 | >5000 个 |

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 永久生效  
**下次审查**: 2026-06-26 (每季度审查一次)
