# Task 1.1.2: users 表设计

## 任务描述
设计用户表结构，支持多组织用户管理、角色权限、登录认证

## 需求详情

### 1. 基本字段
- user_id (主键，UUID)
- org_id (外键，关联 organizations.org_id)
- username (唯一，登录用)
- email (唯一)
- password_hash (加密存储)
- phone (可选)
- avatar_url (可选)

### 2. 角色权限
- role: super_admin | org_admin | team_lead | user | guest
- permissions: JSON 格式，细粒度权限配置

### 3. 状态管理
- status: active | inactive | locked | pending
- last_login: TIMESTAMP NULL
- login_attempts: INT DEFAULT 0 (失败尝试次数)
- locked_until: TIMESTAMP NULL (锁定时长)

### 4. 审计字段
- created_by: TEXT (创建人 user_id)
- created_at: TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- updated_at: TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- deleted_at: TIMESTAMP NULL (软删除)

### 5. 索引设计
- UNIQUE INDEX idx_users_username (username)
- UNIQUE INDEX idx_users_email (email)
- INDEX idx_users_org_id (org_id)
- INDEX idx_users_status (status)
- INDEX idx_users_role (role)
- INDEX idx_users_org_status (org_id, status)

### 6. 触发器
- update_users_updated_at: 自动更新 updated_at

### 7. 示例数据
- 1 个 super_admin
- 2 个 org_admin (不同组织)
- 3 个普通 user

## 输出文件
1. `/root/.openclaw/workspace/agents/database-manager/scripts/002_users_schema.sql`
2. `/root/.openclaw/workspace/agents/database-manager/docs/002_users_schema_design.md`

## 验收标准
- [ ] Schema 包含所有必需字段
- [ ] 支持多组织关联
- [ ] 包含认证和权限字段
- [ ] 索引优化合理
- [ ] 有触发器自动更新
- [ ] 提供示例数据
- [ ] 通过 Spec Review
- [ ] 通过 Code Quality Review

## 参考
- Task 1.1.1: `/root/.openclaw/workspace/agents/database-manager/scripts/001_organizations_schema.sql`
