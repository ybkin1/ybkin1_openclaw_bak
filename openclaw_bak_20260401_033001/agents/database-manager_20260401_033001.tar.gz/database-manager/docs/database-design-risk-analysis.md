# 数据库设计缺陷与风险分析报告

**审查时间**: 2026-03-27 07:37  
**审查人**: Master Agent (喵小白)  
**审查范围**: organizations, users, tracks 三表  
**审查深度**: 架构设计、安全性、扩展性、性能、数据完整性

---

## 🚨 高风险问题 (必须修复)

### R1. 外键约束未启用 (SQLite 特性)

**问题描述**: 
SQLite 默认**不启用**外键约束，即使定义了 FOREIGN KEY 也不会执行。

**影响**:
- ❌ ON DELETE CASCADE 不会自动执行
- ❌ 外键引用完整性无法保证
- ❌ 可能产生孤儿数据

**验证**:
```sql
PRAGMA foreign_keys;  -- 返回 0 表示未启用
```

**解决方案**:
```sql
-- 每次连接时必须执行
PRAGMA foreign_keys = ON;

-- 或在应用层统一设置
-- SQLite 不支持全局启用，必须在每个连接中设置
```

**建议**:
1. 在 Database Manager 的数据库连接初始化时执行 `PRAGMA foreign_keys = ON`
2. 添加文档说明此限制
3. 考虑在应用层实现级联删除逻辑作为兜底

**优先级**: 🔴 P0 (必须修复)

---

### R2. 软删除实现不完整

**问题描述**: 
三张表都有 `deleted_at` 字段，但**没有自动过滤机制**。

**影响**:
- ❌ 查询时必须手动添加 `WHERE deleted_at IS NULL`
- ❌ 容易遗漏导致查询到已删除数据
- ❌ 索引效率降低 (包含已删除数据)

**当前设计**:
```sql
-- 依赖应用层手动过滤
SELECT * FROM users WHERE org_id = 'org_123' AND deleted_at IS NULL;
```

**解决方案**:

**方案 A**: 使用视图 (推荐)
```sql
-- 创建活跃数据视图
CREATE VIEW users_active AS
SELECT * FROM users WHERE deleted_at IS NULL;

-- 应用层查询视图而非原表
SELECT * FROM users_active WHERE org_id = 'org_123';
```

**方案 B**: 使用触发器自动标记
```sql
-- 删除触发器 (替代 DELETE 操作)
CREATE TRIGGER users_soft_delete
BEFORE DELETE ON users
BEGIN
    UPDATE users SET deleted_at = CURRENT_TIMESTAMP WHERE user_id = OLD.user_id;
    SELECT RAISE(IGNORE);  -- 阻止实际删除
END;
```

**建议**: 采用方案 A (视图) + 应用层规范

**优先级**: 🔴 P0 (必须修复)

---

### R3. 唯一索引缺失 (users 表)

**问题描述**: 
users 表定义了 `UNIQUE (username)` 和 `UNIQUE (email)` 约束，但**没有创建唯一索引**。

**影响**:
- ⚠️ SQLite 会自动创建唯一索引，但显式声明更清晰
- ⚠️ 性能优化空间

**验证**:
```sql
-- 检查是否自动创建
SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='users';
```

**解决方案**:
```sql
-- 显式创建唯一索引 (虽然 UNIQUE 约束会自动创建)
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email);
```

**当前状态**: ✅ 已创建 (在 002_users_schema.sql 中)

**优先级**: 🟢 已解决

---

### R4. 级联删除风险 (数据丢失)

**问题描述**: 
`ON DELETE CASCADE` 配置意味着删除组织时，**自动删除所有关联数据**。

**影响**:
- 🔥 误删组织 = 删除所有用户、赛道、记录
- 🔥 无法恢复 (除非有备份)
- 🔥 没有"回收站"机制

**场景**:
```sql
-- 危险操作!
DELETE FROM organizations WHERE org_id = 'org_demo_customer_1';
-- 结果：该组织的所有 users, tracks, records 全部被删除
```

**解决方案**:

**方案 A**: 禁用 CASCADE，改用应用层控制 (推荐)
```sql
-- 移除 ON DELETE CASCADE
FOREIGN KEY (org_id) REFERENCES organizations(org_id)

-- 应用层实现删除检查
-- 1. 检查是否有活跃数据
-- 2. 要求用户确认
-- 3. 先软删除子表，再软删除组织
```

**方案 B**: 添加删除保护触发器
```sql
CREATE TRIGGER prevent_org_delete
BEFORE DELETE ON organizations
BEGIN
    SELECT CASE 
        WHEN (SELECT COUNT(*) FROM users WHERE org_id = OLD.org_id AND deleted_at IS NULL) > 0
        THEN RAISE(ABORT, 'Cannot delete organization with active users')
    END;
END;
```

**建议**: 采用方案 A + 应用层审批流程

**优先级**: 🔴 P0 (必须修复)

---

## ⚠️ 中风险问题 (强烈建议修复)

### M1. 缺少审计日志表

**问题描述**: 
没有专门的审计日志表记录关键操作。

**影响**:
- ❌ 无法追溯谁在什么时候做了什么修改
- ❌ 安全事件无法调查
- ❌ 合规性风险

**建议表结构**:
```sql
CREATE TABLE audit_logs (
    log_id TEXT PRIMARY KEY,
    org_id TEXT NOT NULL,
    user_id TEXT,
    action TEXT NOT NULL,          -- CREATE/UPDATE/DELETE/LOGIN/LOGOUT
    table_name TEXT NOT NULL,
    record_id TEXT,
    old_value JSON,                -- 修改前的数据
    new_value JSON,                -- 修改后的数据
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_logs_org_user ON audit_logs(org_id, user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);
```

**优先级**: 🟡 P1 (强烈建议)

---

### M2. 缺少数据版本控制

**问题描述**: 
没有记录数据的历史版本。

**影响**:
- ❌ 无法回滚到历史版本
- ❌ 无法查看变更历史
- ❌ 误操作后恢复困难

**解决方案**:

**方案 A**: 版本化表设计
```sql
CREATE TABLE tracks_versions (
    version_id TEXT PRIMARY KEY,
    track_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    data JSON NOT NULL,            -- 完整快照
    changed_by TEXT,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    change_reason TEXT
);

CREATE UNIQUE INDEX idx_tracks_versions_track_version ON tracks_versions(track_id, version_number);
```

**方案 B**: 触发器自动记录变更
```sql
CREATE TRIGGER tracks_version_control
AFTER UPDATE ON tracks
BEGIN
    INSERT INTO tracks_versions (track_id, version_number, data, changed_by, change_reason)
    VALUES (NEW.track_id, 
            (SELECT COALESCE(MAX(version_number), 0) + 1 FROM tracks_versions WHERE track_id = NEW.track_id),
            json_object('track_id', NEW.track_id, 'name', NEW.name, ...),
            NEW.updated_by,
            'auto_version');
END;
```

**建议**: 先实现方案 A (手动版本控制)，后续自动化

**优先级**: 🟡 P1 (强烈建议)

---

### M3. JSON 字段缺乏验证

**问题描述**: 
`config` 和 `permissions` 字段使用 JSON 类型，但**没有结构验证**。

**影响**:
- ⚠️ 可能存储无效 JSON
- ⚠️ 字段结构不一致
- ⚠️ 应用层解析失败

**示例问题**:
```sql
-- 这些都能成功插入，但可能导致应用层错误
INSERT INTO users (permissions) VALUES ('not json');
INSERT INTO organizations (config) VALUES ('{"invalid": }');
```

**解决方案**:

**方案 A**: SQLite CHECK 约束 (有限验证)
```sql
-- 验证 JSON 格式
config TEXT CHECK (json_valid(config))

-- 验证必填字段 (SQLite 3.38+)
permissions TEXT CHECK (json_extract(permissions, '$.modules') IS NOT NULL)
```

**方案 B**: 应用层验证 (推荐)
```python
# 在 Database Manager 中实现
def validate_permissions(data):
    required_keys = ['modules', 'data_scope']
    if not all(key in data for key in required_keys):
        raise ValidationError("Missing required keys")
```

**建议**: 方案 B + 文档说明 JSON 结构

**优先级**: 🟡 P1 (强烈建议)

---

### M4. 缺少全文搜索支持

**问题描述**: 
organizations.name, tracks.name/description 等字段需要模糊搜索，但**没有全文索引**。

**影响**:
- ⚠️ LIKE '%keyword%' 查询效率低
- ⚠️ 无法支持复杂搜索 (多关键词、相关性排序)

**解决方案**:
```sql
-- 创建 FTS5 虚拟表
CREATE VIRTUAL TABLE organizations_fts USING fts5(
    name,
    description,
    content='organizations',
    content_rowid='rowid'
);

-- 创建触发器同步数据
CREATE TRIGGER organizations_ai AFTER INSERT ON organizations BEGIN
    INSERT INTO organizations_fts(rowid, name, description) VALUES (NEW.rowid, NEW.name, NEW.description);
END;

-- 查询
SELECT * FROM organizations_fts WHERE organizations_fts MATCH '科技';
```

**建议**: 在数据量>1000 时再实现

**优先级**: 🟡 P2 (可延后)

---

### M5. 时区处理不明确

**问题描述**: 
TIMESTAMP 字段使用 `CURRENT_TIMESTAMP`,但**没有时区信息**。

**影响**:
- ⚠️ SQLite 存储 UTC 时间
- ⚠️ 应用层需要转换时区
- ⚠️ 跨时区系统可能混淆

**建议**:
1. 文档明确：所有时间存储为 UTC
2. 应用层负责转换为本地时间 (GMT+8)
3. 或者使用 ISO 8601 格式：`2026-03-27T07:37:00+08:00`

**优先级**: 🟡 P2 (可延后)

---

## 🟢 低风险问题 (可选优化)

### L1. 缺少表注释

**问题**: SQLite 不支持表/字段注释，建议在设计文档中补充

**建议**: 在 docs/ 目录中维护详细的字段说明

**优先级**: 🟢 P3 (可选)

---

### L2. 索引命名不一致

**问题**: 
- 唯一索引：`idx_users_username` (带表名)
- 复合索引：`idx_users_org_status` (带表名)
- 但 UNIQUE 约束没有显式命名

**建议**: 统一命名规范
```sql
-- 唯一约束
CONSTRAINT uk_users_username UNIQUE (username)

-- 索引
CONSTRAINT idx_users_username UNIQUE (username)
```

**优先级**: 🟢 P3 (可选)

---

### L3. 缺少数据库版本管理

**问题**: 没有迁移版本记录表

**建议**:
```sql
CREATE TABLE schema_migrations (
    version TEXT PRIMARY KEY,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    description TEXT
);

-- 记录已应用的迁移
INSERT INTO schema_migrations (version, description) VALUES 
    ('001', 'organizations schema'),
    ('002', 'users schema'),
    ('003', 'tracks schema');
```

**优先级**: 🟢 P3 (可选)

---

## 📊 架构设计评估

### 多租户隔离 ✅

| 机制 | 状态 | 评价 |
|------|------|------|
| org_id 外键 | ✅ | 设计正确 |
| 查询隔离 | ⚠️ 依赖应用层 | 需文档规范 |
| 级联删除 | 🔴 风险过高 | 建议移除 |

**评分**: 75/100

---

### 安全性 ⚠️

| 机制 | 状态 | 评价 |
|------|------|------|
| 密码哈希 | ✅ | 字段已预留 |
| 防暴力破解 | ✅ | login_attempts, locked_until |
| 权限控制 | ✅ | role + permissions JSON |
| 审计日志 | ❌ 缺失 | 需新增表 |
| 外键启用 | ❌ 需手动启用 | SQLite 限制 |

**评分**: 70/100

---

### 扩展性 ✅

| 机制 | 状态 | 评价 |
|------|------|------|
| JSON 配置 | ✅ | 灵活扩展 |
| 软删除 | ✅ | 支持数据恢复 |
| 状态管理 | ✅ | 完整生命周期 |
| 版本控制 | ❌ 缺失 | 建议新增 |

**评分**: 80/100

---

### 性能优化 ✅

| 机制 | 状态 | 评价 |
|------|------|------|
| 主键索引 | ✅ | 自动创建 |
| 唯一索引 | ✅ | 已创建 |
| 复合索引 | ✅ | 覆盖常用查询 |
| 全文搜索 | ❌ 缺失 | 可延后实现 |

**评分**: 85/100

---

### 数据完整性 ⚠️

| 机制 | 状态 | 评价 |
|------|------|------|
| CHECK 约束 | ✅ | 枚举值验证 |
| UNIQUE 约束 | ✅ | 唯一性保证 |
| NOT NULL | ✅ | 必填字段验证 |
| 外键约束 | ⚠️ SQLite 限制 | 需手动启用 |
| 级联删除 | 🔴 风险过高 | 建议移除 |

**评分**: 70/100

---

## 📋 修复优先级清单

### P0 (必须修复，否则不能上线)

| 编号 | 问题 | 工作量 | 风险 |
|------|------|--------|------|
| R1 | 外键约束未启用 | 1h | 🔴 数据完整性 |
| R2 | 软删除实现不完整 | 2h | 🔴 数据污染 |
| R4 | 级联删除风险 | 1h | 🔴 数据丢失 |

**预计总工作量**: 4 小时

---

### P1 (强烈建议，生产环境需要)

| 编号 | 问题 | 工作量 | 风险 |
|------|------|--------|------|
| M1 | 审计日志表 | 3h | 🟡 合规风险 |
| M2 | 数据版本控制 | 4h | 🟡 运维风险 |
| M3 | JSON 字段验证 | 2h | 🟡 数据质量 |

**预计总工作量**: 9 小时

---

### P2 (可延后，数据量大时实现)

| 编号 | 问题 | 工作量 | 风险 |
|------|------|--------|------|
| M4 | 全文搜索支持 | 3h | 🟢 性能 |
| M5 | 时区处理明确 | 1h | 🟢 国际化 |

**预计总工作量**: 4 小时

---

### P3 (可选优化)

| 编号 | 问题 | 工作量 |
|------|------|--------|
| L1 | 表注释文档 | 1h |
| L2 | 索引命名统一 | 0.5h |
| L3 | 数据库版本管理 | 1h |

**预计总工作量**: 2.5 小时

---

## 🎯 总体评价

| 维度 | 评分 | 说明 |
|------|------|------|
| 架构设计 | 75/100 | 多租户设计正确，但级联删除风险高 |
| 安全性 | 70/100 | 基础安全完整，缺少审计日志 |
| 扩展性 | 80/100 | JSON 配置灵活，缺少版本控制 |
| 性能优化 | 85/100 | 索引覆盖全面 |
| 数据完整性 | 70/100 | SQLite 外键限制是主要问题 |
| **综合评分** | **76/100** | **良好，但有必须修复的高风险问题** |

---

## ✅ 立即行动项

### 阶段 1: P0 修复 (今天完成)

1. **Database Manager 连接初始化**:
   ```sql
   PRAGMA foreign_keys = ON;
   ```

2. **创建活跃数据视图**:
   ```sql
   CREATE VIEW organizations_active AS SELECT * FROM organizations WHERE deleted_at IS NULL;
   CREATE VIEW users_active AS SELECT * FROM users WHERE deleted_at IS NULL;
   CREATE VIEW tracks_active AS SELECT * FROM tracks WHERE deleted_at IS NULL;
   ```

3. **移除级联删除**:
   ```sql
   -- 重建外键约束 (移除 ON DELETE CASCADE)
   -- 或应用层实现删除检查
   ```

### 阶段 2: P1 修复 (本周完成)

1. 创建 audit_logs 表
2. 创建 schema_migrations 表
3. 实现 JSON 验证逻辑
4. 设计版本控制方案

### 阶段 3: P2 优化 (下周完成)

1. 实现全文搜索 (如需要)
2. 明确时区处理规范

---

**审查人**: 喵小白  
**审查时间**: 2026-03-27 07:37  
**下次审查**: 修复完成后重新评估
