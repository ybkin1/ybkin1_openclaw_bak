# tracks 表设计文档

**Task ID**: 1.1.3  
**创建时间**: 2026-03-27 07:32  
**设计者**: database-manager Agent  
**审查状态**: 待 Spec Review + Code Quality Review

---

## 📊 表结构

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| track_id | TEXT | PRIMARY KEY | 赛道唯一标识 (UUID) |
| org_id | TEXT | FOREIGN KEY, NOT NULL | 所属组织 ID |
| name | TEXT | NOT NULL | 赛道名称 |
| code | TEXT | UNIQUE (org_id, code) | 赛道编码 (组织内唯一) |
| description | TEXT | - | 赛道描述 |
| category | TEXT | CHECK | 分类：ai/media/stock/internal/customer/other |
| status | TEXT | CHECK, DEFAULT 'active' | 状态：active/planning/paused/completed/archived |
| priority | TEXT | CHECK, DEFAULT 'medium' | 优先级：low/medium/high/critical |
| budget | DECIMAL(15,2) | - | 预算金额 |
| currency | TEXT | DEFAULT 'CNY' | 货币类型 |
| team_size | INTEGER | DEFAULT 0 | 团队规模 |
| start_date | DATE | - | 开始日期 |
| end_date | DATE | - | 结束日期 |
| milestone_count | INTEGER | DEFAULT 0 | 里程碑数量 |
| config | JSON | DEFAULT '{}' | 赛道特定配置 |
| created_by | TEXT | - | 创建人 user_id |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |
| updated_at | TIMESTAMP | DEFAULT | 更新时间 |
| deleted_at | TIMESTAMP | NULL | 软删除标记 |

---

## 🎯 核心设计

### 赛道分类 (category)

| 分类 | 说明 | 典型场景 |
|------|------|----------|
| **ai** | AI 相关 | AI Agent 开发、RAG 系统、大模型应用 |
| **media** | 自媒体 | 抖音、小红书、公众号内容创作 |
| **stock** | 股票投资 | A 股、港股、美股交易 |
| **internal** | 内部项目 | 工具开发、系统优化、运维自动化 |
| **customer** | 客户项目 | 交付给客户的商业项目 |
| **other** | 其他 | 未分类的赛道 |

### 状态流转

```
planning → active → completed
              ↓
           paused
              ↓
           active
              ↓
         archived
```

| 状态 | 说明 | 典型场景 |
|------|------|----------|
| **planning** | 规划中 | 需求分析、资源筹备 |
| **active** | 进行中 | 正常执行 |
| **paused** | 已暂停 | 需求变更、资源不足 |
| **completed** | 已完成 | 目标达成 |
| **archived** | 已归档 | 历史项目，只读 |

### 优先级定义

| 优先级 | 资源分配 | 响应时间 | 典型场景 |
|--------|----------|----------|----------|
| **critical** | 最高优先级 | 立即响应 | 核心业务、紧急交付 |
| **high** | 高优先级 | 24 小时内 | 重要客户项目 |
| **medium** | 正常优先级 | 48 小时内 | 常规迭代 |
| **low** | 低优先级 | 排期处理 | 优化改进 |

---

## 🔐 多租户隔离

### 隔离机制

1. **org_id 外键约束**
   - 每个赛道必须属于一个组织
   - ON DELETE CASCADE: 组织删除时自动删除赛道
   - 所有查询自动注入 org_id 过滤

2. **组织内唯一编码**
   - `UNIQUE (org_id, code)` 约束
   - 同一组织内赛道编码唯一
   - 不同组织可使用相同编码

3. **数据隔离查询**
   ```sql
   -- 应用层必须注入 org_id 过滤
   SELECT * FROM tracks WHERE org_id = 'org_123' AND status = 'active';
   ```

---

## 📈 索引设计

| 索引名 | 字段 | 类型 | 用途 |
|--------|------|------|------|
| idx_tracks_org_id | org_id | 单列 | 多租户隔离 (最常用) |
| idx_tracks_status | status | 单列 | 过滤活跃赛道 |
| idx_tracks_priority | priority | 单列 | 资源分配 |
| idx_tracks_category | category | 单列 | 分类统计 |
| idx_tracks_created_at | created_at | 单列 | 时间排序 |
| idx_tracks_start_date | start_date | 单列 | 时间线视图 |
| idx_tracks_org_status | org_id, status | 复合 | 查某组织活跃赛道 |
| idx_tracks_org_priority | org_id, priority | 复合 | 资源分配查询 |
| idx_tracks_status_priority | status, priority | 复合 | 优先级排序 |

### 索引使用场景

```sql
-- 场景 1: 查某组织所有活跃赛道
SELECT * FROM tracks WHERE org_id = 'org_123' AND status = 'active';
-- 使用：idx_tracks_org_status

-- 场景 2: 查高优先级赛道
SELECT * FROM tracks WHERE org_id = 'org_123' AND priority IN ('critical', 'high');
-- 使用：idx_tracks_org_priority

-- 场景 3: 赛道统计 (按分类)
SELECT category, COUNT(*) FROM tracks WHERE org_id = 'org_123' GROUP BY category;
-- 使用：idx_tracks_category

-- 场景 4: 时间线视图
SELECT * FROM tracks WHERE org_id = 'org_123' ORDER BY start_date DESC;
-- 使用：idx_tracks_start_date
```

---

## 🔧 触发器

### update_tracks_updated_at

**触发时机**: AFTER UPDATE  
**功能**: 自动更新 updated_at 字段

```sql
CREATE TRIGGER update_tracks_updated_at
AFTER UPDATE ON tracks
BEGIN
    UPDATE tracks SET updated_at = CURRENT_TIMESTAMP WHERE track_id = NEW.track_id;
END;
```

---

## 📊 视图

### v_active_tracks_summary (活跃赛道统计)

**功能**: 按组织统计赛道概况

| 字段 | 说明 |
|------|------|
| total_tracks | 总赛道数 |
| active_count | 进行中数量 |
| planning_count | 规划中数量 |
| paused_count | 已暂停数量 |
| critical_count | 紧急优先级数量 |
| high_count | 高优先级数量 |
| total_budget | 总预算 |

**使用示例**:
```sql
-- 查询各组织赛道统计
SELECT * FROM v_active_tracks_summary WHERE org_id = 'org_demo_internal';
```

### v_tracks_expiring_soon (即将到期的赛道)

**功能**: 识别即将到期的赛道，提前预警

| expiry_status | 说明 |
|---------------|------|
| no_end_date | 未设置结束日期 |
| expired | 已过期 |
| expiring_7days | 7 天内到期 |
| expiring_30days | 30 天内到期 |
| ok | 正常 |

**使用示例**:
```sql
-- 查询 30 天内到期的赛道
SELECT * FROM v_tracks_expiring_soon 
WHERE expiry_status IN ('expiring_7days', 'expiring_30days');
```

---

## ✅ 验收标准

| 标准 | 状态 | 说明 |
|------|------|------|
| Schema 设计完成 | ✅ | SQL 脚本已创建 |
| 包含必需字段 | ✅ | track_id, org_id, name, code, status, priority 等 |
| 支持多组织隔离 | ✅ | org_id 外键 + 级联删除 |
| 状态管理完整 | ✅ | 5 状态覆盖全生命周期 |
| 优先级管理 | ✅ | 4 级优先级 |
| 赛道分类 | ✅ | 6 分类覆盖所有场景 |
| 索引优化 | ✅ | 9 个索引覆盖所有查询 |
| 触发器 | ✅ | 自动更新 updated_at |
| 统计视图 | ✅ | v_active_tracks_summary |
| 预警视图 | ✅ | v_tracks_expiring_soon |
| 示例数据 | ✅ | 8 条测试数据 (覆盖所有分类和状态) |

---

## 📝 使用示例

### 1. 创建新赛道

```sql
INSERT INTO tracks (track_id, org_id, name, code, category, priority, budget, start_date, end_date, created_by)
VALUES (
    'track_new_001',
    'org_demo_internal',
    '新 AI 项目',
    'AI-NEW-001',
    'ai',
    'high',
    300000.00,
    '2026-04-01',
    '2026-09-30',
    'user_001_super'
);
```

### 2. 查询组织内所有活跃赛道

```sql
SELECT track_id, name, code, priority, budget, start_date, end_date
FROM tracks
WHERE org_id = 'org_demo_internal' AND status = 'active'
ORDER BY 
    CASE priority 
        WHEN 'critical' THEN 1 
        WHEN 'high' THEN 2 
        WHEN 'medium' THEN 3 
        ELSE 4 
    END,
    created_at DESC;
```

### 3. 更新赛道状态

```sql
-- 暂停赛道
UPDATE tracks SET status = 'paused' WHERE track_id = 'track_001_ai';

-- 完成赛道
UPDATE tracks 
SET status = 'completed', updated_at = CURRENT_TIMESTAMP 
WHERE track_id = 'track_001_ai';
```

### 4. 查询即将到期的赛道

```sql
SELECT track_id, name, end_date, days_remaining, expiry_status
FROM v_tracks_expiring_soon
WHERE org_id = 'org_demo_internal'
  AND expiry_status IN ('expiring_7days', 'expiring_30days');
```

### 5. 赛道统计

```sql
-- 按分类统计
SELECT category, COUNT(*) as count, SUM(budget) as total_budget
FROM tracks
WHERE org_id = 'org_demo_internal' AND status = 'active'
GROUP BY category;

-- 按优先级统计
SELECT priority, COUNT(*) as count
FROM tracks
WHERE org_id = 'org_demo_internal' AND status = 'active'
GROUP BY priority;
```

---

## 🔗 依赖关系

### 前置依赖
- ✅ Task 1.1.1: organizations 表 (必须先行创建)

### 后续任务
- ⏳ Task 1.1.4: records 表 (动态 schema 设计)
- ⏳ Task 1.1.5: knowledge_docs 表 (知识库文档)
- ⏳ Task 1.1.6: files 表 (文件管理)

---

## 💡 设计亮点

1. **完整的生命周期管理**: 5 状态覆盖赛道从规划到归档的全流程
2. **优先级驱动**: 4 级优先级支持资源优化配置
3. **分类管理**: 6 分类覆盖 AI、自媒体、股票、客户项目等场景
4. **预算跟踪**: DECIMAL 类型确保金额精度
5. **时间管理**: start_date + end_date 支持时间线视图和到期预警
6. **统计视图**: v_active_tracks_summary 提供组织级概览
7. **预警视图**: v_tracks_expiring_soon 提前识别风险

---

**SQL 脚本位置**: `/root/.openclaw/workspace/agents/database-manager/scripts/003_tracks_schema.sql`  
**设计文档位置**: `/root/.openclaw/workspace/agents/database-manager/docs/003_tracks_schema_design.md`

---

**下一步**: 继续 Task 1.1.4 - records 表 (动态 schema 设计)
