# Database Manager Agent - 设计规范

**版本**: 1.0  
**创建时间**: 2026-03-27 09:16  
**状态**: 开发中

---

## 🎯 核心职责

Database Manager Agent 负责企业级数据底座的数据库操作，包括：

1. **数据库连接管理** - 连接池、PRAGMA 配置、错误恢复
2. **CRUD 操作封装** - 统一的增删改查接口
3. **批量操作支持** - 批量插入、更新、删除
4. **事务管理** - 事务支持、回滚、保存点
5. **错误处理** - 统一错误码、重试机制、错误日志
6. **查询优化** - 索引建议、慢查询检测、执行计划分析
7. **数据验证** - JSON 验证、外键检查、约束验证
8. **审计日志** - 自动记录关键操作

---

## 📋 功能模块

### 模块 1: 连接管理

**功能**:
- 数据库连接初始化
- PRAGMA 配置 (foreign_keys, journal_mode, synchronous)
- 连接池管理
- 自动重连
- 健康检查

**接口**:
```python
class DatabaseManager:
    def __init__(self, db_path: str)
    def connect(self) -> sqlite3.Connection
    def close(self)
    def is_healthy(self) -> bool
    def get_connection(self) -> sqlite3.Connection
```

**PRAGMA 配置**:
```sql
PRAGMA foreign_keys = ON;              -- 启用外键
PRAGMA journal_mode = WAL;             -- Write-Ahead Logging
PRAGMA synchronous = NORMAL;           -- 性能与安全平衡
PRAGMA cache_size = -64000;            -- 64MB 缓存
PRAGMA temp_store = MEMORY;            -- 临时存储内存中
PRAGMA busy_timeout = 5000;            -- 忙时超时 5 秒
```

---

### 模块 2: CRUD 操作

**功能**:
- 统一增删改查接口
- 参数化查询 (防 SQL 注入)
- 自动映射 (dict ↔ row)
- 软删除支持
- 批量操作

**接口**:
```python
# 查询
def fetch_one(table: str, where: dict, columns: list = None) -> dict
def fetch_all(table: str, where: dict, columns: list = None, order_by: str = None, limit: int = None) -> list

# 插入
def insert(table: str, data: dict) -> str  # 返回主键
def insert_many(table: str, data_list: list) -> list  # 返回主键列表

# 更新
def update(table: str, data: dict, where: dict) -> int  # 返回影响行数
def update_by_id(table: str, record_id: str, data: dict) -> int

# 删除
def delete(table: str, where: dict, soft: bool = True) -> int
def delete_by_id(table: str, record_id: str, soft: bool = True) -> int
```

**使用示例**:
```python
# 查询
user = db.fetch_one('users', {'user_id': 'user_001'})
users = db.fetch_all('users', {'org_id': 'org_demo_internal'}, order_by='created_at DESC', limit=10)

# 插入
user_id = db.insert('users', {
    'user_id': 'user_new_001',
    'org_id': 'org_demo_internal',
    'username': 'newuser',
    'email': 'newuser@example.com',
    'password_hash': '...'
})

# 更新
rows = db.update('users', {'status': 'active'}, {'user_id': 'user_new_001'})

# 删除 (软删除)
rows = db.delete('users', {'user_id': 'user_new_001'})
```

---

### 模块 3: 事务管理

**功能**:
- 事务开始/提交/回滚
- 保存点支持
- 嵌套事务
- 自动回滚 (异常时)

**接口**:
```python
def begin_transaction()
def commit()
def rollback()
def savepoint(name: str)
def rollback_to(name: str)

# 上下文管理器
@contextmanager
def transaction()
```

**使用示例**:
```python
# 方式 1: 显式事务
db.begin_transaction()
try:
    db.insert('users', {...})
    db.insert('api_keys', {...})
    db.commit()
except Exception as e:
    db.rollback()
    raise

# 方式 2: 上下文管理器
with db.transaction():
    db.insert('users', {...})
    db.insert('api_keys', {...})
# 自动提交，异常自动回滚
```

---

### 模块 4: 批量操作

**功能**:
- 批量插入 (executemany)
- 批量更新
- 批量删除
- 分块处理 (大数据集)

**接口**:
```python
def batch_insert(table: str, data_list: list, chunk_size: int = 1000) -> list
def batch_update(table: str, key_field: str, data_list: list, chunk_size: int = 1000) -> int
def batch_delete(table: str, where_list: list, chunk_size: int = 1000) -> int
```

**使用示例**:
```python
# 批量插入 10000 条记录
users = [{'user_id': f'user_{i}', 'org_id': 'org_demo', ...} for i in range(10000)]
ids = db.batch_insert('users', users, chunk_size=1000)

# 批量更新
updates = [{'user_id': 'user_1', 'status': 'active'}, {'user_id': 'user_2', 'status': 'inactive'}]
rows = db.batch_update('users', 'user_id', updates)
```

---

### 模块 5: 错误处理

**功能**:
- 统一错误码
- 错误分类
- 重试机制
- 错误日志

**错误码**:
```python
class DatabaseError(Exception):
    code: str
    message: str

# 错误码定义
ERROR_CODES = {
    'DB_CONN_FAILED': '数据库连接失败',
    'DB_QUERY_FAILED': '查询执行失败',
    'DB_CONSTRAINT_VIOLATION': '约束违反',
    'DB_FOREIGN_KEY_VIOLATION': '外键约束违反',
    'DB_UNIQUE_VIOLATION': '唯一性约束违反',
    'DB_NOT_NULL_VIOLATION': 'NOT NULL 约束违反',
    'DB_CHECK_VIOLATION': 'CHECK 约束违反',
    'DB_TRANSACTION_FAILED': '事务失败',
    'DB_TIMEOUT': '操作超时',
    'DB_LOCKED': '数据库被锁定',
}
```

**使用示例**:
```python
try:
    db.insert('users', data)
except DatabaseError as e:
    if e.code == 'DB_FOREIGN_KEY_VIOLATION':
        logger.error(f"外键约束违反：{e.message}")
    elif e.code == 'DB_UNIQUE_VIOLATION':
        logger.error(f"唯一性约束违反：{e.message}")
    else:
        logger.error(f"数据库错误：{e.code} - {e.message}")
```

---

### 模块 6: 数据验证

**功能**:
- JSON 字段验证
- 外键存在性检查
- 约束验证
- 业务规则验证

**接口**:
```python
def validate_json(data: any, schema: dict) -> bool
def validate_foreign_key(table: str, field: str, value: str) -> bool
def validate_constraints(table: str, data: dict) -> list  # 返回错误列表
```

**使用示例**:
```python
# JSON 验证
permissions_schema = {
    'type': 'object',
    'required': ['modules', 'data_scope'],
    'properties': {
        'modules': {'type': 'object'},
        'data_scope': {'type': 'string', 'enum': ['org', 'team', 'self']}
    }
}
if not db.validate_json(permissions, permissions_schema):
    raise ValidationError("Invalid permissions format")

# 外键验证
if not db.validate_foreign_key('organizations', 'org_id', org_id):
    raise ValidationError(f"Organization {org_id} does not exist")
```

---

### 模块 7: 查询优化

**功能**:
- 执行计划分析
- 慢查询检测
- 索引建议
- 查询缓存

**接口**:
```python
def explain_query(sql: str, params: tuple = None) -> list
def get_slow_queries(threshold_ms: int = 1000) -> list
def suggest_indexes(table: str, query: str) -> list
```

**使用示例**:
```python
# 执行计划分析
plan = db.explain_query('SELECT * FROM users WHERE org_id = ? AND status = ?', ('org_123', 'active'))
for step in plan:
    print(f"{step['id']}: {step['detail']}")

# 慢查询检测
slow_queries = db.get_slow_queries(threshold_ms=1000)
for query in slow_queries:
    logger.warning(f"Slow query: {query['sql']} ({query['duration']}ms)")
```

---

### 模块 8: 审计日志

**功能**:
- 自动记录关键操作
- 操作类型识别
- 旧值/新值记录
- 异步写入 (性能优化)

**接口**:
```python
def log_action(action: str, table: str, record_id: str, old_value: dict = None, new_value: dict = None)
def get_audit_logs(table: str = None, record_id: str = None, limit: int = 100) -> list
```

**使用示例**:
```python
# 自动记录 (装饰器)
@db.audit_log('CREATE', 'users')
def create_user(data):
    return db.insert('users', data)

# 手动记录
db.log_action('UPDATE', 'users', user_id, old_value=old_data, new_value=new_data)

# 查询审计日志
logs = db.get_audit_logs(table='users', record_id='user_001', limit=50)
```

---

## 📁 文件结构

```
/root/.openclaw/workspace/agents/database-manager/
├── scripts/
│   ├── 001_organizations_schema.sql  →  012_schema_migrations.sql
│   └── run_migrations.sh              # 迁移执行脚本
├── src/
│   ├── __init__.py
│   ├── database.py                    # 核心数据库类
│   ├── connection.py                  # 连接管理
│   ├── crud.py                        # CRUD 操作
│   ├── transaction.py                 # 事务管理
│   ├── batch.py                       # 批量操作
│   ├── validation.py                  # 数据验证
│   ├── errors.py                      # 错误处理
│   ├── audit.py                       # 审计日志
│   └── query_optimizer.py             # 查询优化
├── docs/
│   ├── database-design-risk-analysis.md
│   ├── database-connection-init.md
│   ├── milestone1-completion-report.md
│   └── 001_organizations_schema_design.md → 010_tickets_schema_design.md
├── tests/
│   ├── test_database.py
│   ├── test_crud.py
│   ├── test_transaction.py
│   └── test_validation.py
└── config/
    └── database.json                  # 数据库配置
```

---

## 🚀 开发计划

### Phase 1: 核心功能 (1-2 天)

- [ ] 连接管理 (connection.py)
- [ ] CRUD 操作 (crud.py)
- [ ] 错误处理 (errors.py)
- [ ] 基础测试

### Phase 2: 高级功能 (1-2 天)

- [ ] 事务管理 (transaction.py)
- [ ] 批量操作 (batch.py)
- [ ] 数据验证 (validation.py)
- [ ] 集成测试

### Phase 3: 优化功能 (1 天)

- [ ] 查询优化 (query_optimizer.py)
- [ ] 审计日志 (audit.py)
- [ ] 性能测试
- [ ] 文档完善

---

## ✅ 验收标准

| 标准 | 说明 |
|------|------|
| 代码覆盖率 | > 80% |
| 单元测试 | 所有核心功能有测试 |
| 集成测试 | 端到端测试通过 |
| 性能测试 | 批量插入 10000 条 < 10 秒 |
| 文档完整 | API 文档 + 使用示例 |
| 错误处理 | 所有错误有明确错误码和消息 |
| 安全性 | 防 SQL 注入 + 参数化查询 |

---

**维护者**: Database Manager Agent  
**最后更新**: 2026-03-27 09:16
