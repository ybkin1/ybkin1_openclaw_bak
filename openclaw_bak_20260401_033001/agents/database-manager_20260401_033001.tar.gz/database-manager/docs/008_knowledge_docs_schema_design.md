# knowledge_docs 表设计文档

**Task ID**: 1.1.5  
**创建时间**: 2026-03-27 08:20  
**设计者**: database-manager Agent  
**审查状态**: 待 Spec Review + Code Quality Review

---

## 📊 表结构

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| doc_id | TEXT | PRIMARY KEY | 文档唯一标识 (UUID) |
| org_id | TEXT | FOREIGN KEY, NOT NULL | 所属组织 ID |
| track_id | TEXT | FOREIGN KEY | 所属赛道 ID (可选) |
| record_id | TEXT | FOREIGN KEY | 关联记录 ID (可选) |
| title | TEXT | NOT NULL | 标题 |
| slug | TEXT | UNIQUE (org_id, slug) | URL 友好标识 |
| summary | TEXT | - | 摘要 |
| content | TEXT | NOT NULL | Markdown 内容 |
| content_html | TEXT | - | 渲染后的 HTML |
| doc_type | TEXT | CHECK, DEFAULT 'article' | article/wiki/faq/guide/template |
| doc_category | TEXT | - | 技术/产品/运营/管理等 |
| status | TEXT | CHECK, DEFAULT 'draft' | draft/review/published/archived |
| visibility | TEXT | CHECK, DEFAULT 'internal' | public/internal/private |
| version | INTEGER | DEFAULT 1 | 版本号 |
| parent_doc_id | TEXT | FOREIGN KEY | 父文档 ID (版本历史) |
| is_latest | BOOLEAN | DEFAULT 1 | 是否最新版本 |
| author_id | TEXT | FOREIGN KEY | 作者 user_id |
| reviewer_id | TEXT | FOREIGN KEY | 审核人 user_id |
| owner_id | TEXT | FOREIGN KEY | 负责人 user_id |
| tags | JSON | DEFAULT '[]' | 标签列表 |
| related_docs | JSON | DEFAULT '[]' | 关联文档 ID 列表 |
| attachments | JSON | DEFAULT '[]' | 附件列表 |
| word_count | INTEGER | DEFAULT 0 | 字数统计 |
| read_time_minutes | INTEGER | DEFAULT 0 | 阅读时间 (分钟) |
| view_count | INTEGER | DEFAULT 0 | 浏览次数 |
| like_count | INTEGER | DEFAULT 0 | 点赞数 |
| comment_count | INTEGER | DEFAULT 0 | 评论数 |
| published_at | DATE | - | 发布时间 |
| last_reviewed_at | DATE | - | 最后审核时间 |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |
| updated_at | TIMESTAMP | DEFAULT | 更新时间 |
| deleted_at | TIMESTAMP | NULL | 软删除标记 |

---

## 🎯 核心设计

### 文档类型 (doc_type)

| 类型 | 说明 | 典型场景 |
|------|------|----------|
| **article** | 文章 | 技术文章、博客、分享 |
| **wiki** | 维基 | 知识库、文档中心 |
| **faq** | 问答 | 常见问题解答 |
| **guide** | 指南 | 操作手册、教程 |
| **template** | 模板 | 文档模板、规范 |

### 状态流转

```
draft → review → published → archived
```

| 状态 | 说明 | 典型场景 |
|------|------|----------|
| **draft** | 草稿 | 创建未完成 |
| **review** | 待审核 | 提交审核 |
| **published** | 已发布 | 公开可见 |
| **archived** | 已归档 | 历史文档 |

### 可见性级别

| 可见性 | 说明 | 访问权限 |
|--------|------|----------|
| **public** | 公开 | 所有人可见 |
| **internal** | 内部 | 组织内成员可见 |
| **private** | 私有 | 仅作者和负责人可见 |

---

## 🔐 多租户隔离

### 隔离机制

1. **org_id 外键**: 所有文档必须属于组织
2. **slug 唯一性**: `UNIQUE (org_id, slug)` 确保组织内 URL 唯一
3. **可见性控制**: visibility 字段控制跨组织访问

---

## 📈 索引设计

| 索引名 | 字段 | 类型 | 用途 |
|--------|------|------|------|
| idx_knowledge_docs_org_id | org_id | 单列 | 多租户隔离 |
| idx_knowledge_docs_track_id | track_id | 单列 | 按赛道查询 |
| idx_knowledge_docs_status | status | 单列 | 按状态过滤 |
| idx_knowledge_docs_type | doc_type | 单列 | 按类型过滤 |
| idx_knowledge_docs_visibility | visibility | 单列 | 按可见性过滤 |
| idx_knowledge_docs_author | author_id | 单列 | 按作者查询 |
| idx_knowledge_docs_created_at | created_at | 单列 | 时间排序 |
| idx_knowledge_docs_published_at | published_at | 单列 | 发布时间排序 |
| idx_knowledge_docs_views | view_count DESC | 单列 | 热门文档 |
| idx_knowledge_docs_slug | org_id, slug | 唯一 | URL 唯一性 |
| idx_knowledge_docs_org_status_visibility | org_id, status, visibility | 复合 | 文档列表 |
| idx_knowledge_docs_org_type_status | org_id, doc_type, status | 复合 | 类型列表 |

---

## 🔧 触发器

### update_knowledge_docs_updated_at

**触发时机**: AFTER UPDATE  
**功能**: 自动更新 updated_at 字段

### knowledge_docs_version_control

**触发时机**: AFTER UPDATE (content 变更时)  
**功能**: 版本控制触发器

**逻辑**:
1. 将旧版本标记为 `is_latest = 0`
2. 应用层创建新版本记录

---

## 📊 视图

### v_published_docs (已发布文档)

**功能**: 查询已发布的最新文档

| 字段 | 说明 |
|------|------|
| author_name | 作者姓名 |
| view_count | 浏览次数 |
| like_count | 点赞数 |

**使用示例**:
```sql
SELECT * FROM v_published_docs 
WHERE org_id = 'org_demo_internal' 
LIMIT 10;
```

### v_popular_docs (热门文档)

**功能**: 按热度排序文档

**热度公式**: `popularity_score = view_count + like_count * 10`

**使用示例**:
```sql
SELECT * FROM v_popular_docs 
WHERE org_id = 'org_demo_internal';
```

### v_docs_pending_review (待审核文档)

**功能**: 查询待审核文档

**使用示例**:
```sql
SELECT * FROM v_docs_pending_review 
WHERE org_id = 'org_demo_internal';
```

### v_doc_version_history (版本历史)

**功能**: 查询文档版本历史

| 字段 | 说明 |
|------|------|
| version_status | current/historical |

**使用示例**:
```sql
SELECT * FROM v_doc_version_history 
WHERE parent_doc_id = 'doc_001' OR doc_id = 'doc_001'
ORDER BY version DESC;
```

---

## 🔍 全文搜索

### knowledge_docs_fts (FTS5 虚拟表)

**功能**: 全文搜索支持

**搜索字段**: title, content, summary, tags

**使用示例**:
```sql
-- 搜索包含"数据库"的文档
SELECT * FROM knowledge_docs_fts 
WHERE knowledge_docs_fts MATCH '数据库';

-- 标题搜索
SELECT * FROM knowledge_docs_fts 
WHERE title MATCH '数据库';

-- 高亮显示 (应用层处理)
SELECT highlight(knowledge_docs_fts, 0, '<b>', '</b>') as highlighted_content
FROM knowledge_docs_fts 
WHERE knowledge_docs_fts MATCH '数据库';
```

---

## ✅ 验收标准

| 标准 | 状态 | 说明 |
|------|------|------|
| Schema 设计完成 | ✅ | SQL 脚本已创建 |
| 支持多种文档类型 | ✅ | 5 种类型 (article/wiki/faq/guide/template) |
| 支持版本控制 | ✅ | version + parent_doc_id + is_latest |
| 支持全文搜索 | ✅ | FTS5 虚拟表 + 同步触发器 |
| 支持可见性控制 | ✅ | public/internal/private |
| 支持审核流程 | ✅ | draft/review/published 状态 |
| 统计信息 | ✅ | view_count, like_count, comment_count |
| 阅读时间估算 | ✅ | word_count + read_time_minutes |
| 索引优化 | ✅ | 12 个索引 + 1 个全文索引 |
| 触发器 | ✅ | updated_at + 版本控制 + FTS 同步 |
| 视图 | ✅ | 4 个视图 (已发布/热门/待审核/版本历史) |
| 示例数据 | ✅ | 7 条测试数据 (覆盖所有类型和状态) |

---

## 📝 使用示例

### 1. 创建文档

```sql
INSERT INTO knowledge_docs (doc_id, org_id, track_id, title, slug, summary, content, doc_type, status, author_id, word_count, read_time_minutes, tags)
VALUES (
    'doc_new_001',
    'org_demo_internal',
    'track_001_ai',
    'RAG 系统架构设计',
    'rag-system-architecture',
    'RAG 系统完整架构说明',
    '# RAG 系统架构\n\n## 概述\n\nRAG (Retrieval-Augmented Generation)...\n\n## 架构设计\n\n...',
    'article',
    'draft',
    'user_001_super',
    2500,
    10,
    '["rag", "architecture", "ai"]'
);
```

### 2. 发布文档

```sql
UPDATE knowledge_docs 
SET 
    status = 'published',
    published_at = DATE('now'),
    content_html = '<h1>RAG 系统架构</h1>...',  -- Markdown 渲染后的 HTML
    updated_at = CURRENT_TIMESTAMP
WHERE doc_id = 'doc_new_001';
```

### 3. 查询已发布文档

```sql
SELECT doc_id, title, slug, author_name, view_count, published_at
FROM v_published_docs
WHERE org_id = 'org_demo_internal'
  AND doc_type = 'article'
ORDER BY published_at DESC
LIMIT 10;
```

### 4. 全文搜索

```sql
-- 搜索关键词
SELECT k.doc_id, k.title, k.summary, k.view_count
FROM knowledge_docs_fts fts
JOIN knowledge_docs k ON k.rowid = fts.rowid
WHERE knowledge_docs_fts MATCH '数据库设计'
  AND k.org_id = 'org_demo_internal'
  AND k.status = 'published'
ORDER BY k.view_count DESC;
```

### 5. 创建新版本

```sql
-- 1. 将当前版本标记为非最新
UPDATE knowledge_docs SET is_latest = 0 WHERE doc_id = 'doc_001';

-- 2. 创建新版本
INSERT INTO knowledge_docs (doc_id, parent_doc_id, version, title, content, author_id, is_latest, status)
VALUES (
    'doc_001_v3',
    'doc_001',  -- 父文档 ID
    3,          -- 版本号
    '数据库设计最佳实践',
    '更新内容...',
    'user_001_super',
    1,          -- 最新版本
    'published'
);
```

### 6. 增加浏览计数

```sql
UPDATE knowledge_docs 
SET view_count = view_count + 1, updated_at = CURRENT_TIMESTAMP
WHERE doc_id = 'doc_001';
```

---

## 🔗 依赖关系

### 前置依赖
- ✅ Task 1.1.1: organizations 表
- ✅ Task 1.1.2: users 表
- ✅ Task 1.1.3: tracks 表
- ✅ Task 1.1.4: records 表

### 后续任务
- ⏳ Task 1.1.6: files 表 (文件管理)
- ⏳ Task 1.1.7: doc_comments 表 (文档评论)
- ⏳ Task 1.1.8: doc_likes 表 (文档点赞)

---

## 💡 设计亮点

1. **版本控制**: parent_doc_id + version + is_latest 支持完整版本历史
2. **全文搜索**: FTS5 虚拟表 + 自动同步触发器
3. **Markdown 支持**: content (Markdown) + content_html (渲染后)
4. **审核流程**: draft → review → published 完整工作流
5. **可见性控制**: public/internal/private 三级权限
6. **统计信息**: view_count, like_count, comment_count
7. **阅读时间**: 自动估算 (word_count / 250 字/分钟)
8. **URL 友好**: slug 字段支持 SEO 友好 URL

---

**SQL 脚本位置**: `/root/.openclaw/workspace/agents/database-manager/scripts/008_knowledge_docs_schema.sql`  
**设计文档位置**: `/root/.openclaw/workspace/agents/database-manager/docs/008_knowledge_docs_schema_design.md`

---

**下一步**: 继续 Task 1.1.6 - files 表 (文件管理) 设计
