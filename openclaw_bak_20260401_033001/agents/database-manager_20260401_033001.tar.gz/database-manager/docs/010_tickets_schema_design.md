# tickets 表设计文档

**Task ID**: 1.1.7  
**创建时间**: 2026-03-27 08:55  
**设计者**: database-manager Agent  
**审查状态**: 待 Spec Review + Code Quality Review

---

## 📊 表结构

### tickets (工单主表)

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| ticket_id | TEXT | PRIMARY KEY | 工单唯一标识 (UUID) |
| org_id | TEXT | FOREIGN KEY, NOT NULL | 所属组织 ID |
| track_id | TEXT | FOREIGN KEY | 关联赛道 ID (可选) |
| record_id | TEXT | FOREIGN KEY | 关联记录 ID (可选) |
| file_id | TEXT | FOREIGN KEY | 关联文件 ID (可选) |
| ticket_number | TEXT | NOT NULL | 工单编号 (TKT-2026-0001) |
| title | TEXT | NOT NULL | 标题 |
| description | TEXT | NOT NULL | 描述 |
| ticket_type | TEXT | CHECK, NOT NULL | bug/feature/question/complaint/incident |
| ticket_category | TEXT | - | 技术/产品/运营/财务等 |
| ticket_priority | TEXT | CHECK, DEFAULT 'medium' | low/medium/high/critical |
| status | TEXT | CHECK, DEFAULT 'open' | open/in_progress/pending/resolved/closed |
| resolution | TEXT | - | 解决方案 |
| reporter_id | TEXT | FOREIGN KEY, NOT NULL | 报告人 user_id |
| assignee_id | TEXT | FOREIGN KEY | 处理人 user_id |
| resolver_id | TEXT | FOREIGN KEY | 解决人 user_id |
| sla_hours | INTEGER | - | SLA 时限 (小时) |
| due_at | TIMESTAMP | - | 截止时间 |
| first_response_at | TIMESTAMP | - | 首次响应时间 |
| resolved_at | TIMESTAMP | - | 解决时间 |
| closed_at | TIMESTAMP | - | 关闭时间 |
| satisfaction_rating | INTEGER | CHECK (1-5) | 满意度评分 |
| satisfaction_comment | TEXT | - | 满意度评价 |
| tags | JSON | DEFAULT '[]' | 标签列表 |
| custom_fields | JSON | DEFAULT '{}' | 自定义字段 |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |
| updated_at | TIMESTAMP | DEFAULT | 更新时间 |
| deleted_at | TIMESTAMP | NULL | 软删除标记 |

### ticket_comments (工单评论表)

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| comment_id | TEXT | PRIMARY KEY | 评论唯一标识 |
| ticket_id | TEXT | FOREIGN KEY, NOT NULL | 关联工单 ID |
| content | TEXT | NOT NULL | 评论内容 |
| content_html | TEXT | - | 渲染后的 HTML |
| comment_type | TEXT | CHECK, DEFAULT 'comment' | comment/internal_note/attachment |
| author_id | TEXT | FOREIGN KEY, NOT NULL | 作者 user_id |
| parent_comment_id | TEXT | FOREIGN KEY | 父评论 (回复) |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |
| updated_at | TIMESTAMP | DEFAULT | 更新时间 |
| deleted_at | TIMESTAMP | NULL | 软删除标记 |

### ticket_activities (工单活动日志表)

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| activity_id | TEXT | PRIMARY KEY | 活动唯一标识 |
| ticket_id | TEXT | FOREIGN KEY, NOT NULL | 关联工单 ID |
| activity_type | TEXT | CHECK, NOT NULL | created/assigned/status_changed/priority_changed/commented/resolved/closed/reopened |
| old_value | TEXT | - | 旧值 |
| new_value | TEXT | - | 新值 |
| actor_id | TEXT | FOREIGN KEY, NOT NULL | 操作人 user_id |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |

---

## 🎯 核心设计

### 工单类型 (ticket_type)

| 类型 | 说明 | 典型场景 |
|------|------|----------|
| **bug** | 缺陷 | 系统错误、功能异常 |
| **feature** | 需求 | 新功能请求、改进建议 |
| **question** | 咨询 | 使用问题、技术咨询 |
| **complaint** | 投诉 | 服务投诉、体验问题 |
| **incident** | 事故 | 生产故障、紧急事件 |

### 工单状态流转

```
open → in_progress → pending → resolved → closed
       ↓                    ↓
       └────── reopened ────┘
```

| 状态 | 说明 | 典型场景 |
|------|------|----------|
| **open** | 待处理 | 新工单 |
| **in_progress** | 处理中 | 已分配，处理中 |
| **pending** | 待反馈 | 等待用户反馈 |
| **resolved** | 已解决 | 问题已解决 |
| **closed** | 已关闭 | 用户确认关闭 |

### 优先级定义

| 优先级 | 响应时间 | 解决时间 | 典型场景 |
|--------|----------|----------|----------|
| **critical** | 15 分钟 | 4 小时 | 生产故障、业务中断 |
| **high** | 1 小时 | 24 小时 | 重要功能异常 |
| **medium** | 4 小时 | 48 小时 | 一般问题 |
| **low** | 24 小时 | 7 天 | 优化建议、咨询 |

---

## 🔧 SLA 管理

### 时限计算

```sql
-- 设置 SLA 和截止时间
UPDATE tickets 
SET 
    sla_hours = 24,
    due_at = datetime(created_at, '+24 hours')
WHERE ticket_id = 'ticket_001';
```

### 逾期检测

| due_status | 说明 | 条件 |
|------------|------|------|
| **overdue** | 已逾期 | due_at < now AND status NOT IN (resolved, closed) |
| **due_soon** | 即将到期 | due_at <= now + 4 hours |
| **ok** | 正常 | 其他 |

---

## 📊 视图

### v_my_tickets (我的工单)

**功能**: 查询分配给我的工单，包含逾期状态

**使用示例**:
```sql
SELECT * FROM v_my_tickets 
WHERE assignee_id = 'user_001_super'
  AND status IN ('open', 'in_progress')
ORDER BY 
    CASE due_status 
        WHEN 'overdue' THEN 1 
        WHEN 'due_soon' THEN 2 
        ELSE 3 
    END;
```

### v_overdue_tickets (逾期工单)

**功能**: 识别逾期工单，提前预警

**使用示例**:
```sql
SELECT * FROM v_overdue_tickets 
WHERE org_id = 'org_demo_internal';
```

### v_ticket_stats (工单统计)

**功能**: 按组织、类型、状态统计工单

**字段**:
- count: 工单总数
- critical_count: 紧急工单数
- high_count: 高优先级工单数
- avg_satisfaction: 平均满意度

**使用示例**:
```sql
SELECT * FROM v_ticket_stats 
WHERE org_id = 'org_demo_internal';
```

---

## ✅ 验收标准

| 标准 | 状态 | 说明 |
|------|------|------|
| Schema 设计完成 | ✅ | SQL 脚本已创建 |
| 支持工单类型 | ✅ | 5 种类型 (bug/feature/question/complaint/incident) |
| 支持状态流转 | ✅ | 5 状态完整工作流 |
| 支持优先级 | ✅ | 4 级优先级 |
| SLA 管理 | ✅ | sla_hours + due_at |
| 满意度评价 | ✅ | satisfaction_rating (1-5) + comment |
| 评论系统 | ✅ | ticket_comments 表 |
| 活动日志 | ✅ | ticket_activities 表 |
| 逾期检测 | ✅ | v_overdue_tickets 视图 |
| 统计视图 | ✅ | v_ticket_stats 视图 |
| 索引优化 | ✅ | 15+ 个索引 |
| 触发器 | ✅ | 自动更新 updated_at |
| 示例数据 | ✅ | 6 个工单 + 5 条评论 + 9 条活动记录 |

---

## 📝 使用示例

### 1. 创建工单

```sql
INSERT INTO tickets (ticket_id, org_id, ticket_number, title, description, ticket_type, ticket_priority, reporter_id, assignee_id, sla_hours, due_at, tags)
VALUES (
    'ticket_new_001',
    'org_demo_internal',
    'TKT-2026-0007',
    'RAG 系统检索精度低',
    '用户反馈检索结果不相关，需要优化 embedding 模型',
    'bug',
    'high',
    'user_002_internal',
    'user_001_super',
    24,
    datetime('now', '+24 hours'),
    '["bug", "rag", "search"]'
);
```

### 2. 分配工单

```sql
-- 记录活动日志
INSERT INTO ticket_activities (activity_id, ticket_id, activity_type, old_value, new_value, actor_id)
VALUES ('activity_new_001', 'ticket_new_001', 'assigned', null, 'user_001_super', 'user_002_internal');

-- 更新工单
UPDATE tickets 
SET assignee_id = 'user_001_super', updated_at = CURRENT_TIMESTAMP
WHERE ticket_id = 'ticket_new_001';
```

### 3. 更新状态

```sql
-- 记录活动日志
INSERT INTO ticket_activities (activity_id, ticket_id, activity_type, old_value, new_value, actor_id)
VALUES ('activity_new_002', 'ticket_new_001', 'status_changed', 'open', 'in_progress', 'user_001_super');

-- 更新工单
UPDATE tickets 
SET status = 'in_progress', updated_at = CURRENT_TIMESTAMP
WHERE ticket_id = 'ticket_new_001';
```

### 4. 添加工单评论

```sql
INSERT INTO ticket_comments (comment_id, ticket_id, content, comment_type, author_id)
VALUES (
    'comment_new_001',
    'ticket_new_001',
    '已定位问题，正在优化 embedding 模型...',
    'comment',
    'user_001_super'
);
```

### 5. 解决工单

```sql
-- 记录活动日志
INSERT INTO ticket_activities (activity_id, ticket_id, activity_type, old_value, new_value, actor_id)
VALUES ('activity_new_003', 'ticket_new_001', 'status_changed', 'in_progress', 'resolved', 'user_001_super');

-- 更新工单
UPDATE tickets 
SET 
    status = 'resolved',
    resolution = '已优化 embedding 模型，检索精度提升 30%',
    resolved_at = CURRENT_TIMESTAMP,
    updated_at = CURRENT_TIMESTAMP
WHERE ticket_id = 'ticket_new_001';
```

### 6. 满意度评价

```sql
UPDATE tickets 
SET 
    satisfaction_rating = 5,
    satisfaction_comment = '响应快速，解决问题专业！',
    closed_at = CURRENT_TIMESTAMP,
    status = 'closed',
    updated_at = CURRENT_TIMESTAMP
WHERE ticket_id = 'ticket_new_001';
```

### 7. 查询我的待处理工单

```sql
SELECT ticket_id, ticket_number, title, ticket_priority, due_status
FROM v_my_tickets
WHERE assignee_id = 'user_001_super'
  AND status IN ('open', 'in_progress')
ORDER BY 
    CASE ticket_priority 
        WHEN 'critical' THEN 1 
        WHEN 'high' THEN 2 
        WHEN 'medium' THEN 3 
        ELSE 4 
    END;
```

---

## 🔗 依赖关系

### 前置依赖
- ✅ Task 1.1.1: organizations 表
- ✅ Task 1.1.2: users 表
- ✅ Task 1.1.3: tracks 表
- ✅ Task 1.1.4: records 表
- ✅ Task 1.1.5: knowledge_docs 表
- ✅ Task 1.1.6: files 表

### 后续任务
- ⏳ Task 1.1.8: 完成 Milestone 1 收尾

---

## 💡 设计亮点

1. **完整工单流程**: open → in_progress → pending → resolved → closed
2. **SLA 管理**: sla_hours + due_at 支持时限控制
3. **逾期检测**: v_overdue_tickets 自动识别逾期工单
4. **满意度评价**: 1-5 评分 + 文字评价
5. **评论系统**: ticket_comments 支持评论和内部备注
6. **活动日志**: ticket_activities 完整记录工单变更历史
7. **工单编号**: ticket_number 支持业务友好编号 (TKT-2026-0001)
8. **多类型支持**: 5 种工单类型覆盖所有场景

---

**SQL 脚本位置**: `/root/.openclaw/workspace/agents/database-manager/scripts/010_tickets_schema.sql`  
**设计文档位置**: `/root/.openclaw/workspace/agents/database-manager/docs/010_tickets_schema_design.md`

---

**下一步**: 完成 Milestone 1 收尾工作
