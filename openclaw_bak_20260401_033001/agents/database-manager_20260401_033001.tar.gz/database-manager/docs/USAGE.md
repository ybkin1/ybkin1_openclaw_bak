# Database Manager 使用指南

**版本**: 1.0  
**创建时间**: 2026-03-27  
**状态**: 生产就绪

---

## 🚀 快速开始

### 安装

```bash
# 无需安装，直接使用
cd /root/.openclaw/workspace/agents/database-manager
```

### 初始化

```python
from database_manager import DatabaseManager

# 创建数据库实例
db = DatabaseManager('/path/to/database.db', {
    'audit_enabled': True,
    'org_id': 'org_demo',
    'user_id': 'user_001'
})

# 使用上下文管理器 (自动关闭)
with DatabaseManager('/path/to/database.db') as db:
    # 使用 db...
    pass
```

---

## 📋 CRUD 操作

### 查询

```python
# 查询单条
user = db.fetch_one('users', {'user_id': 'user_001'})
print(user['username'], user['email'])

# 查询多条
users = db.fetch_all('users', 
                     {'org_id': 'org_demo', 'status': 'active'},
                     order_by='created_at DESC',
                     limit=10)

# 计数
count = db.count('users', {'org_id': 'org_demo'})

# 存在性检查
exists = db.exists('users', {'user_id': 'user_001'})

# 查询指定列
users = db.fetch_all('users', {'org_id': 'org_demo'}, 
                     columns=['user_id', 'username', 'email'])
```

### 插入

```python
# 插入单条
user_id = db.insert('users', {
    'user_id': 'user_new',
    'org_id': 'org_demo',
    'username': 'newuser',
    'email': 'new@example.com',
    'password_hash': '...',
    'metadata': {'department': '技术部', 'level': 'P7'}  # 自动序列化为 JSON
})

# 批量插入
users = [
    {'user_id': 'user_001', 'username': 'john', ...},
    {'user_id': 'user_002', 'username': 'jane', ...},
    ...
]
ids = db.batch_insert('users', users, chunk_size=1000)
```

### 更新

```python
# 更新单条
rows = db.update('users', 
                 {'status': 'active', 'age': 26},
                 {'user_id': 'user_001'})

# 按 ID 更新
rows = db.update_by_id('users', 'user_001', {'status': 'inactive'})

# 批量更新
updates = [
    {'user_id': 'user_001', 'status': 'active'},
    {'user_id': 'user_002', 'status': 'inactive'},
]
rows = db.batch_update('users', 'user_id', updates)
```

### 删除

```python
# 软删除 (默认)
rows = db.delete('users', {'user_id': 'user_001'})

# 硬删除
rows = db.delete('users', {'user_id': 'user_001'}, soft=False)

# 批量删除
db.batch_delete('users', 'user_id', ['user_001', 'user_002'])
```

---

## 🔄 事务管理

```python
# 普通事务
with db.transaction():
    db.insert('users', {...})
    db.insert('api_keys', {...})
    # 异常自动回滚

# 嵌套事务 (保存点)
with db.transaction():
    db.insert('users', {...})
    try:
        with db.transaction(savepoint=True):
            db.insert('api_keys', {...})
            # 这里失败只回滚内层
    except:
        pass  # 外层事务不受影响
```

---

## 📊 高级功能

### Upsert 操作

```python
# 插入或更新
rows = db.upsert('users', {
    'user_id': 'user_001',
    'username': 'john',
    'email': 'john@example.com'
}, conflict_columns=['user_id'])
```

### 审计日志

```python
# 启用审计
db.enable_audit(org_id='org_demo', user_id='user_001')

# 自动记录 (装饰器)
@db.audit_logger.audit_create('users')
def create_user(data):
    return db.insert('users', data)

# 查询审计日志
logs = db.audit_logger.get_logs(table='users', record_id='user_001')
```

### 查询优化

```python
# 执行计划分析
plan = db.optimizer.explain_query(
    "SELECT * FROM users WHERE org_id = ? AND status = ?",
    ('org_123', 'active')
)

# 索引使用分析
report = db.optimizer.analyze_index_usage('users', 
    "SELECT * FROM users WHERE org_id = 'org_123'")

# 索引建议
suggestions = db.optimizer.suggest_indexes('users',
    "SELECT * FROM users WHERE org_id = ? AND status = ?")

# 获取表统计
stats = db.optimizer.get_table_stats('users')
```

---

## ⚠️ 错误处理

```python
from database_manager import (
    DatabaseError, UniqueViolationError,
    ForeignKeyViolationError, NotFoundError
)

try:
    db.insert('users', data)
except UniqueViolationError as e:
    print(f"唯一性约束违反：{e.code} - {e.message}")
except ForeignKeyViolationError as e:
    print(f"外键约束违反：{e.code} - {e.message}")
except DatabaseError as e:
    print(f"数据库错误：{e.code} - {e.message}")
```

---

## 🔧 配置选项

```python
config = {
    'audit_enabled': True,      # 启用审计日志
    'org_id': 'org_demo',       # 组织 ID
    'user_id': 'user_001',      # 用户 ID
    'pragma': {
        'foreign_keys': 'ON',
        'journal_mode': 'WAL',
        'synchronous': 'NORMAL',
        'cache_size': -64000,   # 64MB
        'busy_timeout': 5000,   # 5 秒
    }
}

db = DatabaseManager('/path/to/database.db', config)
```

---

## 📁 完整示例

```python
from database_manager import DatabaseManager
from errors import DatabaseError

def main():
    with DatabaseManager('/root/.openclaw/data/app.db', {
        'audit_enabled': True,
        'org_id': 'org_demo'
    }) as db:
        
        # 事务：创建用户和 API 密钥
        try:
            with db.transaction():
                # 创建用户
                user_id = db.insert('users', {
                    'user_id': 'user_new',
                    'org_id': 'org_demo',
                    'username': 'newuser',
                    'email': 'new@example.com',
                    'password_hash': '...'
                })
                
                # 创建 API 密钥
                key_id = db.insert('api_keys', {
                    'key_id': 'key_new',
                    'org_id': 'org_demo',
                    'owner_id': user_id,
                    'key_hash': '...',
                    'key_prefix': 'sk_std_abc'
                })
                
                print(f"创建成功：user={user_id}, key={key_id}")
        
        except DatabaseError as e:
            print(f"创建失败：{e.code} - {e.message}")
        
        # 查询用户
        user = db.fetch_one('users', {'user_id': 'user_new'})
        print(f"用户信息：{user}")
        
        # 统计
        count = db.count('users', {'org_id': 'org_demo'})
        print(f"组织用户数：{count}")

if __name__ == '__main__':
    main()
```

---

## 📊 性能建议

1. **批量操作**: 使用 `batch_insert`/`batch_update` 代替循环
2. **索引优化**: 为常用查询字段创建索引
3. **事务批量**: 多个操作放在一个事务中
4. **连接复用**: 使用上下文管理器或单例
5. **慢查询检测**: 启用 `optimizer.log_query` 监控

---

**维护者**: Database Manager Agent  
**最后更新**: 2026-03-27
