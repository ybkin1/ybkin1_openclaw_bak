# organizations 表设计文档

**Task ID**: 1.1.1  
**创建时间**: 2026-03-26 22:16  
**设计者**: database-manager Agent  
**审查状态**: 待 Spec Review + Code Quality Review

---

## 📊 表结构

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| org_id | TEXT | PRIMARY KEY | 组织唯一标识 |
| name | TEXT | NOT NULL | 组织名称 |
| type | TEXT | CHECK | 组织类型 (customer/internal/partner) |
| industry | TEXT | - | 行业类型 |
| config | JSON | DEFAULT '{}' | 组织特定配置 |
| status | TEXT | CHECK | 状态 (active/suspended/archived) |
| created_by | TEXT | - | 创建人 user_id |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |
| updated_at | TIMESTAMP | DEFAULT | 更新时间 |
| deleted_at | TIMESTAMP | NULL | 软删除标记 |

---

## 🔐 多租户隔离设计

### 隔离机制

1. **org_id 作为所有表的外键**
   - 所有业务表必须包含 org_id 字段
   - 所有查询自动注入 org_id 过滤

2. **软删除支持**
   - deleted_at 字段标记删除
   - 查询时过滤 deleted_at IS NULL

3. **状态管理**
   - active: 正常运营
   - suspended: 暂停服务 (欠费/违规)
   - archived: 已归档 (合同到期)

---

## 📈 索引设计

| 索引名 | 字段 | 类型 | 用途 |
|--------|------|------|------|
| idx_organizations_name | name | 单列 | 名称查询/模糊搜索 |
| idx_organizations_type | type | 单列 | 按类型过滤 |
| idx_organizations_status | status | 单列 | 按状态过滤 (常用) |
| idx_organizations_created_at | created_at | 单列 | 时间排序 |
| idx_organizations_status_type | status, type | 复合 | 常用组合查询 |

---

## 🔧 触发器

### update_organizations_updated_at

**触发时机**: AFTER UPDATE  
**功能**: 自动更新 updated_at 字段

---

## ✅ 验收标准

| 标准 | 状态 | 说明 |
|------|------|------|
| Schema 设计完成 | ✅ | SQL 脚本已创建 |
| 包含必需字段 | ✅ | org_id, name, type, config, status |
| 支持多租户隔离 | ✅ | org_id 为主键，支持外键关联 |
| 索引优化 | ✅ | 5 个索引覆盖常用查询 |
| 触发器 | ✅ | 自动更新 updated_at |
| 示例数据 | ✅ | 4 条测试数据 |

---

**文件位置**: `/root/.openclaw/workspace/agents/database-manager/scripts/001_organizations_schema.sql`  
**设计文档**: `/root/.openclaw/workspace/agents/database-manager/docs/001_organizations_schema_design.md`

