# files 表设计文档

**Task ID**: 1.1.6  
**创建时间**: 2026-03-27 08:45  
**设计者**: database-manager Agent  
**审查状态**: 待 Spec Review + Code Quality Review

---

## 📊 表结构

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| file_id | TEXT | PRIMARY KEY | 文件唯一标识 (UUID) |
| org_id | TEXT | FOREIGN KEY, NOT NULL | 所属组织 ID |
| track_id | TEXT | FOREIGN KEY | 关联赛道 ID (可选) |
| record_id | TEXT | FOREIGN KEY | 关联记录 ID (可选) |
| doc_id | TEXT | FOREIGN KEY | 关联文档 ID (可选) |
| filename | TEXT | NOT NULL | 原始文件名 |
| file_path | TEXT | NOT NULL | 存储路径 (相对路径或 URL) |
| file_hash | TEXT | - | 文件哈希 (SHA256) |
| file_size | INTEGER | NOT NULL | 文件大小 (字节) |
| mime_type | TEXT | - | MIME 类型 |
| file_extension | TEXT | - | 扩展名 |
| file_category | TEXT | - | document/image/video/audio/code/archive/other |
| width | INTEGER | - | 图片宽度 (px) |
| height | INTEGER | - | 图片高度 (px) |
| duration | INTEGER | - | 视频/音频时长 (秒) |
| storage_type | TEXT | CHECK, DEFAULT 'local' | local/s3/oss/cos |
| storage_bucket | TEXT | - | 存储桶名称 |
| storage_region | TEXT | - | 存储区域 |
| version | INTEGER | DEFAULT 1 | 版本号 |
| parent_file_id | TEXT | FOREIGN KEY | 父文件 ID (版本历史) |
| is_latest | BOOLEAN | DEFAULT 1 | 是否最新版本 |
| uploader_id | TEXT | FOREIGN KEY | 上传者 user_id |
| owner_id | TEXT | FOREIGN KEY | 负责人 user_id |
| visibility | TEXT | CHECK, DEFAULT 'private' | private/org/public |
| download_count | INTEGER | DEFAULT 0 | 下载次数 |
| access_password | TEXT | - | 访问密码 (可选) |
| virus_scan_status | TEXT | CHECK, DEFAULT 'pending' | pending/scanning/clean/infected |
| virus_scan_result | TEXT | - | 扫描结果 |
| virus_scanned_at | TIMESTAMP | - | 扫描时间 |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |
| updated_at | TIMESTAMP | DEFAULT | 更新时间 |
| deleted_at | TIMESTAMP | NULL | 软删除标记 |

---

## 🎯 核心设计

### 文件分类 (file_category)

| 分类 | 说明 | 典型文件 |
|------|------|----------|
| **document** | 文档 | PDF, Word, Excel, TXT, CSV |
| **image** | 图片 | JPG, PNG, GIF, SVG, WebP |
| **video** | 视频 | MP4, AVI, MOV, MKV |
| **audio** | 音频 | MP3, WAV, AAC, FLAC |
| **code** | 代码 | SQL, PY, JS, Java, C++ |
| **archive** | 压缩包 | ZIP, RAR, 7Z, TAR |
| **other** | 其他 | 未分类文件 |

### 存储后端 (storage_type)

| 类型 | 说明 | 典型场景 |
|------|------|----------|
| **local** | 本地存储 | 开发环境、小文件 |
| **s3** | AWS S3 | 国际业务、大规模存储 |
| **oss** | 阿里云 OSS | 国内业务、阿里云生态 |
| **cos** | 腾讯云 COS | 国内业务、腾讯云生态 |

### 可见性级别

| 可见性 | 说明 | 访问权限 |
|--------|------|----------|
| **private** | 私有 | 仅上传者和负责人可访问 |
| **org** | 组织内 | 组织内所有成员可访问 |
| **public** | 公开 | 所有人可访问 (无需登录) |

---

## 🔐 安全设计

### 病毒扫描

| 状态 | 说明 | 动作 |
|------|------|------|
| **pending** | 待扫描 | 加入扫描队列 |
| **scanning** | 扫描中 | 禁止访问 |
| **clean** | 安全 | 允许访问 |
| **infected** | 感染 | 隔离文件，通知管理员 |

### 文件哈希

- **算法**: SHA256
- **用途**: 去重检测、完整性验证
- **存储**: file_hash 字段

### 访问控制

1. **visibility 字段**: 粗粒度访问控制
2. **access_password**: 可选密码保护
3. **应用层权限**: 基于 org_id + uploader_id 细粒度控制

---

## 📈 索引设计

| 索引名 | 字段 | 类型 | 用途 |
|--------|------|------|------|
| idx_files_org_id | org_id | 单列 | 多租户隔离 |
| idx_files_track_id | track_id | 单列 | 按赛道查询 |
| idx_files_record_id | record_id | 单列 | 按记录查询 |
| idx_files_doc_id | doc_id | 单列 | 按文档查询 |
| idx_files_uploader | uploader_id | 单列 | 按上传者查询 |
| idx_files_category | file_category | 单列 | 按类型过滤 |
| idx_files_mime_type | mime_type | 单列 | 按 MIME 过滤 |
| idx_files_storage_type | storage_type | 单列 | 按存储类型查询 |
| idx_files_created_at | created_at | 单列 | 时间排序 |
| idx_files_size | file_size DESC | 单列 | 大文件检测 |
| idx_files_virus_status | virus_scan_status | 单列 | 安全检测 |
| idx_files_org_category | org_id, file_category | 复合 | 组织 + 类型 |
| idx_files_org_storage | org_id, storage_type | 复合 | 存储管理 |
| idx_files_org_virus | org_id, virus_scan_status | 复合 | 安全检测 |

---

## 🔧 触发器

### update_files_updated_at

**触发时机**: AFTER UPDATE  
**功能**: 自动更新 updated_at 字段

---

## 📊 视图

### v_my_files (我的文件)

**功能**: 查询我上传的文件

| 字段 | 说明 |
|------|------|
| uploader_name | 上传者姓名 |
| download_count | 下载次数 |

**使用示例**:
```sql
SELECT * FROM v_my_files 
WHERE uploader_id = 'user_001_super'
ORDER BY created_at DESC;
```

### v_public_files (公共文件)

**功能**: 查询公共文件 (安全且已发布)

**过滤条件**:
- visibility = 'public'
- virus_scan_status = 'clean'
- is_latest = 1

**使用示例**:
```sql
SELECT * FROM v_public_files 
WHERE org_id = 'org_demo_internal';
```

### v_files_pending_scan (待扫描文件)

**功能**: 识别待扫描文件，提前预警

| 字段 | 说明 |
|------|------|
| scan_status | overdue/pending |

**使用示例**:
```sql
SELECT * FROM v_files_pending_scan 
WHERE org_id = 'org_demo_internal'
  AND scan_status = 'overdue';
```

### v_storage_stats (存储统计)

**功能**: 按组织和存储类型统计

| 字段 | 说明 |
|------|------|
| file_count | 文件数 |
| total_bytes | 总大小 |
| avg_file_size | 平均大小 |
| largest_file | 最大文件 |
| clean_files | 安全文件数 |
| infected_files | 感染文件数 |

**使用示例**:
```sql
SELECT * FROM v_storage_stats 
WHERE org_id = 'org_demo_internal';
```

### v_large_files (大文件检测)

**功能**: 检测大于 100MB 的文件

**使用示例**:
```sql
SELECT * FROM v_large_files 
WHERE org_id = 'org_demo_internal'
ORDER BY size_mb DESC;
```

---

## ✅ 验收标准

| 标准 | 状态 | 说明 |
|------|------|------|
| Schema 设计完成 | ✅ | SQL 脚本已创建 |
| 支持多存储后端 | ✅ | local/s3/oss/cos |
| 支持版本控制 | ✅ | version + parent_file_id + is_latest |
| 支持病毒扫描 | ✅ | virus_scan_status 字段 |
| 支持访问控制 | ✅ | private/org/public 三级 |
| 支持文件分类 | ✅ | 7 种分类 |
| 支持元数据 | ✅ | width/height/duration |
| 文件哈希 | ✅ | SHA256 去重检测 |
| 统计视图 | ✅ | v_storage_stats |
| 安全视图 | ✅ | v_files_pending_scan |
| 索引优化 | ✅ | 14 个索引覆盖所有查询 |
| 触发器 | ✅ | 自动更新 updated_at |
| 示例数据 | ✅ | 8 条测试数据 (覆盖所有分类) |

---

## 📝 使用示例

### 1. 上传文件

```sql
INSERT INTO files (file_id, org_id, filename, file_path, file_hash, file_size, mime_type, file_category, storage_type, uploader_id, virus_scan_status)
VALUES (
    'file_new_001',
    'org_demo_internal',
    'report.pdf',
    '/storage/org_demo_internal/docs/report.pdf',
    'sha256_xyz789',
    1024000,
    'application/pdf',
    'document',
    'local',
    'user_001_super',
    'pending'  -- 待扫描
);
```

### 2. 更新病毒扫描状态

```sql
UPDATE files 
SET 
    virus_scan_status = 'clean',
    virus_scanned_at = CURRENT_TIMESTAMP,
    updated_at = CURRENT_TIMESTAMP
WHERE file_id = 'file_new_001';
```

### 3. 增加下载次数

```sql
UPDATE files 
SET download_count = download_count + 1
WHERE file_id = 'file_001';
```

### 4. 查询组织内所有文档

```sql
SELECT file_id, filename, file_size, download_count, created_at
FROM files
WHERE org_id = 'org_demo_internal'
  AND file_category = 'document'
  AND virus_scan_status = 'clean'
ORDER BY created_at DESC;
```

### 5. 查询存储统计

```sql
SELECT 
    storage_type,
    COUNT(*) as file_count,
    SUM(file_size) / 1024.0 / 1024.0 as total_mb,
    AVG(file_size) / 1024.0 as avg_kb
FROM files
WHERE org_id = 'org_demo_internal'
GROUP BY storage_type;
```

### 6. 检测大文件

```sql
SELECT 
    filename,
    file_size / 1024.0 / 1024.0 as size_mb,
    uploader_id,
    created_at
FROM v_large_files
WHERE org_id = 'org_demo_internal';
```

---

## 🔗 依赖关系

### 前置依赖
- ✅ Task 1.1.1: organizations 表
- ✅ Task 1.1.2: users 表
- ✅ Task 1.1.3: tracks 表
- ✅ Task 1.1.4: records 表
- ✅ Task 1.1.5: knowledge_docs 表

### 后续任务
- ⏳ Task 1.1.7: file_versions 表 (文件版本详情)
- ⏳ Task 1.1.8: file_access_logs 表 (访问日志)

---

## 💡 设计亮点

1. **多存储后端**: 支持 local/s3/oss/cos，灵活扩展
2. **版本控制**: parent_file_id + version 支持文件版本历史
3. **病毒扫描**: 完整的扫描状态管理，防止恶意文件
4. **文件哈希**: SHA256 去重检测，节省存储空间
5. **元数据支持**: width/height/duration 支持多媒体文件
6. **访问控制**: private/org/public 三级权限
7. **统计视图**: 5 个视图覆盖所有管理场景
8. **大文件检测**: 自动识别 >100MB 文件

---

**SQL 脚本位置**: `/root/.openclaw/workspace/agents/database-manager/scripts/009_files_schema.sql`  
**设计文档位置**: `/root/.openclaw/workspace/agents/database-manager/docs/009_files_schema_design.md`

---

**下一步**: 继续 Task 1.1.7 - file_versions 表 (文件版本详情) 或 Task 1.1.8 - file_access_logs 表 (访问日志)
