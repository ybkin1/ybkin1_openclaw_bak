# Database Manager - 数据库连接初始化规范

**版本**: 1.0  
**创建时间**: 2026-03-27 07:41  
**重要性**: P0 (必须遵循)

---

## 🔴 强制要求

### 1. 启用外键约束 (每次连接必须执行)

**原因**: SQLite 默认不启用外键约束

**代码**:
```python
# Python 示例
import sqlite3

def init_database(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 🔴 必须：启用外键约束
    cursor.execute("PRAGMA foreign_keys = ON")
    
    # 验证是否启用成功
    result = cursor.execute("PRAGMA foreign_keys").fetchone()
    if result[0] != 1:
        raise RuntimeError("Failed to enable foreign keys")
    
    return conn
```

```javascript
// Node.js 示例
const sqlite3 = require('sqlite3').verbose();

function initDatabase(dbPath) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database(dbPath);
        
        // 🔴 必须：启用外键约束
        db.run("PRAGMA foreign_keys = ON", function(err) {
            if (err) return reject(err);
            
            // 验证是否启用成功
            db.get("PRAGMA foreign_keys", (err, row) => {
                if (err) return reject(err);
                if (row.foreign_keys !== 1) {
                    return reject(new Error("Failed to enable foreign keys"));
                }
                resolve(db);
            });
        });
    });
}
```

---

## 📋 连接初始化完整流程

### 步骤 1: 连接数据库

```python
conn = sqlite3.connect(db_path)
```

### 步骤 2: 启用外键约束

```python
cursor.execute("PRAGMA foreign_keys = ON")
```

### 步骤 3: 验证外键已启用

```python
result = cursor.execute("PRAGMA foreign_keys").fetchone()
assert result[0] == 1, "Foreign keys not enabled"
```

### 步骤 4: 设置事务模式 (推荐)

```python
cursor.execute("PRAGMA journal_mode = WAL")  # Write-Ahead Logging
cursor.execute("PRAGMA synchronous = NORMAL")  # 性能与安全的平衡
```

### 步骤 5: 注册清理函数

```python
import atexit

def cleanup():
    if conn:
        conn.close()

atexit.register(cleanup)
```

---

## 🚨 常见错误

### 错误 1: 忘记启用外键

```python
# ❌ 错误示例
conn = sqlite3.connect(db_path)
cursor = conn.cursor()
# 直接开始操作...

# 结果：外键约束不生效，ON DELETE CASCADE 无效
```

```python
# ✅ 正确示例
conn = sqlite3.connect(db_path)
cursor = conn.cursor()
cursor.execute("PRAGMA foreign_keys = ON")  # 🔴 必须
# 开始操作...
```

---

### 错误 2: 只在初始化时启用一次

```python
# ❌ 错误示例
def init_once():
    conn = sqlite3.connect(db_path)
    cursor.execute("PRAGMA foreign_keys = ON")
    return conn

# 后续连接没有启用外键！
```

```python
# ✅ 正确示例
def get_connection():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("PRAGMA foreign_keys = ON")  # 每次连接都执行
    return conn
```

---

## 📊 数据库配置建议

### 性能优化配置

```sql
-- Write-Ahead Logging (推荐)
PRAGMA journal_mode = WAL;

-- 同步模式 (NORMAL 平衡性能与安全)
PRAGMA synchronous = NORMAL;

-- 缓存大小 (根据内存调整)
PRAGMA cache_size = -64000;  -- 64MB

-- 临时存储 (内存中)
PRAGMA temp_store = MEMORY;

-- 忙时超时 (毫秒)
PRAGMA busy_timeout = 5000;
```

### 安全配置

```sql
-- 启用外键约束
PRAGMA foreign_keys = ON;

-- 验证外键
PRAGMA foreign_keys;  -- 应返回 1

-- 完整性检查 (定期执行)
PRAGMA integrity_check;
```

---

## 🔍 验证清单

每次数据库连接初始化后，执行以下验证：

```python
def verify_database(conn):
    cursor = conn.cursor()
    
    # 1. 验证外键已启用
    result = cursor.execute("PRAGMA foreign_keys").fetchone()
    assert result[0] == 1, "Foreign keys not enabled"
    
    # 2. 验证 WAL 模式
    result = cursor.execute("PRAGMA journal_mode").fetchone()
    print(f"Journal mode: {result[0]}")  # 应为 wal
    
    # 3. 验证同步模式
    result = cursor.execute("PRAGMA synchronous").fetchone()
    print(f"Synchronous: {result[0]}")  # 应为 1 (NORMAL)
    
    # 4. 完整性检查
    result = cursor.execute("PRAGMA integrity_check").fetchone()
    assert result[0] == "ok", "Database integrity check failed"
    
    print("✅ Database verification passed")
```

---

## 📁 相关文档

- **活跃数据视图**: `004_active_views.sql`
- **审计日志表**: `005_audit_logs.sql`
- **数据保护触发器**: `006_data_protection.sql`
- **设计风险分析**: `database-design-risk-analysis.md`

---

## 🎯 最佳实践总结

1. **每次连接都启用外键** - 不要假设之前的设置会保留
2. **使用 WAL 模式** - 提升并发性能
3. **验证配置** - 初始化后执行验证
4. **使用活跃视图** - 查询 `xxx_active` 视图而非原表
5. **软删除优先** - 避免硬删除，使用 `deleted_at` 标记
6. **审计关键操作** - 所有 CREATE/UPDATE/DELETE 写入 audit_logs

---

**维护者**: Database Manager Agent  
**最后更新**: 2026-03-27 07:41
