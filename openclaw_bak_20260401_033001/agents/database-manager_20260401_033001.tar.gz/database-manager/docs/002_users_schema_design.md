# users 表设计文档

**Task ID**: 1.1.2  
**创建时间**: 2026-03-27 07:22  
**设计者**: database-manager Agent  
**审查状态**: 待 Spec Review + Code Quality Review

---

## 📊 表结构

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| user_id | TEXT | PRIMARY KEY | 用户唯一标识 (UUID) |
| org_id | TEXT | FOREIGN KEY, NOT NULL | 所属组织 ID (关联 organizations) |
| username | TEXT | UNIQUE, NOT NULL | 用户名 (登录用) |
| email | TEXT | UNIQUE, NOT NULL | 邮箱 (登录/通知) |
| phone | TEXT | - | 手机号 (可选) |
| avatar_url | TEXT | - | 头像 URL |
| display_name | TEXT | - | 显示名称 |
| password_hash | TEXT | NOT NULL | 密码哈希 (bcrypt/argon2) |
| salt | TEXT | - | 密码盐值 |
| last_login | TIMESTAMP | NULL | 最后登录时间 |
| login_attempts | INTEGER | DEFAULT 0 | 登录失败次数 |
| locked_until | TIMESTAMP | NULL | 锁定截止时间 |
| role | TEXT | CHECK, DEFAULT 'user' | 角色：super_admin/org_admin/team_lead/user/guest |
| permissions | JSON | DEFAULT '{}' | 细粒度权限配置 |
| status | TEXT | CHECK, DEFAULT 'pending' | 状态：active/inactive/locked/pending |
| created_by | TEXT | - | 创建人 user_id |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |
| updated_at | TIMESTAMP | DEFAULT | 更新时间 |
| deleted_at | TIMESTAMP | NULL | 软删除标记 |

---

## 🔐 多租户隔离设计

### 组织关联机制

1. **org_id 外键约束**
   - 每个用户必须属于一个组织
   - ON DELETE CASCADE: 组织删除时自动删除用户
   - 所有用户查询自动注入 org_id 过滤

2. **角色权限层级**
   ```
   super_admin  → 管理所有组织
   org_admin    → 管理本组织
   team_lead    → 管理本组织内团队
   user         → 普通成员
   guest        → 访客 (只读权限)
   ```

3. **跨组织访问**
   - 默认：用户只能访问本组织数据
   - 特例：super_admin 可跨组织访问
   - 实现：应用层权限检查 + 数据库视图

---

## 🔒 安全设计

### 密码安全

| 机制 | 说明 |
|------|------|
| **哈希算法** | bcrypt (推荐) 或 argon2 |
| **盐值** | 每用户独立盐值，存储于 salt 字段 |
| **强度要求** | 最小成本因子 12 (bcrypt) |
| **传输加密** | 必须使用 HTTPS |

### 防暴力破解

| 机制 | 阈值 | 动作 |
|------|------|------|
| **失败计数** | login_attempts >= 5 | 触发锁定 |
| **锁定时长** | 30 分钟 (可配置) | locked_until = NOW + 30min |
| **自动解锁** | locked_until < NOW | 自动重置 login_attempts = 0 |
| **IP 限制** | 应用层实现 | 同 IP 失败次数限制 |

### 会话管理 (应用层配合)

- JWT Token 存储 user_id, org_id, role
- Token 有效期：2 小时 (可刷新)
- 登出时加入黑名单 (Redis)

---

## 📈 索引设计

| 索引名 | 字段 | 类型 | 用途 |
|--------|------|------|------|
| idx_users_username | username | 唯一 | 登录查询 |
| idx_users_email | email | 唯一 | 登录/通知 |
| idx_users_org_id | org_id | 单列 | 多租户隔离 (最常用) |
| idx_users_status | status | 单列 | 过滤活跃用户 |
| idx_users_role | role | 单列 | 权限管理 |
| idx_users_created_at | created_at | 单列 | 时间排序 |
| idx_users_org_status | org_id, status | 复合 | 查某组织活跃用户 |
| idx_users_org_role | org_id, role | 复合 | 查某组织管理员 |

### 索引使用场景

```sql
-- 场景 1: 用户登录
SELECT * FROM users WHERE username = 'zhangsan' AND status = 'active';
-- 使用：idx_users_username

-- 场景 2: 查某组织所有活跃用户
SELECT * FROM users WHERE org_id = 'org_123' AND status = 'active';
-- 使用：idx_users_org_status

-- 场景 3: 查某组织的管理员
SELECT * FROM users WHERE org_id = 'org_123' AND role = 'org_admin';
-- 使用：idx_users_org_role

-- 场景 4: 统计各角色用户数
SELECT role, COUNT(*) FROM users WHERE org_id = 'org_123' GROUP BY role;
-- 使用：idx_users_org_role
```

---

## 🔧 触发器

### update_users_updated_at

**触发时机**: AFTER UPDATE  
**功能**: 自动更新 updated_at 字段

```sql
CREATE TRIGGER update_users_updated_at
AFTER UPDATE ON users
BEGIN
    UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE user_id = NEW.user_id;
END;
```

### v_locked_users 视图

**功能**: 查询被锁定或需要解锁的用户

| 字段 | 说明 |
|------|------|
| lock_status = 'currently_locked' | 当前处于锁定状态 |
| lock_status = 'needs_unlock' | 失败次数>=5，待锁定 |
| lock_status = 'ok' | 正常 |

---

## 🎭 角色权限详解

### 角色定义

| 角色 | 权限范围 | 典型场景 |
|------|----------|----------|
| **super_admin** | 全系统 | 平台运营人员 |
| **org_admin** | 本组织所有数据 + 用户管理 | 客户公司管理员 |
| **team_lead** | 本组织内本团队 | 部门主管 |
| **user** | 个人数据 + 团队共享数据 | 普通员工 |
| **guest** | 只读权限 | 外部顾问/访客 |

### permissions JSON 结构示例

```json
{
  "modules": {
    "documents": ["read", "write", "delete"],
    "tasks": ["read", "write"],
    "reports": ["read"],
    "admin": []
  },
  "data_scope": "org",  // org/team/self
  "api_rate_limit": 1000
}
```

---

## ✅ 验收标准

| 标准 | 状态 | 说明 |
|------|------|------|
| Schema 设计完成 | ✅ | SQL 脚本已创建 |
| 包含必需字段 | ✅ | user_id, org_id, username, email, role, status 等 |
| 支持多组织关联 | ✅ | org_id 外键 + 级联删除 |
| 认证字段完整 | ✅ | password_hash, last_login, login_attempts |
| 权限字段完整 | ✅ | role + permissions (JSON) |
| 索引优化 | ✅ | 8 个索引覆盖所有常用查询 |
| 触发器 | ✅ | 自动更新 updated_at |
| 安全视图 | ✅ | v_locked_users |
| 示例数据 | ✅ | 8 条测试数据 (覆盖所有角色) |

---

## 🔗 依赖关系

### 前置依赖
- ✅ Task 1.1.1: organizations 表 (必须先行创建)

### 后续任务
- ⏳ Task 1.1.3: tracks 表 (赛道/项目表)
- ⏳ Task 1.1.4: user_org_mapping 表 (多组织支持，可选)

---

## 📝 使用示例

### 1. 用户登录

```sql
-- 验证用户名和密码
SELECT user_id, org_id, username, role, status, password_hash
FROM users
WHERE username = 'zhangsan' AND status = 'active';

-- 检查是否被锁定
SELECT * FROM v_locked_users WHERE user_id = 'user_004_customer_a';
```

### 2. 查询组织内所有活跃用户

```sql
SELECT user_id, username, email, role, display_name
FROM users
WHERE org_id = 'org_demo_customer_1' AND status = 'active'
ORDER BY created_at DESC;
```

### 3. 查询组织管理员

```sql
SELECT user_id, username, email, display_name
FROM users
WHERE org_id = 'org_demo_customer_1' 
  AND role IN ('super_admin', 'org_admin')
  AND status = 'active';
```

### 4. 用户权限检查

```sql
-- 获取用户权限
SELECT role, permissions FROM users WHERE user_id = 'user_004_customer_a';

-- 检查是否有文档写入权限 (应用层解析 JSON)
-- permissions->'modules'->'documents' 包含 'write'
```

---

**SQL 脚本位置**: `/root/.openclaw/workspace/agents/database-manager/scripts/002_users_schema.sql`  
**设计文档位置**: `/root/.openclaw/workspace/agents/database-manager/docs/002_users_schema_design.md`

---

**下一步**: 继续 Task 1.1.3 - tracks 表 (赛道/项目表) 设计
