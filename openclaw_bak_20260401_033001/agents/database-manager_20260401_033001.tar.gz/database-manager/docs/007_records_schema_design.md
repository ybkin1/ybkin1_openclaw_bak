# records 表设计文档

**Task ID**: 1.1.4  
**创建时间**: 2026-03-27 07:51  
**设计者**: database-manager Agent  
**审查状态**: 待 Spec Review + Code Quality Review

---

## 📊 表结构

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| record_id | TEXT | PRIMARY KEY | 记录唯一标识 (UUID) |
| org_id | TEXT | FOREIGN KEY, NOT NULL | 所属组织 ID |
| track_id | TEXT | FOREIGN KEY, NOT NULL | 所属赛道 ID |
| record_type | TEXT | NOT NULL | 记录类型 (task/note/document/issue/meeting) |
| title | TEXT | NOT NULL | 标题 |
| description | TEXT | - | 描述 |
| content | JSON | - | 动态内容 (根据 type 变化) |
| status | TEXT | CHECK, DEFAULT 'draft' | 状态：draft/active/completed/archived |
| priority | TEXT | CHECK, DEFAULT 'medium' | 优先级：low/medium/high/critical |
| parent_record_id | TEXT | FOREIGN KEY | 父记录 ID (层级结构) |
| related_records | JSON | DEFAULT '[]' | 关联记录 ID 列表 |
| owner_id | TEXT | FOREIGN KEY | 负责人 user_id |
| created_by | TEXT | FOREIGN KEY | 创建人 user_id |
| assigned_to | TEXT | FOREIGN KEY | 分配给 user_id |
| due_date | DATE | - | 截止日期 |
| started_at | DATE | - | 开始日期 |
| completed_at | DATE | - | 完成日期 |
| tags | JSON | DEFAULT '[]' | 标签列表 |
| custom_fields | JSON | DEFAULT '{}' | 自定义字段 |
| created_at | TIMESTAMP | DEFAULT | 创建时间 |
| updated_at | TIMESTAMP | DEFAULT | 更新时间 |
| deleted_at | TIMESTAMP | NULL | 软删除标记 |

---

## 🎯 核心设计

### 记录类型 (record_type)

| 类型 | 说明 | content 结构示例 |
|------|------|-----------------|
| **task** | 任务 | `{"estimated_hours": 4, "completion_percentage": 50}` |
| **note** | 笔记 | `{"content": "...", "format": "markdown"}` |
| **document** | 文档 | `{"content": "...", "format": "markdown", "version": "1.0"}` |
| **issue** | 问题 | `{"severity": "high", "root_cause": "...", "solution": "..."}` |
| **meeting** | 会议 | `{"attendees": [...], "duration_minutes": 60, "notes": "..."}` |
| **milestone** | 里程碑 | `{"deliverables": [...], "success_criteria": "..."}` |
| **risk** | 风险 | `{"probability": "medium", "impact": "high", "mitigation": "..."}` |

### 状态流转

```
draft → active → completed
              ↓
         archived
```

| 状态 | 说明 | 典型场景 |
|------|------|----------|
| **draft** | 草稿 | 创建未完成 |
| **active** | 进行中 | 正常执行 |
| **completed** | 已完成 | 目标达成 |
| **archived** | 已归档 | 历史数据 |

---

## 🔐 多租户隔离

### 隔离机制

1. **org_id 外键**: 所有记录必须属于组织
2. **track_id 外键**: 所有记录必须属于赛道
3. **查询过滤**: 使用活跃视图自动过滤 `deleted_at IS NULL`

### 层级结构

```
Organization
    └── Track (赛道)
        └── Record (记录)
            └── Record (子记录，通过 parent_record_id)
```

---

## 📈 索引设计

| 索引名 | 字段 | 类型 | 用途 |
|--------|------|------|------|
| idx_records_org_id | org_id | 单列 | 多租户隔离 |
| idx_records_track_id | track_id | 单列 | 按赛道查询 |
| idx_records_type | record_type | 单列 | 按类型过滤 |
| idx_records_status | status | 单列 | 按状态过滤 |
| idx_records_priority | priority | 单列 | 按优先级过滤 |
| idx_records_owner | owner_id | 单列 | 按负责人查询 |
| idx_records_created_by | created_by | 单列 | 按创建人查询 |
| idx_records_created_at | created_at | 单列 | 时间排序 |
| idx_records_due_date | due_date | 单列 | 逾期查询 |
| idx_records_org_track | org_id, track_id | 复合 | 组织 + 赛道 |
| idx_records_org_type_status | org_id, record_type, status | 复合 | 类型 + 状态 |
| idx_records_owner_status | owner_id, status | 复合 | 我的待办 |
| idx_records_due_status | due_date, status | 复合 | 逾期查询 |

---

## 🔧 触发器

### update_records_updated_at

**触发时机**: AFTER UPDATE  
**功能**: 自动更新 updated_at 字段

---

## 📊 视图

### v_my_records (我的记录)

**功能**: 查询分配给当前用户的记录，包含逾期状态

| 字段 | 说明 |
|------|------|
| due_status | overdue/due_today/due_soon/ok |
| track_name | 赛道名称 |
| owner_name | 负责人姓名 |

**使用示例**:
```sql
SELECT * FROM v_my_records 
WHERE owner_id = 'user_001_super' 
  AND due_status IN ('overdue', 'due_today');
```

### v_overdue_records (逾期记录)

**功能**: 识别逾期记录，提前预警

| 字段 | 说明 |
|------|------|
| days_overdue | 逾期天数 |

**使用示例**:
```sql
SELECT * FROM v_overdue_records 
WHERE org_id = 'org_demo_internal'
ORDER BY days_overdue DESC;
```

### v_records_by_track (记录统计)

**功能**: 按赛道统计记录概况

| 字段 | 说明 |
|------|------|
| total_count | 总记录数 |
| active_count | 进行中数量 |
| completed_count | 已完成数量 |
| critical_count | 紧急优先级数量 |
| high_count | 高优先级数量 |

**使用示例**:
```sql
SELECT * FROM v_records_by_track 
WHERE org_id = 'org_demo_internal' 
  AND record_type = 'task';
```

---

## ✅ 验收标准

| 标准 | 状态 | 说明 |
|------|------|------|
| Schema 设计完成 | ✅ | SQL 脚本已创建 |
| 支持多类型记录 | ✅ | record_type + content JSON |
| 支持层级结构 | ✅ | parent_record_id 自关联 |
| 支持关联记录 | ✅ | related_records JSON |
| 支持动态字段 | ✅ | custom_fields JSON |
| 支持标签系统 | ✅ | tags JSON |
| 索引优化 | ✅ | 13 个索引覆盖所有查询 |
| 触发器 | ✅ | 自动更新 updated_at |
| 统计视图 | ✅ | v_records_by_track |
| 逾期视图 | ✅ | v_overdue_records |
| 示例数据 | ✅ | 7 条测试数据 (覆盖所有类型) |

---

## 📝 使用示例

### 1. 创建任务

```sql
INSERT INTO records (record_id, org_id, track_id, record_type, title, status, priority, owner_id, due_date, content, tags)
VALUES (
    'rec_new_task',
    'org_demo_internal',
    'track_001_ai',
    'task',
    '完成 RAG 系统设计',
    'active',
    'high',
    'user_001_super',
    '2026-04-05',
    '{"estimated_hours": 16, "completion_percentage": 0}',
    '["design", "rag", "urgent"]'
);
```

### 2. 查询我的待办

```sql
SELECT record_id, title, priority, due_date, due_status
FROM v_my_records
WHERE owner_id = 'user_001_super'
  AND status = 'active'
ORDER BY 
    CASE due_status 
        WHEN 'overdue' THEN 1 
        WHEN 'due_today' THEN 2 
        WHEN 'due_soon' THEN 3 
        ELSE 4 
    END;
```

### 3. 更新任务进度

```sql
UPDATE records 
SET 
    status = 'completed',
    completed_at = DATE('now'),
    content = json_patch(content, '{"completion_percentage": 100, "actual_hours": 14}'),
    updated_at = CURRENT_TIMESTAMP
WHERE record_id = 'rec_001_task';
```

### 4. 创建子任务

```sql
INSERT INTO records (record_id, org_id, track_id, record_type, title, parent_record_id, status, priority, owner_id)
VALUES (
    'rec_subtask_1',
    'org_demo_internal',
    'track_001_ai',
    'task',
    '数据库设计',
    'rec_new_task',  -- 父任务 ID
    'active',
    'high',
    'user_001_super'
);
```

### 5. 关联记录

```sql
UPDATE records 
SET related_records = json_array('rec_001_task', 'rec_003_note')
WHERE record_id = 'rec_005_issue';
```

### 6. 查询赛道记录统计

```sql
SELECT record_type, COUNT(*) as total, 
       SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active
FROM records
WHERE org_id = 'org_demo_internal' AND track_id = 'track_001_ai'
GROUP BY record_type;
```

---

## 🔗 依赖关系

### 前置依赖
- ✅ Task 1.1.1: organizations 表
- ✅ Task 1.1.2: users 表
- ✅ Task 1.1.3: tracks 表

### 后续任务
- ⏳ Task 1.1.5: knowledge_docs 表 (知识库文档)
- ⏳ Task 1.1.6: files 表 (文件管理)
- ⏳ Task 1.1.7: record_versions 表 (版本控制)

---

## 💡 设计亮点

1. **动态类型支持**: record_type + content JSON 支持无限扩展
2. **层级结构**: parent_record_id 自关联支持任务分解
3. **关联记录**: related_records JSON 支持多对多关联
4. **自定义字段**: custom_fields JSON 支持业务扩展
5. **标签系统**: tags JSON 支持灵活分类
6. **逾期预警**: v_overdue_records 自动识别逾期
7. **状态跟踪**: due_status 字段提前 7 天预警

---

**SQL 脚本位置**: `/root/.openclaw/workspace/agents/database-manager/scripts/007_records_schema.sql`  
**设计文档位置**: `/root/.openclaw/workspace/agents/database-manager/docs/007_records_schema_design.md`

---

**下一步**: 继续 Task 1.1.5 - knowledge_docs 表 (知识库文档) 设计
