# Database Manager Agent - 永久生效规范

**版本**: 1.0  
**生效日期**: 2026-03-26  
**优先级**: 高于 AGENT.md，与 openclaw.json 同级

---

## 🔒 核心原则 (不可违背)

### 原则 1: 赛道无关性 (Track-Agnostic)

**规则**: 不得在代码或配置中硬编码任何具体赛道的业务逻辑

```python
# ❌ 错误：硬编码赛道特定实体
def create_server(hostname, model):
    db.insert('servers', {'hostname': hostname, 'model': model})

# ✅ 正确：通用接口
def create_record(table_name, data, org_id, track_id):
    db.insert(table_name, data, org_id=org_id, track_id=track_id)
```

**违规检测**:
- 代码中出现 `servers`, `fault_cases`, `customers`, `employees` 等具体业务表名 → 警告
- 应使用动态 `table_name` 参数 → 正确

---

### 原则 2: 多租户隔离 (Tenant Isolation)

**规则**: 所有数据操作必须自动注入 `org_id` 过滤，禁止跨租户访问

```python
# ❌ 错误：缺少 org_id 过滤
def query_users(user_id):
    return db.query('users', {'user_id': user_id})

# ✅ 正确：自动注入 org_id
def query_users(user_id, org_id):
    return db.query('users', {'user_id': user_id, 'org_id': org_id})

# ✅ 推荐：从上下文自动获取
def query_users(user_id):
    org_id = get_current_org_id()  # 从用户会话获取
    return db.query('users', {'user_id': user_id, 'org_id': org_id})
```

**违规检测**:
- 查询条件中缺少 `org_id` → 严重错误
- 跨租户查询无权限检查 → 严重错误

---

### 原则 3: 权限分级控制 (Permission Hierarchy)

**规则**: 所有操作必须检查 `permission_level`，禁止越权访问

```python
# 权限检查矩阵
PERMISSION_MATRIX = {
    'create': {'min_level': 1},
    'read_own': {'min_level': 0},
    'read_others': {'min_level': 2},
    'update_own': {'min_level': 1},
    'update_others': {'min_level': 3},
    'delete_own': {'min_level': 1},
    'delete_others': {'min_level': 4},
    'manage_permissions': {'min_level': 4}
}

# ✅ 正确：权限检查
def update_record(record_id, updates, user_id, permission_level):
    record = db.get(record_id)
    
    # 检查是否有权更新他人数据
    if record['owner_id'] != user_id:
        if permission_level < 3:
            raise PermissionError("无权更新他人数据")
    
    return db.update(record_id, updates)
```

**违规检测**:
- 操作前未检查 `permission_level` → 严重错误
- 权限等级判断错误 → 严重错误

---

### 原则 4: 数据可追溯 (Data Traceability)

**规则**: 所有数据变更必须记录审计日志

```python
# ✅ 正确：审计日志
def update_record(record_id, updates, user_id):
    # 1. 记录变更前状态
    old_data = db.get(record_id)
    
    # 2. 执行更新
    result = db.update(record_id, updates)
    
    # 3. 记录审计日志
    audit_log(
        action='update',
        target_table=record['table_name'],
        target_id=record_id,
        actor_id=user_id,
        changes={
            'old': old_data,
            'new': updates
        }
    )
    
    return result
```

**审计日志字段**:
```json
{
  "log_id": "log_123",
  "org_id": "org_456",
  "track_id": "track_789",
  "actor_id": "user_001",
  "action": "create|read|update|delete",
  "target_table": "records",
  "target_id": "rec_123",
  "changes": {...},
  "timestamp": "2026-03-26T11:00:00Z"
}
```

---

### 原则 5: 知识库质量保障 (Knowledge Quality)

**规则**: 所有入库知识必须经过质量评分，低于阈值需标记待审查

```python
# 质量评分阈值
QUALITY_THRESHOLDS = {
    'auto_publish': 0.80,      # ≥0.8 自动发布
    'manual_review': 0.60,     # 0.6-0.8 人工审查
    'reject': 0.60             # <0.6 拒绝
}

# ✅ 正确：质量检查
def upload_knowledge(content, metadata):
    # 1. 计算质量评分
    quality = calculate_quality_score(content)
    
    # 2. 根据评分决定处理方式
    if quality['overall'] >= 0.80:
        status = 'published'
    elif quality['overall'] >= 0.60:
        status = 'pending_review'
    else:
        raise QualityError(f"质量评分过低：{quality['overall']}")
    
    # 3. 存储
    doc_id = db.insert('knowledge_docs', {
        'content': content,
        'quality_score': quality['overall'],
        'quality_details': quality,
        'status': status
    })
    
    return doc_id
```

**质量评分维度**:
- `completeness`: 完整性 (0-1)
- `accuracy`: 准确性 (0-1)
- `timeliness`: 时效性 (0-1)
- `readability`: 可读性 (0-1)
- `relevance`: 关联性 (0-1)

---

### 原则 6: RAG 检索透明度 (RAG Transparency)

**规则**: 所有 RAG 检索结果必须标注来源，禁止隐藏引用

```python
# ✅ 正确：引用标注
def build_rag_context(results):
    context = ""
    for i, result in enumerate(results, 1):
        context += f"""
【参考资料 {i}】
来源：{result['metadata']['title']}
文档 ID: {result['doc_id']}
相关性：{result['relevance_score']:.2f}
内容：{result['content']}
---
"""
    return context

# ❌ 错误：隐藏来源
def build_rag_context(results):
    return "\n".join([r['content'] for r in results])
```

**引用格式要求**:
```markdown
【参考资料 N】
来源：{文档标题}
文档 ID: {doc_id}
租户：{org_id}
赛道：{track_id}
版本：{version}
相关性：{score}
内容：{content}
```

---

## 📋 操作规范 (必须遵循)

### 规范 1: 数据库连接管理

```python
# ✅ 正确：连接池管理
class DatabaseManager:
    def __init__(self):
        self.pool = sqlite3.Pool(
            max_connections=20,
            min_connections=5,
            timeout=30
        )
    
    def get_connection(self):
        return self.pool.get()
    
    def close(self):
        self.pool.close_all()

# ❌ 错误：每次操作都新建连接
def query_data():
    conn = sqlite3.connect('db.sqlite')  # 性能差
    ...
    conn.close()
```

**连接池配置**:
- `max_connections`: 20
- `min_connections`: 5
- `timeout`: 30 秒
- `idle_timeout`: 300 秒

---

### 规范 2: 事务处理

```python
# ✅ 正确：事务包裹
def batch_create(records):
    try:
        db.begin_transaction()
        
        for record in records:
            db.insert('records', record)
        
        db.commit()
        return True
    
    except Exception as e:
        db.rollback()
        audit_log(
            action='batch_create_failed',
            error=str(e),
            records_count=len(records)
        )
        raise

# ❌ 错误：无事务保护
def batch_create(records):
    for record in records:
        db.insert('records', record)  # 部分失败会导致数据不一致
```

**事务使用场景**:
- 批量操作 (≥2 条记录)
- 跨表操作
- 关联数据更新

---

### 规范 3: 索引优化

```python
# ✅ 正确：为常用查询字段创建索引
CREATE INDEX idx_records_org_track ON records(org_id, track_id);
CREATE INDEX idx_records_owner ON records(owner_id);
CREATE INDEX idx_knowledge_access ON knowledge_docs(access_level, org_id);

# ❌ 错误：无索引导致全表扫描
# 查询 100 万条记录无索引 → 10 秒+
# 有索引 → 50ms
```

**必须创建的索引**:
| 表名 | 字段 | 索引类型 |
|------|------|---------|
| records | org_id, track_id | 复合索引 |
| records | owner_id | 单列索引 |
| knowledge_docs | org_id, track_id, access_level | 复合索引 |
| files | org_id, track_id | 复合索引 |
| audit_logs | org_id, actor_id, timestamp | 复合索引 |

---

### 规范 4: 错误处理

```python
# ✅ 正确：分层错误处理
class DatabaseError(Exception): pass
class PermissionError(DatabaseError): pass
class ValidationError(DatabaseError): pass
class QualityError(DatabaseError): pass

def create_record(table, data, user_id):
    try:
        # 1. 验证数据
        if not validate_data(data):
            raise ValidationError("数据验证失败")
        
        # 2. 检查权限
        if not check_permission(user_id, table, 'create'):
            raise PermissionError("无创建权限")
        
        # 3. 执行创建
        return db.insert(table, data)
    
    except PermissionError as e:
        audit_log(action='permission_denied', user_id=user_id, error=str(e))
        raise
    
    except ValidationError as e:
        return {'error': 'validation_failed', 'message': str(e)}
    
    except Exception as e:
        audit_log(action='unexpected_error', error=str(e))
        raise DatabaseError(f"数据库操作失败：{str(e)}")
```

**错误分类**:
- `PermissionError`: 权限错误 (403)
- `ValidationError`: 验证错误 (400)
- `QualityError`: 质量错误 (400)
- `DatabaseError`: 数据库错误 (500)
- `RAGError`: RAG 检索错误 (500)

---

### 规范 5: 性能监控

```python
# ✅ 正确：性能指标记录
class PerformanceMonitor:
    def __init__(self):
        self.metrics = {
            'crud_latency': [],      # CRUD 延迟
            'rag_latency': [],       # RAG 检索延迟
            'permission_check': [],  # 权限检查延迟
            'query_count': 0,        # 查询次数
            'error_count': 0         # 错误次数
        }
    
    def record(self, operation, latency_ms, success=True):
        self.metrics[f'{operation}_latency'].append(latency_ms)
        self.metrics['query_count'] += 1
        if not success:
            self.metrics['error_count'] += 1
    
    def get_report(self):
        return {
            'avg_crud_latency': np.mean(self.metrics['crud_latency']),
            'p95_crud_latency': np.percentile(self.metrics['crud_latency'], 95),
            'avg_rag_latency': np.mean(self.metrics['rag_latency']),
            'error_rate': self.metrics['error_count'] / self.metrics['query_count']
        }
```

**监控指标阈值**:
| 指标 | 警告阈值 | 严重阈值 |
|------|---------|---------|
| CRUD 延迟 (P95) | >100ms | >500ms |
| RAG 检索延迟 (P95) | >500ms | >2000ms |
| 权限检查延迟 | >10ms | >50ms |
| 错误率 | >1% | >5% |

---

### 规范 6: 数据备份

```python
# ✅ 正确：定期备份
def backup_database():
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = f'/root/.openclaw/backups/database/db_backup_{timestamp}.sqlite'
    
    # 1. 复制数据库文件
    shutil.copy('/root/.openclaw/data/database.sqlite', backup_path)
    
    # 2. 验证备份完整性
    if not verify_backup(backup_path):
        raise BackupError("备份验证失败")
    
    # 3. 清理旧备份 (保留 7 天)
    cleanup_old_backups(keep_days=7)
    
    # 4. 记录备份日志
    audit_log(
        action='database_backup',
        backup_path=backup_path,
        backup_size=os.path.getsize(backup_path)
    )
    
    return backup_path
```

**备份策略**:
- 频率：每日 03:30 (与系统备份同步)
- 保留：7 天
- 验证：每次备份后自动验证
- 告警：备份失败立即告警

---

## 🔐 安全规范 (红线)

### 红线 1: 禁止 SQL 注入

```python
# ❌ 严重错误：SQL 注入风险
def query_user(user_id):
    sql = f"SELECT * FROM users WHERE user_id = '{user_id}'"
    return db.execute(sql)

# ✅ 正确：参数化查询
def query_user(user_id):
    sql = "SELECT * FROM users WHERE user_id = ?"
    return db.execute(sql, (user_id,))
```

**检测规则**:
- 代码中出现 f-string 拼接 SQL → 严重错误
- 必须使用参数化查询 → 强制要求

---

### 红线 2: 禁止明文存储敏感数据

```python
# ❌ 严重错误：明文存储密码
db.insert('users', {'password': 'plain_password'})

# ✅ 正确：加密存储
from passlib.hash import bcrypt
hashed = bcrypt.hash('plain_password')
db.insert('users', {'password_hash': hashed})
```

**敏感数据列表**:
- 密码 → bcrypt 加密
- API Key → AES-256 加密
- 访问凭证 → AES-256 加密
- 个人隐私数据 → AES-256 加密

---

### 红线 3: 禁止日志泄露敏感信息

```python
# ❌ 严重错误：日志记录敏感数据
log.info(f"用户登录：user_id={user_id}, password={password}")

# ✅ 正确：脱敏处理
log.info(f"用户登录：user_id={user_id}, password=***")
```

**脱敏规则**:
- 密码 → `***`
- API Key → 仅显示前 4 位 `sk-o...`
- 身份证号 → 仅显示后 4 位 `...1234`
- 手机号 → 中间 4 位掩码 `138****5678`

---

### 红线 4: 禁止未授权的数据导出

```python
# ❌ 严重错误：无权限检查导出
def export_all_data():
    return db.query('SELECT * FROM all_tables')

# ✅ 正确：权限检查 + 审计
def export_data(table, user_id, permission_level):
    if permission_level < 4:
        raise PermissionError("无权导出数据")
    
    data = db.query(table)
    
    # 记录审计日志
    audit_log(
        action='data_export',
        user_id=user_id,
        table=table,
        record_count=len(data)
    )
    
    return data
```

---

## 📊 协作规范

### 与其他 Agent 的协作

| 调用方 | 使用场景 | 必须检查项 |
|--------|---------|-----------|
| **任意 Agent** | `db_create` | ✅ org_id, ✅ track_id, ✅ permission_level |
| **任意 Agent** | `rag_search` | ✅ org_id 过滤，✅ access_level 检查 |
| **任意 Agent** | `kb_upload` | ✅ quality_score, ✅ permission_level |
| **任意 Agent** | `file_register` | ✅ file_id 存在性，✅ permission_level |

### 调用 File Processor 的规范

```python
# ✅ 正确：调用 File Processor
def upload_document(file_bytes, filename, user_id):
    # 1. 调用 File Processor 上传文件
    file_result = file_processor.upload(
        file=file_bytes,
        filename=filename,
        org_id=get_org_id(user_id),
        track_id=get_track_id(),
        owner_id=user_id
    )
    
    # 2. 注册文件元数据
    db.insert('files', {
        'file_id': file_result['file_id'],
        'filename': filename,
        'file_type': 'document',
        'owner_id': user_id
    })
    
    return file_result['file_id']
```

---

## 📝 版本与变更管理

### 规范 1: Schema 变更流程

```
1. 创建迁移脚本 (migration_001_add_users_table.sql)
2. 在测试环境验证
3. 备份生产数据库
4. 执行迁移
5. 验证数据完整性
6. 记录变更日志
```

**迁移脚本模板**:
```sql
-- migration_001_add_users_table.sql
-- 创建日期：2026-03-26
-- 描述：添加用户表

BEGIN TRANSACTION;

CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    org_id TEXT,
    name TEXT NOT NULL,
    permission_level INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_org ON users(org_id);

COMMIT;
```

---

### 规范 2: 配置变更记录

```markdown
## 变更日志

### 2026-03-26
- 创建 AGENT_RULES.md
- 定义 6 大核心原则
- 定义 6 项操作规范
- 定义 4 条安全红线

### 待定
- [ ] 性能优化记录
- [ ] 安全审计记录
```

---

## ✅ 合规检查清单

### 每次发布前必须检查

```markdown
□ 所有查询都包含 org_id 过滤
□ 所有操作都检查 permission_level
□ 所有变更都记录审计日志
□ 所有 SQL 都使用参数化查询
□ 所有敏感数据都加密存储
□ 所有日志都脱敏处理
□ 所有知识都有 quality_score
□ 所有 RAG 结果都标注来源
□ 数据库连接使用连接池
□ 批量操作使用事务包裹
□ 常用查询字段有索引
□ 错误处理分层清晰
□ 性能指标有监控
□ 备份策略已配置
```

---

## 🔧 违规处理

| 违规等级 | 处理方式 | 示例 |
|---------|---------|------|
| **严重** | 立即修复 + 审查 | SQL 注入、明文密码、越权访问 |
| **警告** | 限期修复 | 缺少审计日志、无索引优化 |
| **建议** | 逐步优化 | 代码风格、注释完善 |

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 永久生效  
**下次审查**: 2026-06-26 (每季度审查一次)
