#!/usr/bin/env python3
"""
Ticket Manager - 测试套件

测试工单系统的所有功能
"""

import sys
import os
import sqlite3
import hashlib

# 添加 src 到路径
src_path = os.path.join(os.path.dirname(__file__), '..', 'src')
sys.path.insert(0, src_path)

from connection import DatabaseConnection
from ticket_manager import TicketManager


def setup_test_db():
    """准备测试数据库"""
    db_path = '/tmp/test_tickets_full.db'
    
    # 创建数据库
    conn = sqlite3.connect(db_path)
    
    # 创建基础表
    conn.execute('''CREATE TABLE IF NOT EXISTS organizations (
        org_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT DEFAULT 'customer',
        status TEXT DEFAULT 'active'
    )''')
    
    conn.execute('''CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        username TEXT NOT NULL,
        email TEXT,
        role TEXT DEFAULT 'user',
        password_hash TEXT,
        status TEXT DEFAULT 'active'
    )''')
    
    conn.execute('''CREATE TABLE IF NOT EXISTS tickets (
        ticket_id TEXT PRIMARY KEY,
        org_id TEXT NOT NULL,
        ticket_number TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        ticket_type TEXT NOT NULL,
        ticket_category TEXT,
        ticket_priority TEXT DEFAULT 'medium',
        status TEXT DEFAULT 'open',
        resolution TEXT,
        reporter_id TEXT NOT NULL,
        assignee_id TEXT,
        resolver_id TEXT,
        sla_hours INTEGER,
        due_at TIMESTAMP,
        first_response_at TIMESTAMP,
        resolved_at TIMESTAMP,
        closed_at TIMESTAMP,
        satisfaction_rating INTEGER,
        satisfaction_comment TEXT,
        tags JSON DEFAULT '[]',
        custom_fields JSON DEFAULT '{}',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        deleted_at TIMESTAMP NULL
    )''')
    
    conn.execute('''CREATE TABLE IF NOT EXISTS ticket_comments (
        comment_id TEXT PRIMARY KEY,
        ticket_id TEXT NOT NULL,
        author_id TEXT NOT NULL,
        content TEXT NOT NULL,
        comment_type TEXT DEFAULT 'comment',
        is_internal INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    conn.execute('''CREATE TABLE IF NOT EXISTS ticket_logs (
        log_id TEXT PRIMARY KEY,
        ticket_id TEXT NOT NULL,
        action TEXT NOT NULL,
        user_id TEXT NOT NULL,
        details JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # 插入测试数据
    password_hash = hashlib.sha256('password'.encode()).hexdigest()
    conn.execute("INSERT INTO organizations (org_id, name, type, status) VALUES ('org_demo', '测试组织', 'internal', 'active')")
    conn.execute("INSERT INTO users (user_id, org_id, username, email, role, password_hash, status) VALUES ('user_001', 'org_demo', '张三', 'test@test.com', 'user', ?, 'active')", (password_hash,))
    conn.execute("INSERT INTO users (user_id, org_id, username, email, role, password_hash, status) VALUES ('user_002', 'org_demo', '李四', 'test2@test.com', 'user', ?, 'active')", (password_hash,))
    conn.execute("INSERT INTO users (user_id, org_id, username, email, role, password_hash, status) VALUES ('user_003', 'org_demo', '王五', 'test3@test.com', 'user', ?, 'active')", (password_hash,))
    
    conn.commit()
    conn.close()
    
    return db_path


def test_create_ticket():
    """测试工单创建"""
    print("=" * 60)
    print("测试工单创建")
    print("=" * 60)
    
    db = DatabaseConnection('/tmp/test_tickets_full.db')
    db.connect()
    manager = TicketManager(db)
    
    # 创建工单
    ticket_id = manager.create_ticket(
        org_id='org_demo',
        reporter_id='user_001',
        title='系统登录失败',
        description='用户无法登录系统，提示密码错误',
        ticket_type='bug',
        ticket_priority='high',
        sla_hours=24,
        tags=['登录', '紧急']
    )
    
    print(f"   ✅ 工单创建成功：{ticket_id}")
    
    # 验证工单
    ticket = manager.get_ticket(ticket_id)
    assert ticket['title'] == '系统登录失败'
    assert ticket['status'] == 'open'
    assert ticket['ticket_priority'] == 'high'
    print(f"   ✅ 工单验证通过：{ticket['ticket_number']}")
    
    return ticket_id


def test_assign_ticket(ticket_id):
    """测试工单分配"""
    print("\n" + "=" * 60)
    print("测试工单分配")
    print("=" * 60)
    
    db = DatabaseConnection('/tmp/test_tickets_full.db')
    db.connect()
    manager = TicketManager(db)
    
    # 手动分配
    success = manager.assign_ticket(ticket_id, 'user_002', 'user_001')
    assert success == True
    print(f"   ✅ 手动分配成功")
    
    # 验证状态变更
    ticket = manager.get_ticket(ticket_id)
    assert ticket['assignee_id'] == 'user_002'
    assert ticket['status'] == 'in_progress'
    print(f"   ✅ 状态更新验证通过")
    
    # 自动分配（负载均衡）
    ticket_id2 = manager.create_ticket(
        org_id='org_demo',
        reporter_id='user_001',
        title='测试工单 2',
        description='测试',
        ticket_type='question'
    )
    
    assignee = manager.auto_assign_ticket(ticket_id2, ['user_002', 'user_003'])
    print(f"   ✅ 自动分配成功：{assignee}")
    
    return True


def test_workflow(ticket_id):
    """测试工单流转"""
    print("\n" + "=" * 60)
    print("测试工单流转")
    print("=" * 60)
    
    db = DatabaseConnection('/tmp/test_tickets_full.db')
    db.connect()
    manager = TicketManager(db)
    
    # 添加评论
    comment_id = manager.add_comment(ticket_id, 'user_002', '正在排查问题', is_internal=False)
    print(f"   ✅ 添加评论：{comment_id}")
    
    # 更新状态为 resolved
    success = manager.update_status(ticket_id, 'resolved', 'user_002', '已修复密码策略配置')
    assert success == True
    print(f"   ✅ 状态更新为 resolved")
    
    # 验证解决时间
    ticket = manager.get_ticket(ticket_id)
    assert ticket['status'] == 'resolved'
    assert ticket['resolver_id'] == 'user_002'
    print(f"   ✅ 解决人记录正确")
    
    # 添加用户评论
    comment_id2 = manager.add_comment(ticket_id, 'user_001', '感谢解决！', is_internal=False)
    print(f"   ✅ 用户评论：{comment_id2}")
    
    return True


def test_query_tickets():
    """测试工单查询"""
    print("\n" + "=" * 60)
    print("测试工单查询")
    print("=" * 60)
    
    db = DatabaseConnection('/tmp/test_tickets_full.db')
    db.connect()
    manager = TicketManager(db)
    
    # 查询所有工单
    tickets = manager.list_tickets('org_demo')
    print(f"   ✅ 查询到 {len(tickets)} 个工单")
    
    # 按状态查询
    open_tickets = manager.list_tickets('org_demo', status='open')
    print(f"   ✅ Open 状态：{len(open_tickets)} 个")
    
    # 按处理人查询
    user_tickets = manager.list_tickets('org_demo', assignee_id='user_002')
    print(f"   ✅ user_002 的工单：{len(user_tickets)} 个")
    
    # 按类型查询
    bug_tickets = manager.list_tickets('org_demo', ticket_type='bug')
    print(f"   ✅ Bug 类型：{len(bug_tickets)} 个")
    
    return True


def test_stats():
    """测试工单统计"""
    print("\n" + "=" * 60)
    print("测试工单统计")
    print("=" * 60)
    
    db = DatabaseConnection('/tmp/test_tickets_full.db')
    db.connect()
    manager = TicketManager(db)
    
    stats = manager.get_stats('org_demo', days=30)
    
    print(f"   ✅ 总工单数：{stats.get('total_tickets', 0)}")
    print(f"   ✅ SLA 达标率：{stats.get('sla_compliance', 0):.1f}%")
    print(f"   ✅ 按状态：{stats.get('by_status', {})}")
    print(f"   ✅ 按类型：{stats.get('by_type', {})}")
    
    return True


def main():
    """主测试流程"""
    print("\n🧪 Ticket Manager 完整测试套件")
    print("=" * 60)
    
    # 准备测试数据库
    print("\n准备测试环境...")
    setup_test_db()
    print("✅ 测试环境就绪\n")
    
    passed = 0
    failed = 0
    
    try:
        # 测试 1: 工单创建
        ticket_id = test_create_ticket()
        passed += 1
        
        # 测试 2: 工单分配
        test_assign_ticket(ticket_id)
        passed += 1
        
        # 测试 3: 工单流转
        test_workflow(ticket_id)
        passed += 1
        
        # 测试 4: 工单查询
        test_query_tickets()
        passed += 1
        
        # 测试 5: 工单统计
        test_stats()
        passed += 1
        
    except Exception as e:
        print(f"\n❌ 测试失败：{e}")
        failed += 1
        import traceback
        traceback.print_exc()
    
    # 总结
    print("\n" + "=" * 60)
    print(f"测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60)
    
    if failed == 0:
        print("\n🎉 所有测试通过!")
        return 0
    else:
        print(f"\n⚠️ {failed} 个测试失败")
        return 1


if __name__ == "__main__":
    sys.exit(main())
