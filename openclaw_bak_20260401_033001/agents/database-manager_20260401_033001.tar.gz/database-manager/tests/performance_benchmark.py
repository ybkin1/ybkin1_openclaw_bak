#!/usr/bin/env python3
"""
Database Manager - 性能基准测试脚本

测试数据库操作性能，建立性能基线
"""

import time
import sqlite3
import statistics
from typing import Dict, Any


class PerformanceBenchmark:
    """性能基准测试"""
    
    def __init__(self, db_path: str = '/tmp/benchmark.db'):
        self.db_path = db_path
        self.results: Dict[str, Any] = {}
    
    def setup(self):
        """准备测试环境"""
        conn = sqlite3.connect(self.db_path)
        
        # 创建测试表
        conn.execute('''
            CREATE TABLE IF NOT EXISTS benchmark_data (
                id TEXT PRIMARY KEY,
                name TEXT,
                value REAL,
                category TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def cleanup(self):
        """清理测试环境"""
        import os
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
    
    def benchmark_insert(self, count: int = 1000) -> Dict[str, float]:
        """测试插入性能"""
        conn = sqlite3.connect(self.db_path)
        
        # 批量插入
        start = time.time()
        
        conn.execute("BEGIN TRANSACTION")
        for i in range(count):
            conn.execute(
                "INSERT INTO benchmark_data (id, name, value, category) VALUES (?, ?, ?, ?)",
                (f'item_{i}', f'名称_{i}', i * 1.5, f'cat_{i % 10}')
            )
        conn.execute("COMMIT")
        
        elapsed = time.time() - start
        
        conn.close()
        
        return {
            'operation': 'insert',
            'count': count,
            'total_time_sec': elapsed,
            'ops_per_sec': count / elapsed,
            'ms_per_op': (elapsed * 1000) / count
        }
    
    def benchmark_query(self, iterations: int = 100) -> Dict[str, float]:
        """测试查询性能"""
        conn = sqlite3.connect(self.db_path)
        
        times = []
        
        for i in range(iterations):
            start = time.time()
            
            cursor = conn.execute(
                "SELECT * FROM benchmark_data WHERE category = ?",
                (f'cat_{i % 10}',)
            )
            cursor.fetchall()
            
            elapsed = time.time() - start
            times.append(elapsed)
        
        conn.close()
        
        return {
            'operation': 'query',
            'iterations': iterations,
            'avg_time_ms': statistics.mean(times) * 1000,
            'min_time_ms': min(times) * 1000,
            'max_time_ms': max(times) * 1000,
            'stddev_ms': statistics.stdev(times) * 1000 if len(times) > 1 else 0
        }
    
    def benchmark_update(self, count: int = 100) -> Dict[str, float]:
        """测试更新性能"""
        conn = sqlite3.connect(self.db_path)
        
        start = time.time()
        
        conn.execute("BEGIN TRANSACTION")
        for i in range(count):
            conn.execute(
                "UPDATE benchmark_data SET value = ? WHERE id = ?",
                (i * 2.0, f'item_{i}')
            )
        conn.execute("COMMIT")
        
        elapsed = time.time() - start
        
        conn.close()
        
        return {
            'operation': 'update',
            'count': count,
            'total_time_sec': elapsed,
            'ops_per_sec': count / elapsed,
            'ms_per_op': (elapsed * 1000) / count
        }
    
    def benchmark_delete(self, count: int = 100) -> Dict[str, float]:
        """测试删除性能"""
        conn = sqlite3.connect(self.db_path)
        
        start = time.time()
        
        conn.execute("BEGIN TRANSACTION")
        for i in range(count):
            conn.execute(
                "DELETE FROM benchmark_data WHERE id = ?",
                (f'item_{i}',)
            )
        conn.execute("COMMIT")
        
        elapsed = time.time() - start
        
        conn.close()
        
        return {
            'operation': 'delete',
            'count': count,
            'total_time_sec': elapsed,
            'ops_per_sec': count / elapsed,
            'ms_per_op': (elapsed * 1000) / count
        }
    
    def run_all(self) -> Dict[str, Any]:
        """运行全部基准测试"""
        print("开始性能基准测试...")
        print("=" * 60)
        
        # 准备
        self.setup()
        
        # 测试
        results = {}
        
        print("\n1. 插入测试 (1000 条)...")
        results['insert'] = self.benchmark_insert(1000)
        print(f"   ✅ {results['insert']['ops_per_sec']:.0f} ops/sec")
        
        print("\n2. 查询测试 (100 次)...")
        results['query'] = self.benchmark_query(100)
        print(f"   ✅ 平均 {results['query']['avg_time_ms']:.2f} ms")
        
        print("\n3. 更新测试 (100 条)...")
        results['update'] = self.benchmark_update(100)
        print(f"   ✅ {results['update']['ops_per_sec']:.0f} ops/sec")
        
        print("\n4. 删除测试 (100 条)...")
        results['delete'] = self.benchmark_delete(100)
        print(f"   ✅ {results['delete']['ops_per_sec']:.0f} ops/sec")
        
        # 清理
        self.cleanup()
        
        # 总结
        print("\n" + "=" * 60)
        print("性能基准测试完成!")
        print("\n性能基线:")
        print(f"  插入：{results['insert']['ops_per_sec']:.0f} ops/sec")
        print(f"  查询：{results['query']['avg_time_ms']:.2f} ms (平均)")
        print(f"  更新：{results['update']['ops_per_sec']:.0f} ops/sec")
        print(f"  删除：{results['delete']['ops_per_sec']:.0f} ops/sec")
        
        return results


# 运行基准测试
if __name__ == "__main__":
    benchmark = PerformanceBenchmark()
    results = benchmark.run_all()
