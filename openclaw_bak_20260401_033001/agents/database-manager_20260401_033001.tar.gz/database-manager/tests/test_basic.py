#!/usr/bin/env python3
"""
Database Manager - 快速测试脚本

测试核心功能是否正常工作
"""

import sys
import os

# 添加 src 到路径
src_path = os.path.join(os.path.dirname(__file__), '..', 'src')
sys.path.insert(0, src_path)

# 直接导入模块
from connection import DatabaseConnection
from crud import CRUDOperations
from errors import DatabaseError, UniqueViolationError, ForeignKeyViolationError

# 简单封装
class DatabaseManager(CRUDOperations):
    def __init__(self, db_path):
        self.connection = DatabaseConnection(db_path)
        self.connection.connect()
        super().__init__(self.connection)
    
    def close(self):
        self.connection.close()
    
    def execute(self, sql, params=None):
        with self.connection.cursor() as cursor:
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            self.connection.conn.commit()
            return cursor.rowcount
    
    def transaction(self):
        return self.connection.conn

def create_database(db_path):
    return DatabaseManager(db_path)


def test_basic_crud():
    """测试基本 CRUD 操作"""
    print("=" * 60)
    print("测试基本 CRUD 操作")
    print("=" * 60)
    
    db = create_database('/tmp/test_db.db')
    
    try:
        # 清理测试数据
        db.execute("DROP TABLE IF EXISTS test_users")
        db.execute("""
            CREATE TABLE test_users (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                age INTEGER,
                status TEXT DEFAULT 'active',
                metadata TEXT DEFAULT '{}'
            )
        """)
        
        # 测试插入
        print("\n1. 测试插入...")
        user_id = db.insert('test_users', {
            'id': 'user_001',
            'name': '张三',
            'email': 'zhangsan@example.com',
            'age': 25,
            'metadata': {'department': '技术部', 'level': 'P7'}
        })
        print(f"   ✅ 插入成功：{user_id}")
        
        # 测试查询单条
        print("\n2. 测试查询单条...")
        user = db.fetch_one('test_users', {'id': 'user_001'})
        print(f"   ✅ 查询成功：{user['name']}, {user['email']}")
        
        # 测试查询多条
        print("\n3. 测试查询多条...")
        db.insert('test_users', {'id': 'user_002', 'name': '李四', 'email': 'lisi@example.com', 'age': 30})
        db.insert('test_users', {'id': 'user_003', 'name': '王五', 'email': 'wangwu@example.com', 'age': 28})
        
        users = db.fetch_all('test_users', {'age': 25})
        print(f"   ✅ 查询到 {len(users)} 条记录")
        
        # 测试计数
        print("\n4. 测试计数...")
        count = db.count('test_users')
        print(f"   ✅ 总记录数：{count}")
        
        # 测试更新
        print("\n5. 测试更新...")
        rows = db.update('test_users', {'age': 26, 'status': 'inactive'}, {'id': 'user_001'})
        print(f"   ✅ 更新 {rows} 条记录")
        
        # 验证更新
        user = db.fetch_one('test_users', {'id': 'user_001'})
        print(f"   ✅ 验证：age={user['age']}, status={user['status']}")
        
        # 测试删除 (硬删除，因为测试表没有 deleted_at 字段)
        print("\n6. 测试删除...")
        rows = db.delete('test_users', {'id': 'user_003'}, soft=False)
        print(f"   ✅ 删除 {rows} 条记录")
        
        # 验证删除
        count = db.count('test_users')
        print(f"   ✅ 删除后记录数：{count}")
        
        # 测试唯一性约束
        print("\n7. 测试唯一性约束...")
        try:
            db.insert('test_users', {'id': 'user_004', 'name': '重复', 'email': 'zhangsan@example.com'})
            print(f"   ❌ 应该抛出 UniqueViolationError")
        except UniqueViolationError as e:
            print(f"   ✅ 正确捕获唯一性约束错误：{e.code}")
        
        # 测试存在性检查
        print("\n8. 测试存在性检查...")
        exists = db.exists('test_users', {'id': 'user_001'})
        print(f"   ✅ user_001 存在：{exists}")
        
        exists = db.exists('test_users', {'id': 'user_not_exists'})
        print(f"   ✅ user_not_exists 存在：{exists}")
        
        print("\n" + "=" * 60)
        print("✅ 所有测试通过!")
        print("=" * 60)
        
    except DatabaseError as e:
        print(f"\n❌ 测试失败：{e.code} - {e.message}")
        raise
    finally:
        db.close()
        # 清理测试文件
        if os.path.exists('/tmp/test_db.db'):
            os.remove('/tmp/test_db.db')


def test_transaction():
    """测试事务"""
    print("\n" + "=" * 60)
    print("测试事务")
    print("=" * 60)
    
    db = create_database('/tmp/test_db.db')
    
    try:
        # 创建表
        db.execute("DROP TABLE IF EXISTS test_accounts")
        db.execute("""
            CREATE TABLE test_accounts (
                id TEXT PRIMARY KEY,
                balance REAL DEFAULT 0
            )
        """)
        
        # 初始化账户
        db.insert('test_accounts', {'id': 'acc_001', 'balance': 1000})
        db.insert('test_accounts', {'id': 'acc_002', 'balance': 1000})
        
        print("\n1. 测试成功事务...")
        with db.transaction():
            db.execute("UPDATE test_accounts SET balance = balance - 100 WHERE id = 'acc_001'")
            db.execute("UPDATE test_accounts SET balance = balance + 100 WHERE id = 'acc_002'")
        
        acc1 = db.fetch_one('test_accounts', {'id': 'acc_001'})
        acc2 = db.fetch_one('test_accounts', {'id': 'acc_002'})
        print(f"   ✅ acc_001: {acc1['balance']}, acc_002: {acc2['balance']}")
        
        print("\n2. 测试回滚事务...")
        try:
            with db.transaction():
                db.execute("UPDATE test_accounts SET balance = balance - 100 WHERE id = 'acc_001'")
                db.execute("UPDATE test_accounts SET balance = balance + 100 WHERE id = 'acc_002'")
                # 模拟错误
                raise Exception("模拟错误")
        except Exception as e:
            print(f"   ✅ 捕获错误：{e}")
        
        # 验证回滚
        acc1 = db.fetch_one('test_accounts', {'id': 'acc_001'})
        acc2 = db.fetch_one('test_accounts', {'id': 'acc_002'})
        print(f"   ✅ 回滚后 acc_001: {acc1['balance']}, acc_002: {acc2['balance']}")
        
        print("\n" + "=" * 60)
        print("✅ 事务测试通过!")
        print("=" * 60)
        
    except DatabaseError as e:
        print(f"\n❌ 测试失败：{e.code} - {e.message}")
        raise
    finally:
        db.close()
        if os.path.exists('/tmp/test_db.db'):
            os.remove('/tmp/test_db.db')


if __name__ == '__main__':
    print("\nDatabase Manager 测试套件\n")
    
    test_basic_crud()
    test_transaction()
    
    print("\n🎉 所有测试完成!\n")
