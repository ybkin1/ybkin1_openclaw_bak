#!/usr/bin/env python3
"""
Database Manager - 完整测试套件

测试所有模块功能
"""

import sys
import os
src_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src')
sys.path.insert(0, src_path)

from connection import DatabaseConnection
from crud import CRUDOperations
from batch import BatchOperations
from transaction import TransactionManager
from errors import DatabaseError, UniqueViolationError

# 简单封装
class TestDatabaseManager(CRUDOperations, BatchOperations):
    def __init__(self, db_path):
        self.connection = DatabaseConnection(db_path)
        self.connection.connect()
        CRUDOperations.__init__(self, self.connection)
        BatchOperations.__init__(self, self.connection)
        self.transaction_manager = TransactionManager(self.connection)
    
    def close(self):
        self.connection.close()
    
    def execute(self, sql, params=None):
        with self.connection.cursor() as cursor:
            cursor.execute(sql, params) if params else cursor.execute(sql)
            self.connection.conn.commit()
            return cursor.rowcount
    
    def transaction(self):
        return self.transaction_manager.transaction()
    
    def fetch_value(self, sql, params=None):
        with self.connection.cursor() as cursor:
            cursor.execute(sql, params) if params else cursor.execute(sql)
            row = cursor.fetchone()
            return row[0] if row else None


def test_all():
    """完整测试套件"""
    print("\n" + "=" * 70)
    print("Database Manager 完整测试套件")
    print("=" * 70)
    
    db = TestDatabaseManager('/tmp/test_full.db')
    
    try:
        # 1. 基础表创建
        print("\n[1/8] 创建测试表...")
        db.execute("DROP TABLE IF EXISTS test_products")
        db.execute("""
            CREATE TABLE test_products (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                price REAL,
                stock INTEGER DEFAULT 0,
                metadata TEXT DEFAULT '{}',
                status TEXT DEFAULT 'active'
            )
        """)
        print("   ✅ 表创建成功")
        
        # 2. 单条操作测试
        print("\n[2/8] 测试单条操作...")
        db.insert('test_products', {
            'id': 'prod_001',
            'name': '产品 A',
            'price': 99.99,
            'stock': 100,
            'metadata': {'category': '电子产品', 'brand': '品牌 A'}
        })
        product = db.fetch_one('test_products', {'id': 'prod_001'})
        assert product['name'] == '产品 A'
        assert product['price'] == 99.99
        print("   ✅ 插入和查询成功")
        
        # 3. 批量操作测试
        print("\n[3/8] 测试批量操作...")
        products = [
            {'id': f'prod_{i:03d}', 'name': f'产品{i}', 'price': i * 10, 'stock': 50}
            for i in range(2, 102)
        ]
        ids = db.batch_insert('test_products', products, chunk_size=50)
        assert len(ids) == 100
        count = db.count('test_products')
        assert count == 101
        print(f"   ✅ 批量插入 100 条记录，总计{count}条")
        
        # 4. 更新操作测试
        print("\n[4/8] 测试更新操作...")
        rows = db.update('test_products', {'price': 89.99}, {'id': 'prod_001'})
        product = db.fetch_one('test_products', {'id': 'prod_001'})
        assert product['price'] == 89.99
        print("   ✅ 更新成功")
        
        # 5. 批量更新测试
        print("\n[5/8] 测试批量更新...")
        updates = [
            {'id': f'prod_{i:03d}', 'stock': 200}
            for i in range(1, 11)
        ]
        rows = db.batch_update('test_products', 'id', updates)
        print(f"   ✅ 批量更新{rows}条记录")
        
        # 6. 事务测试
        print("\n[6/8] 测试事务...")
        with db.transaction():
            db.execute("INSERT INTO test_products (id, name, price) VALUES ('prod_tx1', '事务产品 1', 50)")
            db.execute("INSERT INTO test_products (id, name, price) VALUES ('prod_tx2', '事务产品 2', 60)")
        count_after = db.count('test_products')
        assert count_after == 103
        print("   ✅ 事务提交成功")
        
        # 7. 查询优化测试
        print("\n[7/8] 测试查询优化...")
        from query_optimizer import QueryOptimizer
        optimizer = QueryOptimizer(db.connection)
        plan = optimizer.explain_query(
            "SELECT * FROM test_products WHERE id = ?",
            ('prod_001',)
        )
        assert len(plan) > 0
        print(f"   ✅ 执行计划分析成功 ({len(plan)}步)")
        
        # 8. 错误处理测试
        print("\n[8/8] 测试错误处理...")
        try:
            db.insert('test_products', {'id': 'prod_001', 'name': '重复'})
            print("   ❌ 应该抛出异常")
        except UniqueViolationError as e:
            print(f"   ✅ 正确捕获唯一性约束错误：{e.code}")
        
        print("\n" + "=" * 70)
        print("✅ 所有测试通过!")
        print("=" * 70)
        
        # 性能统计
        print("\n📊 性能统计:")
        print(f"   - 单条插入：✓")
        print(f"   - 批量插入：100 条 ✓")
        print(f"   - 批量更新：10 条 ✓")
        print(f"   - 事务操作：✓")
        print(f"   - 查询优化：✓")
        print(f"   - 错误处理：✓")
        
    except Exception as e:
        print(f"\n❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()
        raise
    finally:
        db.close()
        if os.path.exists('/tmp/test_full.db'):
            os.remove('/tmp/test_full.db')


if __name__ == '__main__':
    test_all()
    print("\n🎉 测试完成!\n")
