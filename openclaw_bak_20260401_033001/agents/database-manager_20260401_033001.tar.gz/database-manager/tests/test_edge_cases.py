#!/usr/bin/env python3
"""
Database Manager - 边界条件测试

测试各种边界情况和异常处理
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from connection import DatabaseConnection
from crud import CRUDOperations
from errors import (
    DatabaseError, UniqueViolationError,
    ForeignKeyViolationError, NotNullViolationError
)


class TestDatabaseManager(CRUDOperations):
    """测试用数据库管理器"""
    def __init__(self, db_path):
        self.connection = DatabaseConnection(db_path)
        self.connection.connect()
        super().__init__(self.connection)
    
    def close(self):
        self.connection.close()
    
    def execute(self, sql, params=None):
        with self.connection.cursor() as cursor:
            cursor.execute(sql, params) if params else cursor.execute(sql)
            self.connection.conn.commit()
            return cursor.rowcount


def test_empty_input():
    """测试空输入"""
    print("\n[测试] 空输入处理...")
    db = TestDatabaseManager('/tmp/test_edge.db')
    
    try:
        # 创建测试表
        db.execute("DROP TABLE IF EXISTS test_edge")
        db.execute("""
            CREATE TABLE test_edge (
                id TEXT PRIMARY KEY,
                name TEXT,
                value INTEGER
            )
        """)
        
        # 测试空 where 条件
        results = db.fetch_all('test_edge', where={})
        assert results == [], "空表应该返回空列表"
        print("   ✅ 空 where 条件处理正确")
        
        # 测试空数据插入
        try:
            db.insert('test_edge', {})
            print("   ❌ 应该抛出错误")
        except Exception as e:
            print(f"   ✅ 空数据插入正确抛出异常：{type(e).__name__}")
        
        # 测试 NULL 值
        db.insert('test_edge', {'id': 'test_null', 'name': None, 'value': None})
        result = db.fetch_one('test_edge', {'id': 'test_null'})
        assert result['name'] is None, "NULL 值应该保持为 None"
        print("   ✅ NULL 值处理正确")
        
        print("   ✅ 空输入测试通过\n")
        
    finally:
        db.close()
        if os.path.exists('/tmp/test_edge.db'):
            os.remove('/tmp/test_edge.db')


def test_unique_violation():
    """测试唯一性约束违反"""
    print("\n[测试] 唯一性约束违反...")
    db = TestDatabaseManager('/tmp/test_edge.db')
    
    try:
        # 创建带唯一约束的表
        db.execute("DROP TABLE IF EXISTS test_unique")
        db.execute("""
            CREATE TABLE test_unique (
                id TEXT PRIMARY KEY,
                email TEXT UNIQUE NOT NULL
            )
        """)
        
        # 插入第一条数据
        db.insert('test_unique', {'id': 'user_1', 'email': 'test@example.com'})
        
        # 尝试插入重复数据
        try:
            db.insert('test_unique', {'id': 'user_2', 'email': 'test@example.com'})
            print("   ❌ 应该抛出 UniqueViolationError")
            return False
        except UniqueViolationError as e:
            print(f"   ✅ 正确捕获唯一性约束错误：{e.code}")
            return True
            
    finally:
        db.close()
        if os.path.exists('/tmp/test_edge.db'):
            os.remove('/tmp/test_edge.db')


def test_foreign_key_violation():
    """测试外键约束违反"""
    print("\n[测试] 外键约束违反...")
    db = TestDatabaseManager('/tmp/test_edge.db')
    
    try:
        # 创建主表
        db.execute("DROP TABLE IF EXISTS parent_table")
        db.execute("DROP TABLE IF EXISTS child_table")
        
        db.execute("""
            CREATE TABLE parent_table (
                id TEXT PRIMARY KEY,
                name TEXT
            )
        """)
        
        db.execute("""
            CREATE TABLE child_table (
                id TEXT PRIMARY KEY,
                parent_id TEXT,
                FOREIGN KEY (parent_id) REFERENCES parent_table(id)
            )
        """)
        
        # 尝试插入不存在的外键
        try:
            db.insert('child_table', {'id': 'child_1', 'parent_id': 'non_existent'})
            print("   ❌ 应该抛出 ForeignKeyViolationError")
            return False
        except ForeignKeyViolationError as e:
            print(f"   ✅ 正确捕获外键约束错误：{e.code}")
            return True
            
    finally:
        db.close()
        if os.path.exists('/tmp/test_edge.db'):
            os.remove('/tmp/test_edge.db')


def test_not_null_violation():
    """测试 NOT NULL 约束违反"""
    print("\n[测试] NOT NULL 约束违反...")
    db = TestDatabaseManager('/tmp/test_edge.db')
    
    try:
        # 创建带 NOT NULL 约束的表
        db.execute("DROP TABLE IF EXISTS test_notnull")
        db.execute("""
            CREATE TABLE test_notnull (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL
            )
        """)
        
        # 尝试插入 NULL 值
        try:
            db.insert('test_notnull', {'id': 'test_1', 'name': None})
            print("   ❌ 应该抛出 NotNullViolationError")
            return False
        except NotNullViolationError as e:
            print(f"   ✅ 正确捕获 NOT NULL 错误：{e.code}")
            return True
            
    finally:
        db.close()
        if os.path.exists('/tmp/test_edge.db'):
            os.remove('/tmp/test_edge.db')


def test_large_batch():
    """测试大批量操作"""
    print("\n[测试] 大批量操作...")
    db = TestDatabaseManager('/tmp/test_edge.db')
    
    try:
        # 创建测试表
        db.execute("DROP TABLE IF EXISTS test_batch")
        db.execute("""
            CREATE TABLE test_batch (
                id TEXT PRIMARY KEY,
                value INTEGER
            )
        """)
        
        # 批量插入 1000 条数据
        import time
        start = time.time()
        
        data = [{'id': f'item_{i}', 'value': i} for i in range(1000)]
        ids = db.batch_insert('test_batch', data, chunk_size=100)
        
        elapsed = time.time() - start
        
        assert len(ids) == 1000, f"应该插入 1000 条，实际{len(ids)}条"
        print(f"   ✅ 批量插入 1000 条记录，耗时 {elapsed:.2f}秒")
        
        # 验证数量
        count = db.count('test_batch')
        assert count == 1000, f"应该有 1000 条记录，实际{count}条"
        print(f"   ✅ 记录数验证通过：{count}条")
        
        # 批量更新
        updates = [{'id': f'item_{i}', 'value': i * 2} for i in range(1000)]
        rows = db.batch_update('test_batch', 'id', updates)
        print(f"   ✅ 批量更新 {rows} 条记录")
        
        print("   ✅ 大批量操作测试通过\n")
        
    finally:
        db.close()
        if os.path.exists('/tmp/test_edge.db'):
            os.remove('/tmp/test_edge.db')


def test_transaction_rollback():
    """测试事务回滚"""
    print("\n[测试] 事务回滚...")
    db = TestDatabaseManager('/tmp/test_edge.db')
    
    try:
        # 创建测试表
        db.execute("DROP TABLE IF EXISTS test_tx")
        db.execute("""
            CREATE TABLE test_tx (
                id TEXT PRIMARY KEY,
                value INTEGER
            )
        """)
        
        # 测试事务回滚
        initial_count = db.count('test_tx')
        
        try:
            with db.transaction():
                db.insert('test_tx', {'id': 'tx_1', 'value': 1})
                db.insert('test_tx', {'id': 'tx_2', 'value': 2})
                # 故意抛出异常
                raise Exception("测试回滚")
        except Exception as e:
            if str(e) == "测试回滚":
                print("   ✅ 捕获测试异常")
        
        # 验证回滚
        final_count = db.count('test_tx')
        assert final_count == initial_count, f"事务应该回滚，初始{initial_count}, 最终{final_count}"
        print(f"   ✅ 事务回滚成功，记录数保持：{final_count}")
        
        print("   ✅ 事务回滚测试通过\n")
        
    finally:
        db.close()
        if os.path.exists('/tmp/test_edge.db'):
            os.remove('/tmp/test_edge.db')


def run_all_tests():
    """运行所有边界测试"""
    print("\n" + "=" * 60)
    print("Database Manager 边界条件测试")
    print("=" * 60)
    
    tests = [
        test_empty_input,
        test_unique_violation,
        test_foreign_key_violation,
        test_not_null_violation,
        test_large_batch,
        test_transaction_rollback
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"   ❌ 测试失败：{e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60 + "\n")
    
    return failed == 0


if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)
