# Database Manager Agent - 通用数据管理基础设施

**Agent ID**: `database-manager`  
**定位**: 多租户数据底座与知识检索基础设施  
**特性**: 赛道无关、权限感知、RAG 增强

---

## 🎯 核心定位

Database Manager 是**通用的数据管理基础设施**，为所有上层 Agent 提供：
- 📦 **数据存储**: 多租户隔离的结构化数据存储
- 🔍 **知识检索**: RAG 增强的语义检索 + 元数据过滤
- 🔐 **权限控制**: 基于用户等级和数据域的双维权限
- 📚 **知识库**: 版本化、赛道化的知识管理

**不绑定具体业务角色**，仅关注：
- 用户是谁 (user_id)
- 用户权限等级 (permission_level)
- 用户所属租户 (org_id)
- 当前赛道 (track_id)
- 数据类型 (data_type)

---

## 🧩 能力架构

```
┌─────────────────────────────────────────────────────────────────┐
│                  Database Manager Agent                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   数据访问层                             │   │
│  │  • 多租户隔离 (org_id 自动注入)                          │   │
│  │  • 赛道上下文 (track_id 自动注入)                        │   │
│  │  • 权限检查 (permission_level 验证)                      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                          ↓                                      │
│  ┌─────────────┬─────────────┬─────────────┬─────────────┐    │
│  │  CRUD 操作  │  RAG 检索   │  知识库管理  │  文件索引   │    │
│  ├─────────────┼─────────────┼─────────────┼─────────────┤    │
│  │ • 创建记录  │ • 语义检索  │ • 文档上传  │ • 文件元数据│    │
│  │ • 查询记录  │ • 元数据过滤│ • 版本管理  │ • 关联检索  │    │
│  │ • 更新记录  │ • 重排序    │ • 权限设置  │ • 存储位置  │    │
│  │ • 删除记录  │ • 上下文构建│ • 质量评分  │ • 访问控制  │    │
│  └─────────────┴─────────────┴─────────────┴─────────────┘    │
│                          ↓                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   数据存储层                             │   │
│  │  • SQLite: 结构化数据 (用户、权限、工单、产品...)        │   │
│  │  • LanceDB: 向量索引 (知识文档、案例、语义检索)          │   │
│  │  • 文件系统：大文件存储 (图片、日志、视频、压缩包)       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔧 核心能力

### 能力 1: 多租户数据 CRUD

**通用数据操作接口**，不绑定具体业务表：

```python
# 通用创建接口
db_create(
    table: str,           # 表名 (如：users, tickets, products...)
    data: dict,           # 数据内容
    org_id: str,          # 租户 ID (自动注入当前用户所属租户)
    track_id: str,        # 赛道 ID (自动注入当前赛道)
    permission_level: int # 创建者权限等级
) → record_id

# 通用查询接口
db_query(
    table: str,           # 表名
    filters: dict,        # 查询条件 (自动附加 org_id, track_id)
    permission_level: int, # 查询者权限等级
    fields: list = None   # 返回字段 (默认全部)
) → list[record]

# 通用更新接口
db_update(
    table: str,
    record_id: str,
    updates: dict,
    permission_level: int  # 检查是否有更新权限
) → success

# 通用删除接口
db_delete(
    table: str,
    record_id: str,
    permission_level: int  # 检查是否有删除权限
) → success
```

**权限检查规则**:
| 操作 | 权限要求 |
|------|---------|
| 创建 | permission_level ≥ 1 |
| 查询自己的数据 | permission_level ≥ 0 |
| 查询他人数据 | permission_level ≥ 2 |
| 更新自己的数据 | permission_level ≥ 1 |
| 更新他人数据 | permission_level ≥ 3 |
| 删除自己的数据 | permission_level ≥ 1 |
| 删除他人数据 | permission_level ≥ 4 (admin) |

---

### 能力 2: RAG 知识检索

**通用知识检索接口**，支持多租户 + 多赛道隔离：

```python
rag_search(
    query: str,                    # 查询文本
    org_id: str = None,            # 租户过滤 (默认当前用户租户)
    track_id: str = None,          # 赛道过滤 (默认当前赛道)
    doc_type: str = None,          # 文档类型过滤
    access_level: str = None,      # 权限级别过滤 (public/internal/restricted)
    metadata_filters: dict = None, # 其他元数据过滤 (如 system_version, hardware_config)
    top_k: int = 5,                # 返回数量
    permission_level: int = 0      # 查询者权限等级
) → list[KnowledgeResult]
```

**返回结构**:
```json
{
  "doc_id": "doc_123",
  "content": "文档内容片段...",
  "relevance_score": 0.92,
  "metadata": {
    "title": "文档标题",
    "org_id": "org_456",
    "track_id": "server_maintenance",
    "access_level": "internal",
    "version": 2,
    "system_version": "OpenCloudOS 9.4",
    "hardware_config": "NVIDIA A800 x8"
  },
  "citation": "【参考资料 1】"
}
```

**检索流程**:
```
用户查询
  ↓
1. 权限检查 (用户是否有权限查询该赛道/租户的数据)
  ↓
2. 向量化查询 (bge-m3 嵌入模型)
  ↓
3. 元数据过滤 (org_id, track_id, access_level, 自定义字段)
  ↓
4. 重排序 (Cross-Encoder 优化相关性)
  ↓
5. Top-K 精选
  ↓
6. 上下文构建 (Prompt 注入)
  ↓
返回结果
```

---

### 能力 3: 知识库管理

**通用知识库接口**，支持版本化和权限控制：

```python
# 上传文档
kb_upload(
    title: str,
    content: str,
    doc_type: str,
    track_id: str,
    access_level: str,      # public/internal/restricted
    metadata: dict = None,  # 自定义元数据 (system_version, hardware_config...)
    file_ids: list = None,  # 关联文件
    permission_level: int
) → doc_id

# 版本更新
kb_version(
    doc_id: str,
    new_content: str,
    version_comment: str,   # 版本变更说明
    permission_level: int
) → new_version_id

# 设置权限
kb_set_permission(
    doc_id: str,
    access_level: str,
    allowed_orgs: list = None,  # 允许访问的租户列表
    allowed_tracks: list = None, # 允许访问的赛道列表
    permission_level: int
) → success

# 质量评分 (自动)
kb_quality_score(
    doc_id: str
) → {
    "completeness": 0.9,    # 完整性
    "accuracy": 0.85,       # 准确性
    "timeliness": 0.95,     # 时效性
    "readability": 0.88,    # 可读性
    "relevance": 0.92,      # 关联性
    "overall": 0.90         # 综合评分
}
```

---

### 能力 4: 文件索引与关联

**通用文件元数据管理**，不存储文件本身，仅管理索引：

```python
# 注册文件元数据
file_register(
    filename: str,
    file_path: str,
    file_type: str,         # image/document/video/log/archive/firmware...
    file_size: int,
    mime_type: str,
    org_id: str,
    track_id: str,
    owner_id: str,
    permissions: dict,      # 访问权限控制
    related_record: dict    # 关联记录 (table, record_id)
) → file_id

# 文件检索
file_search(
    org_id: str,
    track_id: str,
    file_type: str = None,
    related_table: str = None,
    related_record_id: str = None,
    permission_level: int
) → list[file_info]

# 文件关联
file_link(
    file_id: str,
    target_table: str,
    target_record_id: str
) → success
```

---

## 🔐 权限模型

### 通用权限等级

| 等级 | 名称 | 读取 | 写入 | 更新 | 删除 | 权限管理 |
|------|------|------|------|------|------|---------|
| **0** | guest | 公开数据 | ❌ | ❌ | ❌ | ❌ |
| **1** | user | 自己数据 | ✅ | 自己 | 自己 | ❌ |
| **2** | member | 同组织数据 | ✅ | 自己 | ❌ | ❌ |
| **3** | manager | 所有数据 | ✅ | 所有 | ❌ | ❌ |
| **4** | admin | 所有数据 | ✅ | 所有 | ✅ | ✅ |

### 数据域权限

| 数据域 | 读取权限 | 写入权限 | 说明 |
|--------|---------|---------|------|
| **public** | 0+ | 3+ | 公开数据，所有用户可读 |
| **internal** | 1+ | 2+ | 内部数据，同组织可读 |
| **restricted** | 3+ | 4+ | 受限数据，仅管理员 |

### 租户隔离

- 所有查询**自动注入** `org_id` 过滤
- 用户**只能访问**自己所属租户的数据
- 跨租户访问需要 `permission_level ≥ 4` (admin)

### 赛道隔离

- 所有数据关联 `track_id`
- 用户**默认访问**当前赛道数据
- 跨赛道访问需要显式指定 + 权限检查

---

## 🛠️ 工具接口清单

### CRUD 工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `db_create` | 创建记录 | ✅ |
| `db_query` | 查询记录 | ✅ |
| `db_update` | 更新记录 | ✅ |
| `db_delete` | 删除记录 | ✅ |
| `db_batch_create` | 批量创建 | ✅ |
| `db_batch_query` | 批量查询 | ✅ |

### RAG 检索工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `rag_search` | 语义检索 | ✅ |
| `rag_search_similar` | 相似案例检索 | ✅ |
| `rag_search_by_metadata` | 元数据检索 | ✅ |
| `rag_build_context` | 构建 Prompt 上下文 | ✅ |

### 知识库工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `kb_upload` | 上传文档 | ✅ |
| `kb_version` | 版本更新 | ✅ |
| `kb_delete` | 删除文档 | ✅ |
| `kb_set_permission` | 设置权限 | ✅ |
| `kb_quality_score` | 质量评分 | ❌ |
| `kb_list` | 文档列表 | ✅ |

### 文件管理工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `file_register` | 注册文件元数据 | ✅ |
| `file_search` | 文件检索 | ✅ |
| `file_link` | 文件关联 | ✅ |
| `file_unlink` | 取消关联 | ✅ |
| `file_delete` | 删除文件索引 | ✅ |

### 权限工具

| 工具名 | 功能 | 权限检查 |
|--------|------|---------|
| `check_permission` | 检查权限 | ❌ |
| `get_user_level` | 获取用户权限等级 | ❌ |
| `get_org_id` | 获取用户所属组织 | ❌ |
| `get_track_id` | 获取当前赛道 | ❌ |

---

## 📦 数据表结构 (通用设计)

### 核心表

```sql
-- 租户/组织表
CREATE TABLE organizations (
    org_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT,              -- 不定义具体类型，由赛道配置决定
    config JSON,            -- 租户特定配置
    created_at TIMESTAMP,
    status TEXT
);

-- 用户表 (通用，不区分客户/员工)
CREATE TABLE users (
    user_id TEXT PRIMARY KEY,
    org_id TEXT,
    name TEXT NOT NULL,
    permission_level INTEGER DEFAULT 1,
    skills JSON,            -- 技能标签 (赛道相关)
    config JSON,            -- 用户特定配置
    created_at TIMESTAMP,
    FOREIGN KEY (org_id) REFERENCES organizations(org_id)
);

-- 赛道表
CREATE TABLE tracks (
    track_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    config JSON,            -- 赛道配置 (用户角色映射、实体定义...)
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP
);

-- 通用数据记录表 (动态 schema)
CREATE TABLE records (
    record_id TEXT PRIMARY KEY,
    table_name TEXT NOT NULL,
    org_id TEXT,
    track_id TEXT,
    owner_id TEXT,
    data JSON NOT NULL,     -- 动态数据内容
    metadata JSON,          -- 元数据
    version INTEGER DEFAULT 1,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- 知识文档表
CREATE TABLE knowledge_docs (
    doc_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT,
    org_id TEXT,
    track_id TEXT,
    doc_type TEXT,
    access_level TEXT DEFAULT 'internal',
    metadata JSON,          -- system_version, hardware_config...
    file_ids JSON,          -- 关联文件
    version INTEGER DEFAULT 1,
    parent_doc_id TEXT,     -- 版本链
    quality_score REAL,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- 文件元数据表
CREATE TABLE files (
    file_id TEXT PRIMARY KEY,
    org_id TEXT,
    track_id TEXT,
    owner_id TEXT,
    filename TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_type TEXT,         -- image/document/video/log/archive/firmware...
    file_size INTEGER,
    mime_type TEXT,
    permissions JSON,       -- 访问权限
    related_records JSON,   -- 关联记录 [{table, record_id}]
    checksum TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- 审计日志表
CREATE TABLE audit_logs (
    log_id TEXT PRIMARY KEY,
    org_id TEXT,
    track_id TEXT,
    actor_id TEXT,
    action TEXT,            -- create/read/update/delete
    target_table TEXT,
    target_id TEXT,
    changes JSON,           -- 变更详情
    created_at TIMESTAMP
);
```

---

## 🔄 与其他 Agent 的协作

### 被调用场景

| 调用方 Agent | 使用场景 | 调用接口 |
|-------------|---------|---------|
| **任意 Agent** | 存储/读取业务数据 | `db_create`, `db_query` |
| **任意 Agent** | 检索相关知识 | `rag_search` |
| **任意 Agent** | 上传文档到知识库 | `kb_upload` |
| **任意 Agent** | 关联文件到记录 | `file_link` |
| **任意 Agent** | 检查用户权限 | `check_permission` |

### 调用示例

```python
# 场景：任意 Agent 需要存储业务数据
# (不绑定具体业务，仅演示调用方式)

# 1. 创建记录
record_id = db_create(
    table="custom_entity",  # 任意业务实体
    data={
        "field1": "value1",
        "field2": "value2"
    },
    org_id=current_org_id,
    track_id=current_track_id,
    permission_level=user_permission_level
)

# 2. 检索相关知识
results = rag_search(
    query="相关业务问题",
    org_id=current_org_id,
    track_id=current_track_id,
    top_k=5
)

# 3. 构建 Prompt 上下文
context = rag_build_context(results)
prompt = f"""
请根据以下参考资料回答问题：

{context}

问题：{user_query}

回答：
"""
```

---

## 📊 性能指标

| 指标 | 目标值 | 测量方式 |
|------|--------|---------|
| CRUD 延迟 | <50ms | 单次查询 P95 |
| RAG 检索延迟 | <500ms | 语义检索 + 重排序 |
| 向量索引大小 | <10GB | 100 万文档 |
| 并发支持 | 100+ QPS | 压力测试 |
| 权限检查开销 | <5ms | 单次检查 |

---

## 🚀 部署配置

### 资源需求

| 资源 | 最小配置 | 推荐配置 |
|------|---------|---------|
| CPU | 2 核 | 4 核 |
| 内存 | 4GB | 8GB |
| 存储 | 50GB | 200GB |
| GPU | 可选 | 可选 (加速向量化) |

### 依赖项

- Python 3.11+
- SQLite 3.35+
- LanceDB 0.5+
- FlagEmbedding (bge-m3)
- sentence-transformers (重排序)

---

## 📝 版本历史

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| 1.0 | 2026-03-26 | 初始版本，通用化设计 |

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 设计完成，待开发
