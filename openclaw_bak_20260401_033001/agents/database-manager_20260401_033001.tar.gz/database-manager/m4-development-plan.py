#!/usr/bin/env python3
"""
Database Manager - M4 阶段开发计划

RAG 检索系统实施计划
"""

M4_TASKS = {
    "模块 1: LanceDB 集成": {
        "文件": "src/lancedb_client.py",
        "功能": [
            "LanceDB 连接管理",
            "向量表创建",
            "向量索引",
            "批量插入"
        ],
        "API": [
            "connect(uri)",
            "create_table(name, schema)",
            "add_vectors(vectors)",
            "create_index(field)"
        ],
        "状态": "⏳ 待开发"
    },
    
    "模块 2: 向量检索": {
        "文件": "src/vector_search.py",
        "功能": [
            "相似度搜索",
            "距离计算",
            "结果排序",
            "分页支持"
        ],
        "API": [
            "search(query_vector, limit=10)",
            "calculate_distance(v1, v2)",
            "rank_results(results)",
            "paginate(results, page, page_size)"
        ],
        "状态": "⏳ 待开发"
    },
    
    "模块 3: 混合检索": {
        "文件": "src/hybrid_search.py",
        "功能": [
            "语义 + 元数据过滤",
            "多路召回",
            "结果融合",
            "权重调整"
        ],
        "API": [
            "hybrid_search(query, filters, limit)",
            "multi_recall(queries)",
            "merge_results(results)",
            "adjust_weights(weights)"
        ],
        "状态": "⏳ 待开发"
    },
    
    "模块 4: 重排序": {
        "文件": "src/reranker.py",
        "功能": [
            "Cross-Encoder 重排序",
            "相关性评分",
            "多样性控制",
            "业务规则融合"
        ],
        "API": [
            "rerank(query, candidates)",
            "score_relevance(query, doc)",
            "control_diversity(results)",
            "apply_business_rules(results, rules)"
        ],
        "状态": "⏳ 待开发"
    },
    
    "模块 5: RAG 上下文构建": {
        "文件": "src/rag_context.py",
        "功能": [
            "检索结果整合",
            "上下文构建",
            "引用标注",
            "来源追踪"
        ],
        "API": [
            "build_context(query, results)",
            "add_citations(results)",
            "track_sources(results)",
            "format_for_llm(context)"
        ],
        "状态": "⏳ 待开发"
    }
}

# 开发顺序
DEVELOPMENT_ORDER = [
    "模块 1: LanceDB 集成",
    "模块 2: 向量检索",
    "模块 3: 混合检索",
    "模块 4: 重排序",
    "模块 5: RAG 上下文构建"
]

# 验收标准
ACCEPTANCE_CRITERIA = [
    "✅ LanceDB 集成完成，支持向量存储和检索",
    "✅ 向量检索支持相似度搜索和分页",
    "✅ 混合检索支持语义 + 元数据过滤",
    "✅ 重排序提升结果相关性",
    "✅ RAG 上下文构建完整，支持引用标注",
    "✅ 所有模块测试通过",
    "✅ 集成测试验证"
]

if __name__ == "__main__":
    print("M4 阶段开发计划")
    print("=" * 60)
    for task in DEVELOPMENT_ORDER:
        info = M4_TASKS[task]
        print(f"\n{task}")
        print(f"  文件：{info['文件']}")
        print(f"  功能：{len(info['功能'])} 个")
        print(f"  API: {len(info['API'])} 个")
        print(f"  状态：{info['状态']}")
    
    print("\n" + "=" * 60)
    print("验收标准:")
    for criterion in ACCEPTANCE_CRITERIA:
        print(f"  {criterion}")
