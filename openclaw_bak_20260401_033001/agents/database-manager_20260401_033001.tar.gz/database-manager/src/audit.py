"""
Database Manager - 审计日志模块

自动记录关键数据库操作
"""

import json
import uuid
from datetime import datetime
from typing import Optional, Dict, Any, List

try:
    from .connection import DatabaseConnection
    from .errors import parse_sqlite_error
except ImportError:
    from connection import DatabaseConnection
    from errors import parse_sqlite_error


class AuditLogger:
    """审计日志类"""
    
    def __init__(self, db: DatabaseConnection, org_id: str = None, user_id: str = None):
        """
        初始化审计日志
        
        Args:
            db: 数据库连接
            org_id: 组织 ID
            user_id: 用户 ID
        """
        self.db = db
        self.org_id = org_id
        self.user_id = user_id
        self.enabled = True
        self._buffer = []
        self._buffer_size = 100
    
    def log(self, action: str, table: str, record_id: str = None,
            old_value: Dict[str, Any] = None, new_value: Dict[str, Any] = None,
            ip_address: str = None, user_agent: str = None):
        """
        记录审计日志
        
        Args:
            action: 操作类型 (CREATE/UPDATE/DELETE/LOGIN/LOGOUT/ACCESS)
            table: 表名
            record_id: 记录 ID
            old_value: 旧值
            new_value: 新值
            ip_address: IP 地址
            user_agent: User-Agent
        """
        if not self.enabled:
            return
        
        log_entry = {
            'log_id': f"log_{uuid.uuid4().hex[:12]}",
            'org_id': self.org_id,
            'user_id': self.user_id,
            'action': action,
            'table_name': table,
            'record_id': record_id,
            'old_value': json.dumps(old_value) if old_value else None,
            'new_value': json.dumps(new_value) if new_value else None,
            'ip_address': ip_address,
            'user_agent': user_agent,
            'created_at': datetime.now().isoformat()
        }
        
        self._buffer.append(log_entry)
        
        # 缓冲区满时批量写入
        if len(self._buffer) >= self._buffer_size:
            self.flush()
    
    def flush(self):
        """刷新缓冲区到数据库"""
        if not self._buffer:
            return
        
        sql = """
            INSERT INTO audit_logs 
            (log_id, org_id, user_id, action, table_name, record_id, 
             old_value, new_value, ip_address, user_agent, created_at)
            VALUES 
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            with self.db.cursor() as cursor:
                values = [
                    (
                        entry['log_id'], entry['org_id'], entry['user_id'],
                        entry['action'], entry['table_name'], entry['record_id'],
                        entry['old_value'], entry['new_value'],
                        entry['ip_address'], entry['user_agent'],
                        entry['created_at']
                    )
                    for entry in self._buffer
                ]
                cursor.executemany(sql, values)
                self.db.conn.commit()
                self._buffer.clear()
                
        except sqlite3.Error as e:
            # 审计日志失败不应影响主流程
            print(f"Audit log flush failed: {e}")
    
    def get_logs(self, table: str = None, record_id: str = None, 
                 limit: int = 100) -> List[Dict[str, Any]]:
        """
        查询审计日志
        
        Args:
            table: 表名
            record_id: 记录 ID
            limit: 限制数量
        
        Returns:
            审计日志列表
        """
        where_clauses = []
        params = []
        
        if self.org_id:
            where_clauses.append("org_id = ?")
            params.append(self.org_id)
        
        if table:
            where_clauses.append("table_name = ?")
            params.append(table)
        
        if record_id:
            where_clauses.append("record_id = ?")
            params.append(record_id)
        
        where_sql = " WHERE " + " AND ".join(where_clauses) if where_clauses else ""
        sql = f"""
            SELECT log_id, org_id, user_id, action, table_name, record_id,
                   old_value, new_value, ip_address, user_agent, created_at
            FROM audit_logs
            {where_sql}
            ORDER BY created_at DESC
            LIMIT ?
        """
        params.append(limit)
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                
                columns = [desc[0] for desc in cursor.description]
                result = []
                for row in rows:
                    entry = dict(zip(columns, row))
                    # 解析 JSON 字段
                    if entry.get('old_value'):
                        try:
                            entry['old_value'] = json.loads(entry['old_value'])
                        except:
                            pass
                    if entry.get('new_value'):
                        try:
                            entry['new_value'] = json.loads(entry['new_value'])
                        except:
                            pass
                    result.append(entry)
                
                return result
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.flush()


class AuditDecorator:
    """审计装饰器"""
    
    def __init__(self, logger: AuditLogger):
        self.logger = logger
    
    def audit_create(self, table: str):
        """CREATE 操作审计装饰器"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                result = func(*args, **kwargs)
                # 假设返回的是 record_id
                if result:
                    self.logger.log('CREATE', table, record_id=str(result), new_value=kwargs.get('data'))
                return result
            return wrapper
        return decorator
    
    def audit_update(self, table: str):
        """UPDATE 操作审计装饰器"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                old_value = kwargs.get('old_value')
                new_value = kwargs.get('data')
                where = kwargs.get('where')
                result = func(*args, **kwargs)
                if result > 0:
                    self.logger.log('UPDATE', table, record_id=str(where), 
                                   old_value=old_value, new_value=new_value)
                return result
            return wrapper
        return decorator
    
    def audit_delete(self, table: str):
        """DELETE 操作审计装饰器"""
        def decorator(func):
            def wrapper(*args, **kwargs):
                where = kwargs.get('where')
                result = func(*args, **kwargs)
                if result > 0:
                    self.logger.log('DELETE', table, record_id=str(where))
                return result
            return wrapper
        return decorator
