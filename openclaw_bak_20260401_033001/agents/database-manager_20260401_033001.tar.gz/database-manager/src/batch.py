"""
Database Manager - 批量操作模块

提供批量插入、更新、删除功能
"""

import json
from typing import List, Dict, Any
from datetime import datetime

try:
    from .connection import DatabaseConnection
    from .errors import parse_sqlite_error
except ImportError:
    from connection import DatabaseConnection
    from errors import parse_sqlite_error


class BatchOperations:
    """批量操作类"""
    
    def __init__(self, db: DatabaseConnection):
        self.db = db
    
    def batch_insert(self, table: str, data_list: List[Dict[str, Any]], 
                     chunk_size: int = 1000) -> List[int]:
        """
        批量插入记录
        
        Args:
            table: 表名
            data_list: 数据列表
            chunk_size: 批次大小
        
        Returns:
            主键 ID 列表
        
        Example:
            users = [
                {'user_id': 'user_001', 'username': 'john', ...},
                {'user_id': 'user_002', 'username': 'jane', ...},
                ...
            ]
            ids = db.batch_insert('users', users, chunk_size=1000)
        """
        if not data_list:
            return []
        
        # 验证 JSON 字段并序列化
        processed_data = []
        for data in data_list:
            processed = {}
            for key, value in data.items():
                if isinstance(value, (dict, list)):
                    processed[key] = json.dumps(value, ensure_ascii=False)
                else:
                    processed[key] = value
            processed_data.append(processed)
        
        # 获取字段名
        columns = list(processed_data[0].keys())
        columns_str = ', '.join(columns)
        placeholders = ', '.join(['?' for _ in columns])
        sql = f"INSERT INTO {table} ({columns_str}) VALUES ({placeholders})"
        
        ids = []
        
        try:
            with self.db.cursor() as cursor:
                for i in range(0, len(processed_data), chunk_size):
                    chunk = processed_data[i:i + chunk_size]
                    values = [[item[col] for col in columns] for item in chunk]
                    cursor.executemany(sql, values)
                    ids.extend([cursor.lastrowid for _ in chunk])
                
                self.db.conn.commit()
                return ids
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def batch_update(self, table: str, key_field: str, 
                     data_list: List[Dict[str, Any]], 
                     chunk_size: int = 1000) -> int:
        """
        批量更新记录
        
        Args:
            table: 表名
            key_field: 主键字段名
            data_list: 数据列表 (每个字典包含 key_field 和要更新的字段)
            chunk_size: 批次大小
        
        Returns:
            影响行数
        
        Example:
            updates = [
                {'user_id': 'user_001', 'status': 'active', 'age': 26},
                {'user_id': 'user_002', 'status': 'inactive', 'age': 31},
                ...
            ]
            rows = db.batch_update('users', 'user_id', updates)
        """
        if not data_list:
            return 0
        
        # 获取要更新的字段 (排除 key_field)
        update_fields = [k for k in data_list[0].keys() if k != key_field]
        
        if not update_fields:
            return 0
        
        # 验证 JSON 字段
        processed_data = []
        for data in data_list:
            processed = {}
            for key, value in data.items():
                if isinstance(value, (dict, list)):
                    processed[key] = json.dumps(value, ensure_ascii=False)
                else:
                    processed[key] = value
            processed_data.append(processed)
        
        # 构建 SET 子句
        set_clause = ', '.join([f"{field} = ?" for field in update_fields])
        sql = f"UPDATE {table} SET {set_clause} WHERE {key_field} = ?"
        
        total_rows = 0
        
        try:
            with self.db.cursor() as cursor:
                for i in range(0, len(processed_data), chunk_size):
                    chunk = processed_data[i:i + chunk_size]
                    
                    # 为每个记录构建参数
                    params_list = []
                    for item in chunk:
                        params = [item[field] for field in update_fields]
                        params.append(item[key_field])
                        params_list.append(params)
                    
                    cursor.executemany(sql, params_list)
                    total_rows += cursor.rowcount
                
                self.db.conn.commit()
                return total_rows
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def batch_delete(self, table: str, key_field: str, 
                     key_values: List[Any], 
                     chunk_size: int = 1000,
                     soft: bool = True) -> int:
        """
        批量删除记录
        
        Args:
            table: 表名
            key_field: 主键字段名
            key_values: 主键值列表
            chunk_size: 批次大小
            soft: 是否软删除
        
        Returns:
            影响行数
        
        Example:
            # 硬删除
            rows = db.batch_delete('users', 'user_id', ['user_001', 'user_002'])
            
            # 软删除
            rows = db.batch_delete('users', 'user_id', ['user_001', 'user_002'], soft=True)
        """
        if not key_values:
            return 0
        
        if soft:
            # 软删除：批量更新 deleted_at
            data_list = [{key_field: key, 'deleted_at': datetime.now().isoformat()} 
                        for key in key_values]
            return self.batch_update(table, key_field, data_list, chunk_size)
        else:
            # 硬删除
            placeholders = ', '.join(['?' for _ in key_values])
            sql = f"DELETE FROM {table} WHERE {key_field} IN ({placeholders})"
            
            try:
                with self.db.cursor() as cursor:
                    # 分块执行
                    total_rows = 0
                    for i in range(0, len(key_values), chunk_size):
                        chunk = key_values[i:i + chunk_size]
                        chunk_placeholders = ', '.join(['?' for _ in chunk])
                        chunk_sql = f"DELETE FROM {table} WHERE {key_field} IN ({chunk_placeholders})"
                        cursor.execute(chunk_sql, chunk)
                        total_rows += cursor.rowcount
                    
                    self.db.conn.commit()
                    return total_rows
                    
            except sqlite3.Error as e:
                raise parse_sqlite_error(e, sql)
    
    def upsert(self, table: str, data: Dict[str, Any], 
               conflict_columns: List[str] = None) -> int:
        """
        Upsert 操作 (插入或更新)
        
        Args:
            table: 表名
            data: 数据字典
            conflict_columns: 冲突检测字段列表 (默认使用所有字段)
        
        Returns:
            影响行数
        
        Example:
            # 如果 user_id 冲突则更新
            rows = db.upsert('users', {
                'user_id': 'user_001',
                'username': 'john',
                'email': 'john@example.com'
            }, conflict_columns=['user_id'])
        """
        if conflict_columns is None:
            conflict_columns = list(data.keys())
        
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        values = list(data.values())
        
        # 构建 UPDATE 子句 (排除冲突字段)
        update_fields = [k for k in data.keys() if k not in conflict_columns]
        
        if update_fields:
            update_clause = ', '.join([f"{field} = excluded.{field}" for field in update_fields])
            conflict_cols_str = ', '.join(conflict_columns)
            sql = f"""
                INSERT INTO {table} ({columns}) VALUES ({placeholders})
                ON CONFLICT({conflict_cols_str}) DO UPDATE SET {update_clause}
            """
        else:
            conflict_cols_str = ', '.join(conflict_columns)
            sql = f"""
                INSERT INTO {table} ({columns}) VALUES ({placeholders})
                ON CONFLICT({conflict_cols_str}) DO NOTHING
            """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, values)
                self.db.conn.commit()
                return cursor.rowcount
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def batch_upsert(self, table: str, data_list: List[Dict[str, Any]], 
                     conflict_columns: List[str] = None,
                     chunk_size: int = 1000) -> int:
        """
        批量 Upsert 操作
        
        Args:
            table: 表名
            data_list: 数据列表
            conflict_columns: 冲突检测字段列表
            chunk_size: 批次大小
        
        Returns:
            影响行数
        """
        if not data_list:
            return 0
        
        if conflict_columns is None:
            conflict_columns = list(data_list[0].keys())
        
        total_rows = 0
        
        for i in range(0, len(data_list), chunk_size):
            chunk = data_list[i:i + chunk_size]
            for data in chunk:
                total_rows += self.upsert(table, data, conflict_columns)
        
        return total_rows
