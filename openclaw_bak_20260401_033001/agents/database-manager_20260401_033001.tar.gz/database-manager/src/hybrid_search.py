#!/usr/bin/env python3
"""
Database Manager - 混合检索模块

结合向量检索 + 元数据过滤，提升检索准确性
"""

import sqlite3
from typing import Optional, List, Dict, Any
import numpy as np

try:
    from .connection import DatabaseConnection
    from .lancedb_client import LanceDBClient
except ImportError:
    from connection import DatabaseConnection
    from lancedb_client import LanceDBClient


class HybridSearch:
    """混合检索器"""
    
    def __init__(self, db: DatabaseConnection, lancedb: LanceDBClient):
        self.db = db
        self.lancedb = lancedb
    
    def search(
        self,
        query: str,
        query_vector: List[float],
        table_name: str = 'embeddings',
        filters: Dict[str, Any] = None,
        limit: int = 10,
        weights: Dict[str, float] = None
    ) -> List[Dict[str, Any]]:
        """
        混合检索（向量 + 元数据）
        
        Args:
            query: 查询文本
            query_vector: 查询向量
            table_name: LanceDB 表名
            filters: 元数据过滤条件
            limit: 返回数量
            weights: 权重配置 {'vector': 0.7, 'metadata': 0.3}
        
        Returns:
            检索结果（按综合得分排序）
        """
        weights = weights or {'vector': 0.7, 'metadata': 0.3}
        
        # 1. 向量检索
        vector_results = self._vector_search(
            query_vector,
            table_name,
            limit * 2  # 多召回一些用于重排序
        )
        
        # 2. 元数据过滤
        if filters:
            filtered_results = self._apply_metadata_filters(vector_results, filters)
        else:
            filtered_results = vector_results
        
        # 3. 计算综合得分
        scored_results = self._calculate_combined_scores(
            filtered_results,
            weights
        )
        
        # 4. 排序并返回 Top-K
        scored_results.sort(key=lambda x: x['combined_score'], reverse=True)
        
        return scored_results[:limit]
    
    def _vector_search(
        self,
        query_vector: List[float],
        table_name: str,
        limit: int
    ) -> List[Dict[str, Any]]:
        """向量检索"""
        try:
            results = self.lancedb.search_vectors(
                table_name,
                query_vector,
                limit=limit
            )
            
            # 添加向量相似度分数
            for result in results:
                result['vector_score'] = 1.0 - (result.get('_distance', 0) / 2.0)  # 余弦相似度转分数
            
            return results
            
        except Exception as e:
            print(f"向量检索失败：{e}")
            return []
    
    def _apply_metadata_filters(
        self,
        results: List[Dict[str, Any]],
        filters: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """应用元数据过滤"""
        filtered = []
        
        for result in results:
            match = True
            
            for key, value in filters.items():
                # 从 metadata JSON 中解析
                import json
                metadata = {}
                if result.get('metadata'):
                    try:
                        metadata = json.loads(result['metadata'])
                    except:
                        pass
                
                # 检查过滤条件
                if key in metadata:
                    if metadata[key] != value:
                        match = False
                        break
                elif key in result:
                    if result[key] != value:
                        match = False
                        break
            
            if match:
                filtered.append(result)
        
        return filtered
    
    def _calculate_combined_scores(
        self,
        results: List[Dict[str, Any]],
        weights: Dict[str, float]
    ) -> List[Dict[str, Any]]:
        """计算综合得分"""
        scored = []
        
        for result in results:
            vector_score = result.get('vector_score', 0.0)
            
            # 元数据完整性评分
            metadata_score = self._calculate_metadata_score(result)
            
            # 综合得分
            combined_score = (
                weights.get('vector', 0.7) * vector_score +
                weights.get('metadata', 0.3) * metadata_score
            )
            
            result['combined_score'] = combined_score
            result['scores'] = {
                'vector': vector_score,
                'metadata': metadata_score,
                'combined': combined_score
            }
            
            scored.append(result)
        
        return scored
    
    def _calculate_metadata_score(self, result: Dict[str, Any]) -> float:
        """计算元数据完整性得分"""
        score = 0.0
        
        # 检查必要字段
        if result.get('content'):
            score += 0.4
        
        if result.get('metadata'):
            score += 0.3
        
        if result.get('created_at'):
            score += 0.2
        
        if result.get('id'):
            score += 0.1
        
        return min(1.0, score)
    
    def rerank(
        self,
        query: str,
        candidates: List[Dict[str, Any]],
        strategy: str = 'combined'
    ) -> List[Dict[str, Any]]:
        """
        重排序
        
        Args:
            query: 查询文本
            candidates: 候选结果
            strategy: 重排序策略 (combined/recency/relevance)
        
        Returns:
            重排序结果
        """
        if strategy == 'recency':
            # 按时间排序
            candidates.sort(
                key=lambda x: x.get('created_at', ''),
                reverse=True
            )
        elif strategy == 'relevance':
            # 按相关性排序
            candidates.sort(
                key=lambda x: x.get('combined_score', 0),
                reverse=True
            )
        else:  # combined
            # 综合排序（已计算）
            candidates.sort(
                key=lambda x: x.get('combined_score', 0),
                reverse=True
            )
        
        return candidates


# 使用示例
if __name__ == "__main__":
    print("混合检索模块 - 设计完成")
    print("=" * 60)
    print("\n功能:")
    print("  1. 向量检索 + 元数据过滤")
    print("  2. 可配置权重（vector/metadata）")
    print("  3. 综合得分排序")
    print("  4. 多种重排序策略")
    print("\n下一步：集成 Embedding 模型进行实际测试")
    print("=" * 60)
