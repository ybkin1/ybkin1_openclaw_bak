#!/usr/bin/env python3
"""
Database Manager - 事实记忆管理模块 (L3) + 防 AI 幻觉工作流

负责事实记忆的存储、验证和冲突检测
"""

import sqlite3
import uuid
import re
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime

try:
    from .connection import DatabaseConnection
except ImportError:
    from connection import DatabaseConnection


class FactMemoryManager:
    """事实记忆管理器 + 防 AI 幻觉"""
    
    def __init__(self, db: DatabaseConnection):
        self.db = db
    
    # ========== 事实记忆管理 ==========
    
    def add_fact(
        self,
        subject: str,
        predicate: str,
        object: str,
        category: str = 'general',
        confidence: float = 1.0,
        source_memory_id: Optional[str] = None,
        valid_until: Optional[str] = None
    ) -> Tuple[str, bool]:
        """
        添加事实记忆（带冲突检测）
        
        Args:
            subject: 主体
            predicate: 谓词
            object: 客体
            category: 分类
            confidence: 置信度
            source_memory_id: 来源记忆 ID
            valid_until: 有效期
        
        Returns:
            (fact_id, is_new): 事实 ID 和是否为新事实
        """
        # 先检查冲突
        has_conflict, conflicting = self.check_conflict(subject, predicate, object)
        
        if has_conflict:
            # 发现冲突，拒绝添加
            return None, False
        
        fact_id = f"fact_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO memory_facts
            (fact_id, subject, predicate, object, category, confidence,
             source_memory_id, valid_until)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [
                    fact_id,
                    subject,
                    predicate,
                    object,
                    category,
                    confidence,
                    source_memory_id,
                    valid_until
                ])
                self.db.conn.commit()
                
            return fact_id, True
            
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def check_conflict(
        self,
        subject: str,
        predicate: str,
        object: str
    ) -> Tuple[bool, List[Dict[str, Any]]]:
        """
        检查事实冲突
        
        Args:
            subject: 主体
            predicate: 谓词
            object: 客体
        
        Returns:
            (has_conflict, conflicting_facts)
        """
        sql = """
            SELECT * FROM memory_facts
            WHERE subject = ? AND predicate = ? AND object != ?
            AND verified = 1 AND deleted_at IS NULL
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [subject, predicate, object])
                rows = cursor.fetchall()
                
                conflicts = [dict(row) for row in rows]
                has_conflict = len(conflicts) > 0
                
                return has_conflict, conflicts
                
        except sqlite3.Error as e:
            raise
    
    def query_facts(
        self,
        subject: Optional[str] = None,
        predicate: Optional[str] = None,
        category: Optional[str] = None,
        verified_only: bool = True
    ) -> List[Dict[str, Any]]:
        """
        查询事实
        
        Args:
            subject: 主体过滤
            predicate: 谓词过滤
            category: 分类过滤
            verified_only: 仅返回已验证
        
        Returns:
            事实列表
        """
        conditions = ['deleted_at IS NULL']
        params = []
        
        if subject:
            conditions.append('subject = ?')
            params.append(subject)
        
        if predicate:
            conditions.append('predicate = ?')
            params.append(predicate)
        
        if category:
            conditions.append('category = ?')
            params.append(category)
        
        if verified_only:
            conditions.append('verified = 1')
        
        where_clause = ' AND '.join(conditions)
        
        sql = f"""
            SELECT * FROM memory_facts
            WHERE {where_clause}
            ORDER BY verified_at DESC
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                columns = [description[0] for description in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
                
        except sqlite3.Error as e:
            raise
    
    def verify_fact(
        self,
        fact_id: str,
        verified_by: str,
        verification_type: str = 'user_confirm'
    ) -> bool:
        """
        验证事实
        
        Args:
            fact_id: 事实 ID
            verified_by: 验证者
            verification_type: 验证类型
        
        Returns:
            是否成功
        """
        sql = """
            UPDATE memory_facts
            SET 
                verified = 1,
                verified_by = ?,
                verified_at = CURRENT_TIMESTAMP
            WHERE fact_id = ?
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [verified_by, fact_id])
                self.db.conn.commit()
                return True
                
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    # ========== 防 AI 幻觉工作流 ==========
    
    def extract_facts_from_text(self, text: str) -> List[Dict[str, str]]:
        """
        从文本中提取事实候选（增强版）
        
        Args:
            text: 输入文本
        
        Returns:
            事实候选列表
        """
        facts = []
        
        # 模式 1: "X 是 Y"
        pattern1 = r'(.+?)\s+是\s+(.+?)[,.!?。！？]'
        for match in re.finditer(pattern1, text):
            facts.append({
                'subject': match.group(1).strip(),
                'predicate': '是',
                'object': match.group(2).strip(),
                'category': 'fact'
            })
        
        # 模式 2: "X 喜欢 Y"
        pattern2 = r'(.+?)\s+喜欢\s+(.+?)[,.!?。！？]'
        for match in re.finditer(pattern2, text):
            facts.append({
                'subject': match.group(1).strip(),
                'predicate': '喜欢',
                'object': match.group(2).strip(),
                'category': 'preference'
            })
        
        # 模式 3: "X 在 Y 工作"
        pattern3 = r'(.+?)\s+在\s+(.+?)\s+工作 [,.!?。！？]?'
        for match in re.finditer(pattern3, text):
            facts.append({
                'subject': match.group(1).strip(),
                'predicate': '工作于',
                'object': match.group(2).strip(),
                'category': 'professional'
            })
        
        # 模式 4: "X 擅长 Y"
        pattern4 = r'(.+?)\s+擅长\s+(.+?)[,.!?。！？]'
        for match in re.finditer(pattern4, text):
            facts.append({
                'subject': match.group(1).strip(),
                'predicate': '擅长',
                'object': match.group(2).strip(),
                'category': 'skill'
            })
        
        # 模式 5: "X 居住在 Y"
        pattern5 = r'(.+?)\s+居住 [在于]?\s+(.+?)[,.!?。！？]'
        for match in re.finditer(pattern5, text):
            facts.append({
                'subject': match.group(1).strip(),
                'predicate': '居住于',
                'object': match.group(2).strip(),
                'category': 'context'
            })
        
        return facts
    
    def verify_with_anti_hallucination(
        self,
        candidate_facts: List[Dict[str, Any]],
        min_confidence: float = 0.9
    ) -> Dict[str, Any]:
        """
        防 AI 幻觉验证工作流
        
        Args:
            candidate_facts: 候选事实列表
            min_confidence: 最低置信度阈值
        
        Returns:
            验证结果
        """
        results = {
            'verified': [],
            'rejected': [],
            'conflicts': [],
            'low_confidence': []
        }
        
        for fact in candidate_facts:
            subject = fact.get('subject', '')
            predicate = fact.get('predicate', '')
            object_val = fact.get('object', '')
            
            # 1. 检查冲突
            has_conflict, conflicting = self.check_conflict(subject, predicate, object_val)
            
            if has_conflict:
                results['conflicts'].append({
                    **fact,
                    'conflicting_facts': conflicting,
                    'reason': '与已验证事实冲突'
                })
                continue
            
            # 2. 评估置信度
            confidence = self._evaluate_confidence(fact)
            
            if confidence < min_confidence:
                results['low_confidence'].append({
                    **fact,
                    'confidence': confidence,
                    'reason': f'置信度不足 ({confidence:.2f} < {min_confidence})'
                })
                continue
            
            # 3. 验证通过，添加到事实记忆
            fact_id, is_new = self.add_fact(
                subject=subject,
                predicate=predicate,
                object=object_val,
                category=fact.get('category', 'general'),
                confidence=confidence
            )
            
            if fact_id:
                results['verified'].append({
                    **fact,
                    'fact_id': fact_id,
                    'confidence': confidence
                })
            else:
                results['rejected'].append({
                    **fact,
                    'reason': '添加失败'
                })
        
        return results
    
    def _evaluate_confidence(self, fact: Dict[str, Any]) -> float:
        """
        评估事实置信度
        
        Args:
            fact: 事实
        
        Returns:
            置信度 (0-1)
        """
        confidence = 0.5  # 基础置信度
        
        # 规则 1: 来自主语明确的事实 +0.2
        if fact.get('subject') and len(fact['subject']) > 1:
            confidence += 0.2
        
        # 规则 2: 来自明确谓词的事实 +0.1
        if fact.get('predicate') in ['是', '喜欢', '工作于', '居住在', '擅长']:
            confidence += 0.1
        
        # 规则 3: 来自完整宾语的事实 +0.1
        if fact.get('object') and len(fact['object']) > 1:
            confidence += 0.1
        
        # 规则 4: 分类为 preference/professional 的事实 +0.1
        if fact.get('category') in ['preference', 'professional']:
            confidence += 0.1
        
        return min(1.0, confidence)
    
    def query_with_anti_hallucination(
        self,
        query: str,
        subject: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        带防 AI 幻觉的查询
        
        Args:
            query: 查询内容
            subject: 主体过滤
        
        Returns:
            {
                'answer': str,
                'confidence': float,
                'evidence': list,
                'source': str
            }
        """
        # 查询相关事实
        facts = self.query_facts(subject=subject, verified_only=True)
        
        if not facts:
            return {
                'answer': '未找到相关事实',
                'confidence': 0.0,
                'evidence': [],
                'source': 'memory_facts'
            }
        
        # 计算平均置信度
        avg_confidence = sum(f['confidence'] for f in facts) / len(facts)
        
        # 构建答案
        answer_parts = []
        for fact in facts[:5]:  # 最多返回 5 个事实
            answer_parts.append(f"{fact['subject']} {fact['predicate']} {fact['object']}")
        
        return {
            'answer': '；'.join(answer_parts),
            'confidence': avg_confidence,
            'evidence': facts,
            'source': 'memory_facts (verified)'
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        sql = """
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN verified = 1 THEN 1 ELSE 0 END) as verified,
                AVG(confidence) as avg_confidence
            FROM memory_facts
            WHERE deleted_at IS NULL
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql)
                row = cursor.fetchone()
                columns = [description[0] for description in cursor.description]
                row_dict = dict(zip(columns, row))
                
                return {
                    'total': row_dict['total'] or 0,
                    'verified': row_dict['verified'] or 0,
                    'avg_confidence': row_dict['avg_confidence'] or 0.0
                }
                
        except sqlite3.Error as e:
            raise


# 使用示例
if __name__ == "__main__":
    print("Fact Memory Manager + Anti-Hallucination - 测试")
    print("=" * 60)
    
    # 初始化
    db = DatabaseConnection('/tmp/test_facts.db')
    db.connect()
    manager = FactMemoryManager(db)
    
    # 提取事实
    print("\n1. 从文本提取事实...")
    text = "张三喜欢 Python。张三在腾讯工作。李四擅长机器学习。"
    facts = manager.extract_facts_from_text(text)
    print(f"   ✅ 提取到 {len(facts)} 个事实候选")
    for fact in facts:
        print(f"      - {fact['subject']} {fact['predicate']} {fact['object']}")
    
    # 防 AI 幻觉验证
    print("\n2. 防 AI 幻觉验证...")
    results = manager.verify_with_anti_hallucination(facts, min_confidence=0.7)
    print(f"   ✅ 验证通过：{len(results['verified'])}")
    print(f"   ⚠️ 置信度不足：{len(results['low_confidence'])}")
    print(f"   ❌ 冲突：{len(results['conflicts'])}")
    
    # 查询事实
    print("\n3. 查询事实...")
    zhangsan_facts = manager.query_facts(subject='张三')
    print(f"   ✅ 张三相关事实：{len(zhangsan_facts)}")
    
    # 带防 AI 幻觉的查询
    print("\n4. 带防 AI 幻觉的查询...")
    result = manager.query_with_anti_hallucination('张三的信息', subject='张三')
    print(f"   答案：{result['answer']}")
    print(f"   置信度：{result['confidence']:.2f}")
    print(f"   来源：{result['source']}")
    
    # 统计信息
    print("\n5. 获取统计信息...")
    stats = manager.get_stats()
    print(f"   ✅ 总计：{stats['total']}, 已验证：{stats['verified']}, 平均置信度：{stats['avg_confidence']:.2f}")
    
    print("\n" + "=" * 60)
    print("✅ 所有测试完成!")
