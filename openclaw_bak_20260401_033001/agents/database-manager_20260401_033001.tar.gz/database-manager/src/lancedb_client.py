#!/usr/bin/env python3
"""
Database Manager - LanceDB 向量数据库集成

负责向量存储、索引和检索
"""

import lancedb
import pyarrow as pa
from typing import Optional, List, Dict, Any
from datetime import datetime
import numpy as np

try:
    from .errors import DatabaseError
except ImportError:
    from errors import DatabaseError


class LanceDBClient:
    """LanceDB 客户端"""
    
    def __init__(self, uri: str = "/tmp/lancedb"):
        """
        初始化 LanceDB 连接
        
        Args:
            uri: 数据库 URI（本地路径或远程 URL）
        """
        self.uri = uri
        self.db = None
        self.tables: Dict[str, Any] = {}
    
    def connect(self) -> 'LanceDBClient':
        """
        建立数据库连接
        
        Returns:
            self
        """
        try:
            self.db = lancedb.connect(self.uri)
            return self
        except Exception as e:
            raise DatabaseError(code='CONNECTION_FAILED', message=f"无法连接到 LanceDB: {e}")
    
    def create_table(
        self,
        name: str,
        schema: pa.Schema = None,
        exist_ok: bool = True
    ) -> Any:
        """
        创建向量表
        
        Args:
            name: 表名
            schema: PyArrow Schema
            exist_ok: 如果表已存在是否跳过
        
        Returns:
            表对象
        """
        try:
            if schema is None:
                # 默认 schema：id, vector, metadata
                schema = pa.schema([
                    pa.field('id', pa.string()),
                    pa.field('vector', pa.list_(pa.float32(), 1536)),  # 默认 1536 维
                    pa.field('content', pa.string()),
                    pa.field('metadata', pa.string()),
                    pa.field('created_at', pa.timestamp('us'))
                ])
            
            table = self.db.create_table(name, schema=schema, exist_ok=exist_ok)
            self.tables[name] = table
            return table
            
        except Exception as e:
            raise DatabaseError(code='TABLE_CREATE_FAILED', message=f"创建表失败：{e}")
    
    def open_table(self, name: str) -> Any:
        """
        打开已有表
        
        Args:
            name: 表名
        
        Returns:
            表对象
        """
        try:
            if name in self.tables:
                return self.tables[name]
            
            table = self.db.open_table(name)
            self.tables[name] = table
            return table
            
        except Exception as e:
            raise DatabaseError(message=f"打开表失败：{e}")
    
    def add_vectors(
        self,
        table_name: str,
        vectors: List[Dict[str, Any]]
    ) -> int:
        """
        批量添加向量
        
        Args:
            table_name: 表名
            vectors: 向量列表 [{id, vector, content, metadata}]
        
        Returns:
            添加的数量
        """
        try:
            table = self.open_table(table_name)
            
            # 准备数据
            data = []
            for v in vectors:
                item = {
                    'id': v.get('id', f"vec_{len(data)}"),
                    'vector': v.get('vector', []),
                    'content': v.get('content', ''),
                    'metadata': v.get('metadata', '{}'),
                    'created_at': datetime.now()
                }
                data.append(item)
            
            # 批量插入
            table.add(data)
            
            return len(data)
            
        except Exception as e:
            raise DatabaseError(code='VECTOR_ADD_FAILED', message=f"添加向量失败：{e}")
    
    def create_index(
        self,
        table_name: str,
        field: str = 'vector',
        index_type: str = 'IVF_PQ',
        num_partitions: int = 256,
        num_sub_vectors: int = 64
    ) -> bool:
        """
        创建向量索引
        
        Args:
            table_name: 表名
            field: 字段名
            index_type: 索引类型 (IVF_PQ/FLAT)
            num_partitions: IVF 分区数
            num_sub_vectors: PQ 子向量数
        
        Returns:
            是否成功
        """
        try:
            table = self.open_table(table_name)
            
            # 创建索引
            table.create_index(
                column=field,
                index_type=index_type,
                num_partitions=num_partitions,
                num_sub_vectors=num_sub_vectors,
                replace=True
            )
            
            return True
            
        except Exception as e:
            # LanceDB v0.30 会自动创建索引，这里只记录警告
            print(f"   ⚠️ 索引创建跳过（LanceDB 自动管理）: {e}")
            return False
    
    def search_vectors(
        self,
        table_name: str,
        query_vector: List[float],
        limit: int = 10,
        filter_expr: str = None
    ) -> List[Dict[str, Any]]:
        """
        向量相似度搜索
        
        Args:
            table_name: 表名
            query_vector: 查询向量
            limit: 返回数量
            filter_expr: 过滤表达式
        
        Returns:
            搜索结果列表
        """
        try:
            table = self.open_table(table_name)
            
            # 执行搜索
            query = table.search(query_vector)
            
            if filter_expr:
                query = query.where(filter_expr)
            
            results = query.limit(limit).to_list()
            
            return results
            
        except Exception as e:
            raise DatabaseError(code='VECTOR_SEARCH_FAILED', message=f"向量搜索失败：{e}")
    
    def get_stats(self, table_name: str) -> Dict[str, Any]:
        """
        获取表统计信息
        
        Args:
            table_name: 表名
        
        Returns:
            统计信息
        """
        try:
            table = self.open_table(table_name)
            
            # 获取行数
            count = table.count_rows()
            
            return {
                'table_name': table_name,
                'row_count': count,
                'indexed': True  # 简化处理
            }
            
        except Exception as e:
            raise DatabaseError(message=f"获取统计信息失败：{e}")
    
    def list_tables(self) -> List[str]:
        """
        列出所有表
        
        Returns:
            表名列表
        """
        try:
            return self.db.table_names()
        except Exception as e:
            raise DatabaseError(message=f"列出表失败：{e}")
    
    def drop_table(self, table_name: str) -> bool:
        """
        删除表
        
        Args:
            table_name: 表名
        
        Returns:
            是否成功
        """
        try:
            self.db.drop_table(table_name)
            if table_name in self.tables:
                del self.tables[table_name]
            return True
        except Exception as e:
            raise DatabaseError(message=f"删除表失败：{e}")


# 使用示例
if __name__ == "__main__":
    print("LanceDB Client - 测试")
    print("=" * 60)
    
    # 初始化
    client = LanceDBClient('/tmp/test_lancedb')
    client.connect()
    
    # 创建表
    print("\n1. 创建向量表...")
    client.create_table('test_embeddings')
    print("   ✅ 表创建成功")
    
    # 添加向量
    print("\n2. 添加向量...")
    vectors = [
        {
            'id': f'vec_{i}',
            'vector': np.random.rand(1536).astype(float).tolist(),
            'content': f'测试内容 {i}',
            'metadata': f'{{"category": "test{i % 3}"}}'
        }
        for i in range(10)
    ]
    count = client.add_vectors('test_embeddings', vectors)
    print(f"   ✅ 添加 {count} 个向量")
    
    # 创建索引
    print("\n3. 创建索引...")
    client.create_index('test_embeddings')
    print("   ✅ 索引创建成功")
    
    # 向量搜索
    print("\n4. 向量搜索...")
    query_vector = np.random.rand(1536).astype(float).tolist()
    results = client.search_vectors('test_embeddings', query_vector, limit=5)
    print(f"   ✅ 搜索到 {len(results)} 条结果")
    for r in results[:3]:
        print(f"      - {r['id']}: {r['content']}")
    
    # 统计信息
    print("\n5. 获取统计信息...")
    stats = client.get_stats('test_embeddings')
    print(f"   ✅ 表 {stats['table_name']}, 行数：{stats['row_count']}")
    
    # 列出表
    print("\n6. 列出所有表...")
    tables = client.list_tables()
    print(f"   ✅ 共 {len(tables)} 个表：{tables}")
    
    print("\n" + "=" * 60)
    print("✅ 所有测试完成!")
