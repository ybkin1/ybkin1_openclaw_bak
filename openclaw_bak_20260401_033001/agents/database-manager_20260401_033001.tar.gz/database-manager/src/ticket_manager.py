#!/usr/bin/env python3
"""
Database Manager - 工单系统管理模块

负责工单的创建、分配、流转和统计
"""

import sqlite3
import uuid
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta

try:
    from .connection import DatabaseConnection
except ImportError:
    from connection import DatabaseConnection


class TicketManager:
    """工单管理器"""
    
    def __init__(self, db: DatabaseConnection):
        self.db = db
    
    # ========== 工单提交 ==========
    
    def create_ticket(
        self,
        org_id: str,
        reporter_id: str,
        title: str,
        description: str,
        ticket_type: str,
        ticket_category: str = None,
        ticket_priority: str = 'medium',
        sla_hours: int = 48,
        track_id: str = None,
        record_id: str = None,
        tags: List[str] = None
    ) -> str:
        """
        创建工单
        
        Args:
            org_id: 组织 ID
            reporter_id: 报告人 ID
            title: 工单标题
            description: 工单描述
            ticket_type: 类型 (bug/feature/question/complaint/incident)
            ticket_category: 分类
            ticket_priority: 优先级
            sla_hours: SLA 时限（小时）
            track_id: 关联赛道
            record_id: 关联记录
            tags: 标签列表
        
        Returns:
            ticket_id: 工单 ID
        """
        import json
        
        ticket_id = f"tkt_{uuid.uuid4().hex[:16]}"
        ticket_number = self._generate_ticket_number(org_id)
        due_at = datetime.now() + timedelta(hours=sla_hours)
        
        sql = """
            INSERT INTO tickets
            (ticket_id, org_id, ticket_number, title, description,
             ticket_type, ticket_category, ticket_priority, sla_hours, due_at,
             reporter_id, tags)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [
                    ticket_id,
                    org_id,
                    ticket_number,
                    title,
                    description,
                    ticket_type,
                    ticket_category,
                    ticket_priority,
                    sla_hours,
                    due_at,
                    reporter_id,
                    json.dumps(tags or [])
                ])
                self.db.conn.commit()
                
            return ticket_id
            
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def _generate_ticket_number(self, org_id: str) -> str:
        """生成工单编号"""
        year = datetime.now().year
        
        sql = """
            SELECT COUNT(*) FROM tickets
            WHERE org_id = ? AND strftime('%Y', created_at) = ?
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [org_id, str(year)])
                count = cursor.fetchone()[0]
                return f"TKT-{year}-{count + 1:04d}"
        except sqlite3.Error:
            return f"TKT-{year}-0001"
    
    # ========== 工单分配 ==========
    
    def assign_ticket(
        self,
        ticket_id: str,
        assignee_id: str,
        assigned_by: str
    ) -> bool:
        """
        分配工单
        
        Args:
            ticket_id: 工单 ID
            assignee_id: 处理人 ID
            assigned_by: 分配人 ID
        
        Returns:
            是否成功
        """
        sql = """
            UPDATE tickets
            SET 
                assignee_id = ?,
                status = 'in_progress',
                updated_at = CURRENT_TIMESTAMP
            WHERE ticket_id = ?
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [assignee_id, ticket_id])
                self.db.conn.commit()
                
                # 记录分配日志
                self._log_ticket_action(
                    ticket_id=ticket_id,
                    action='assigned',
                    user_id=assigned_by,
                    details={'assignee_id': assignee_id}
                )
                
                return True
                
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def auto_assign_ticket(
        self,
        ticket_id: str,
        available_assignees: List[str]
    ) -> Optional[str]:
        """
        自动分配工单（负载均衡）
        
        Args:
            ticket_id: 工单 ID
            available_assignees: 可用处理人列表
        
        Returns:
            assignee_id: 分配的处理人 ID
        """
        if not available_assignees:
            return None
        
        # 查询每个处理人的当前工单数
        sql = """
            SELECT assignee_id, COUNT(*) as ticket_count
            FROM tickets
            WHERE assignee_id IN ({})
            AND status IN ('open', 'in_progress')
            GROUP BY assignee_id
        """.format(','.join(['?' for _ in available_assignees]))
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, available_assignees)
                rows = cursor.fetchall()
                
                # 找到工单最少的人
                assignee_load = {row[0]: row[1] for row in rows}
                
                # 默认负载为 0（如果没有工单）
                assignee = min(
                    available_assignees,
                    key=lambda x: assignee_load.get(x, 0)
                )
                
                # 分配工单
                self.assign_ticket(ticket_id, assignee, 'system')
                
                return assignee
                
        except sqlite3.Error as e:
            raise
    
    # ========== 工单流转 ==========
    
    def update_status(
        self,
        ticket_id: str,
        status: str,
        user_id: str,
        resolution: str = None
    ) -> bool:
        """
        更新工单状态
        
        Args:
            ticket_id: 工单 ID
            status: 新状态
            user_id: 操作人 ID
            resolution: 解决方案（关闭时使用）
        
        Returns:
            是否成功
        """
        updates = ['status = ?', 'updated_at = CURRENT_TIMESTAMP']
        params = [status]
        
        if status == 'resolved' and resolution:
            updates.append('resolution = ?')
            updates.append('resolved_at = CURRENT_TIMESTAMP')
            updates.append('resolver_id = ?')
            params.extend([resolution, user_id])
        
        if status == 'closed':
            updates.append('closed_at = CURRENT_TIMESTAMP')
        
        sql = f"""
            UPDATE tickets
            SET {', '.join(updates)}
            WHERE ticket_id = ?
        """
        params.append(ticket_id)
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                self.db.conn.commit()
                
                # 记录状态变更日志
                self._log_ticket_action(
                    ticket_id=ticket_id,
                    action='status_changed',
                    user_id=user_id,
                    details={'status': status, 'resolution': resolution}
                )
                
                return True
                
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def add_comment(
        self,
        ticket_id: str,
        author_id: str,
        content: str,
        comment_type: str = 'comment',
        is_internal: bool = False
    ) -> str:
        """
        添加评论
        
        Args:
            ticket_id: 工单 ID
            author_id: 作者 ID
            content: 评论内容
            comment_type: 类型
            is_internal: 是否内部评论
        
        Returns:
            comment_id: 评论 ID
        """
        comment_id = f"cmt_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO ticket_comments
            (comment_id, ticket_id, author_id, content, comment_type, is_internal)
            VALUES (?, ?, ?, ?, ?, ?)
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [
                    comment_id,
                    ticket_id,
                    author_id,
                    content,
                    comment_type,
                    1 if is_internal else 0
                ])
                self.db.conn.commit()
                
            return comment_id
            
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    # ========== 工单查询 ==========
    
    def get_ticket(self, ticket_id: str) -> Optional[Dict[str, Any]]:
        """获取工单详情"""
        sql = "SELECT * FROM tickets WHERE ticket_id = ?"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [ticket_id])
                row = cursor.fetchone()
                if row:
                    columns = [description[0] for description in cursor.description]
                    return dict(zip(columns, row))
                return None
        except sqlite3.Error as e:
            raise
    
    def list_tickets(
        self,
        org_id: str,
        status: str = None,
        assignee_id: str = None,
        reporter_id: str = None,
        ticket_type: str = None,
        limit: int = 50,
        offset: int = 0
    ) -> List[Dict[str, Any]]:
        """
        查询工单列表
        
        Args:
            org_id: 组织 ID
            status: 状态过滤
            assignee_id: 处理人过滤
            reporter_id: 报告人过滤
            ticket_type: 类型过滤
            limit: 数量限制
            offset: 偏移量
        
        Returns:
            工单列表
        """
        conditions = ['org_id = ?']
        params = [org_id]
        
        if status:
            conditions.append('status = ?')
            params.append(status)
        
        if assignee_id:
            conditions.append('assignee_id = ?')
            params.append(assignee_id)
        
        if reporter_id:
            conditions.append('reporter_id = ?')
            params.append(reporter_id)
        
        if ticket_type:
            conditions.append('ticket_type = ?')
            params.append(ticket_type)
        
        where_clause = ' AND '.join(conditions)
        
        sql = f"""
            SELECT * FROM tickets
            WHERE {where_clause}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                columns = [description[0] for description in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
        except sqlite3.Error as e:
            raise
    
    # ========== 工单统计 ==========
    
    def get_stats(self, org_id: str, days: int = 30) -> Dict[str, Any]:
        """
        获取工单统计
        
        Args:
            org_id: 组织 ID
            days: 统计天数
        
        Returns:
            统计信息
        """
        since = datetime.now() - timedelta(days=days)
        
        stats = {}
        
        # 按状态统计
        sql_status = """
            SELECT status, COUNT(*) as count
            FROM tickets
            WHERE org_id = ? AND created_at >= ?
            GROUP BY status
        """
        
        # 按类型统计
        sql_type = """
            SELECT ticket_type, COUNT(*) as count
            FROM tickets
            WHERE org_id = ? AND created_at >= ?
            GROUP BY ticket_type
        """
        
        # SLA 达标率
        sql_sla = """
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN resolved_at <= due_at THEN 1 ELSE 0 END) as met_sla
            FROM tickets
            WHERE org_id = ? AND created_at >= ? AND resolved_at IS NOT NULL
        """
        
        try:
            with self.db.cursor() as cursor:
                # 状态统计
                cursor.execute(sql_status, [org_id, since.isoformat()])
                stats['by_status'] = {row[0]: row[1] for row in cursor.fetchall()}
                
                # 类型统计
                cursor.execute(sql_type, [org_id, since.isoformat()])
                stats['by_type'] = {row[0]: row[1] for row in cursor.fetchall()}
                
                # SLA 统计
                cursor.execute(sql_sla, [org_id, since.isoformat()])
                row = cursor.fetchone()
                total = row[0] or 0
                met = row[1] or 0
                stats['sla_compliance'] = (met / total * 100) if total > 0 else 100.0
                stats['total_tickets'] = total
                stats['sla_met'] = met
                
                return stats
                
        except sqlite3.Error as e:
            raise
    
    def _log_ticket_action(
        self,
        ticket_id: str,
        action: str,
        user_id: str,
        details: Dict[str, Any] = None
    ):
        """记录工单操作日志"""
        import json
        
        log_id = f"log_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO ticket_logs
            (log_id, ticket_id, action, user_id, details)
            VALUES (?, ?, ?, ?, ?)
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [
                    log_id,
                    ticket_id,
                    action,
                    user_id,
                    json.dumps(details or {})
                ])
                self.db.conn.commit()
        except sqlite3.Error:
            pass  # 日志记录失败不影响主流程


# 使用示例
if __name__ == "__main__":
    print("Ticket Manager - 测试")
    print("=" * 60)
    
    # 初始化
    db = DatabaseConnection('/tmp/test_tickets.db')
    db.connect()
    
    # 插入测试数据
    with db.cursor() as cursor:
        cursor.execute("INSERT OR IGNORE INTO organizations (org_id, name, type, status) VALUES ('org_demo', '测试组织', 'internal', 'active')")
        cursor.execute("INSERT OR IGNORE INTO users (user_id, org_id, username, email, role, status) VALUES ('user_001', 'org_demo', '张三', 'test@test.com', 'member', 'active')")
        cursor.execute("INSERT OR IGNORE INTO users (user_id, org_id, username, email, role, status) VALUES ('user_002', 'org_demo', '李四', 'test2@test.com', 'member', 'active')")
        db.conn.commit()
    
    manager = TicketManager(db)
    
    # 创建工单
    print("\n1. 创建工单...")
    ticket_id = manager.create_ticket(
        org_id='org_demo',
        reporter_id='user_001',
        title='测试工单',
        description='这是一个测试工单',
        ticket_type='bug',
        ticket_priority='high',
        sla_hours=24
    )
    print(f"   ✅ 创建成功：{ticket_id}")
    
    # 获取工单
    print("\n2. 获取工单详情...")
    ticket = manager.get_ticket(ticket_id)
    print(f"   ✅ 工单编号：{ticket['ticket_number']}, 状态：{ticket['status']}")
    
    # 分配工单
    print("\n3. 分配工单...")
    success = manager.assign_ticket(ticket_id, 'user_002', 'user_001')
    print(f"   ✅ 分配成功：{success}")
    
    # 更新状态
    print("\n4. 更新状态...")
    success = manager.update_status(ticket_id, 'resolved', 'user_002', '问题已解决')
    print(f"   ✅ 状态更新：{success}")
    
    # 添加评论
    print("\n5. 添加评论...")
    comment_id = manager.add_comment(ticket_id, 'user_001', '感谢解决！')
    print(f"   ✅ 评论成功：{comment_id}")
    
    # 统计信息
    print("\n6. 获取统计...")
    stats = manager.get_stats('org_demo', days=30)
    print(f"   ✅ 总工单：{stats['total_tickets']}, SLA 达标率：{stats['sla_compliance']:.1f}%")
    
    print("\n" + "=" * 60)
    print("✅ 所有测试完成!")
