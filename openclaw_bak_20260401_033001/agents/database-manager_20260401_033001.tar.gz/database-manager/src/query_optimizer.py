"""
Database Manager - 查询优化模块

提供执行计划分析、慢查询检测、索引建议
"""

import sqlite3
import time
from typing import List, Dict, Any, Optional
from functools import wraps

try:
    from .connection import DatabaseConnection
    from .errors import parse_sqlite_error
except ImportError:
    from connection import DatabaseConnection
    from errors import parse_sqlite_error


class QueryOptimizer:
    """查询优化类"""
    
    def __init__(self, db: DatabaseConnection):
        self.db = db
        self.slow_queries = []
        self.slow_threshold_ms = 1000
    
    def explain_query(self, sql: str, params: tuple = None) -> List[Dict[str, Any]]:
        """
        分析查询执行计划
        
        Args:
            sql: SQL 语句
            params: 参数
        
        Returns:
            执行计划步骤列表
        
        Example:
            plan = db.optimizer.explain_query(
                "SELECT * FROM users WHERE org_id = ? AND status = ?",
                ('org_123', 'active')
            )
        """
        explain_sql = f"EXPLAIN QUERY PLAN {sql}"
        
        try:
            with self.db.cursor() as cursor:
                if params:
                    cursor.execute(explain_sql, params)
                else:
                    cursor.execute(explain_sql)
                
                rows = cursor.fetchall()
                
                # 解析执行计划
                plan = []
                for row in rows:
                    plan.append({
                        'id': row[0],
                        'parent': row[1],
                        'notused': row[2],
                        'detail': row[3]
                    })
                
                return plan
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, explain_sql)
    
    def analyze_index_usage(self, table: str, query: str) -> Dict[str, Any]:
        """
        分析索引使用情况
        
        Args:
            table: 表名
            query: 查询语句
        
        Returns:
            索引使用分析报告
        """
        plan = self.explain_query(query)
        
        # 分析是否使用索引
        uses_index = False
        index_name = None
        scan_type = None
        
        for step in plan:
            detail = step['detail'].lower()
            if 'using index' in detail:
                uses_index = True
                if 'idx_' in detail:
                    index_name = detail.split('idx_')[1].split()[0]
            if 'scan' in detail:
                scan_type = 'FULL TABLE SCAN' if 'using index' not in detail else 'INDEX SCAN'
        
        return {
            'table': table,
            'query': query,
            'uses_index': uses_index,
            'index_name': index_name,
            'scan_type': scan_type,
            'plan': plan
        }
    
    def suggest_indexes(self, table: str, query: str) -> List[str]:
        """
        建议索引
        
        Args:
            table: 表名
            query: 查询语句
        
        Returns:
            建议的索引创建语句列表
        """
        # 简单分析 WHERE 子句
        import re
        
        where_match = re.search(r'WHERE\s+(.+?)(?:ORDER|LIMIT|$)', query, re.IGNORECASE)
        if not where_match:
            return []
        
        where_clause = where_match.group(1)
        
        # 提取字段名
        field_pattern = r'(\w+)\s*[=<>]'
        fields = re.findall(field_pattern, where_clause)
        
        if not fields:
            return []
        
        # 生成索引建议
        suggestions = []
        
        # 单字段索引
        for field in fields:
            if field not in ['AND', 'OR', 'NOT']:
                suggestions.append(f"CREATE INDEX IF NOT EXISTS idx_{table}_{field} ON {table}({field})")
        
        # 复合索引 (如果有多个字段)
        if len(fields) >= 2:
            fields_str = ', '.join(fields[:3])  # 最多 3 个字段
            suggestions.append(f"CREATE INDEX IF NOT EXISTS idx_{table}_composite ON {table}({fields_str})")
        
        return suggestions
    
    def get_table_indexes(self, table: str) -> List[Dict[str, Any]]:
        """
        获取表的所有索引
        
        Args:
            table: 表名
        
        Returns:
            索引信息列表
        """
        sql = """
            SELECT name, tbl_name, sql
            FROM sqlite_master
            WHERE type='index' AND tbl_name=?
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, (table,))
                rows = cursor.fetchall()
                
                return [
                    {
                        'name': row[0],
                        'table': row[1],
                        'sql': row[2]
                    }
                    for row in rows
                ]
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def get_slow_queries(self, threshold_ms: int = None) -> List[Dict[str, Any]]:
        """
        获取慢查询列表
        
        Args:
            threshold_ms: 阈值 (毫秒)
        
        Returns:
            慢查询列表
        """
        threshold = threshold_ms or self.slow_threshold_ms
        return [q for q in self.slow_queries if q['duration_ms'] >= threshold]
    
    def log_query(self, sql: str, duration_ms: float, params: tuple = None):
        """
        记录查询
        
        Args:
            sql: SQL 语句
            duration_ms: 执行时间 (毫秒)
            params: 参数
        """
        self.slow_queries.append({
            'sql': sql,
            'params': params,
            'duration_ms': duration_ms,
            'timestamp': datetime.now().isoformat()
        })
        
        # 保留最近 1000 条
        if len(self.slow_queries) > 1000:
            self.slow_queries = self.slow_queries[-1000:]
    
    def get_table_stats(self, table: str) -> Dict[str, Any]:
        """
        获取表统计信息
        
        Args:
            table: 表名
        
        Returns:
            统计表信息
        """
        stats = {}
        
        # 行数
        stats['row_count'] = self.db.fetch_value(f"SELECT COUNT(*) FROM {table}")
        
        # 索引数量
        indexes = self.get_table_indexes(table)
        stats['index_count'] = len(indexes)
        stats['indexes'] = indexes
        
        # 表大小 (近似)
        try:
            with self.db.cursor() as cursor:
                cursor.execute(f"PRAGMA page_count")
                page_count = cursor.fetchone()[0]
                cursor.execute(f"PRAGMA page_size")
                page_size = cursor.fetchone()[0]
                stats['approx_size_bytes'] = page_count * page_size
        except:
            pass
        
        return stats


def slow_query_logger(threshold_ms: int = 1000):
    """
    慢查询日志装饰器
    
    Example:
        @slow_query_logger(1000)
        def my_query(db, sql, params):
            return db.execute(sql, params)
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.time()
            result = func(*args, **kwargs)
            duration_ms = (time.time() - start) * 1000
            
            if duration_ms >= threshold_ms:
                # 获取 db 实例
                db = args[0] if args else kwargs.get('db')
                if hasattr(db, 'optimizer'):
                    sql = args[1] if len(args) > 1 else kwargs.get('sql')
                    params = args[2] if len(args) > 2 else kwargs.get('params')
                    db.optimizer.log_query(sql, duration_ms, params)
            
            return result
        return wrapper
    return decorator
