"""
Database Manager - 错误处理模块

定义统一的错误码和异常类
"""

from typing import Optional, Dict, Any


# 错误码定义
ERROR_CODES = {
    'DB_CONN_FAILED': '数据库连接失败',
    'DB_QUERY_FAILED': '查询执行失败',
    'DB_CONSTRAINT_VIOLATION': '约束违反',
    'DB_FOREIGN_KEY_VIOLATION': '外键约束违反',
    'DB_UNIQUE_VIOLATION': '唯一性约束违反',
    'DB_NOT_NULL_VIOLATION': 'NOT NULL 约束违反',
    'DB_CHECK_VIOLATION': 'CHECK 约束违反',
    'DB_TRANSACTION_FAILED': '事务失败',
    'DB_TIMEOUT': '操作超时',
    'DB_LOCKED': '数据库被锁定',
    'DB_VALIDATION_ERROR': '数据验证失败',
    'DB_JSON_INVALID': 'JSON 格式无效',
    'DB_RECORD_NOT_FOUND': '记录不存在',
    'DB_PERMISSION_DENIED': '权限不足',
}


class DatabaseError(Exception):
    """数据库异常基类"""
    
    def __init__(self, code: str, message: str = None, details: Dict[str, Any] = None):
        self.code = code
        self.message = message or ERROR_CODES.get(code, '未知数据库错误')
        self.details = details or {}
        super().__init__(f"[{code}] {self.message}")
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'code': self.code,
            'message': self.message,
            'details': self.details
        }


class ConnectionError(DatabaseError):
    """连接错误"""
    def __init__(self, message: str = None, details: Dict[str, Any] = None):
        super().__init__('DB_CONN_FAILED', message, details)


class QueryError(DatabaseError):
    """查询错误"""
    def __init__(self, message: str = None, sql: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if sql:
            details['sql'] = sql
        super().__init__('DB_QUERY_FAILED', message, details)


class ConstraintViolationError(DatabaseError):
    """约束违反错误"""
    pass


class ForeignKeyViolationError(ConstraintViolationError):
    """外键约束违反"""
    def __init__(self, table: str = None, field: str = None, value: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if table:
            details['table'] = table
        if field:
            details['field'] = field
        if value:
            details['value'] = value
        message = f"外键约束违反：{table}.{field} = {value}" if table and field else '外键约束违反'
        super().__init__('DB_FOREIGN_KEY_VIOLATION', message, details)


class UniqueViolationError(ConstraintViolationError):
    """唯一性约束违反"""
    def __init__(self, table: str = None, field: str = None, value: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if table:
            details['table'] = table
        if field:
            details['field'] = field
        if value:
            details['value'] = value
        message = f"唯一性约束违反：{table}.{field} = {value}" if table and field else '唯一性约束违反'
        super().__init__('DB_UNIQUE_VIOLATION', message, details)


class NotNullViolationError(ConstraintViolationError):
    """NOT NULL 约束违反"""
    def __init__(self, table: str = None, field: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if table:
            details['table'] = table
        if field:
            details['field'] = field
        message = f"NOT NULL 约束违反：{table}.{field}" if table and field else 'NOT NULL 约束违反'
        super().__init__('DB_NOT_NULL_VIOLATION', message, details)


class CheckViolationError(ConstraintViolationError):
    """CHECK 约束违反"""
    def __init__(self, table: str = None, constraint: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if table:
            details['table'] = table
        if constraint:
            details['constraint'] = constraint
        message = f"CHECK 约束违反：{table}.{constraint}" if table and constraint else 'CHECK 约束违反'
        super().__init__('DB_CHECK_VIOLATION', message, details)


class TransactionError(DatabaseError):
    """事务错误"""
    def __init__(self, message: str = None, details: Dict[str, Any] = None):
        super().__init__('DB_TRANSACTION_FAILED', message, details)


class TimeoutError(DatabaseError):
    """超时错误"""
    def __init__(self, message: str = None, operation: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if operation:
            details['operation'] = operation
        message = message or f"操作超时：{operation}" if operation else '操作超时'
        super().__init__('DB_TIMEOUT', message, details)


class LockedError(DatabaseError):
    """数据库锁定错误"""
    def __init__(self, message: str = None, details: Dict[str, Any] = None):
        super().__init__('DB_LOCKED', message or '数据库被锁定，请稍后重试', details)


class ValidationError(DatabaseError):
    """验证错误"""
    def __init__(self, message: str = None, field: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if field:
            details['field'] = field
        super().__init__('DB_VALIDATION_ERROR', message, details)


class JSONError(DatabaseError):
    """JSON 错误"""
    def __init__(self, message: str = None, field: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if field:
            details['field'] = field
        super().__init__('DB_JSON_INVALID', message, details)


class NotFoundError(DatabaseError):
    """记录不存在错误"""
    def __init__(self, table: str = None, record_id: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if table:
            details['table'] = table
        if record_id:
            details['record_id'] = record_id
        message = f"记录不存在：{table}.{record_id}" if table and record_id else '记录不存在'
        super().__init__('DB_RECORD_NOT_FOUND', message, details)


class PermissionError(DatabaseError):
    """权限错误"""
    def __init__(self, message: str = None, resource: str = None, action: str = None, details: Dict[str, Any] = None):
        details = details or {}
        if resource:
            details['resource'] = resource
        if action:
            details['action'] = action
        message = message or f"权限不足：无法{action} {resource}" if resource and action else '权限不足'
        super().__init__('DB_PERMISSION_DENIED', message, details)


def parse_sqlite_error(error: Exception, sql: str = None) -> DatabaseError:
    """
    解析 SQLite 错误，转换为对应的 DatabaseError
    
    Args:
        error: SQLite 异常
        sql: 执行的 SQL (可选)
    
    Returns:
        对应的 DatabaseError 实例
    """
    error_msg = str(error).lower()
    details = {'original_error': str(error)}
    if sql:
        details['sql'] = sql
    
    # 外键约束违反
    if 'foreign key constraint failed' in error_msg:
        return ForeignKeyViolationError(details=details)
    
    # 唯一性约束违反
    if 'unique constraint failed' in error_msg or 'column(s) is/are not unique' in error_msg:
        return UniqueViolationError(details=details)
    
    # NOT NULL 约束违反
    if 'not null constraint failed' in error_msg or 'column(s) is/are not unique' in error_msg:
        return NotNullViolationError(details=details)
    
    # CHECK 约束违反
    if 'check constraint failed' in error_msg:
        return CheckViolationError(details=details)
    
    # 数据库锁定
    if 'database is locked' in error_msg:
        return LockedError(details=details)
    
    # 超时
    if 'timeout' in error_msg:
        return TimeoutError(details=details)
    
    # 其他约束违反
    if 'constraint' in error_msg:
        return ConstraintViolationError(details=details)
    
    # 默认查询错误
    return QueryError(message=str(error), sql=sql, details=details)
