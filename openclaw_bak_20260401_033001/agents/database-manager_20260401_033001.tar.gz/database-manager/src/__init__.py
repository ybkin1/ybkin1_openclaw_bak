"""
Database Manager - 企业级 SQLite 数据库操作库

功能:
- 连接管理 (PRAGMA 配置、连接池)
- CRUD 操作 (增删改查)
- 事务管理
- 批量操作
- 数据验证
- 错误处理
- 审计日志
- 查询优化

使用示例:
    from database_manager import DatabaseManager
    
    # 初始化
    db = DatabaseManager('/path/to/database.db')
    
    # 查询
    user = db.fetch_one('users', {'user_id': 'user_001'})
    users = db.fetch_all('users', {'org_id': 'org_123'}, limit=10)
    
    # 插入
    user_id = db.insert('users', {
        'user_id': 'user_new',
        'username': 'newuser',
        'email': 'new@example.com'
    })
    
    # 更新
    db.update('users', {'status': 'active'}, {'user_id': 'user_new'})
    
    # 事务
    with db.transaction():
        db.insert('users', {...})
        db.insert('api_keys', {...})
    
    # 批量操作
    ids = db.batch_insert('users', user_list, chunk_size=1000)
"""

__version__ = '1.0.0'
__author__ = 'Database Manager Agent'

import sqlite3
from typing import Dict, Any, Optional
from contextlib import contextmanager

from .connection import DatabaseConnection, ConnectionPool, get_database
from .crud import CRUDOperations
from .transaction import TransactionManager
from .batch import BatchOperations
from .errors import (
    DatabaseError, ConnectionError, QueryError,
    ConstraintViolationError, ForeignKeyViolationError,
    UniqueViolationError, ValidationError, JSONError,
    NotFoundError, parse_sqlite_error
)
from .audit import AuditLogger
from .query_optimizer import QueryOptimizer


class DatabaseManager(CRUDOperations, BatchOperations):
    """
    Database Manager 主类
    
    提供完整的数据库操作功能
    """
    
    def __init__(self, db_path: str, config: Dict[str, Any] = None):
        """
        初始化 Database Manager
        
        Args:
            db_path: 数据库文件路径
            config: 配置参数
        
        Example:
            db = DatabaseManager('/root/.openclaw/data/app.db')
        """
        self.connection = DatabaseConnection(db_path, config)
        self.connection.connect()
        
        # 初始化模块
        CRUDOperations.__init__(self, self.connection)
        BatchOperations.__init__(self, self.connection)
        
        self.transaction_manager = TransactionManager(self.connection)
        self.audit_logger = None
        self.optimizer = QueryOptimizer(self.connection)
        
        # 配置
        self.config = config or {}
        if self.config.get('audit_enabled'):
            self.enable_audit(
                org_id=self.config.get('org_id'),
                user_id=self.config.get('user_id')
            )
    
    def close(self):
        """关闭数据库连接"""
        if self.audit_logger:
            self.audit_logger.flush()
        self.connection.close()
    
    def is_healthy(self) -> bool:
        """检查数据库连接是否健康"""
        return self.connection.is_healthy()
    
    def get_connection(self) -> sqlite3.Connection:
        """获取底层 SQLite 连接"""
        return self.connection.get_connection()
    
    def execute(self, sql: str, params: tuple = None) -> int:
        """
        执行原生 SQL
        
        Args:
            sql: SQL 语句
            params: 参数元组
        
        Returns:
            影响行数
        """
        try:
            with self.connection.cursor() as cursor:
                if params:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)
                self.connection.conn.commit()
                return cursor.rowcount
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def fetch_column(self, sql: str, params: tuple = None) -> list:
        """查询单列数据"""
        try:
            with self.connection.cursor() as cursor:
                if params:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)
                return [row[0] for row in cursor.fetchall()]
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def fetch_value(self, sql: str, params: tuple = None) -> Any:
        """查询单个值"""
        try:
            with self.connection.cursor() as cursor:
                if params:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)
                row = cursor.fetchone()
                return row[0] if row else None
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    @contextmanager
    def transaction(self, savepoint: bool = False, name: str = None):
        """
        事务上下文管理器
        
        Args:
            savepoint: 是否使用保存点 (嵌套事务)
            name: 保存点名称
        
        Example:
            with db.transaction():
                db.insert('users', {...})
                db.insert('api_keys', {...})
        """
        with self.transaction_manager.transaction(savepoint=savepoint, name=name):
            yield
    
    def enable_audit(self, org_id: str = None, user_id: str = None):
        """
        启用审计日志
        
        Args:
            org_id: 组织 ID
            user_id: 用户 ID
        """
        self.audit_logger = AuditLogger(self.connection, org_id=org_id, user_id=user_id)
    
    def disable_audit(self):
        """禁用审计日志"""
        if self.audit_logger:
            self.audit_logger.enabled = False
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        if self.audit_logger:
            self.audit_logger.flush()
        self.close()
        return False


# 便捷函数
def create_database(db_path: str, config: Dict[str, Any] = None) -> DatabaseManager:
    """创建 Database Manager 实例"""
    return DatabaseManager(db_path, config)


__all__ = [
    # 主类
    'DatabaseManager',
    'DatabaseConnection',
    'ConnectionPool',
    'CRUDOperations',
    'BatchOperations',
    'TransactionManager',
    'AuditLogger',
    'QueryOptimizer',
    
    # 错误类
    'DatabaseError',
    'ConnectionError',
    'QueryError',
    'ConstraintViolationError',
    'ForeignKeyViolationError',
    'UniqueViolationError',
    'ValidationError',
    'JSONError',
    'NotFoundError',
    
    # 便捷函数
    'create_database',
    'get_database',
]
