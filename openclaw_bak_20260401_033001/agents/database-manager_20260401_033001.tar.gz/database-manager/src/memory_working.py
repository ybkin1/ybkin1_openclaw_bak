#!/usr/bin/env python3
"""
Database Manager - 工作记忆管理模块 (L1)

负责短期记忆的存储、检索和 TTL 过期管理
"""

import sqlite3
import uuid
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta

try:
    from .connection import DatabaseConnection
except ImportError:
    from connection import DatabaseConnection


class WorkingMemoryManager:
    """工作记忆管理器"""
    
    def __init__(self, db: DatabaseConnection):
        self.db = db
    
    def add_memory(
        self,
        session_id: str,
        content: str,
        role: str = 'user',
        user_id: Optional[str] = None,
        metadata: Dict[str, Any] = None,
        ttl_hours: int = 24
    ) -> str:
        """
        添加工作记忆
        
        Args:
            session_id: 会话 ID
            content: 记忆内容
            role: 角色 (user/assistant/system)
            user_id: 用户 ID
            metadata: 元数据 (JSON)
            ttl_hours: 生存时间（小时）
        
        Returns:
            memory_id: 记忆 ID
        """
        import json
        
        memory_id = f"wm_{uuid.uuid4().hex[:16]}"
        expires_at = datetime.now() + timedelta(hours=ttl_hours)
        
        sql = """
            INSERT INTO memory_working 
            (memory_id, session_id, user_id, content, role, metadata, expires_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [
                    memory_id,
                    session_id,
                    user_id,
                    content,
                    role,
                    json.dumps(metadata or {}),
                    expires_at.isoformat()
                ])
                self.db.conn.commit()
                
            return memory_id
            
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def get_memories(
        self,
        session_id: str,
        limit: int = 10,
        include_expired: bool = False
    ) -> List[Dict[str, Any]]:
        """
        获取工作记忆
        
        Args:
            session_id: 会话 ID
            limit: 返回数量限制
            include_expired: 是否包含过期记忆
        
        Returns:
            记忆列表
        """
        import json
        
        if include_expired:
            sql = """
                SELECT * FROM memory_working
                WHERE session_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            """
        else:
            sql = """
                SELECT * FROM memory_working
                WHERE session_id = ? AND expires_at > CURRENT_TIMESTAMP
                ORDER BY created_at DESC
                LIMIT ?
            """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [session_id, limit])
                rows = cursor.fetchall()
                columns = [description[0] for description in cursor.description]
                
                memories = []
                for row in rows:
                    memory = dict(zip(columns, row))
                    if memory.get('metadata'):
                        memory['metadata'] = json.loads(memory['metadata'])
                    memories.append(memory)
                
                return memories
                
        except sqlite3.Error as e:
            raise
    
    def get_recent_conversation(
        self,
        session_id: str,
        limit: int = 10
    ) -> List[Dict[str, str]]:
        """
        获取最近对话（用于上下文）
        
        Args:
            session_id: 会话 ID
            limit: 返回消息数量
        
        Returns:
            对话列表 [{role, content, created_at}]
        """
        memories = self.get_memories(session_id, limit=limit, include_expired=False)
        
        # 按时间正序排列
        memories.reverse()
        
        return [
            {
                'role': m['role'],
                'content': m['content'],
                'created_at': m['created_at']
            }
            for m in memories
        ]
    
    def cleanup_expired(self) -> int:
        """
        清理过期记忆
        
        Returns:
            删除的记录数
        """
        sql = "DELETE FROM memory_working WHERE expires_at <= CURRENT_TIMESTAMP"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql)
                deleted_count = cursor.rowcount
                self.db.conn.commit()
                
            return deleted_count
            
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def export_session(self, session_id: str) -> Dict[str, Any]:
        """
        导出会话记忆
        
        Args:
            session_id: 会话 ID
        
        Returns:
            导出的数据
        """
        memories = self.get_memories(session_id, limit=1000, include_expired=True)
        
        return {
            'session_id': session_id,
            'memory_count': len(memories),
            'memories': memories,
            'exported_at': datetime.now().isoformat()
        }
    
    def get_stats(self, session_id: str = None) -> Dict[str, Any]:
        """
        获取统计信息
        
        Args:
            session_id: 会话 ID（可选）
        
        Returns:
            统计信息
        """
        if session_id:
            sql = """
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN expires_at > CURRENT_TIMESTAMP THEN 1 ELSE 0 END) as active,
                    SUM(CASE WHEN expires_at <= CURRENT_TIMESTAMP THEN 1 ELSE 0 END) as expired
                FROM memory_working
                WHERE session_id = ?
            """
            params = [session_id]
        else:
            sql = """
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN expires_at > CURRENT_TIMESTAMP THEN 1 ELSE 0 END) as active,
                    SUM(CASE WHEN expires_at <= CURRENT_TIMESTAMP THEN 1 ELSE 0 END) as expired
                FROM memory_working
            """
            params = []
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                row = cursor.fetchone()
                columns = [description[0] for description in cursor.description]
                row_dict = dict(zip(columns, row))
                
                return {
                    'total': row_dict['total'] or 0,
                    'active': row_dict['active'] or 0,
                    'expired': row_dict['expired'] or 0
                }
                
        except sqlite3.Error as e:
            raise


# 使用示例
if __name__ == "__main__":
    # 测试代码
    print("Working Memory Manager - 测试")
    print("=" * 60)
    
    # 初始化
    db = DatabaseConnection('/tmp/test_memory.db')
    db.connect()
    manager = WorkingMemoryManager(db)
    
    # 添加记忆
    print("\n1. 添加工作记忆...")
    memory_id = manager.add_memory(
        session_id='test_session_001',
        content='用户询问如何安装 Python',
        role='user',
        user_id='user_123',
        ttl_hours=24
    )
    print(f"   ✅ 添加成功：{memory_id}")
    
    # 获取记忆
    print("\n2. 获取工作记忆...")
    memories = manager.get_memories('test_session_001')
    print(f"   ✅ 获取到 {len(memories)} 条记忆")
    
    # 获取对话
    print("\n3. 获取最近对话...")
    conversation = manager.get_recent_conversation('test_session_001', limit=5)
    for msg in conversation:
        print(f"   - {msg['role']}: {msg['content'][:50]}...")
    
    # 统计信息
    print("\n4. 获取统计信息...")
    stats = manager.get_stats()
    print(f"   ✅ 总计：{stats['total']}, 活跃：{stats['active']}, 过期：{stats['expired']}")
    
    # 清理过期
    print("\n5. 清理过期记忆...")
    deleted = manager.cleanup_expired()
    print(f"   ✅ 清理 {deleted} 条过期记忆")
    
    print("\n" + "=" * 60)
    print("✅ 所有测试完成!")
