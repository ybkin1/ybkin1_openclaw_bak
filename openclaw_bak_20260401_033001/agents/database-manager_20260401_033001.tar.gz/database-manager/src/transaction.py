"""
Database Manager - 事务管理模块

提供事务支持、保存点、上下文管理器
"""

import sqlite3
from contextlib import contextmanager
from typing import Optional

try:
    from .connection import DatabaseConnection
    from .errors import TransactionError, parse_sqlite_error
except ImportError:
    from connection import DatabaseConnection
    from errors import TransactionError, parse_sqlite_error


class TransactionManager:
    """事务管理类"""
    
    def __init__(self, db: DatabaseConnection):
        """
        初始化事务管理器
        
        Args:
            db: 数据库连接对象
        """
        self.db = db
        self._savepoint_counter = 0
    
    def begin(self):
        """开始事务"""
        try:
            self.db.conn.execute("BEGIN")
        except sqlite3.Error as e:
            raise TransactionError(message=f"开始事务失败：{e}")
    
    def commit(self):
        """提交事务"""
        try:
            self.db.conn.commit()
        except sqlite3.Error as e:
            raise TransactionError(message=f"提交事务失败：{e}")
    
    def rollback(self):
        """回滚事务"""
        try:
            self.db.conn.rollback()
        except sqlite3.Error as e:
            raise TransactionError(message=f"回滚事务失败：{e}")
    
    def savepoint(self, name: str = None) -> str:
        """
        创建保存点
        
        Args:
            name: 保存点名称 (可选，自动生成)
        
        Returns:
            保存点名称
        """
        if name is None:
            self._savepoint_counter += 1
            name = f"sp_{self._savepoint_counter}"
        
        try:
            self.db.conn.execute(f"SAVEPOINT {name}")
            return name
        except sqlite3.Error as e:
            raise TransactionError(message=f"创建保存点失败：{e}")
    
    def rollback_to(self, name: str):
        """
        回滚到保存点
        
        Args:
            name: 保存点名称
        """
        try:
            self.db.conn.execute(f"ROLLBACK TO {name}")
        except sqlite3.Error as e:
            raise TransactionError(message=f"回滚到保存点失败：{e}")
    
    def release(self, name: str):
        """
        释放保存点
        
        Args:
            name: 保存点名称
        """
        try:
            self.db.conn.execute(f"RELEASE {name}")
        except sqlite3.Error as e:
            raise TransactionError(message=f"释放保存点失败：{e}")
    
    @contextmanager
    def transaction(self, savepoint: bool = False, name: str = None):
        """
        事务上下文管理器
        
        Args:
            savepoint: 是否使用保存点 (嵌套事务)
            name: 保存点名称
        
        Yields:
            None
        
        Example:
            # 普通事务
            with tm.transaction():
                db.insert('users', {...})
                db.insert('api_keys', {...})
            
            # 嵌套事务 (保存点)
            with tm.transaction():
                db.insert('users', {...})
                try:
                    with tm.transaction(savepoint=True, name='sp1'):
                        db.insert('api_keys', {...})
                except Exception:
                    pass  # 回滚到保存点，不影响外层事务
        """
        if savepoint:
            # 嵌套事务 - 使用保存点
            sp_name = self.savepoint(name)
            try:
                yield
                self.release(sp_name)
            except Exception:
                self.rollback_to(sp_name)
                raise
        else:
            # 普通事务
            self.begin()
            try:
                yield
                self.commit()
            except Exception as e:
                self.rollback()
                raise
    
    @contextmanager
    def nested_transaction(self, name: str = None):
        """
        嵌套事务上下文管理器 (保存点的便捷方法)
        
        Args:
            name: 保存点名称
        
        Example:
            with tm.transaction():
                db.insert('users', {...})
                with tm.nested_transaction():
                    db.insert('api_keys', {...})
        """
        with self.transaction(savepoint=True, name=name):
            yield


class AutoCommitManager:
    """自动提交管理器"""
    
    def __init__(self, db: DatabaseConnection):
        self.db = db
        self._original_isolation = None
    
    def __enter__(self):
        """进入自动提交模式"""
        self._original_isolation = self.db.conn.isolation_level
        self.db.conn.isolation_level = None  # 自动提交
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出自动提交模式"""
        if self._original_isolation is not None:
            self.db.conn.isolation_level = self._original_isolation
        return False
