#!/usr/bin/env python3
"""
Database Manager - NLP 增强事实提取模块

使用简单规则 + 置信度评分提升事实提取准确率
TODO: 未来集成真实 NLP 模型（如 ChatGLM、Qwen）
"""

import re
from typing import List, Dict, Any


class NLPEnhancedExtractor:
    """NLP 增强事实提取器"""
    
    def __init__(self):
        # 定义更丰富的提取模式
        self.patterns = [
            # 模式 1: "X 是 Y"
            {
                'pattern': r'(.+?)\s+是\s+(.+?)[,.!?。！？]',
                'predicate': '是',
                'category': 'fact',
                'confidence': 0.85
            },
            # 模式 2: "X 喜欢 Y"
            {
                'pattern': r'(.+?)\s+喜欢\s+(.+?)[,.!?。！？]',
                'predicate': '喜欢',
                'category': 'preference',
                'confidence': 0.90
            },
            # 模式 3: "X 在 Y 工作"
            {
                'pattern': r'(.+?)\s+在\s+(.+?)\s+工作 [,.!?。！？]?',
                'predicate': '工作于',
                'category': 'professional',
                'confidence': 0.88
            },
            # 模式 4: "X 擅长 Y"
            {
                'pattern': r'(.+?)\s+擅长\s+(.+?)[,.!?。！？]',
                'predicate': '擅长',
                'category': 'skill',
                'confidence': 0.87
            },
            # 模式 5: "X 居住在 Y"
            {
                'pattern': r'(.+?)\s+居住 [在于]?\s+(.+?)[,.!?。！？]',
                'predicate': '居住于',
                'category': 'context',
                'confidence': 0.86
            },
            # 模式 6: "X 毕业于 Y"
            {
                'pattern': r'(.+?)\s+毕业 [于]?\s+(.+?)[,.!?。！？]',
                'predicate': '毕业于',
                'category': 'professional',
                'confidence': 0.89
            },
            # 模式 7: "X 担任 Y 职位"
            {
                'pattern': r'(.+?)\s+担任\s+(.+?)[,.!?。！？]',
                'predicate': '担任',
                'category': 'professional',
                'confidence': 0.88
            },
            # 模式 8: "X 拥有 Y 技能"
            {
                'pattern': r'(.+?)\s+拥有\s+(.+?)\s+技能 [,.!?。！？]?',
                'predicate': '拥有技能',
                'category': 'skill',
                'confidence': 0.85
            }
        ]
    
    def extract_facts(self, text: str) -> List[Dict[str, Any]]:
        """
        提取事实（增强版）
        
        Args:
            text: 输入文本
        
        Returns:
            事实列表（带置信度）
        """
        facts = []
        
        for pattern_config in self.patterns:
            pattern = pattern_config['pattern']
            
            for match in re.finditer(pattern, text):
                subject = match.group(1).strip()
                object_val = match.group(2).strip()
                
                # 验证主体和客体有效性
                if self._is_valid_entity(subject) and self._is_valid_entity(object_val):
                    facts.append({
                        'subject': subject,
                        'predicate': pattern_config['predicate'],
                        'object': object_val,
                        'category': pattern_config['category'],
                        'confidence': pattern_config['confidence'],
                        'source_pattern': pattern_config['pattern']
                    })
        
        # 按置信度排序
        facts.sort(key=lambda x: x['confidence'], reverse=True)
        
        return facts
    
    def _is_valid_entity(self, text: str) -> bool:
        """
        验证实体有效性
        
        Args:
            text: 实体文本
        
        Returns:
            是否有效
        """
        # 长度检查
        if len(text) < 2 or len(text) > 100:
            return False
        
        # 排除常见无效模式
        invalid_patterns = [
            r'^[,.!?。！？]+$',  # 纯标点
            r'^[0-9]+$',  # 纯数字
            r'^(我 | 你 | 他 | 她 | 它)$',  # 单字代词
        ]
        
        for pattern in invalid_patterns:
            if re.match(pattern, text):
                return False
        
        return True
    
    def extract_with_nlp_enhancement(self, text: str) -> Dict[str, Any]:
        """
        NLP 增强提取（带分析）
        
        Args:
            text: 输入文本
        
        Returns:
            提取结果（含分析）
        """
        facts = self.extract_facts(text)
        
        # 分析统计
        analysis = {
            'input_length': len(text),
            'facts_count': len(facts),
            'categories': {},
            'avg_confidence': 0.0,
            'high_confidence_count': 0
        }
        
        # 分类统计
        for fact in facts:
            cat = fact['category']
            analysis['categories'][cat] = analysis['categories'].get(cat, 0) + 1
            
            if fact['confidence'] >= 0.85:
                analysis['high_confidence_count'] += 1
        
        # 平均置信度
        if facts:
            analysis['avg_confidence'] = sum(f['confidence'] for f in facts) / len(facts)
        
        return {
            'facts': facts,
            'analysis': analysis,
            'status': 'success' if facts else 'no_facts_found'
        }


# 使用示例
if __name__ == "__main__":
    print("NLP 增强事实提取器 - 测试")
    print("=" * 60)
    
    extractor = NLPEnhancedExtractor()
    
    # 测试文本
    text = "张三喜欢 Python。张三在腾讯工作，担任高级工程师。李四擅长机器学习和深度学习。王五居住在北京，毕业于清华大学。"
    
    print(f"\n输入文本：{text}\n")
    
    # 提取事实
    result = extractor.extract_with_nlp_enhancement(text)
    
    print(f"提取结果:")
    print(f"  事实数量：{result['analysis']['facts_count']}")
    print(f"  平均置信度：{result['analysis']['avg_confidence']:.2f}")
    print(f"  高置信度：{result['analysis']['high_confidence_count']}")
    print(f"\n分类统计:")
    for cat, count in result['analysis']['categories'].items():
        print(f"  - {cat}: {count}")
    
    print(f"\n详细事实:")
    for fact in result['facts']:
        print(f"  - {fact['subject']} {fact['predicate']} {fact['object']}")
        print(f"    分类：{fact['category']}, 置信度：{fact['confidence']:.2f}")
    
    print("\n" + "=" * 60)
    print("✅ NLP 增强提取测试完成!")
    print("\n下一步：集成真实 NLP 模型（ChatGLM/Qwen）进一步提升准确率")
