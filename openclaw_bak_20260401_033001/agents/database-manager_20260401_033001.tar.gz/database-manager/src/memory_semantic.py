#!/usr/bin/env python3
"""
Database Manager - 语义记忆管理模块 (L2)

负责长期语义记忆的存储、检索和置信度管理
"""

import sqlite3
import uuid
from typing import Optional, List, Dict, Any
from datetime import datetime

try:
    from .connection import DatabaseConnection
except ImportError:
    from connection import DatabaseConnection


class SemanticMemoryManager:
    """语义记忆管理器"""
    
    def __init__(self, db: DatabaseConnection):
        self.db = db
    
    def add_memory(
        self,
        content: str,
        category: str = 'general',
        confidence: float = 0.8,
        summary: Optional[str] = None,
        source_session_id: Optional[str] = None,
        source_message_id: Optional[str] = None
    ) -> str:
        """
        添加语义记忆
        
        Args:
            content: 记忆内容
            category: 分类 (fact/opinion/preference/context/emotion/general)
            confidence: 置信度 (0-1)
            summary: 摘要
            source_session_id: 来源会话 ID
            source_message_id: 来源消息 ID
        
        Returns:
            memory_id: 记忆 ID
        """
        memory_id = f"sm_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO memory_semantic 
            (memory_id, content, category, confidence, summary, 
             source_session_id, source_message_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [
                    memory_id,
                    content,
                    category,
                    confidence,
                    summary,
                    source_session_id,
                    source_message_id
                ])
                self.db.conn.commit()
                
            return memory_id
            
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def search(
        self,
        category: Optional[str] = None,
        min_confidence: float = 0.7,
        limit: int = 50,
        verified_only: bool = False
    ) -> List[Dict[str, Any]]:
        """
        检索语义记忆
        
        Args:
            category: 分类过滤
            min_confidence: 最低置信度
            limit: 返回数量限制
            verified_only: 仅返回已验证
        
        Returns:
            记忆列表
        """
        conditions = ['confidence >= ?', 'deleted_at IS NULL']
        params = [min_confidence]
        
        if category:
            conditions.append('category = ?')
            params.append(category)
        
        if verified_only:
            conditions.append('verified = 1')
        
        where_clause = ' AND '.join(conditions)
        
        sql = f"""
            SELECT * FROM memory_semantic
            WHERE {where_clause}
            ORDER BY confidence DESC, last_accessed_at DESC
            LIMIT ?
        """
        params.append(limit)
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                columns = [description[0] for description in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
                
        except sqlite3.Error as e:
            raise
    
    def update_access_stats(self, memory_id: str) -> bool:
        """
        更新访问统计
        
        Args:
            memory_id: 记忆 ID
        
        Returns:
            是否成功
        """
        sql = """
            UPDATE memory_semantic
            SET 
                access_count = access_count + 1,
                last_accessed_at = CURRENT_TIMESTAMP
            WHERE memory_id = ?
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [memory_id])
                self.db.conn.commit()
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def adjust_confidence(
        self,
        memory_id: str,
        delta: float,
        verified_by: Optional[str] = None
    ) -> float:
        """
        调整置信度
        
        Args:
            memory_id: 记忆 ID
            delta: 调整值（正数增加，负数减少）
            verified_by: 验证者
        
        Returns:
            新的置信度
        """
        # 先获取当前置信度
        current = self.get_memory(memory_id)
        if not current:
            raise ValueError(f"记忆不存在：{memory_id}")
        
        new_confidence = max(0.0, min(1.0, current['confidence'] + delta))
        
        sql = """
            UPDATE memory_semantic
            SET 
                confidence = ?,
                verified = CASE WHEN ? >= 0.9 THEN 1 ELSE verified END,
                verified_by = CASE WHEN ? >= 0.9 THEN ? ELSE verified_by END,
                verified_at = CASE WHEN ? >= 0.9 THEN CURRENT_TIMESTAMP ELSE verified_at END
            WHERE memory_id = ?
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [
                    new_confidence,
                    new_confidence,
                    new_confidence,
                    verified_by,
                    new_confidence,
                    memory_id
                ])
                self.db.conn.commit()
                
            return new_confidence
            
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def get_memory(self, memory_id: str) -> Optional[Dict[str, Any]]:
        """
        获取单个记忆
        
        Args:
            memory_id: 记忆 ID
        
        Returns:
            记忆详情
        """
        sql = "SELECT * FROM memory_semantic WHERE memory_id = ?"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [memory_id])
                row = cursor.fetchone()
                if row:
                    columns = [description[0] for description in cursor.description]
                    return dict(zip(columns, row))
                return None
                
        except sqlite3.Error as e:
            raise
    
    def verify_memory(
        self,
        memory_id: str,
        verified_by: str,
        verification_type: str = 'user_confirm'
    ) -> bool:
        """
        验证记忆
        
        Args:
            memory_id: 记忆 ID
            verified_by: 验证者
            verification_type: 验证类型
        
        Returns:
            是否成功
        """
        sql = """
            UPDATE memory_semantic
            SET 
                verified = 1,
                verified_by = ?,
                verified_at = CURRENT_TIMESTAMP
            WHERE memory_id = ?
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [verified_by, memory_id])
                self.db.conn.commit()
                
                # 记录验证日志
                self._log_verification(
                    memory_id=memory_id,
                    memory_type='semantic',
                    verification_type=verification_type,
                    result='confirmed',
                    verified_by=verified_by
                )
                
                return True
                
        except sqlite3.Error as e:
            self.db.conn.rollback()
            raise
    
    def _log_verification(
        self,
        memory_id: str,
        memory_type: str,
        verification_type: str,
        result: str,
        verified_by: str,
        original_content: Optional[str] = None,
        verified_content: Optional[str] = None,
        reason: Optional[str] = None,
        confidence_before: Optional[float] = None,
        confidence_after: Optional[float] = None
    ):
        """记录验证日志"""
        import json
        
        log_id = f"vl_{uuid.uuid4().hex[:16]}"
        
        sql = """
            INSERT INTO memory_verification_log
            (log_id, memory_id, memory_type, verification_type,
             original_content, verified_content, result, reason,
             confidence_before, confidence_after, verified_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, [
                    log_id,
                    memory_id,
                    memory_type,
                    verification_type,
                    original_content,
                    verified_content,
                    result,
                    reason,
                    confidence_before,
                    confidence_after,
                    verified_by
                ])
                self.db.conn.commit()
        except sqlite3.Error:
            pass  # 日志记录失败不影响主流程
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        sql = """
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN verified = 1 THEN 1 ELSE 0 END) as verified,
                SUM(CASE WHEN confidence >= 0.9 THEN 1 ELSE 0 END) as high_confidence,
                AVG(confidence) as avg_confidence
            FROM memory_semantic
            WHERE deleted_at IS NULL
        """
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql)
                row = cursor.fetchone()
                columns = [description[0] for description in cursor.description]
                row_dict = dict(zip(columns, row))
                
                return {
                    'total': row_dict['total'] or 0,
                    'verified': row_dict['verified'] or 0,
                    'high_confidence': row_dict['high_confidence'] or 0,
                    'avg_confidence': row_dict['avg_confidence'] or 0.0
                }
                
        except sqlite3.Error as e:
            raise


# 使用示例
if __name__ == "__main__":
    print("Semantic Memory Manager - 测试")
    print("=" * 60)
    
    # 初始化
    db = DatabaseConnection('/tmp/test_semantic.db')
    db.connect()
    manager = SemanticMemoryManager(db)
    
    # 添加记忆
    print("\n1. 添加语义记忆...")
    memory_id = manager.add_memory(
        content='用户偏好使用 Python 进行开发',
        category='preference',
        confidence=0.85,
        source_session_id='session_001'
    )
    print(f"   ✅ 添加成功：{memory_id}")
    
    # 检索记忆
    print("\n2. 检索语义记忆...")
    memories = manager.search(category='preference', min_confidence=0.8)
    print(f"   ✅ 检索到 {len(memories)} 条记忆")
    
    # 更新访问统计
    print("\n3. 更新访问统计...")
    success = manager.update_access_stats(memory_id)
    print(f"   ✅ 更新成功：{success}")
    
    # 调整置信度
    print("\n4. 调整置信度...")
    new_conf = manager.adjust_confidence(memory_id, 0.1, verified_by='system')
    print(f"   ✅ 新置信度：{new_conf}")
    
    # 验证记忆
    print("\n5. 验证记忆...")
    success = manager.verify_memory(memory_id, 'user_123')
    print(f"   ✅ 验证成功：{success}")
    
    # 统计信息
    print("\n6. 获取统计信息...")
    stats = manager.get_stats()
    print(f"   ✅ 总计：{stats['total']}, 已验证：{stats['verified']}, 平均置信度：{stats['avg_confidence']:.2f}")
    
    print("\n" + "=" * 60)
    print("✅ 所有测试完成!")
