"""
Database Manager - 连接管理模块

负责数据库连接初始化、配置、池化管理
"""

import sqlite3
import os
from typing import Optional, Dict, Any
from contextlib import contextmanager

try:
    from .errors import ConnectionError, parse_sqlite_error
except ImportError:
    from errors import ConnectionError, parse_sqlite_error


class DatabaseConnection:
    """数据库连接管理类"""
    
    def __init__(self, db_path: str, config: Dict[str, Any] = None):
        """
        初始化数据库连接
        
        Args:
            db_path: 数据库文件路径
            config: 配置参数
        """
        self.db_path = db_path
        self.config = config or {}
        self.conn: Optional[sqlite3.Connection] = None
        
        # 默认配置
        self.pragma_config = {
            'foreign_keys': 'ON',
            'journal_mode': 'WAL',
            'synchronous': 'NORMAL',
            'cache_size': -64000,  # 64MB
            'temp_store': 'MEMORY',
            'busy_timeout': 5000,
        }
        
        # 覆盖配置
        if 'pragma' in self.config:
            self.pragma_config.update(self.config['pragma'])
    
    def connect(self) -> sqlite3.Connection:
        """
        建立数据库连接
        
        Returns:
            sqlite3.Connection 对象
        
        Raises:
            ConnectionError: 连接失败时抛出
        """
        try:
            # 确保目录存在
            db_dir = os.path.dirname(self.db_path)
            if db_dir and not os.path.exists(db_dir):
                os.makedirs(db_dir, exist_ok=True)
            
            # 创建连接
            self.conn = sqlite3.connect(
                self.db_path,
                timeout=self.pragma_config.get('busy_timeout', 5000) / 1000.0,
                check_same_thread=False,  # 允许多线程
                isolation_level=None  # 自动提交模式
            )
            
            # 配置 PRAGMA
            self._configure_pragmas()
            
            return self.conn
            
        except sqlite3.Error as e:
            raise ConnectionError(message=f"无法连接到数据库：{e}", details={'path': self.db_path})
    
    def _configure_pragmas(self):
        """配置 SQLite PRAGMA 参数"""
        if not self.conn:
            return
        
        cursor = self.conn.cursor()
        
        try:
            # 启用外键约束 (必须！)
            cursor.execute("PRAGMA foreign_keys = ON")
            
            # 验证外键已启用
            result = cursor.execute("PRAGMA foreign_keys").fetchone()
            if result[0] != 1:
                raise ConnectionError("无法启用外键约束")
            
            # 配置其他 PRAGMA
            for key, value in self.pragma_config.items():
                if key != 'foreign_keys':  # foreign_keys 已单独处理
                    cursor.execute(f"PRAGMA {key} = {value}")
            
            self.conn.commit()
            
        except sqlite3.Error as e:
            raise ConnectionError(message=f"PRAGMA 配置失败：{e}")
    
    def close(self):
        """关闭数据库连接"""
        if self.conn:
            self.conn.close()
            self.conn = None
    
    def is_healthy(self) -> bool:
        """
        检查数据库连接是否健康
        
        Returns:
            bool: 连接是否健康
        """
        if not self.conn:
            return False
        
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT 1")
            cursor.fetchone()
            
            # 验证外键已启用
            result = cursor.execute("PRAGMA foreign_keys").fetchone()
            if result[0] != 1:
                return False
            
            return True
            
        except sqlite3.Error:
            return False
    
    def get_connection(self) -> sqlite3.Connection:
        """
        获取数据库连接
        
        Returns:
            sqlite3.Connection 对象
        
        Raises:
            ConnectionError: 连接不可用时抛出
        """
        if not self.is_healthy():
            self.connect()
        return self.conn
    
    @contextmanager
    def cursor(self):
        """
        上下文管理器：获取游标
        
        Yields:
            sqlite3.Cursor 对象
        
        Example:
            with db.cursor() as cur:
                cur.execute("SELECT * FROM users")
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            yield cursor
        finally:
            cursor.close()
    
    def __enter__(self):
        """上下文管理器入口"""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
        return False  # 不吞异常


class ConnectionPool:
    """简单连接池 (单例模式)"""
    
    _instance = None
    _connections: Dict[str, DatabaseConnection] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def get_connection(self, db_path: str, config: Dict[str, Any] = None) -> DatabaseConnection:
        """
        获取数据库连接
        
        Args:
            db_path: 数据库文件路径
            config: 配置参数
        
        Returns:
            DatabaseConnection 对象
        """
        if db_path not in self._connections:
            self._connections[db_path] = DatabaseConnection(db_path, config)
        
        conn = self._connections[db_path]
        if not conn.is_healthy():
            conn.connect()
        
        return conn
    
    def close_all(self):
        """关闭所有连接"""
        for conn in self._connections.values():
            conn.close()
        self._connections.clear()


# 全局连接池
pool = ConnectionPool()


def get_database(db_path: str, config: Dict[str, Any] = None) -> DatabaseConnection:
    """
    获取数据库连接 (便捷函数)
    
    Args:
        db_path: 数据库文件路径
        config: 配置参数
    
    Returns:
        DatabaseConnection 对象
    
    Example:
        db = get_database('/path/to/database.db')
        with db.cursor() as cur:
            cur.execute("SELECT * FROM users")
    """
    return pool.get_connection(db_path, config)
