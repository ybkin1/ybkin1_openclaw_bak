"""
Database Manager - JSON 字段验证模块

功能:
- JSON Schema 验证
- 权限字段验证
- 配置字段验证
- 自定义字段验证
- 结构化数据校验
"""

import json
import re
from typing import Any, Dict, List, Optional, Union
from datetime import datetime


class JSONValidator:
    """JSON 字段验证器"""
    
    # 预定义 Schema
    SCHEMAS = {
        'permissions': {
            'type': 'object',
            'required': ['modules', 'data_scope'],
            'properties': {
                'modules': {'type': 'object'},
                'data_scope': {
                    'type': 'string',
                    'enum': ['org', 'team', 'self']
                },
                'api_rate_limit': {'type': 'integer', 'minimum': 0}
            }
        },
        'config': {
            'type': 'object',
            'properties': {
                'theme': {'type': 'string'},
                'language': {'type': 'string'},
                'notifications': {'type': 'boolean'},
                'timezone': {'type': 'string'}
            }
        },
        'custom_fields': {
            'type': 'object',
            'additionalProperties': True
        },
        'metadata': {
            'type': 'object',
            'properties': {
                'source': {'type': 'string'},
                'tags': {'type': 'array', 'items': {'type': 'string'}},
                'created_by': {'type': 'string'}
            }
        }
    }
    
    def __init__(self, strict: bool = False):
        """
        初始化 JSON 验证器
        
        Args:
            strict: 严格模式 (不允许额外字段)
        """
        self.strict = strict
        self.errors = []
    
    def validate(self, data: Any, schema: Dict = None, 
                 schema_name: str = None) -> bool:
        """
        验证 JSON 数据
        
        Args:
            data: 待验证数据
            schema: JSON Schema
            schema_name: 预定义 Schema 名称
        
        Returns:
            bool: 是否通过验证
        
        Example:
            validator = JSONValidator()
            is_valid = validator.validate(
                {'modules': {}, 'data_scope': 'org'},
                schema_name='permissions'
            )
        """
        self.errors = []
        
        # 使用预定义 Schema
        if schema_name and schema_name in self.SCHEMAS:
            schema = self.SCHEMAS[schema_name]
        
        if not schema:
            # 没有 Schema 时只做基本验证
            return self._basic_validate(data)
        
        # 类型验证
        if not self._validate_type(data, schema):
            return False
        
        # 必需字段验证
        if not self._validate_required(data, schema):
            return False
        
        # 属性验证
        if not self._validate_properties(data, schema):
            return False
        
        # 枚举验证
        if not self._validate_enum(data, schema):
            return False
        
        # 数值范围验证
        if not self._validate_numeric(data, schema):
            return False
        
        return len(self.errors) == 0
    
    def _basic_validate(self, data: Any) -> bool:
        """基本验证"""
        try:
            # 确保可以 JSON 序列化
            json.dumps(data, ensure_ascii=False)
            return True
        except (TypeError, ValueError) as e:
            self.errors.append(f"JSON 序列化失败：{e}")
            return False
    
    def _validate_type(self, data: Any, schema: Dict) -> bool:
        """类型验证"""
        expected_type = schema.get('type')
        
        if not expected_type:
            return True
        
        type_map = {
            'string': str,
            'integer': int,
            'number': (int, float),
            'boolean': bool,
            'array': list,
            'object': dict,
            'null': type(None)
        }
        
        python_type = type_map.get(expected_type)
        
        if python_type and not isinstance(data, python_type):
            self.errors.append(
                f"类型错误：期望 {expected_type}, 得到 {type(data).__name__}"
            )
            return False
        
        return True
    
    def _validate_required(self, data: Dict, schema: Dict) -> bool:
        """必需字段验证"""
        required = schema.get('required', [])
        
        if not required:
            return True
        
        for field in required:
            if field not in data:
                self.errors.append(f"缺少必需字段：{field}")
                return False
        
        return True
    
    def _validate_properties(self, data: Dict, schema: Dict) -> bool:
        """属性验证"""
        properties = schema.get('properties', {})
        
        if not properties:
            return True
        
        # 严格模式下检查额外字段
        if self.strict:
            allowed_fields = set(properties.keys())
            additional = schema.get('additionalProperties', False)
            
            if not additional:
                for key in data.keys():
                    if key not in allowed_fields:
                        self.errors.append(f"不允许的字段：{key}")
                        return False
        
        # 验证每个属性
        for key, value in data.items():
            if key in properties:
                prop_schema = properties[key]
                if not self.validate(value, prop_schema):
                    return False
        
        return True
    
    def _validate_enum(self, data: Any, schema: Dict) -> bool:
        """枚举验证"""
        enum_values = schema.get('enum')
        
        if not enum_values:
            return True
        
        if data not in enum_values:
            self.errors.append(
                f"值不在枚举范围内：{data} (允许值：{enum_values})"
            )
            return False
        
        return True
    
    def _validate_numeric(self, data: Any, schema: Dict) -> bool:
        """数值范围验证"""
        if not isinstance(data, (int, float)):
            return True
        
        # 最小值
        minimum = schema.get('minimum')
        if minimum is not None and data < minimum:
            self.errors.append(f"值小于最小值：{data} < {minimum}")
            return False
        
        # 最大值
        maximum = schema.get('maximum')
        if maximum is not None and data > maximum:
            self.errors.append(f"值大于最大值：{data} > {maximum}")
            return False
        
        return True
    
    def get_errors(self) -> List[str]:
        """获取错误列表"""
        return self.errors


class PermissionValidator(JSONValidator):
    """权限字段验证器"""
    
    def __init__(self):
        super().__init__(strict=True)
    
    def validate_permissions(self, permissions: Dict) -> bool:
        """
        验证权限配置
        
        Args:
            permissions: 权限字典
        
        Returns:
            bool: 是否有效
        
        Example:
            perms = {
                'modules': {
                    'documents': ['read', 'write'],
                    'tasks': ['read']
                },
                'data_scope': 'org',
                'api_rate_limit': 1000
            }
            is_valid = validator.validate_permissions(perms)
        """
        schema = self.SCHEMAS['permissions']
        
        if not self.validate(permissions, schema):
            return False
        
        # 额外验证：modules 结构
        modules = permissions.get('modules', {})
        if not isinstance(modules, dict):
            self.errors.append("modules 必须是对象")
            return False
        
        # 验证每个模块的权限列表
        for module, actions in modules.items():
            if not isinstance(actions, list):
                self.errors.append(f"模块 {module} 的权限必须是列表")
                return False
            
            for action in actions:
                if not isinstance(action, str):
                    self.errors.append(f"模块 {module} 的权限项必须是字符串")
                    return False
        
        return True
    
    def normalize_permissions(self, permissions: Dict) -> Dict:
        """
        标准化权限配置
        
        Args:
            permissions: 权限字典
        
        Returns:
            标准化后的权限字典
        """
        normalized = {
            'modules': {},
            'data_scope': permissions.get('data_scope', 'org'),
        }
        
        # 添加可选字段
        if 'api_rate_limit' in permissions:
            normalized['api_rate_limit'] = int(permissions['api_rate_limit'])
        
        # 标准化 modules
        modules = permissions.get('modules', {})
        for module, actions in modules.items():
            if isinstance(actions, list):
                # 去重并排序
                normalized['modules'][module] = sorted(list(set(actions)))
        
        return normalized


class ConfigValidator(JSONValidator):
    """配置字段验证器"""
    
    def __init__(self):
        super().__init__(strict=False)
    
    def validate_config(self, config: Dict) -> bool:
        """
        验证配置
        
        Args:
            config: 配置字典
        
        Returns:
            bool: 是否有效
        """
        schema = self.SCHEMAS['config']
        return self.validate(config, schema)
    
    def validate_user_config(self, config: Dict) -> bool:
        """
        验证用户配置
        
        Args:
            config: 用户配置字典
        
        Returns:
            bool: 是否有效
        """
        # 必需字段
        required_fields = ['theme', 'language']
        
        for field in required_fields:
            if field in config and not isinstance(config[field], str):
                self.errors.append(f"{field} 必须是字符串")
                return False
        
        # 可选字段验证
        if 'notifications' in config:
            if not isinstance(config['notifications'], bool):
                self.errors.append("notifications 必须是布尔值")
                return False
        
        if 'timezone' in config:
            if not self._validate_timezone(config['timezone']):
                self.errors.append("时区格式无效")
                return False
        
        return True
    
    def _validate_timezone(self, timezone: str) -> bool:
        """验证时区格式"""
        # 简单验证：GMT+8, UTC-5 等
        pattern = r'^(GMT|UTC)[+-]\d{1,2}$'
        return bool(re.match(pattern, timezone))


class CustomFieldsValidator(JSONValidator):
    """自定义字段验证器"""
    
    def __init__(self):
        super().__init__(strict=False)
    
    def validate_custom_fields(self, fields: Dict) -> bool:
        """
        验证自定义字段
        
        Args:
            fields: 自定义字段字典
        
        Returns:
            bool: 是否有效
        """
        # 基本验证
        if not isinstance(fields, dict):
            self.errors.append("自定义字段必须是对象")
            return False
        
        # 验证每个字段
        for key, value in fields.items():
            # 键必须是字符串
            if not isinstance(key, str):
                self.errors.append(f"字段名必须是字符串：{key}")
                return False
            
            # 值不能是复杂对象
            if isinstance(value, (set, frozenset, bytes)):
                self.errors.append(f"字段值不支持的类型：{key}")
                return False
            
            # 日期时间转换
            if isinstance(value, datetime):
                # 自动转换为 ISO 格式
                pass
        
        return True


class MetadataValidator(JSONValidator):
    """元数据验证器"""
    
    def __init__(self):
        super().__init__(strict=False)
    
    def validate_metadata(self, metadata: Dict) -> bool:
        """
        验证元数据
        
        Args:
            metadata: 元数据字典
        
        Returns:
            bool: 是否有效
        """
        schema = self.SCHEMAS['metadata']
        return self.validate(metadata, schema)
    
    def validate_tags(self, tags: List) -> bool:
        """
        验证标签列表
        
        Args:
            tags: 标签列表
        
        Returns:
            bool: 是否有效
        """
        if not isinstance(tags, list):
            self.errors.append("标签必须是列表")
            return False
        
        for tag in tags:
            if not isinstance(tag, str):
                self.errors.append("标签项必须是字符串")
                return False
            
            if len(tag) > 50:
                self.errors.append(f"标签过长：{tag[:20]}...")
                return False
        
        return True


def validate_json_field(field_name: str, value: Any, 
                       schema_name: str = None) -> tuple:
    """
    验证 JSON 字段的便捷函数
    
    Args:
        field_name: 字段名称
        value: 字段值
        schema_name: Schema 名称
    
    Returns:
        (is_valid, error_message)
    
    Example:
        is_valid, error = validate_json_field(
            'permissions',
            {'modules': {}, 'data_scope': 'org'},
            'permissions'
        )
    """
    validator = JSONValidator()
    
    is_valid = validator.validate(value, schema_name=schema_name)
    
    if is_valid:
        return True, None
    else:
        errors = validator.get_errors()
        return False, f"{field_name}: {'; '.join(errors)}"


# 便捷函数
def create_permission_validator() -> PermissionValidator:
    """创建权限验证器"""
    return PermissionValidator()

def create_config_validator() -> ConfigValidator:
    """创建配置验证器"""
    return ConfigValidator()

def create_custom_fields_validator() -> CustomFieldsValidator:
    """创建自定义字段验证器"""
    return CustomFieldsValidator()
