-- Migration: 013_version_control
-- Created: 2026-03-27 13:25
-- Task: P1-2 (数据版本控制表)
-- Description: 创建版本控制表，支持 records/knowledge_docs/files 的历史版本管理
-- Dependencies: 007_records_schema.sql, 008_knowledge_docs_schema.sql, 009_files_schema.sql

BEGIN TRANSACTION;

-- 表名：records_versions
CREATE TABLE IF NOT EXISTS records_versions (
    version_id TEXT PRIMARY KEY,
    record_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    version_label TEXT,
    title TEXT,
    description TEXT,
    content JSON,
    status TEXT,
    priority TEXT,
    change_summary TEXT,
    change_reason TEXT,
    created_by TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (version_number >= 1),
    UNIQUE (record_id, version_number),
    FOREIGN KEY (record_id) REFERENCES records(record_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE INDEX IF NOT EXISTS idx_records_versions_record_id ON records_versions(record_id);
CREATE INDEX IF NOT EXISTS idx_records_versions_version_number ON records_versions(record_id, version_number);
CREATE INDEX IF NOT EXISTS idx_records_versions_created_at ON records_versions(created_at);

-- 表名：knowledge_docs_versions
CREATE TABLE IF NOT EXISTS knowledge_docs_versions (
    version_id TEXT PRIMARY KEY,
    doc_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    version_label TEXT,
    title TEXT,
    content TEXT,
    content_html TEXT,
    summary TEXT,
    change_summary TEXT,
    change_reason TEXT,
    created_by TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (version_number >= 1),
    UNIQUE (doc_id, version_number),
    FOREIGN KEY (doc_id) REFERENCES knowledge_docs(doc_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE INDEX IF NOT EXISTS idx_knowledge_docs_versions_doc_id ON knowledge_docs_versions(doc_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_versions_version_number ON knowledge_docs_versions(doc_id, version_number);
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_versions_created_at ON knowledge_docs_versions(created_at);

-- 表名：files_versions
CREATE TABLE IF NOT EXISTS files_versions (
    version_id TEXT PRIMARY KEY,
    file_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    version_label TEXT,
    filename TEXT,
    file_path TEXT,
    file_hash TEXT,
    file_size INTEGER,
    mime_type TEXT,
    change_summary TEXT,
    change_reason TEXT,
    created_by TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (version_number >= 1),
    CHECK (file_size >= 0),
    UNIQUE (file_id, version_number),
    FOREIGN KEY (file_id) REFERENCES files(file_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE INDEX IF NOT EXISTS idx_files_versions_file_id ON files_versions(file_id);
CREATE INDEX IF NOT EXISTS idx_files_versions_version_number ON files_versions(file_id, version_number);
CREATE INDEX IF NOT EXISTS idx_files_versions_created_at ON files_versions(created_at);

COMMIT;
