-- Migration: 007_records_schema
-- Created: 2026-03-27 07:51
-- Task: 1.1.4 (设计 records 表 - 动态 schema)
-- Description: 通用记录表，支持多赛道、多类型、动态字段
-- Dependencies: 001_organizations_schema.sql, 003_tracks_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：records
-- 描述：通用记录表，支持多赛道、多类型、动态字段 (EAV 模式扩展)
-- ============================================================================

CREATE TABLE IF NOT EXISTS records (
    -- 主键
    record_id TEXT PRIMARY KEY,
    
    -- 组织关联 (多租户隔离)
    org_id TEXT NOT NULL,
    
    -- 赛道关联
    track_id TEXT NOT NULL,
    
    -- 记录类型 (动态扩展)
    record_type TEXT NOT NULL,         -- task/note/document/issue/meeting/etc.
    
    -- 基本信息
    title TEXT NOT NULL,
    description TEXT,
    content JSON,                      -- 动态字段 (根据 record_type 变化)
    
    -- 状态管理
    status TEXT DEFAULT 'draft',       -- draft/active/completed/archived
    priority TEXT DEFAULT 'medium',    -- low/medium/high/critical
    
    -- 关联字段
    parent_record_id TEXT,             -- 父记录 (层级结构)
    related_records JSON DEFAULT '[]', -- 关联记录 ID 列表
    
    -- 人员关联
    owner_id TEXT,                     -- 负责人 user_id
    created_by TEXT,                   -- 创建人 user_id
    assigned_to TEXT,                  -- 分配给 user_id
    
    -- 时间管理
    due_date DATE,                     -- 截止日期
    started_at DATE,                   -- 开始日期
    completed_at DATE,                 -- 完成日期
    
    -- 元数据
    tags JSON DEFAULT '[]',            -- 标签列表
    custom_fields JSON DEFAULT '{}',   -- 自定义字段
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    
    -- 约束
    CHECK (status IN ('draft', 'active', 'completed', 'archived')),
    CHECK (priority IN ('low', 'medium', 'high', 'critical')),
    FOREIGN KEY (org_id) REFERENCES organizations(org_id),
    FOREIGN KEY (track_id) REFERENCES tracks(track_id),
    FOREIGN KEY (owner_id) REFERENCES users(user_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    FOREIGN KEY (assigned_to) REFERENCES users(user_id),
    FOREIGN KEY (parent_record_id) REFERENCES records(record_id)
);

-- ============================================================================
-- 索引
-- ============================================================================

-- 按组织查询 (多租户隔离)
CREATE INDEX IF NOT EXISTS idx_records_org_id ON records(org_id);

-- 按赛道查询 (常用)
CREATE INDEX IF NOT EXISTS idx_records_track_id ON records(track_id);

-- 按记录类型查询
CREATE INDEX IF NOT EXISTS idx_records_type ON records(record_type);

-- 按状态查询
CREATE INDEX IF NOT EXISTS idx_records_status ON records(status);

-- 按优先级查询
CREATE INDEX IF NOT EXISTS idx_records_priority ON records(priority);

-- 按负责人查询
CREATE INDEX IF NOT EXISTS idx_records_owner ON records(owner_id);

-- 按创建人查询
CREATE INDEX IF NOT EXISTS idx_records_created_by ON records(created_by);

-- 按创建时间排序
CREATE INDEX IF NOT EXISTS idx_records_created_at ON records(created_at);

-- 按截止日期排序 (逾期提醒)
CREATE INDEX IF NOT EXISTS idx_records_due_date ON records(due_date);

-- 复合索引：组织 + 赛道 (常用组合)
CREATE INDEX IF NOT EXISTS idx_records_org_track ON records(org_id, track_id);

-- 复合索引：组织 + 类型 + 状态 (常用组合)
CREATE INDEX IF NOT EXISTS idx_records_org_type_status ON records(org_id, record_type, status);

-- 复合索引：组织 + 负责人 + 状态 (我的待办)
CREATE INDEX IF NOT EXISTS idx_records_owner_status ON records(owner_id, status);

-- 复合索引：组织 + 截止日期 + 状态 (逾期查询)
CREATE INDEX IF NOT EXISTS idx_records_due_status ON records(due_date, status);

-- ============================================================================
-- 触发器：自动更新 updated_at
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_records_updated_at
AFTER UPDATE ON records
BEGIN
    UPDATE records SET updated_at = CURRENT_TIMESTAMP WHERE record_id = NEW.record_id;
END;

-- ============================================================================
-- 视图：我的记录 (按当前用户过滤 - 应用层替换 user_id)
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_my_records AS
SELECT 
    r.record_id,
    r.org_id,
    r.track_id,
    t.name as track_name,
    r.record_type,
    r.title,
    r.status,
    r.priority,
    r.owner_id,
    o.username as owner_name,
    r.due_date,
    r.created_at,
    CASE 
        WHEN r.due_date < DATE('now') AND r.status != 'completed' THEN 'overdue'
        WHEN r.due_date = DATE('now') THEN 'due_today'
        WHEN r.due_date <= DATE('now', '+7 days') THEN 'due_soon'
        ELSE 'ok'
    END AS due_status
FROM records r
LEFT JOIN tracks t ON r.track_id = t.track_id
LEFT JOIN users o ON r.owner_id = o.user_id
WHERE r.deleted_at IS NULL;

-- ============================================================================
-- 视图：逾期记录
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_overdue_records AS
SELECT 
    record_id,
    org_id,
    track_id,
    record_type,
    title,
    owner_id,
    due_date,
    JULIANDAY('now') - JULIANDAY(due_date) AS days_overdue
FROM records
WHERE deleted_at IS NULL
  AND status != 'completed'
  AND due_date < DATE('now')
ORDER BY due_date ASC;

-- ============================================================================
-- 视图：记录统计 (按赛道)
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_records_by_track AS
SELECT 
    org_id,
    track_id,
    record_type,
    COUNT(*) as total_count,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
    SUM(CASE WHEN priority = 'critical' THEN 1 ELSE 0 END) as critical_count,
    SUM(CASE WHEN priority = 'high' THEN 1 ELSE 0 END) as high_count
FROM records
WHERE deleted_at IS NULL
GROUP BY org_id, track_id, record_type;

-- ============================================================================
-- 示例数据 (测试用)
-- ============================================================================

INSERT OR IGNORE INTO records (record_id, org_id, track_id, record_type, title, status, priority, owner_id, created_by, due_date, content, tags) VALUES
    -- Task 类型
    ('rec_001_task', 'org_demo_internal', 'track_001_ai', 'task', '完成 Schema 设计', 'active', 'high', 'user_001_super', 'user_001_super', '2026-03-28', 
     '{"estimated_hours": 4, "actual_hours": null, "completion_percentage": 50}', '["design", "database"]'),
    
    ('rec_002_task', 'org_demo_internal', 'track_001_ai', 'task', 'Code Review', 'completed', 'medium', 'user_002_internal', 'user_001_super', '2026-03-27',
     '{"estimated_hours": 2, "actual_hours": 1.5, "completion_percentage": 100}', '["review", "code"]'),
    
    -- Note 类型
    ('rec_003_note', 'org_demo_internal', 'track_001_ai', 'note', '数据库设计笔记', 'active', 'low', 'user_001_super', 'user_001_super', null,
     '{"content": "多租户设计要点...", "format": "markdown"}', '["notes", "design"]'),
    
    -- Document 类型
    ('rec_004_doc', 'org_demo_internal', 'track_002_media', 'document', '内容创作指南', 'active', 'medium', 'user_002_internal', 'user_002_internal', null,
     '{"content": "抖音、小红书创作规范...", "format": "markdown", "version": "1.0"}', '["guide", "content"]'),
    
    -- Issue 类型
    ('rec_005_issue', 'org_demo_internal', 'track_001_ai', 'issue', '外键约束问题', 'completed', 'critical', 'user_001_super', 'user_001_super', '2026-03-27',
     '{"severity": "high", "root_cause": "SQLite 默认不启用外键", "solution": "PRAGMA foreign_keys = ON"}', '["bug", "database"]'),
    
    -- Meeting 类型
    ('rec_006_meeting', 'org_demo_customer_1', 'track_004_customer_a', 'meeting', '项目启动会', 'completed', 'high', 'user_003_customer_a', 'user_003_customer_a', '2026-03-25',
     '{"attendees": ["user_003_customer_a", "user_004_customer_a"], "duration_minutes": 60, "notes": "讨论项目范围..."}', '["meeting", "kickoff"]'),
    
    -- 逾期任务 (测试用)
    ('rec_007_task', 'org_demo_internal', 'track_001_ai', 'task', '逾期任务示例', 'active', 'high', 'user_002_internal', 'user_001_super', '2026-03-20',
     '{"estimated_hours": 8, "actual_hours": null, "completion_percentage": 20}', '["overdue", "test"]');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM records;

-- 验证索引
-- SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='records';

-- 验证触发器
-- SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='records';

-- 查询我的记录
-- SELECT * FROM v_my_records WHERE owner_id = 'user_001_super';

-- 查询逾期记录
-- SELECT * FROM v_overdue_records WHERE org_id = 'org_demo_internal';

-- 查询赛道记录统计
-- SELECT * FROM v_records_by_track WHERE org_id = 'org_demo_internal';

COMMIT;
