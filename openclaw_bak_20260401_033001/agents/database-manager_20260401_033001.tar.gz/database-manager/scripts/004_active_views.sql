-- Migration: 004_active_views
-- Created: 2026-03-27 07:40
-- Task: P0-2 (软删除实现 - 活跃数据视图)
-- Description: 创建活跃数据视图，自动过滤已删除数据
-- Dependencies: 001_organizations_schema.sql, 002_users_schema.sql, 003_tracks_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 活跃组织视图
-- ============================================================================

CREATE VIEW IF NOT EXISTS organizations_active AS
SELECT 
    org_id,
    name,
    type,
    industry,
    config,
    status,
    created_by,
    created_at,
    updated_at,
    deleted_at
FROM organizations
WHERE deleted_at IS NULL;

-- ============================================================================
-- 活跃用户视图
-- ============================================================================

CREATE VIEW IF NOT EXISTS users_active AS
SELECT 
    user_id,
    org_id,
    username,
    email,
    phone,
    avatar_url,
    display_name,
    password_hash,
    salt,
    last_login,
    login_attempts,
    locked_until,
    role,
    permissions,
    status,
    created_by,
    created_at,
    updated_at,
    deleted_at
FROM users
WHERE deleted_at IS NULL;

-- ============================================================================
-- 活跃赛道视图
-- ============================================================================

CREATE VIEW IF NOT EXISTS tracks_active AS
SELECT 
    track_id,
    org_id,
    name,
    code,
    description,
    category,
    status,
    priority,
    budget,
    currency,
    team_size,
    start_date,
    end_date,
    milestone_count,
    config,
    created_by,
    created_at,
    updated_at,
    deleted_at
FROM tracks
WHERE deleted_at IS NULL;

-- ============================================================================
-- 使用示例
-- ============================================================================

-- 查询活跃组织
-- SELECT * FROM organizations_active WHERE org_id = 'org_demo_internal';

-- 查询某组织的所有活跃用户
-- SELECT * FROM users_active WHERE org_id = 'org_demo_customer_1' AND status = 'active';

-- 查询所有活跃赛道 (按优先级排序)
-- SELECT * FROM tracks_active 
-- WHERE org_id = 'org_demo_internal'
-- ORDER BY 
--     CASE priority 
--         WHEN 'critical' THEN 1 
--         WHEN 'high' THEN 2 
--         WHEN 'medium' THEN 3 
--         ELSE 4 
--     END;

COMMIT;

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证视图创建
-- SELECT name FROM sqlite_master WHERE type='view' AND name LIKE '%_active';

-- 验证活跃组织数量
-- SELECT COUNT(*) FROM organizations_active;

-- 验证活跃用户数量
-- SELECT COUNT(*) FROM users_active;

-- 验证活跃赛道数量
-- SELECT COUNT(*) FROM tracks_active;
