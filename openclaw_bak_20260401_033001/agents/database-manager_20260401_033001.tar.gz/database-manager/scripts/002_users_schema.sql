-- Migration: 002_users_schema
-- Created: 2026-03-27 07:22
-- Task: 1.1.2 (设计 users 表)
-- Description: 用户表结构，支持多组织用户管理、角色权限、登录认证
-- Author: database-manager Agent
-- Dependencies: 001_organizations_schema.sql (必须先行执行)

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：users
-- 描述：用户表，支持多组织关联、角色权限、登录认证
-- ============================================================================

CREATE TABLE IF NOT EXISTS users (
    -- 主键
    user_id TEXT PRIMARY KEY,
    
    -- 组织关联 (多租户隔离)
    org_id TEXT NOT NULL,
    
    -- 基本信息
    username TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    avatar_url TEXT,
    display_name TEXT,
    
    -- 认证信息
    password_hash TEXT NOT NULL,
    salt TEXT,                                    -- 密码盐值
    last_login TIMESTAMP NULL,                    -- 最后登录时间
    login_attempts INTEGER DEFAULT 0,             -- 失败尝试次数
    locked_until TIMESTAMP NULL,                  -- 锁定截止时间
    
    -- 角色权限
    role TEXT DEFAULT 'user',                     -- super_admin/org_admin/team_lead/user/guest
    permissions JSON DEFAULT '{}',                -- 细粒度权限配置
    
    -- 状态
    status TEXT DEFAULT 'pending',                -- active/inactive/locked/pending
    
    -- 审计字段
    created_by TEXT,                              -- 创建人 user_id
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,                    -- 软删除标记
    
    -- 约束
    CHECK (role IN ('super_admin', 'org_admin', 'team_lead', 'user', 'guest')),
    CHECK (status IN ('active', 'inactive', 'locked', 'pending')),
    CHECK (login_attempts >= 0),
    UNIQUE (username),
    UNIQUE (email),
    FOREIGN KEY (org_id) REFERENCES organizations(org_id)
    -- 注意：移除了 ON DELETE CASCADE，防止误删组织导致用户数据丢失
    -- 删除组织前需应用层检查并处理关联数据
);

-- ============================================================================
-- 索引
-- ============================================================================

-- 唯一索引：username (登录用)
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username);

-- 唯一索引：email (登录/通知用)
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- 按组织查询 (多租户隔离，最常用)
CREATE INDEX IF NOT EXISTS idx_users_org_id ON users(org_id);

-- 按状态查询 (过滤活跃用户)
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);

-- 按角色查询 (权限管理)
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- 按创建时间排序
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);

-- 复合索引：组织 + 状态 (常用组合查询)
CREATE INDEX IF NOT EXISTS idx_users_org_status ON users(org_id, status);

-- 复合索引：组织 + 角色 (按组织查管理员)
CREATE INDEX IF NOT EXISTS idx_users_org_role ON users(org_id, role);

-- ============================================================================
-- 触发器：自动更新 updated_at
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_users_updated_at
AFTER UPDATE ON users
BEGIN
    UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE user_id = NEW.user_id;
END;

-- ============================================================================
-- 触发器：登录失败计数 (可选，应用层调用)
-- ============================================================================

-- 注意：SQLite 不支持存储过程，登录失败计数建议在应用层实现
-- 这里提供一个视图用于查询被锁定的用户

CREATE VIEW IF NOT EXISTS v_locked_users AS
SELECT 
    user_id,
    username,
    email,
    org_id,
    login_attempts,
    locked_until,
    CASE 
        WHEN locked_until IS NOT NULL AND locked_until > CURRENT_TIMESTAMP THEN 'currently_locked'
        WHEN login_attempts >= 5 THEN 'needs_unlock'
        ELSE 'ok'
    END AS lock_status
FROM users
WHERE status != 'deleted' AND (login_attempts >= 5 OR locked_until IS NOT NULL);

-- ============================================================================
-- 示例数据 (测试用)
-- ============================================================================

-- 注意：实际密码应使用 bcrypt/argon2 加密，这里仅示例
-- 密码示例：password123 -> bcrypt 哈希

INSERT OR IGNORE INTO users (user_id, org_id, username, email, role, status, password_hash, display_name) VALUES
    -- Super Admin (可以管理所有组织)
    ('user_001_super', 'org_demo_internal', 'admin', 'admin@system.com', 'super_admin', 'active', 
     '$2b$12$example_hash_for_super_admin', '系统管理员'),
    
    -- Org Admin - 内部组织
    ('user_002_internal', 'org_demo_internal', 'internal_admin', 'internal@admin.com', 'org_admin', 'active',
     '$2b$12$example_hash_for_internal_admin', '内部组织管理员'),
    
    -- Org Admin - 客户 A
    ('user_003_customer_a', 'org_demo_customer_1', 'customer_a_admin', 'admin@customer-a.com', 'org_admin', 'active',
     '$2b$12$example_hash_for_customer_a_admin', '客户 A 管理员'),
    
    -- 普通用户 - 客户 A
    ('user_004_customer_a', 'org_demo_customer_1', 'zhangsan', 'zhangsan@customer-a.com', 'user', 'active',
     '$2b$12$example_hash_for_zhangsan', '张三'),
    
    -- 普通用户 - 客户 A
    ('user_005_customer_a', 'org_demo_customer_1', 'lisi', 'lisi@customer-a.com', 'user', 'active',
     '$2b$12$example_hash_for_lisi', '李四'),
    
    -- 团队领导 - 客户 B
    ('user_006_customer_b', 'org_demo_customer_2', 'wangwu_lead', 'wangwu@customer-b.com', 'team_lead', 'active',
     '$2b$12$example_hash_for_wangwu', '王五 (团队领导)'),
    
    -- 访客 - 合作伙伴 C
    ('user_007_partner', 'org_demo_partner_1', 'guest_user', 'guest@partner-c.com', 'guest', 'pending',
     '$2b$12$example_hash_for_guest', '访客用户'),
    
    -- 被锁定的用户 (测试用)
    ('user_008_locked', 'org_demo_customer_1', 'locked_user', 'locked@customer-a.com', 'user', 'locked',
     '$2b$12$example_hash_for_locked', '被锁定用户');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM users;

-- 验证索引
-- SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='users';

-- 验证触发器
-- SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='users';

-- 查询某个组织的所有活跃用户
-- SELECT user_id, username, email, role FROM users WHERE org_id = 'org_demo_customer_1' AND status = 'active';

-- 查询所有管理员
-- SELECT user_id, username, org_id, role FROM users WHERE role IN ('super_admin', 'org_admin') AND status = 'active';

-- 查询被锁定的用户
-- SELECT * FROM v_locked_users;

COMMIT;
