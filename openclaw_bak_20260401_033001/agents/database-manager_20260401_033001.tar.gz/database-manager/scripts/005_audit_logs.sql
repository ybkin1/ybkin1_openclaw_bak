-- Migration: 005_audit_logs
-- Created: 2026-03-27 07:40
-- Task: P1-1 (审计日志表)
-- Description: 创建审计日志表，记录所有关键操作
-- Dependencies: 001_organizations_schema.sql, 002_users_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：audit_logs
-- 描述：审计日志表，记录所有关键操作 (CREATE/UPDATE/DELETE/LOGIN/LOGOUT)
-- ============================================================================

CREATE TABLE IF NOT EXISTS audit_logs (
    -- 主键
    log_id TEXT PRIMARY KEY,
    
    -- 组织关联 (多租户隔离)
    org_id TEXT NOT NULL,
    
    -- 操作用户
    user_id TEXT,                              -- NULL 表示系统操作
    
    -- 操作信息
    action TEXT NOT NULL,                      -- CREATE/UPDATE/DELETE/LOGIN/LOGOUT/ACCESS
    table_name TEXT NOT NULL,                  -- 操作的表名
    record_id TEXT,                            -- 操作的记录 ID
    old_value JSON,                            -- 修改前的数据 (UPDATE/DELETE)
    new_value JSON,                            -- 修改后的数据 (CREATE/UPDATE)
    
    -- 环境信息
    ip_address TEXT,                           -- 客户端 IP
    user_agent TEXT,                           -- 客户端信息
    session_id TEXT,                           -- 会话 ID
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 外键约束 (放在最后)
    FOREIGN KEY (org_id) REFERENCES organizations(org_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- ============================================================================
-- 索引
-- ============================================================================

-- 按组织查询 (多租户隔离)
CREATE INDEX IF NOT EXISTS idx_audit_logs_org_id ON audit_logs(org_id);

-- 按用户查询 (审计特定用户)
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);

-- 按操作时间查询 (时间线视图)
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);

-- 复合索引：组织 + 时间 (常用组合查询)
CREATE INDEX IF NOT EXISTS idx_audit_logs_org_time ON audit_logs(org_id, created_at DESC);

-- 复合索引：组织 + 用户 + 时间 (审计特定用户)
CREATE INDEX IF NOT EXISTS idx_audit_logs_org_user_time ON audit_logs(org_id, user_id, created_at DESC);

-- 按表名查询 (审计特定表)
CREATE INDEX IF NOT EXISTS idx_audit_logs_table_name ON audit_logs(table_name);

-- 按操作类型查询
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);

-- ============================================================================
-- 视图：最近操作日志
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_recent_audit_logs AS
SELECT 
    log_id,
    org_id,
    user_id,
    username,
    action,
    table_name,
    record_id,
    created_at
FROM audit_logs
LEFT JOIN users ON audit_logs.user_id = users.user_id
ORDER BY created_at DESC
LIMIT 100;

-- ============================================================================
-- 视图：用户登录日志
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_login_logs AS
SELECT 
    log_id,
    org_id,
    user_id,
    username,
    ip_address,
    user_agent,
    created_at,
    CASE 
        WHEN action = 'LOGIN' THEN 'success'
        WHEN action = 'LOGIN_FAILED' THEN 'failed'
        ELSE 'unknown'
    END AS login_status
FROM audit_logs
LEFT JOIN users ON audit_logs.user_id = users.user_id
WHERE action IN ('LOGIN', 'LOGIN_FAILED')
ORDER BY created_at DESC;

-- ============================================================================
-- 触发器：自动审计 (示例 - 用户登录)
-- ============================================================================

-- 注意：完整的审计触发器需要在应用层实现，这里仅提供示例

-- 示例：用户登录成功审计
-- INSERT INTO audit_logs (log_id, org_id, user_id, action, table_name, ip_address, user_agent)
-- VALUES ('log_' || datetime('now'), 'org_demo_internal', 'user_001_super', 'LOGIN', 'users', '127.0.0.1', 'Mozilla/5.0');

-- ============================================================================
-- 示例数据 (测试用)
-- ============================================================================

INSERT OR IGNORE INTO audit_logs (log_id, org_id, user_id, action, table_name, record_id, ip_address, user_agent) VALUES
    ('log_001', 'org_demo_internal', 'user_001_super', 'LOGIN', 'users', 'user_001_super', '127.0.0.1', 'Mozilla/5.0'),
    ('log_002', 'org_demo_internal', 'user_001_super', 'CREATE', 'tracks', 'track_001_ai', '127.0.0.1', 'Mozilla/5.0'),
    ('log_003', 'org_demo_customer_1', 'user_003_customer_a', 'LOGIN', 'users', 'user_003_customer_a', '192.168.1.100', 'Chrome/120.0'),
    ('log_004', 'org_demo_customer_1', 'user_003_customer_a', 'UPDATE', 'tracks', 'track_004_customer_a', '192.168.1.100', 'Chrome/120.0');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM audit_logs;

-- 验证索引
-- SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='audit_logs';

-- 查询最近 100 条操作日志
-- SELECT * FROM v_recent_audit_logs;

-- 查询用户登录日志
-- SELECT * FROM v_login_logs WHERE org_id = 'org_demo_internal';

-- 查询某组织的所有操作日志
-- SELECT * FROM audit_logs WHERE org_id = 'org_demo_internal' ORDER BY created_at DESC LIMIT 50;

COMMIT;
