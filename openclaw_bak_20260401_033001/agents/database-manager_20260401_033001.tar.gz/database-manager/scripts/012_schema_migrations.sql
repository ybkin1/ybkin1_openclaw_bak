-- Migration: 012_schema_migrations
-- Created: 2026-03-27 09:00
-- Task: 1.1.8 (设计 schema_migrations 表 - 数据库版本管理)
-- Description: 数据库迁移版本管理表，记录所有已执行的迁移
-- Dependencies: None (基础表)

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：schema_migrations
-- 描述：数据库迁移版本管理表，记录所有已执行的迁移
-- ============================================================================

CREATE TABLE IF NOT EXISTS schema_migrations (
    -- 主键
    migration_id TEXT PRIMARY KEY,
    
    -- 迁移信息
    version TEXT NOT NULL UNIQUE,        -- 版本号 (如：001, 002, 003)
    name TEXT NOT NULL,                  -- 迁移名称
    description TEXT,                    -- 迁移描述
    
    -- 执行信息
    executed_by TEXT,                    -- 执行人
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- 执行时间
    execution_time_ms INTEGER,           -- 执行耗时 (毫秒)
    
    -- 迁移内容
    sql_hash TEXT,                       -- SQL 内容哈希 (防止重复执行)
    rollback_sql TEXT,                   -- 回滚 SQL (可选)
    
    -- 状态
    status TEXT DEFAULT 'success',       -- success/failed/rolled_back
    
    -- 备注
    notes TEXT,
    
    -- 约束
    CHECK (status IN ('success', 'failed', 'rolled_back'))
);

-- ============================================================================
-- 索引
-- ============================================================================

-- 按版本号查询
CREATE UNIQUE INDEX IF NOT EXISTS idx_migrations_version ON schema_migrations(version);

-- 按执行时间排序
CREATE INDEX IF NOT EXISTS idx_migrations_executed_at ON schema_migrations(executed_at DESC);

-- 按状态查询
CREATE INDEX IF NOT EXISTS idx_migrations_status ON schema_migrations(status);

-- ============================================================================
-- 视图：迁移历史
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_migration_history AS
SELECT 
    version,
    name,
    description,
    status,
    executed_by,
    executed_at,
    execution_time_ms
FROM schema_migrations
ORDER BY version ASC;

-- ============================================================================
-- 视图：当前版本
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_current_schema_version AS
SELECT 
    version as current_version,
    executed_at as last_migration_at,
    (SELECT COUNT(*) FROM schema_migrations WHERE status = 'success') as total_migrations
FROM schema_migrations
WHERE status = 'success'
ORDER BY version DESC
LIMIT 1;

-- ============================================================================
-- 示例数据：记录本次所有迁移
-- ============================================================================

INSERT OR IGNORE INTO schema_migrations (migration_id, version, name, description, executed_by, executed_at, status) VALUES
    ('mig_001', '001', 'organizations_schema', '组织表 - 多租户基础', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_002', '002', 'users_schema', '用户表 - 认证与权限', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_003', '003', 'tracks_schema', '赛道表 - 项目管理', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_004', '004', 'active_views', '活跃数据视图 - 软删除支持', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_005', '005', 'audit_logs', '审计日志表 - 操作记录', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_006', '006', 'data_protection', '数据保护触发器 - 删除保护', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_007', '007', 'records_schema', '通用记录表 - 动态 schema', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_008', '008', 'knowledge_docs_schema', '知识库文档表 - Markdown + FTS', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_009', '009', 'files_schema', '文件管理表 - 多存储后端', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_010', '010', 'tickets_schema', '工单系统表 - 完整工作流', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_011', '011', 'api_keys_schema', 'API 密钥表 - 访问控制', 'system', '2026-03-27 09:00:00', 'success'),
    ('mig_012', '012', 'schema_migrations', '迁移版本管理表', 'system', '2026-03-27 09:00:00', 'success');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 查询迁移历史
-- SELECT * FROM v_migration_history;

-- 查询当前版本
-- SELECT * FROM v_current_schema_version;

-- 查询失败迁移
-- SELECT * FROM schema_migrations WHERE status = 'failed';

COMMIT;

-- ============================================================================
-- 使用示例
-- ============================================================================

-- 检查迁移是否已执行
-- SELECT COUNT(*) FROM schema_migrations WHERE version = '001' AND status = 'success';

-- 记录新迁移
-- INSERT INTO schema_migrations (migration_id, version, name, description, executed_by, status)
-- VALUES ('mig_013', '013', 'new_feature', '新功能迁移', 'admin', 'success');

-- 回滚迁移
-- UPDATE schema_migrations SET status = 'rolled_back' WHERE version = '013';
