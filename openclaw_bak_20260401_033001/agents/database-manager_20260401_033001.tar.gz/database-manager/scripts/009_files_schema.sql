-- Migration: 009_files_schema
-- Created: 2026-03-27 08:45
-- Task: 1.1.6 (设计 files 表 - 文件管理)
-- Description: 文件管理表，支持多存储后端、版本控制、访问控制
-- Dependencies: 001_organizations_schema.sql, 003_tracks_schema.sql, 007_records_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：files
-- 描述：文件管理表，支持多存储后端、版本控制、访问控制
-- ============================================================================

CREATE TABLE IF NOT EXISTS files (
    -- 主键
    file_id TEXT PRIMARY KEY,
    
    -- 组织关联 (多租户隔离)
    org_id TEXT NOT NULL,
    
    -- 关联对象 (可选)
    track_id TEXT,                     -- 关联赛道
    record_id TEXT,                    -- 关联记录
    doc_id TEXT,                       -- 关联文档
    
    -- 文件基本信息
    filename TEXT NOT NULL,            -- 原始文件名
    file_path TEXT NOT NULL,           -- 存储路径 (相对路径或 URL)
    file_hash TEXT,                    -- 文件哈希 (SHA256)
    file_size INTEGER NOT NULL,        -- 文件大小 (字节)
    mime_type TEXT,                    -- MIME 类型
    
    -- 文件元数据
    file_extension TEXT,               -- 扩展名
    file_category TEXT,                -- document/image/video/audio/code/archive/other
    width INTEGER,                     -- 图片宽度 (px)
    height INTEGER,                    -- 图片高度 (px)
    duration INTEGER,                  -- 视频/音频时长 (秒)
    
    -- 存储信息
    storage_type TEXT DEFAULT 'local', -- local/s3/oss/cos
    storage_bucket TEXT,               -- 存储桶名称
    storage_region TEXT,               -- 存储区域
    
    -- 版本控制
    version INTEGER DEFAULT 1,
    parent_file_id TEXT,               -- 父文件 ID (版本历史)
    is_latest BOOLEAN DEFAULT 1,       -- 是否最新版本
    
    -- 人员关联
    uploader_id TEXT,                  -- 上传者 user_id
    owner_id TEXT,                     -- 负责人 user_id
    
    -- 访问控制
    visibility TEXT DEFAULT 'private', -- private/org/public
    download_count INTEGER DEFAULT 0,  -- 下载次数
    access_password TEXT,              -- 访问密码 (可选)
    
    -- 病毒扫描
    virus_scan_status TEXT DEFAULT 'pending',  -- pending/scanning/clean/infected
    virus_scan_result TEXT,                    -- 扫描结果
    virus_scanned_at TIMESTAMP,                -- 扫描时间
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    
    -- 约束
    CHECK (storage_type IN ('local', 's3', 'oss', 'cos')),
    CHECK (visibility IN ('private', 'org', 'public')),
    CHECK (virus_scan_status IN ('pending', 'scanning', 'clean', 'infected')),
    CHECK (version >= 1),
    CHECK (file_size >= 0),
    CHECK (width >= 0),
    CHECK (height >= 0),
    CHECK (duration >= 0),
    FOREIGN KEY (org_id) REFERENCES organizations(org_id),
    FOREIGN KEY (track_id) REFERENCES tracks(track_id),
    FOREIGN KEY (record_id) REFERENCES records(record_id),
    FOREIGN KEY (doc_id) REFERENCES knowledge_docs(doc_id),
    FOREIGN KEY (uploader_id) REFERENCES users(user_id),
    FOREIGN KEY (owner_id) REFERENCES users(user_id),
    FOREIGN KEY (parent_file_id) REFERENCES files(file_id)
);

-- ============================================================================
-- 索引
-- ============================================================================

-- 按组织查询 (多租户隔离)
CREATE INDEX IF NOT EXISTS idx_files_org_id ON files(org_id);

-- 按关联对象查询
CREATE INDEX IF NOT EXISTS idx_files_track_id ON files(track_id);
CREATE INDEX IF NOT EXISTS idx_files_record_id ON files(record_id);
CREATE INDEX IF NOT EXISTS idx_files_doc_id ON files(doc_id);

-- 按上传者查询
CREATE INDEX IF NOT EXISTS idx_files_uploader ON files(uploader_id);

-- 按文件类型查询
CREATE INDEX IF NOT EXISTS idx_files_category ON files(file_category);

-- 按 MIME 类型查询
CREATE INDEX IF NOT EXISTS idx_files_mime_type ON files(mime_type);

-- 按存储类型查询
CREATE INDEX IF NOT EXISTS idx_files_storage_type ON files(storage_type);

-- 按创建时间排序
CREATE INDEX IF NOT EXISTS idx_files_created_at ON files(created_at);

-- 按文件大小排序 (大文件检测)
CREATE INDEX IF NOT EXISTS idx_files_size ON files(file_size DESC);

-- 按病毒扫描状态查询
CREATE INDEX IF NOT EXISTS idx_files_virus_status ON files(virus_scan_status);

-- 复合索引：组织 + 类型 (常用组合)
CREATE INDEX IF NOT EXISTS idx_files_org_category ON files(org_id, file_category);

-- 复合索引：组织 + 存储类型 (存储管理)
CREATE INDEX IF NOT EXISTS idx_files_org_storage ON files(org_id, storage_type);

-- 复合索引：组织 + 病毒状态 (安全检测)
CREATE INDEX IF NOT EXISTS idx_files_org_virus ON files(org_id, virus_scan_status);

-- ============================================================================
-- 触发器：自动更新 updated_at
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_files_updated_at
AFTER UPDATE ON files
BEGIN
    UPDATE files SET updated_at = CURRENT_TIMESTAMP WHERE file_id = NEW.file_id;
END;

-- ============================================================================
-- 视图：我的文件
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_my_files AS
SELECT 
    f.file_id,
    f.org_id,
    f.filename,
    f.file_path,
    f.file_size,
    f.mime_type,
    f.file_category,
    f.storage_type,
    f.visibility,
    f.download_count,
    f.uploader_id,
    u.username as uploader_name,
    f.created_at
FROM files f
LEFT JOIN users u ON f.uploader_id = u.user_id
WHERE f.deleted_at IS NULL;

-- ============================================================================
-- 视图：公共文件
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_public_files AS
SELECT 
    file_id,
    org_id,
    filename,
    file_path,
    file_size,
    mime_type,
    file_category,
    download_count,
    created_at
FROM files
WHERE deleted_at IS NULL 
  AND visibility = 'public'
  AND virus_scan_status = 'clean'
  AND is_latest = 1;

-- ============================================================================
-- 视图：待扫描文件
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_files_pending_scan AS
SELECT 
    file_id,
    org_id,
    filename,
    file_path,
    file_size,
    uploader_id,
    created_at,
    CASE 
        WHEN created_at < datetime('now', '-1 hour') THEN 'overdue'
        ELSE 'pending'
    END AS scan_status
FROM files
WHERE deleted_at IS NULL 
  AND virus_scan_status IN ('pending', 'scanning')
ORDER BY created_at ASC;

-- ============================================================================
-- 视图：存储统计
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_storage_stats AS
SELECT 
    org_id,
    storage_type,
    COUNT(*) as file_count,
    SUM(file_size) as total_bytes,
    AVG(file_size) as avg_file_size,
    MAX(file_size) as largest_file,
    SUM(CASE WHEN virus_scan_status = 'clean' THEN 1 ELSE 0 END) as clean_files,
    SUM(CASE WHEN virus_scan_status = 'infected' THEN 1 ELSE 0 END) as infected_files
FROM files
WHERE deleted_at IS NULL
GROUP BY org_id, storage_type;

-- ============================================================================
-- 视图：大文件检测 (>100MB)
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_large_files AS
SELECT 
    file_id,
    org_id,
    filename,
    file_path,
    file_size,
    file_size / 1024.0 / 1024.0 as size_mb,
    mime_type,
    uploader_id,
    created_at
FROM files
WHERE deleted_at IS NULL 
  AND file_size > 104857600  -- 100MB
ORDER BY file_size DESC;

-- ============================================================================
-- 示例数据 (测试用)
-- ============================================================================

INSERT OR IGNORE INTO files (file_id, org_id, track_id, filename, file_path, file_hash, file_size, mime_type, file_category, storage_type, visibility, version, uploader_id, virus_scan_status, created_at) VALUES
    -- 文档文件
    ('file_001', 'org_demo_internal', 'track_001_ai', 'database-design.pdf', '/storage/org_demo_internal/docs/database-design.pdf', 'sha256_abc123', 2458624, 'application/pdf', 'document', 'local', 'org', 1, 'user_001_super', 'clean', '2026-03-25 10:00:00'),
    
    -- 图片文件
    ('file_002', 'org_demo_internal', 'track_002_media', 'cover-image.png', '/storage/org_demo_internal/images/cover-image.png', 'sha256_def456', 1024000, 'image/png', 'image', 'local', 'org', 1, 'user_002_internal', 'clean', '2026-03-24 14:30:00'),
    
    -- 视频文件
    ('file_003', 'org_demo_internal', 'track_002_media', 'tutorial-video.mp4', '/storage/org_demo_internal/videos/tutorial-video.mp4', 'sha256_ghi789', 52428800, 'video/mp4', 'video', 'local', 'org', 1, 'user_002_internal', 'clean', '2026-03-23 09:15:00'),
    
    -- 代码文件
    ('file_004', 'org_demo_internal', 'track_001_ai', 'schema.sql', '/storage/org_demo_internal/code/schema.sql', 'sha256_jkl012', 15360, 'application/sql', 'code', 'local', 'org', 1, 'user_001_super', 'clean', '2026-03-26 16:45:00'),
    
    -- 压缩包
    ('file_005', 'org_demo_customer_1', 'track_004_customer_a', 'project-delivery.zip', '/storage/org_demo_customer_1/archives/project-delivery.zip', 'sha256_mno345', 104857600, 'application/zip', 'archive', 'local', 'org', 1, 'user_003_customer_a', 'clean', '2026-03-25 18:00:00'),
    
    -- 公共文件
    ('file_006', 'org_demo_internal', null, 'openclaw-logo.svg', '/storage/org_demo_internal/public/openclaw-logo.svg', 'sha256_pqr678', 51200, 'image/svg+xml', 'image', 'local', 'public', 1, 'user_001_super', 'clean', '2026-03-20 12:00:00'),
    
    -- 待扫描文件 (测试用)
    ('file_007', 'org_demo_internal', null, 'unknown-file.bin', '/storage/org_demo_internal/uploads/unknown-file.bin', 'sha256_stu901', 2048000, 'application/octet-stream', 'other', 'local', 'private', 1, 'user_002_internal', 'pending', datetime('now', '-30 minutes')),
    
    -- 大文件 (测试用)
    ('file_008', 'org_demo_internal', 'track_001_ai', 'large-dataset.csv', '/storage/org_demo_internal/data/large-dataset.csv', 'sha256_vwx234', 209715200, 'text/csv', 'document', 'local', 'org', 1, 'user_001_super', 'clean', '2026-03-22 08:00:00');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM files;

-- 验证索引
-- SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='files';

-- 验证触发器
-- SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='files';

-- 查询我的文件
-- SELECT * FROM v_my_files WHERE uploader_id = 'user_001_super';

-- 查询公共文件
-- SELECT * FROM v_public_files LIMIT 10;

-- 查询待扫描文件
-- SELECT * FROM v_files_pending_scan;

-- 查询存储统计
-- SELECT * FROM v_storage_stats WHERE org_id = 'org_demo_internal';

-- 查询大文件
-- SELECT * FROM v_large_files WHERE org_id = 'org_demo_internal';

COMMIT;
