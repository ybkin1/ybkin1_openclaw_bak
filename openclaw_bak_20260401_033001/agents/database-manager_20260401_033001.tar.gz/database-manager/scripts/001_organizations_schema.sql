-- Migration: 001_organizations_schema
-- Created: 2026-03-26 22:16
-- Task: 1.1.1 (设计 organizations 表)
-- Description: 多租户表结构 - organizations 表，支持客户/组织管理
-- Author: database-manager Agent

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：organizations
-- 描述：租户/组织表，支持多客户公司隔离
-- ============================================================================

CREATE TABLE IF NOT EXISTS organizations (
    -- 主键
    org_id TEXT PRIMARY KEY,
    
    -- 基本信息
    name TEXT NOT NULL,                    -- 组织名称
    type TEXT DEFAULT 'customer',          -- 组织类型：customer/internal/partner
    industry TEXT,                         -- 行业类型
    
    -- 配置
    config JSON DEFAULT '{}',              -- 组织特定配置 (JSON 格式)
    
    -- 状态
    status TEXT DEFAULT 'active',          -- 状态：active/suspended/archived
    
    -- 审计字段
    created_by TEXT,                       -- 创建人 user_id
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,             -- 软删除标记
    
    -- 约束
    CHECK (type IN ('customer', 'internal', 'partner')),
    CHECK (status IN ('active', 'suspended', 'archived'))
);

-- ============================================================================
-- 索引
-- ============================================================================

-- 按名称查询 (支持模糊搜索)
CREATE INDEX IF NOT EXISTS idx_organizations_name ON organizations(name);

-- 按类型查询
CREATE INDEX IF NOT EXISTS idx_organizations_type ON organizations(type);

-- 按状态查询 (常用过滤)
CREATE INDEX IF NOT EXISTS idx_organizations_status ON organizations(status);

-- 按创建时间排序
CREATE INDEX IF NOT EXISTS idx_organizations_created_at ON organizations(created_at);

-- 复合索引：状态 + 类型 (常用组合查询)
CREATE INDEX IF NOT EXISTS idx_organizations_status_type ON organizations(status, type);

-- ============================================================================
-- 触发器：自动更新 updated_at
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_organizations_updated_at
AFTER UPDATE ON organizations
BEGIN
    UPDATE organizations SET updated_at = CURRENT_TIMESTAMP WHERE org_id = NEW.org_id;
END;

-- ============================================================================
-- 示例数据 (测试用)
-- ============================================================================

INSERT OR IGNORE INTO organizations (org_id, name, type, industry, status) VALUES
    ('org_demo_internal', '内部组织', 'internal', 'technology', 'active'),
    ('org_demo_customer_1', '示例客户 A', 'customer', 'finance', 'active'),
    ('org_demo_customer_2', '示例客户 B', 'customer', 'manufacturing', 'active'),
    ('org_demo_partner_1', '合作伙伴 C', 'partner', 'services', 'active');

COMMIT;

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM organizations;

-- 验证索引
-- SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='organizations';

-- 验证触发器
-- SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='organizations';
