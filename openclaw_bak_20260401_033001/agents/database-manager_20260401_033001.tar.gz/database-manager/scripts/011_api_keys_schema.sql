-- Migration: 011_api_keys_schema
-- Created: 2026-03-27 08:58
-- Task: 1.1.8 (设计 api_keys 表 - API 密钥管理)
-- Description: API 密钥管理表，支持密钥生成、权限控制、访问统计
-- Dependencies: 001_organizations_schema.sql, 002_users_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：api_keys
-- 描述：API 密钥管理表，支持密钥生成、权限控制、访问统计
-- ============================================================================

CREATE TABLE IF NOT EXISTS api_keys (
    -- 主键
    key_id TEXT PRIMARY KEY,
    
    -- 组织关联 (多租户隔离)
    org_id TEXT NOT NULL,
    
    -- 密钥信息
    key_hash TEXT NOT NULL,              -- 密钥哈希 (SHA256)
    key_prefix TEXT NOT NULL,            -- 密钥前缀 (用于识别，如：sk_std_abc123)
    key_name TEXT,                       -- 密钥名称 (用户自定义)
    
    -- 密钥类型
    key_type TEXT DEFAULT 'standard',    -- standard/service/personal
    
    -- 权限控制
    permissions JSON DEFAULT '{}',       -- 权限配置
    rate_limit INTEGER DEFAULT 1000,     -- 速率限制 (次/小时)
    
    -- 状态管理
    status TEXT DEFAULT 'active',        -- active/revoked/expired
    
    -- 人员关联
    owner_id TEXT NOT NULL,              -- 所有者 user_id
    created_by TEXT NOT NULL,            -- 创建人 user_id
    
    -- 时间管理
    expires_at DATE,                     -- 过期时间
    last_used_at TIMESTAMP,              -- 最后使用时间
    
    -- 统计信息
    usage_count INTEGER DEFAULT 0,       -- 使用次数
    last_ip TEXT,                        -- 最后使用 IP
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    
    -- 约束
    CHECK (key_type IN ('standard', 'service', 'personal')),
    CHECK (status IN ('active', 'revoked', 'expired')),
    CHECK (rate_limit > 0),
    CHECK (usage_count >= 0),
    FOREIGN KEY (org_id) REFERENCES organizations(org_id),
    FOREIGN KEY (owner_id) REFERENCES users(user_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- ============================================================================
-- 表名：api_access_logs
-- 描述：API 访问日志表
-- ============================================================================

CREATE TABLE IF NOT EXISTS api_access_logs (
    -- 主键
    log_id TEXT PRIMARY KEY,
    
    -- 组织关联
    org_id TEXT NOT NULL,
    
    -- 密钥关联
    key_id TEXT NOT NULL,
    
    -- 请求信息
    endpoint TEXT NOT NULL,              -- API 端点
    method TEXT NOT NULL,                -- HTTP 方法
    request_headers JSON,                -- 请求头
    request_body JSON,                   -- 请求体 (脱敏)
    response_status INTEGER,             -- 响应状态码
    response_time_ms INTEGER,            -- 响应时间 (毫秒)
    
    -- 客户端信息
    ip_address TEXT,                     -- 客户端 IP
    user_agent TEXT,                     -- 客户端信息
    geo_location TEXT,                   -- 地理位置
    
    -- 错误信息
    error_code TEXT,                     -- 错误代码
    error_message TEXT,                  -- 错误消息
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 约束
    CHECK (response_status >= 100 AND response_status < 600),
    CHECK (response_time_ms >= 0),
    FOREIGN KEY (org_id) REFERENCES organizations(org_id),
    FOREIGN KEY (key_id) REFERENCES api_keys(key_id)
);

-- ============================================================================
-- 索引：api_keys
-- ============================================================================

-- 按组织查询
CREATE INDEX IF NOT EXISTS idx_api_keys_org_id ON api_keys(org_id);

-- 按密钥哈希查询 (唯一)
CREATE UNIQUE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash);

-- 按所有者查询
CREATE INDEX IF NOT EXISTS idx_api_keys_owner ON api_keys(owner_id);

-- 按状态查询
CREATE INDEX IF NOT EXISTS idx_api_keys_status ON api_keys(status);

-- 按过期时间查询
CREATE INDEX IF NOT EXISTS idx_api_keys_expires_at ON api_keys(expires_at);

-- 复合索引：组织 + 状态 + 所有者
CREATE INDEX IF NOT EXISTS idx_api_keys_org_status_owner ON api_keys(org_id, status, owner_id);

-- ============================================================================
-- 索引：api_access_logs
-- ============================================================================

-- 按组织查询
CREATE INDEX IF NOT EXISTS idx_api_logs_org_id ON api_access_logs(org_id);

-- 按密钥查询
CREATE INDEX IF NOT EXISTS idx_api_logs_key_id ON api_access_logs(key_id);

-- 按创建时间排序
CREATE INDEX IF NOT EXISTS idx_api_logs_created_at ON api_access_logs(created_at);

-- 按响应状态查询
CREATE INDEX IF NOT EXISTS idx_api_logs_status ON api_access_logs(response_status);

-- 复合索引：组织 + 密钥 + 时间
CREATE INDEX IF NOT EXISTS idx_api_logs_org_key_time ON api_access_logs(org_id, key_id, created_at DESC);

-- 复合索引：组织 + 时间 (日志查询)
CREATE INDEX IF NOT EXISTS idx_api_logs_org_time ON api_access_logs(org_id, created_at DESC);

-- ============================================================================
-- 触发器：自动更新 updated_at
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_api_keys_updated_at
AFTER UPDATE ON api_keys
BEGIN
    UPDATE api_keys SET updated_at = CURRENT_TIMESTAMP WHERE key_id = NEW.key_id;
END;

-- ============================================================================
-- 视图：我的密钥
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_my_api_keys AS
SELECT 
    key_id,
    org_id,
    key_prefix,
    key_name,
    key_type,
    status,
    rate_limit,
    expires_at,
    last_used_at,
    usage_count,
    created_at
FROM api_keys
WHERE deleted_at IS NULL;

-- ============================================================================
-- 视图：即将过期的密钥
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_api_keys_expiring_soon AS
SELECT 
    key_id,
    org_id,
    key_prefix,
    key_name,
    owner_id,
    expires_at,
    CASE 
        WHEN expires_at < DATE('now') THEN 'expired'
        WHEN expires_at <= DATE('now', '+7 days') THEN 'expiring_7days'
        WHEN expires_at <= DATE('now', '+30 days') THEN 'expiring_30days'
        ELSE 'ok'
    END AS expiry_status,
    JULIANDAY(expires_at) - JULIANDAY('now') AS days_until_expiry
FROM api_keys
WHERE deleted_at IS NULL 
  AND status = 'active'
  AND expires_at IS NOT NULL
ORDER BY expires_at ASC;

-- ============================================================================
-- 视图：API 使用统计
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_api_usage_stats AS
SELECT 
    k.org_id,
    k.key_id,
    k.key_name,
    k.key_prefix,
    k.owner_id,
    k.status,
    k.usage_count,
    k.rate_limit,
    k.last_used_at,
    COUNT(l.log_id) as today_requests,
    AVG(l.response_time_ms) as avg_response_time,
    SUM(CASE WHEN l.response_status >= 500 THEN 1 ELSE 0 END) as error_count
FROM api_keys k
LEFT JOIN api_access_logs l ON k.key_id = l.key_id 
    AND DATE(l.created_at) = DATE('now')
WHERE k.deleted_at IS NULL
GROUP BY k.key_id;

-- ============================================================================
-- 示例数据：api_keys
-- ============================================================================

INSERT OR IGNORE INTO api_keys (key_id, org_id, key_hash, key_prefix, key_name, key_type, rate_limit, status, owner_id, created_by, expires_at, usage_count) VALUES
    -- 标准密钥
    ('key_001', 'org_demo_internal', 'sha256_abc123', 'sk_std_abc123', '开发环境密钥', 'standard', 1000, 'active', 'user_001_super', 'user_001_super', '2027-03-27', 156),
    
    -- 服务密钥
    ('key_002', 'org_demo_internal', 'sha256_def456', 'sk_svc_def456', 'CI/CD 服务密钥', 'service', 5000, 'active', 'user_001_super', 'user_001_super', null, 2890),
    
    -- 个人密钥
    ('key_003', 'org_demo_internal', 'sha256_ghi789', 'sk_prs_ghi789', '个人测试密钥', 'personal', 100, 'active', 'user_002_internal', 'user_002_internal', '2026-06-27', 45),
    
    -- 已撤销密钥
    ('key_004', 'org_demo_customer_1', 'sha256_jkl012', 'sk_std_jkl012', '已撤销密钥', 'standard', 1000, 'revoked', 'user_003_customer_a', 'user_003_customer_a', null, 520),
    
    -- 即将过期密钥 (测试用)
    ('key_005', 'org_demo_internal', 'sha256_mno345', 'sk_std_mno345', '即将过期密钥', 'standard', 1000, 'active', 'user_001_super', 'user_001_super', DATE('now', '+3 days'), 89);

-- ============================================================================
-- 示例数据：api_access_logs
-- ============================================================================

INSERT OR IGNORE INTO api_access_logs (log_id, org_id, key_id, endpoint, method, response_status, response_time_ms, ip_address, created_at) VALUES
    ('log_001', 'org_demo_internal', 'key_001', '/api/v1/documents', 'GET', 200, 45, '192.168.1.100', '2026-03-27 08:00:00'),
    ('log_002', 'org_demo_internal', 'key_001', '/api/v1/documents', 'POST', 201, 120, '192.168.1.100', '2026-03-27 08:05:00'),
    ('log_003', 'org_demo_internal', 'key_002', '/api/v1/tracks', 'GET', 200, 38, '10.0.0.50', '2026-03-27 08:10:00'),
    ('log_004', 'org_demo_internal', 'key_002', '/api/v1/records', 'POST', 500, 5000, '10.0.0.50', '2026-03-27 08:15:00'),
    ('log_005', 'org_demo_customer_1', 'key_004', '/api/v1/users', 'GET', 401, 5, '203.0.113.50', '2026-03-26 10:00:00');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM api_keys;
-- SELECT COUNT(*) FROM api_access_logs;

-- 查询我的密钥
-- SELECT * FROM v_my_api_keys WHERE owner_id = 'user_001_super';

-- 查询即将过期的密钥
-- SELECT * FROM v_api_keys_expiring_soon WHERE org_id = 'org_demo_internal';

-- 查询 API 使用统计
-- SELECT * FROM v_api_usage_stats WHERE org_id = 'org_demo_internal';

COMMIT;
