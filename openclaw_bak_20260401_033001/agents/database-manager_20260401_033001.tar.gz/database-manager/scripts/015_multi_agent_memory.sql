-- Migration: 015_multi_agent_memory
-- Created: 2026-03-27 16:00
-- Task: 多 Agent 记忆架构升级
-- Description: 升级记忆表支持多 Agent 隔离 + 系统记忆 + 跨 Agent 共享
-- Dependencies: 014_memory_architecture.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 1. 升级 memory_working 表 - 添加 agent_id
-- ============================================================================

-- 添加 agent_id 列
ALTER TABLE memory_working ADD COLUMN agent_id TEXT NOT NULL DEFAULT 'master';

-- 更新索引
DROP INDEX IF EXISTS idx_memory_working_session;
CREATE INDEX IF NOT EXISTS idx_memory_working_agent ON memory_working(agent_id);
CREATE INDEX IF NOT EXISTS idx_memory_working_agent_session ON memory_working(agent_id, session_id);

-- ============================================================================
-- 2. 升级 memory_semantic 表 - 添加 agent_id 和共享控制
-- ============================================================================

-- 添加 agent_id 列
ALTER TABLE memory_semantic ADD COLUMN agent_id TEXT NOT NULL DEFAULT 'master';

-- 添加共享控制列
ALTER TABLE memory_semantic ADD COLUMN shareable BOOLEAN DEFAULT FALSE;
ALTER TABLE memory_semantic ADD COLUMN share_with JSON DEFAULT '[]';

-- 更新索引
DROP INDEX IF EXISTS idx_memory_semantic_category;
CREATE INDEX IF NOT EXISTS idx_memory_semantic_agent ON memory_semantic(agent_id);
CREATE INDEX IF NOT EXISTS idx_memory_semantic_shareable ON memory_semantic(shareable);
CREATE INDEX IF NOT EXISTS idx_memory_semantic_agent_category ON memory_semantic(agent_id, category);

-- ============================================================================
-- 3. 升级 memory_facts 表 - 添加 agent_id 和共享控制
-- ============================================================================

-- 添加 agent_id 列 (允许 NULL，NULL 表示系统级事实)
ALTER TABLE memory_facts ADD COLUMN agent_id TEXT;

-- 添加共享控制列
ALTER TABLE memory_facts ADD COLUMN shareable BOOLEAN DEFAULT TRUE;
ALTER TABLE memory_facts ADD COLUMN share_with JSON DEFAULT '[]';

-- 更新现有事实为 agent 级 (非系统级)
UPDATE memory_facts SET agent_id = 'master' WHERE agent_id IS NULL;

-- 更新索引
DROP INDEX IF EXISTS idx_memory_facts_subject;
CREATE INDEX IF NOT EXISTS idx_memory_facts_agent ON memory_facts(agent_id);
CREATE INDEX IF NOT EXISTS idx_memory_facts_shareable ON memory_facts(shareable);
CREATE INDEX IF NOT EXISTS idx_memory_facts_agent_subject ON memory_facts(agent_id, subject);

-- ============================================================================
-- 4. 创建 memory_system 表 - 系统记忆
-- ============================================================================

CREATE TABLE IF NOT EXISTS memory_system (
    system_id TEXT PRIMARY KEY,
    
    -- 记忆类型
    type TEXT NOT NULL,  -- config/rule/knowledge/user_profile
    
    -- 内容
    key TEXT NOT NULL UNIQUE,  -- 唯一键
    value JSON NOT NULL,       -- JSON 值
    description TEXT,
    
    -- 元数据
    category TEXT,
    tags JSON DEFAULT '[]',
    
    -- 版本控制
    version INTEGER DEFAULT 1,
    updated_by TEXT,
    
    -- 时间
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 约束
    CHECK (type IN ('config', 'rule', 'knowledge', 'user_profile'))
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_memory_system_type ON memory_system(type);
CREATE INDEX IF NOT EXISTS idx_memory_system_category ON memory_system(category);
CREATE INDEX IF NOT EXISTS idx_memory_system_key ON memory_system(key);

-- ============================================================================
-- 5. 创建 memory_cross_agent_log 表 - 跨 Agent 访问日志
-- ============================================================================

CREATE TABLE IF NOT EXISTS memory_cross_agent_log (
    log_id TEXT PRIMARY KEY,
    
    -- 访问信息
    source_agent_id TEXT NOT NULL,  -- 源 Agent
    target_agent_id TEXT NOT NULL,  -- 目标 Agent
    memory_type TEXT NOT NULL,      -- working/semantic/fact
    memory_id TEXT NOT NULL,
    
    -- 操作
    action TEXT NOT NULL,           -- read/write/share
    
    -- 结果
    success BOOLEAN DEFAULT TRUE,
    reason TEXT,
    
    -- 时间
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_memory_cross_agent_source ON memory_cross_agent_log(source_agent_id);
CREATE INDEX IF NOT EXISTS idx_memory_cross_agent_target ON memory_cross_agent_log(target_agent_id);
CREATE INDEX IF NOT EXISTS idx_memory_cross_agent_time ON memory_cross_agent_log(created_at);

-- ============================================================================
-- 6. 创建视图 - 多 Agent 视角
-- ============================================================================

-- 视图：Agent 可见的所有事实 (系统级 + 自己的 + 共享的)
CREATE VIEW IF NOT EXISTS v_agent_facts AS
SELECT 
    fact_id,
    agent_id,
    subject,
    predicate,
    object,
    category,
    confidence,
    verified,
    shareable,
    CASE 
        WHEN agent_id IS NULL THEN 'system'
        WHEN agent_id = 'master' THEN 'own'
        ELSE 'shared'
    END as fact_source
FROM memory_facts
WHERE deleted_at IS NULL 
  AND verified = TRUE
  AND (
      agent_id IS NULL  -- 系统级事实
      OR agent_id = 'master'  -- 自己的事实 (示例，实际应该用当前 agent_id)
      OR (shareable = TRUE AND json_array_length(share_with) > 0)  -- 共享事实
  )
ORDER BY verified_at DESC;

-- 视图：Agent 可见的语义记忆 (自己的 + 共享的)
CREATE VIEW IF NOT EXISTS v_agent_semantic AS
SELECT 
    memory_id,
    agent_id,
    content,
    summary,
    category,
    confidence,
    shareable,
    verified,
    CASE 
        WHEN agent_id = 'master' THEN 'own'
        ELSE 'shared'
    END as memory_source
FROM memory_semantic
WHERE deleted_at IS NULL
  AND (
      agent_id = 'master'  -- 自己的
      OR (shareable = TRUE AND json_array_length(share_with) > 0)  -- 共享的
  )
ORDER BY confidence DESC, access_count DESC;

-- 视图：系统记忆分类统计
CREATE VIEW IF NOT EXISTS v_system_memory_stats AS
SELECT 
    type,
    category,
    COUNT(*) as count,
    MAX(updated_at) as last_updated
FROM memory_system
GROUP BY type, category;

-- 视图：跨 Agent 访问统计
CREATE VIEW IF NOT EXISTS v_cross_agent_stats AS
SELECT 
    source_agent_id,
    target_agent_id,
    memory_type,
    action,
    COUNT(*) as count,
    SUM(CASE WHEN success = TRUE THEN 1 ELSE 0 END) as success_count,
    SUM(CASE WHEN success = FALSE THEN 1 ELSE 0 END) as failure_count
FROM memory_cross_agent_log
GROUP BY source_agent_id, target_agent_id, memory_type, action;

-- ============================================================================
-- 7. 触发器 - 自动更新
-- ============================================================================

-- 触发器：更新 memory_system 的 updated_at
CREATE TRIGGER IF NOT EXISTS update_system_memory_timestamp
AFTER UPDATE ON memory_system
BEGIN
    UPDATE memory_system 
    SET updated_at = CURRENT_TIMESTAMP
    WHERE system_id = NEW.system_id;
END;

-- 触发器：记录跨 Agent 访问 (示例：读取共享记忆)
CREATE TRIGGER IF NOT EXISTS log_cross_agent_access
AFTER SELECT ON v_agent_semantic
WHEN NEW.agent_id != 'master'  -- 访问其他 Agent 的记忆
BEGIN
    INSERT INTO memory_cross_agent_log (log_id, source_agent_id, target_agent_id, memory_type, memory_id, action, success)
    VALUES (
        'log_' || datetime('now') || '_' || NEW.memory_id,
        'master',  -- 当前访问者
        NEW.agent_id,  -- 记忆所有者
        'semantic',
        NEW.memory_id,
        'read',
        TRUE
    );
END;

-- ============================================================================
-- 8. 示例数据 - 系统记忆
-- ============================================================================

-- 系统配置示例
INSERT OR IGNORE INTO memory_system (system_id, type, key, value, description, category) VALUES
    ('sys_config_001', 'config', 'model.primary', '{"name": "qwencode/qwen3.5-plus", "fallbacks": []}', '主模型配置', 'model'),
    ('sys_config_002', 'config', 'memory.cleanup_interval_hours', '1', '记忆清理间隔 (小时)', 'memory'),
    ('sys_config_003', 'config', 'memory.retention_days', '30', '记忆保留天数', 'memory');

-- 系统规则示例
INSERT OR IGNORE INTO memory_system (system_id, type, key, value, description, category) VALUES
    ('sys_rule_001', 'rule', 'agent.architecture', '{"master": "主控", "assistant": "助手", "branches": ["analysis", "backup", "monitoring"]}', 'Agent 架构规则', 'architecture'),
    ('sys_rule_002', 'rule', 'task.workflow', '["receive", "align", "execute", "report", "document"]', '任务处理流程', 'workflow');

-- 用户画像示例
INSERT OR IGNORE INTO memory_system (system_id, type, key, value, description, category) VALUES
    ('sys_profile_001', 'user_profile', 'user:ou_b46467cc1563871aab03ac1d4f9216f0', '{"name": "俞斌", "role": "智算服务器硬件运维经理", "preferences": {"language": "zh-CN", "timezone": "GMT+8"}}', '用户画像', 'user');

-- 全局知识示例
INSERT OR IGNORE INTO memory_system (system_id, type, key, value, description, category) VALUES
    ('sys_knowledge_001', 'knowledge', 'gpu.maintenance.best_practices', '{"check_interval": "daily", "key_metrics": ["temperature", "power", "memory"]}', 'GPU 维护最佳实践', 'maintenance');

-- ============================================================================
-- 9. 数据迁移 - 将现有记忆标记为 master Agent
-- ============================================================================

-- 更新现有工作记忆为 master Agent
UPDATE memory_working SET agent_id = 'master' WHERE agent_id = 'master';

-- 更新现有语义记忆为 master Agent
UPDATE memory_semantic SET agent_id = 'master' WHERE agent_id = 'master';

-- 更新现有事实记忆为 master Agent (非系统级)
UPDATE memory_facts SET agent_id = 'master' WHERE agent_id IS NULL;

-- ============================================================================
-- 10. 验证查询
-- ============================================================================

-- 查询系统记忆统计
-- SELECT * FROM v_system_memory_stats;

-- 查询跨 Agent 访问统计
-- SELECT * FROM v_cross_agent_stats;

-- 查询 Agent 可见的所有事实
-- SELECT * FROM v_agent_facts;

-- 查询 Agent 可见的语义记忆
-- SELECT * FROM v_agent_semantic;

COMMIT;
