-- Migration: 006_data_protection
-- Created: 2026-03-27 07:41
-- Task: P0-3 (数据保护 - 删除保护触发器)
-- Description: 创建删除保护触发器，防止误删数据
-- Dependencies: 001_organizations_schema.sql, 002_users_schema.sql, 003_tracks_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 触发器：防止删除活跃组织 (有活跃用户时)
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS prevent_org_delete_with_users
BEFORE DELETE ON organizations
BEGIN
    SELECT CASE 
        WHEN (
            SELECT COUNT(*) FROM users 
            WHERE org_id = OLD.org_id AND deleted_at IS NULL
        ) > 0
        THEN RAISE(ABORT, 'Cannot delete organization: has active users. Please delete or transfer users first.')
    END;
END;

-- ============================================================================
-- 触发器：防止删除活跃组织 (有活跃赛道时)
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS prevent_org_delete_with_tracks
BEFORE DELETE ON organizations
BEGIN
    SELECT CASE 
        WHEN (
            SELECT COUNT(*) FROM tracks 
            WHERE org_id = OLD.org_id AND deleted_at IS NULL
        ) > 0
        THEN RAISE(ABORT, 'Cannot delete organization: has active tracks. Please delete or transfer tracks first.')
    END;
END;

-- ============================================================================
-- 触发器：防止删除活跃用户 (有创建记录时)
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS prevent_user_delete_with_records
BEFORE DELETE ON users
BEGIN
    SELECT CASE 
        WHEN (
            SELECT COUNT(*) FROM tracks 
            WHERE created_by = OLD.user_id AND deleted_at IS NULL
        ) > 0
        THEN RAISE(ABORT, 'Cannot delete user: has created tracks. Please transfer ownership first.')
    END;
END;

-- ============================================================================
-- 触发器：软删除替代硬删除 (organizations)
-- 注意：这个触发器会阻止 DELETE 操作，改为自动标记 deleted_at
-- 如果需要真正删除，先 DROP TRIGGER 再 DELETE
-- ============================================================================

-- 移除冲突的触发器 (如果存在)
-- DROP TRIGGER IF EXISTS organizations_soft_delete;
-- DROP TRIGGER IF EXISTS users_soft_delete;
-- DROP TRIGGER IF EXISTS tracks_soft_delete;

-- 注意：软删除逻辑应该在应用层实现，而不是触发器
-- 应用层代码示例:
-- UPDATE organizations SET deleted_at = CURRENT_TIMESTAMP WHERE org_id = ?;
-- 而不是：DELETE FROM organizations WHERE org_id = ?;

-- ============================================================================
-- 使用示例
-- ============================================================================

-- 尝试删除组织 (会失败，因为有活跃用户)
-- DELETE FROM organizations WHERE org_id = 'org_demo_customer_1';
-- 错误：Cannot delete organization: has active users. Please delete or transfer users first.

-- 正确做法：先软删除用户，再软删除组织
-- UPDATE users SET deleted_at = CURRENT_TIMESTAMP WHERE org_id = 'org_demo_customer_1';
-- UPDATE organizations SET deleted_at = CURRENT_TIMESTAMP WHERE org_id = 'org_demo_customer_1';

-- 如果需要真正删除 (硬删除)，先删除触发器
-- DROP TRIGGER prevent_org_delete_with_users;
-- DROP TRIGGER prevent_org_delete_with_tracks;
-- DELETE FROM organizations WHERE org_id = 'org_demo_customer_1';

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证触发器创建
-- SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE 'prevent_%';
-- SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE '%_soft_delete';

COMMIT;
