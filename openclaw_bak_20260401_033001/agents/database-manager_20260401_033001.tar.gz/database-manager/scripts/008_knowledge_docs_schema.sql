-- Migration: 008_knowledge_docs_schema
-- Created: 2026-03-27 08:20
-- Task: 1.1.5 (设计 knowledge_docs 表 - 知识库文档)
-- Description: 知识库文档表，支持 Markdown、版本控制、全文搜索
-- Dependencies: 001_organizations_schema.sql, 003_tracks_schema.sql, 007_records_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：knowledge_docs
-- 描述：知识库文档表，支持 Markdown、版本控制、全文搜索
-- ============================================================================

CREATE TABLE IF NOT EXISTS knowledge_docs (
    -- 主键
    doc_id TEXT PRIMARY KEY,
    
    -- 组织关联 (多租户隔离)
    org_id TEXT NOT NULL,
    
    -- 赛道关联 (可选)
    track_id TEXT,
    
    -- 关联记录 (可选)
    record_id TEXT,
    
    -- 基本信息
    title TEXT NOT NULL,
    slug TEXT,                              -- URL 友好标识
    summary TEXT,                           -- 摘要
    content TEXT NOT NULL,                  -- Markdown 内容
    content_html TEXT,                      -- 渲染后的 HTML
    
    -- 文档类型
    doc_type TEXT DEFAULT 'article',        -- article/wiki/faq/guide/template
    doc_category TEXT,                      -- 技术/产品/运营/管理等
    
    -- 状态管理
    status TEXT DEFAULT 'draft',            -- draft/review/published/archived
    visibility TEXT DEFAULT 'internal',     -- public/internal/private
    
    -- 版本控制
    version INTEGER DEFAULT 1,
    parent_doc_id TEXT,                     -- 父文档 (用于版本历史)
    is_latest BOOLEAN DEFAULT 1,            -- 是否最新版本
    
    -- 人员关联
    author_id TEXT,                         -- 作者 user_id
    reviewer_id TEXT,                       -- 审核人 user_id
    owner_id TEXT,                          -- 负责人 user_id
    
    -- 元数据
    tags JSON DEFAULT '[]',                 -- 标签列表
    related_docs JSON DEFAULT '[]',         -- 关联文档 ID 列表
    attachments JSON DEFAULT '[]',          -- 附件列表 [{file_id, name, size}]
    word_count INTEGER DEFAULT 0,           -- 字数统计
    read_time_minutes INTEGER DEFAULT 0,    -- 阅读时间 (分钟)
    
    -- 统计信息
    view_count INTEGER DEFAULT 0,           -- 浏览次数
    like_count INTEGER DEFAULT 0,           -- 点赞数
    comment_count INTEGER DEFAULT 0,        -- 评论数
    
    -- 时间管理
    published_at DATE,                      -- 发布时间
    last_reviewed_at DATE,                  -- 最后审核时间
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    
    -- 约束
    CHECK (status IN ('draft', 'review', 'published', 'archived')),
    CHECK (visibility IN ('public', 'internal', 'private')),
    CHECK (doc_type IN ('article', 'wiki', 'faq', 'guide', 'template')),
    CHECK (version >= 1),
    CHECK (word_count >= 0),
    CHECK (read_time_minutes >= 0),
    FOREIGN KEY (org_id) REFERENCES organizations(org_id),
    FOREIGN KEY (track_id) REFERENCES tracks(track_id),
    FOREIGN KEY (record_id) REFERENCES records(record_id),
    FOREIGN KEY (author_id) REFERENCES users(user_id),
    FOREIGN KEY (reviewer_id) REFERENCES users(user_id),
    FOREIGN KEY (owner_id) REFERENCES users(user_id),
    FOREIGN KEY (parent_doc_id) REFERENCES knowledge_docs(doc_id)
);

-- ============================================================================
-- 索引
-- ============================================================================

-- 按组织查询 (多租户隔离)
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_org_id ON knowledge_docs(org_id);

-- 按赛道查询
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_track_id ON knowledge_docs(track_id);

-- 按状态查询
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_status ON knowledge_docs(status);

-- 按文档类型查询
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_type ON knowledge_docs(doc_type);

-- 按可见性查询
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_visibility ON knowledge_docs(visibility);

-- 按作者查询
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_author ON knowledge_docs(author_id);

-- 按创建时间排序
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_created_at ON knowledge_docs(created_at);

-- 按发布时间排序
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_published_at ON knowledge_docs(published_at);

-- 按浏览次数排序 (热门文档)
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_views ON knowledge_docs(view_count DESC);

-- 唯一索引：slug (组织内唯一)
CREATE UNIQUE INDEX IF NOT EXISTS idx_knowledge_docs_slug ON knowledge_docs(org_id, slug);

-- 复合索引：组织 + 状态 + 可见性 (常用组合)
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_org_status_visibility ON knowledge_docs(org_id, status, visibility);

-- 复合索引：组织 + 类型 + 状态 (文档列表)
CREATE INDEX IF NOT EXISTS idx_knowledge_docs_org_type_status ON knowledge_docs(org_id, doc_type, status);

-- 复合索引：组织 + 标签 (JSON 提取，SQLite 3.38+)
-- CREATE INDEX IF NOT EXISTS idx_knowledge_docs_tags ON knowledge_docs(org_id, json_extract(tags, '$[0]'));

-- ============================================================================
-- 触发器：自动更新 updated_at
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_knowledge_docs_updated_at
AFTER UPDATE ON knowledge_docs
BEGIN
    UPDATE knowledge_docs SET updated_at = CURRENT_TIMESTAMP WHERE doc_id = NEW.doc_id;
END;

-- ============================================================================
-- 触发器：版本控制 (创建新版本)
-- ============================================================================

-- 注意：完整版本控制需要应用层配合，这里提供基础触发器

CREATE TRIGGER IF NOT EXISTS knowledge_docs_version_control
AFTER UPDATE ON knowledge_docs
WHEN OLD.content != NEW.content AND NEW.is_latest = 1
BEGIN
    -- 1. 将旧版本标记为非最新
    UPDATE knowledge_docs SET is_latest = 0 WHERE doc_id = OLD.doc_id;
    
    -- 2. 创建新版本 (应用层实现更佳)
    -- INSERT INTO knowledge_docs (doc_id, parent_doc_id, version, content, ...)
    -- VALUES (...);
END;

-- ============================================================================
-- 视图：已发布文档
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_published_docs AS
SELECT 
    doc_id,
    org_id,
    track_id,
    title,
    slug,
    summary,
    doc_type,
    doc_category,
    author_id,
    u.username as author_name,
    version,
    view_count,
    like_count,
    published_at,
    read_time_minutes
FROM knowledge_docs
LEFT JOIN users u ON knowledge_docs.author_id = u.user_id
WHERE deleted_at IS NULL 
  AND status = 'published'
  AND is_latest = 1
ORDER BY published_at DESC;

-- ============================================================================
-- 视图：热门文档
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_popular_docs AS
SELECT 
    doc_id,
    org_id,
    title,
    slug,
    doc_type,
    author_id,
    view_count,
    like_count,
    (view_count * 1.0 + like_count * 10.0) as popularity_score
FROM knowledge_docs
WHERE deleted_at IS NULL 
  AND status = 'published'
  AND is_latest = 1
ORDER BY popularity_score DESC
LIMIT 100;

-- ============================================================================
-- 视图：待审核文档
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_docs_pending_review AS
SELECT 
    doc_id,
    org_id,
    title,
    author_id,
    reviewer_id,
    doc_type,
    created_at,
    word_count
FROM knowledge_docs
WHERE deleted_at IS NULL 
  AND status = 'review'
  AND is_latest = 1
ORDER BY created_at DESC;

-- ============================================================================
-- 视图：文档版本历史
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_doc_version_history AS
SELECT 
    doc_id,
    parent_doc_id,
    title,
    version,
    author_id,
    created_at,
    word_count,
    CASE WHEN is_latest = 1 THEN 'current' ELSE 'historical' END AS version_status
FROM knowledge_docs
WHERE deleted_at IS NULL
ORDER BY parent_doc_id, version DESC;

-- ============================================================================
-- FTS5 全文搜索虚拟表
-- ============================================================================

-- 注意：FTS5 触发器同步需要特殊处理，这里使用简化版本
-- 完整实现需要在应用层同步 FTS 索引

CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_docs_fts USING fts5(
    title,
    content,
    summary,
    content='knowledge_docs',
    content_rowid='rowid'
);

-- 应用层同步示例 (Python):
-- def index_document(doc_id, title, content, summary):
--     cursor.execute("INSERT OR REPLACE INTO knowledge_docs_fts(rowid, title, content, summary) VALUES (?, ?, ?, ?)",
--                    (doc_id, title, content, summary))

-- ============================================================================
-- 示例数据 (测试用)
-- ============================================================================

INSERT OR IGNORE INTO knowledge_docs (doc_id, org_id, track_id, title, slug, summary, content, doc_type, doc_category, status, visibility, version, author_id, word_count, read_time_minutes, view_count, published_at, tags) VALUES
    -- 技术文章
    ('doc_001', 'org_demo_internal', 'track_001_ai', '数据库设计最佳实践', 'database-design-best-practices', '多租户数据库设计指南', '# 数据库设计最佳实践\n\n## 多租户隔离\n\n使用 org_id 进行数据隔离...\n\n## 索引优化\n\n...', 'article', '技术', 'published', 'internal', 1, 'user_001_super', 2500, 10, 156, '2026-03-25', '["database", "design", "best-practices"]'),
    
    -- Wiki 文档
    ('doc_002', 'org_demo_internal', 'track_001_ai', 'OpenClaw 架构说明', 'openclaw-architecture', 'OpenClaw 系统架构详解', '# OpenClaw 架构\n\n## Agent 架构\n\n- master: 主控 Agent\n- assistant: 助手 Agent\n...', 'wiki', '技术', 'published', 'internal', 1, 'user_001_super', 3200, 15, 289, '2026-03-20', '["openclaw", "architecture", "agent"]'),
    
    -- FAQ
    ('doc_003', 'org_demo_internal', null, '常见问题解答', 'faq-general', '常见问题汇总', '# 常见问题\n\n## Q: 如何启用外键约束？\n\nA: PRAGMA foreign_keys = ON;\n\n## Q: 如何实现软删除？\n\n...', 'faq', '技术', 'published', 'public', 1, 'user_002_internal', 1800, 8, 520, '2026-03-22', '["faq", "troubleshooting"]'),
    
    -- 指南
    ('doc_004', 'org_demo_internal', 'track_002_media', '内容创作指南', 'content-creation-guide', '抖音、小红书创作规范', '# 内容创作指南\n\n## 抖音创作要点\n\n1. 前 3 秒抓住注意力\n2. 节奏要快\n...', 'guide', '运营', 'published', 'internal', 1, 'user_002_internal', 4500, 20, 98, '2026-03-18', '["content", "douyin", "xiaohongshu"]'),
    
    -- 草稿
    ('doc_005', 'org_demo_internal', 'track_001_ai', 'RAG 系统设计 (草稿)', 'rag-system-design-draft', 'RAG 系统架构设计', '# RAG 系统设计\n\n## 架构概览\n\n用户查询 → 检索 → 生成...\n\n## 技术选型\n\n...', 'article', '技术', 'draft', 'internal', 1, 'user_001_super', 1200, 5, 0, null, '["rag", "design", "draft"]'),
    
    -- 待审核
    ('doc_006', 'org_demo_customer_1', 'track_004_customer_a', '项目交付文档模板', 'project-delivery-template', '项目交付标准模板', '# 项目交付文档\n\n## 1. 项目概述\n\n## 2. 技术方案\n\n## 3. 部署指南\n\n...', 'template', '技术', 'review', 'internal', 1, 'user_003_customer_a', 2800, 12, 0, null, '["template", "delivery"]'),
    
    -- 历史版本 (用于测试版本历史视图)
    ('doc_001_v2', 'org_demo_internal', 'track_001_ai', '数据库设计最佳实践', 'database-design-best-practices', '多租户数据库设计指南 v2', '# 数据库设计最佳实践 v2\n\n更新内容...\n', 'article', '技术', 'published', 'internal', 2, 'user_001_super', 2800, 12, 0, '2026-03-26', '["database", "design", "v2"]');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM knowledge_docs;

-- 验证索引
-- SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='knowledge_docs';

-- 验证触发器
-- SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='knowledge_docs';

-- 查询已发布文档
-- SELECT * FROM v_published_docs WHERE org_id = 'org_demo_internal' LIMIT 10;

-- 查询热门文档
-- SELECT * FROM v_popular_docs WHERE org_id = 'org_demo_internal';

-- 查询待审核文档
-- SELECT * FROM v_docs_pending_review WHERE org_id = 'org_demo_internal';

-- 查询文档版本历史
-- SELECT * FROM v_doc_version_history WHERE parent_doc_id = 'doc_001' OR doc_id = 'doc_001';

-- 全文搜索
-- SELECT * FROM knowledge_docs_fts WHERE knowledge_docs_fts MATCH '数据库';

COMMIT;
