-- Migration: 014_memory_architecture
-- Created: 2026-03-27 15:16
-- Description: 创建三层记忆架构表 (工作记忆/语义记忆/事实记忆/验证日志)

BEGIN TRANSACTION;

-- L1: 工作记忆表
CREATE TABLE IF NOT EXISTS memory_working (
    memory_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    user_id TEXT,
    content TEXT NOT NULL,
    role TEXT NOT NULL,
    metadata TEXT DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    CHECK (role IN ('user', 'assistant', 'system'))
);

CREATE INDEX IF NOT EXISTS idx_memory_working_session ON memory_working(session_id);
CREATE INDEX IF NOT EXISTS idx_memory_working_expires ON memory_working(expires_at);

-- L2: 语义记忆表
CREATE TABLE IF NOT EXISTS memory_semantic (
    memory_id TEXT PRIMARY KEY,
    vector_id TEXT,
    content TEXT NOT NULL,
    summary TEXT,
    category TEXT DEFAULT 'general',
    confidence REAL DEFAULT 1.0,
    source_session_id TEXT,
    source_message_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at TIMESTAMP,
    access_count INTEGER DEFAULT 0,
    verified INTEGER DEFAULT 0,
    verified_by TEXT,
    verified_at TIMESTAMP,
    deleted_at TIMESTAMP,
    CHECK (category IN ('fact', 'opinion', 'preference', 'context', 'emotion', 'general')),
    CHECK (confidence >= 0 AND confidence <= 1)
);

CREATE INDEX IF NOT EXISTS idx_memory_semantic_category ON memory_semantic(category);
CREATE INDEX IF NOT EXISTS idx_memory_semantic_confidence ON memory_semantic(confidence);
CREATE INDEX IF NOT EXISTS idx_memory_semantic_verified ON memory_semantic(verified);

-- L3: 事实记忆表
CREATE TABLE IF NOT EXISTS memory_facts (
    fact_id TEXT PRIMARY KEY,
    subject TEXT NOT NULL,
    predicate TEXT NOT NULL,
    object TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    confidence REAL DEFAULT 1.0,
    source_memory_id TEXT,
    verified INTEGER DEFAULT 1,
    verified_by TEXT,
    verified_at TIMESTAMP,
    valid_from DATE DEFAULT (DATE('now')),
    valid_until DATE,
    deleted_at TIMESTAMP,
    CHECK (category IN ('personal', 'professional', 'preference', 'skill', 'context', 'general')),
    CHECK (confidence >= 0 AND confidence <= 1)
);

CREATE INDEX IF NOT EXISTS idx_memory_facts_subject ON memory_facts(subject);
CREATE INDEX IF NOT EXISTS idx_memory_facts_category ON memory_facts(category);
CREATE INDEX IF NOT EXISTS idx_memory_facts_verified ON memory_facts(verified);

-- 验证日志表
CREATE TABLE IF NOT EXISTS memory_verification_log (
    log_id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL,
    memory_type TEXT NOT NULL,
    verification_type TEXT NOT NULL,
    original_content TEXT,
    verified_content TEXT,
    result TEXT NOT NULL,
    reason TEXT,
    confidence_before REAL,
    confidence_after REAL,
    verified_by TEXT,
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (memory_type IN ('semantic', 'fact')),
    CHECK (verification_type IN ('user_confirm', 'auto_verify', 'conflict_detect', 'cross_validate')),
    CHECK (result IN ('confirmed', 'corrected', 'rejected'))
);

CREATE INDEX IF NOT EXISTS idx_memory_verification_memory ON memory_verification_log(memory_id);

-- 视图：活跃工作记忆
CREATE VIEW IF NOT EXISTS v_active_working_memory AS
SELECT memory_id, session_id, user_id, content, role, created_at, expires_at
FROM memory_working
WHERE expires_at > CURRENT_TIMESTAMP
ORDER BY created_at DESC;

-- 视图：已验证事实
CREATE VIEW IF NOT EXISTS v_verified_facts AS
SELECT fact_id, subject, predicate, object, category, confidence, verified_by, verified_at
FROM memory_facts
WHERE deleted_at IS NULL AND verified = 1
ORDER BY verified_at DESC;

COMMIT;
