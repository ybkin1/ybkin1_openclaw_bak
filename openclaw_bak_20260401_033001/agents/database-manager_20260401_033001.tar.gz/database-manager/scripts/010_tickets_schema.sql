-- Migration: 010_tickets_schema
-- Created: 2026-03-27 08:55
-- Task: 1.1.7 (设计 tickets 表 - 工单系统)
-- Description: 工单系统表，支持工单提交、分配、处理、流转
-- Dependencies: 001_organizations_schema.sql, 002_users_schema.sql, 003_tracks_schema.sql, 007_records_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：tickets
-- 描述：工单系统表，支持工单提交、分配、处理、流转
-- ============================================================================

CREATE TABLE IF NOT EXISTS tickets (
    -- 主键
    ticket_id TEXT PRIMARY KEY,
    
    -- 组织关联 (多租户隔离)
    org_id TEXT NOT NULL,
    
    -- 关联对象 (可选)
    track_id TEXT,                     -- 关联赛道
    record_id TEXT,                    -- 关联记录
    file_id TEXT,                      -- 关联文件
    
    -- 工单基本信息
    ticket_number TEXT NOT NULL,       -- 工单编号 (如：TKT-2026-0001)
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    
    -- 工单类型
    ticket_type TEXT NOT NULL,         -- bug/feature/question/complaint/incident
    ticket_category TEXT,              -- 技术/产品/运营/财务等
    ticket_priority TEXT DEFAULT 'medium',  -- low/medium/high/critical
    
    -- 状态管理
    status TEXT DEFAULT 'open',        -- open/in_progress/pending/resolved/closed
    resolution TEXT,                   -- 解决方案
    
    -- 人员关联
    reporter_id TEXT NOT NULL,         -- 报告人 user_id
    assignee_id TEXT,                  -- 处理人 user_id
    resolver_id TEXT,                  -- 解决人 user_id
    
    -- SLA 管理
    sla_hours INTEGER,                 -- SLA 时限 (小时)
    due_at TIMESTAMP,                  -- 截止时间
    first_response_at TIMESTAMP,       -- 首次响应时间
    resolved_at TIMESTAMP,             -- 解决时间
    closed_at TIMESTAMP,               -- 关闭时间
    
    -- 满意度
    satisfaction_rating INTEGER,       -- 满意度评分 (1-5)
    satisfaction_comment TEXT,         -- 满意度评价
    
    -- 元数据
    tags JSON DEFAULT '[]',            -- 标签列表
    custom_fields JSON DEFAULT '{}',   -- 自定义字段
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    
    -- 约束
    CHECK (ticket_type IN ('bug', 'feature', 'question', 'complaint', 'incident')),
    CHECK (ticket_priority IN ('low', 'medium', 'high', 'critical')),
    CHECK (status IN ('open', 'in_progress', 'pending', 'resolved', 'closed')),
    CHECK (satisfaction_rating >= 1 AND satisfaction_rating <= 5),
    CHECK (sla_hours > 0)
    -- 外键约束（部署时确保依赖表已创建）
    -- FOREIGN KEY (org_id) REFERENCES organizations(org_id),
    -- FOREIGN KEY (track_id) REFERENCES tracks(track_id),
    -- FOREIGN KEY (record_id) REFERENCES records(record_id),
    -- FOREIGN KEY (file_id) REFERENCES files(file_id),
    -- FOREIGN KEY (reporter_id) REFERENCES users(user_id),
    -- FOREIGN KEY (assignee_id) REFERENCES users(user_id),
    -- FOREIGN KEY (resolver_id) REFERENCES users(user_id)
);

-- ============================================================================
-- 表名：ticket_comments
-- 描述：工单评论表
-- ============================================================================

CREATE TABLE IF NOT EXISTS ticket_comments (
    -- 主键
    comment_id TEXT PRIMARY KEY,
    
    -- 工单关联
    ticket_id TEXT NOT NULL,
    
    -- 评论内容
    content TEXT NOT NULL,
    content_html TEXT,
    
    -- 评论类型
    comment_type TEXT DEFAULT 'comment',  -- comment/internal_note/attachment
    
    -- 人员关联
    author_id TEXT NOT NULL,
    
    -- 父评论 (回复)
    parent_comment_id TEXT,
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    
    -- 约束
    CHECK (comment_type IN ('comment', 'internal_note', 'attachment')),
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id),
    FOREIGN KEY (author_id) REFERENCES users(user_id),
    FOREIGN KEY (parent_comment_id) REFERENCES ticket_comments(comment_id)
);

-- ============================================================================
-- 表名：ticket_activities
-- 描述：工单活动日志表 (状态变更、分配等)
-- ============================================================================

CREATE TABLE IF NOT EXISTS ticket_activities (
    -- 主键
    activity_id TEXT PRIMARY KEY,
    
    -- 工单关联
    ticket_id TEXT NOT NULL,
    
    -- 活动信息
    activity_type TEXT NOT NULL,       -- created/assigned/status_changed/priority_changed/commented/resolved/closed
    old_value TEXT,                    -- 旧值
    new_value TEXT,                    -- 新值
    
    -- 人员关联
    actor_id TEXT NOT NULL,            -- 操作人 user_id
    
    -- 审计字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 约束
    CHECK (activity_type IN ('created', 'assigned', 'status_changed', 'priority_changed', 'commented', 'resolved', 'closed', 'reopened')),
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id),
    FOREIGN KEY (actor_id) REFERENCES users(user_id)
);

-- ============================================================================
-- 索引：tickets
-- ============================================================================

-- 按组织查询
CREATE INDEX IF NOT EXISTS idx_tickets_org_id ON tickets(org_id);

-- 按工单编号查询
CREATE UNIQUE INDEX IF NOT EXISTS idx_tickets_number ON tickets(org_id, ticket_number);

-- 按状态查询
CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);

-- 按类型查询
CREATE INDEX IF NOT EXISTS idx_tickets_type ON tickets(ticket_type);

-- 按优先级查询
CREATE INDEX IF NOT EXISTS idx_tickets_priority ON tickets(ticket_priority);

-- 按报告人查询
CREATE INDEX IF NOT EXISTS idx_tickets_reporter ON tickets(reporter_id);

-- 按处理人查询
CREATE INDEX IF NOT EXISTS idx_tickets_assignee ON tickets(assignee_id);

-- 按创建时间排序
CREATE INDEX IF NOT EXISTS idx_tickets_created_at ON tickets(created_at);

-- 按截止时间排序 (逾期检测)
CREATE INDEX IF NOT EXISTS idx_tickets_due_at ON tickets(due_at);

-- 复合索引：组织 + 状态 + 处理人 (我的工单)
CREATE INDEX IF NOT EXISTS idx_tickets_org_assignee_status ON tickets(org_id, assignee_id, status);

-- 复合索引：组织 + 状态 + 优先级 (工单列表)
CREATE INDEX IF NOT EXISTS idx_tickets_org_status_priority ON tickets(org_id, status, ticket_priority);

-- ============================================================================
-- 索引：ticket_comments
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_ticket_comments_ticket_id ON ticket_comments(ticket_id);
CREATE INDEX IF NOT EXISTS idx_ticket_comments_author ON ticket_comments(author_id);
CREATE INDEX IF NOT EXISTS idx_ticket_comments_created_at ON ticket_comments(created_at);

-- ============================================================================
-- 索引：ticket_activities
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_ticket_activities_ticket_id ON ticket_activities(ticket_id);
CREATE INDEX IF NOT EXISTS idx_ticket_activities_actor ON ticket_activities(actor_id);
CREATE INDEX IF NOT EXISTS idx_ticket_activities_created_at ON ticket_activities(created_at);

-- ============================================================================
-- 触发器：自动更新 updated_at
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_tickets_updated_at
AFTER UPDATE ON tickets
BEGIN
    UPDATE tickets SET updated_at = CURRENT_TIMESTAMP WHERE ticket_id = NEW.ticket_id;
END;

CREATE TRIGGER IF NOT EXISTS update_ticket_comments_updated_at
AFTER UPDATE ON ticket_comments
BEGIN
    UPDATE ticket_comments SET updated_at = CURRENT_TIMESTAMP WHERE comment_id = NEW.comment_id;
END;

-- ============================================================================
-- 视图：我的工单
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_my_tickets AS
SELECT 
    t.ticket_id,
    t.ticket_number,
    t.title,
    t.ticket_type,
    t.ticket_priority,
    t.status,
    t.reporter_id,
    r.username as reporter_name,
    t.assignee_id,
    a.username as assignee_name,
    t.due_at,
    t.created_at,
    CASE 
        WHEN t.due_at < datetime('now') AND t.status NOT IN ('resolved', 'closed') THEN 'overdue'
        WHEN t.due_at <= datetime('now', '+4 hours') THEN 'due_soon'
        ELSE 'ok'
    END AS due_status
FROM tickets t
LEFT JOIN users r ON t.reporter_id = r.user_id
LEFT JOIN users a ON t.assignee_id = a.user_id
WHERE t.deleted_at IS NULL;

-- ============================================================================
-- 视图：逾期工单
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_overdue_tickets AS
SELECT 
    ticket_id,
    ticket_number,
    title,
    ticket_type,
    ticket_priority,
    assignee_id,
    reporter_id,
    due_at,
    JULIANDAY('now') - JULIANDAY(due_at) AS hours_overdue
FROM tickets
WHERE deleted_at IS NULL
  AND status NOT IN ('resolved', 'closed')
  AND due_at < datetime('now')
ORDER BY due_at ASC;

-- ============================================================================
-- 视图：工单统计
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_ticket_stats AS
SELECT 
    org_id,
    ticket_type,
    status,
    COUNT(*) as count,
    SUM(CASE WHEN ticket_priority = 'critical' THEN 1 ELSE 0 END) as critical_count,
    SUM(CASE WHEN ticket_priority = 'high' THEN 1 ELSE 0 END) as high_count,
    AVG(satisfaction_rating) as avg_satisfaction
FROM tickets
WHERE deleted_at IS NULL
GROUP BY org_id, ticket_type, status;

-- ============================================================================
-- 示例数据：tickets
-- ============================================================================

INSERT OR IGNORE INTO tickets (ticket_id, org_id, ticket_number, title, description, ticket_type, ticket_category, ticket_priority, status, reporter_id, assignee_id, sla_hours, due_at, created_at, tags) VALUES
    -- Bug 类型
    ('ticket_001', 'org_demo_internal', 'TKT-2026-0001', '数据库外键约束不生效', 'SQLite 默认不启用外键约束，需要手动 PRAGMA foreign_keys = ON', 'bug', '技术', 'high', 'resolved', 'user_001_super', 'user_002_internal', 24, datetime('2026-03-26 10:00:00'), '2026-03-25 10:00:00', '["bug", "database", "sqlite"]'),
    
    -- Feature 类型
    ('ticket_002', 'org_demo_internal', 'TKT-2026-0002', '增加全文搜索功能', '需要为 knowledge_docs 表添加 FTS5 全文搜索支持', 'feature', '技术', 'medium', 'in_progress', 'user_002_internal', 'user_001_super', 48, datetime('2026-03-28 14:00:00'), '2026-03-26 14:00:00', '["feature", "search", "fts5"]'),
    
    -- Question 类型
    ('ticket_003', 'org_demo_customer_1', 'TKT-2026-0003', '如何配置多租户隔离？', '想了解多租户数据隔离的最佳实践', 'question', '技术', 'low', 'resolved', 'user_003_customer_a', 'user_001_super', 48, datetime('2026-03-27 09:00:00'), '2026-03-25 09:00:00', '["question", "multi-tenant"]'),
    
    -- Incident 类型 (紧急)
    ('ticket_004', 'org_demo_internal', 'TKT-2026-0004', '生产环境数据库连接失败', 'Gateway 无法连接数据库，服务中断', 'incident', '技术', 'critical', 'closed', 'user_001_super', 'user_002_internal', 4, datetime('2026-03-24 16:00:00'), '2026-03-24 15:30:00', '["incident", "production", "database"]'),
    
    -- Complaint 类型
    ('ticket_005', 'org_demo_customer_1', 'TKT-2026-0005', '响应速度太慢', '工单提交后 2 天才回复', 'complaint', '服务', 'medium', 'pending', 'user_004_customer_a', 'user_003_customer_a', 24, datetime('2026-03-28 10:00:00'), '2026-03-27 10:00:00', '["complaint", "service"]'),
    
    -- 逾期工单 (测试用)
    ('ticket_006', 'org_demo_internal', 'TKT-2026-0006', '逾期工单示例', '这个工单已经逾期了', 'bug', '技术', 'high', 'open', 'user_002_internal', 'user_001_super', 24, datetime('2026-03-26 08:00:00'), '2026-03-25 08:00:00', '["overdue", "test"]');

-- ============================================================================
-- 示例数据：ticket_comments
-- ============================================================================

INSERT OR IGNORE INTO ticket_comments (comment_id, ticket_id, content, comment_type, author_id, created_at) VALUES
    ('comment_001', 'ticket_001', '已确认问题，SQLite 需要手动启用外键约束', 'comment', 'user_002_internal', '2026-03-25 11:00:00'),
    ('comment_002', 'ticket_001', '已在 Database Manager 中添加初始化代码', 'comment', 'user_002_internal', '2026-03-25 14:00:00'),
    ('comment_003', 'ticket_002', 'FTS5 虚拟表已创建，正在添加同步触发器', 'comment', 'user_001_super', '2026-03-27 08:00:00'),
    ('comment_004', 'ticket_004', '已恢复，根因是配置错误', 'comment', 'user_002_internal', '2026-03-24 15:45:00'),
    ('comment_005', 'ticket_001', '感谢快速解决！', 'comment', 'user_001_super', '2026-03-25 15:00:00');

-- ============================================================================
-- 示例数据：ticket_activities
-- ============================================================================

INSERT OR IGNORE INTO ticket_activities (activity_id, ticket_id, activity_type, old_value, new_value, actor_id, created_at) VALUES
    ('activity_001', 'ticket_001', 'created', null, 'open', 'user_001_super', '2026-03-25 10:00:00'),
    ('activity_002', 'ticket_001', 'assigned', null, 'user_002_internal', 'user_001_super', '2026-03-25 10:05:00'),
    ('activity_003', 'ticket_001', 'status_changed', 'open', 'in_progress', 'user_002_internal', '2026-03-25 11:00:00'),
    ('activity_004', 'ticket_001', 'status_changed', 'in_progress', 'resolved', 'user_002_internal', '2026-03-25 14:00:00'),
    ('activity_005', 'ticket_004', 'created', null, 'open', 'user_001_super', '2026-03-24 15:30:00'),
    ('activity_006', 'ticket_004', 'assigned', null, 'user_002_internal', 'user_001_super', '2026-03-24 15:30:00'),
    ('activity_007', 'ticket_004', 'status_changed', 'open', 'in_progress', 'user_002_internal', '2026-03-24 15:35:00'),
    ('activity_008', 'ticket_004', 'status_changed', 'in_progress', 'resolved', 'user_002_internal', '2026-03-24 15:45:00'),
    ('activity_009', 'ticket_004', 'status_changed', 'resolved', 'closed', 'user_001_super', '2026-03-24 16:00:00');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM tickets;
-- SELECT COUNT(*) FROM ticket_comments;
-- SELECT COUNT(*) FROM ticket_activities;

-- 查询我的工单
-- SELECT * FROM v_my_tickets WHERE assignee_id = 'user_001_super';

-- 查询逾期工单
-- SELECT * FROM v_overdue_tickets WHERE org_id = 'org_demo_internal';

-- 查询工单统计
-- SELECT * FROM v_ticket_stats WHERE org_id = 'org_demo_internal';

COMMIT;
