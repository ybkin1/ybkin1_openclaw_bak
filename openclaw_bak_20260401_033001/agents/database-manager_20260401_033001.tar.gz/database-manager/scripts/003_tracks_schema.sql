-- Migration: 003_tracks_schema
-- Created: 2026-03-27 07:32
-- Task: 1.1.3 (设计 tracks 表)
-- Description: 赛道/项目表，支持多赛道管理、状态跟踪、资源配置
-- Author: database-manager Agent
-- Dependencies: 001_organizations_schema.sql (必须先行执行)

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：tracks
-- 描述：赛道/项目表，用于管理不同业务赛道或项目
-- ============================================================================

CREATE TABLE IF NOT EXISTS tracks (
    -- 主键
    track_id TEXT PRIMARY KEY,
    
    -- 组织关联 (多租户隔离)
    org_id TEXT NOT NULL,
    
    -- 基本信息
    name TEXT NOT NULL,                        -- 赛道名称
    code TEXT,                                 -- 赛道编码 (唯一标识)
    description TEXT,                          -- 赛道描述
    category TEXT,                             -- 赛道分类 (ai/media/stock/internal)
    
    -- 状态管理
    status TEXT DEFAULT 'active',              -- active/planning/paused/completed/archived
    priority TEXT DEFAULT 'medium',            -- low/medium/high/critical
    
    -- 资源配置
    budget DECIMAL(15, 2),                     -- 预算
    currency TEXT DEFAULT 'CNY',               -- 货币类型
    team_size INTEGER DEFAULT 0,               -- 团队规模
    
    -- 时间管理
    start_date DATE,                           -- 开始日期
    end_date DATE,                             -- 结束日期
    milestone_count INTEGER DEFAULT 0,         -- 里程碑数量
    
    -- 配置
    config JSON DEFAULT '{}',                  -- 赛道特定配置
    
    -- 审计字段
    created_by TEXT,                           -- 创建人 user_id
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,                 -- 软删除标记
    
    -- 约束
    CHECK (status IN ('active', 'planning', 'paused', 'completed', 'archived')),
    CHECK (priority IN ('low', 'medium', 'high', 'critical')),
    CHECK (category IN ('ai', 'media', 'stock', 'internal', 'customer', 'other')),
    CHECK (team_size >= 0),
    UNIQUE (org_id, code),                     -- 同一组织内赛道编码唯一
    FOREIGN KEY (org_id) REFERENCES organizations(org_id)
    -- 注意：移除了 ON DELETE CASCADE，防止误删组织导致赛道数据丢失
    -- 删除组织前需应用层检查并处理关联数据
);

-- ============================================================================
-- 索引
-- ============================================================================

-- 按组织查询 (多租户隔离，最常用)
CREATE INDEX IF NOT EXISTS idx_tracks_org_id ON tracks(org_id);

-- 按状态查询 (过滤活跃赛道)
CREATE INDEX IF NOT EXISTS idx_tracks_status ON tracks(status);

-- 按优先级查询 (资源分配)
CREATE INDEX IF NOT EXISTS idx_tracks_priority ON tracks(priority);

-- 按分类查询
CREATE INDEX IF NOT EXISTS idx_tracks_category ON tracks(category);

-- 按创建时间排序
CREATE INDEX IF NOT EXISTS idx_tracks_created_at ON tracks(created_at);

-- 按开始日期排序 (时间线视图)
CREATE INDEX IF NOT EXISTS idx_tracks_start_date ON tracks(start_date);

-- 复合索引：组织 + 状态 (常用组合查询)
CREATE INDEX IF NOT EXISTS idx_tracks_org_status ON tracks(org_id, status);

-- 复合索引：组织 + 优先级 (资源分配查询)
CREATE INDEX IF NOT EXISTS idx_tracks_org_priority ON tracks(org_id, priority);

-- 复合索引：状态 + 优先级 (优先级排序)
CREATE INDEX IF NOT EXISTS idx_tracks_status_priority ON tracks(status, priority);

-- ============================================================================
-- 触发器：自动更新 updated_at
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_tracks_updated_at
AFTER UPDATE ON tracks
BEGIN
    UPDATE tracks SET updated_at = CURRENT_TIMESTAMP WHERE track_id = NEW.track_id;
END;

-- ============================================================================
-- 视图：活跃赛道统计
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_active_tracks_summary AS
SELECT 
    org_id,
    COUNT(*) as total_tracks,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
    SUM(CASE WHEN status = 'planning' THEN 1 ELSE 0 END) as planning_count,
    SUM(CASE WHEN status = 'paused' THEN 1 ELSE 0 END) as paused_count,
    SUM(CASE WHEN priority = 'critical' THEN 1 ELSE 0 END) as critical_count,
    SUM(CASE WHEN priority = 'high' THEN 1 ELSE 0 END) as high_count,
    SUM(budget) as total_budget
FROM tracks
WHERE deleted_at IS NULL
GROUP BY org_id;

-- ============================================================================
-- 视图：即将到期的赛道
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_tracks_expiring_soon AS
SELECT 
    track_id,
    org_id,
    name,
    code,
    status,
    priority,
    start_date,
    end_date,
    CASE 
        WHEN end_date IS NULL THEN 'no_end_date'
        WHEN end_date < DATE('now') THEN 'expired'
        WHEN end_date <= DATE('now', '+7 days') THEN 'expiring_7days'
        WHEN end_date <= DATE('now', '+30 days') THEN 'expiring_30days'
        ELSE 'ok'
    END AS expiry_status,
    JULIANDAY(end_date) - JULIANDAY('now') AS days_remaining
FROM tracks
WHERE deleted_at IS NULL 
  AND status IN ('active', 'planning')
  AND end_date IS NOT NULL
ORDER BY days_remaining ASC;

-- ============================================================================
-- 示例数据 (测试用)
-- ============================================================================

INSERT OR IGNORE INTO tracks (track_id, org_id, name, code, category, status, priority, budget, start_date, end_date, created_by, description) VALUES
    -- AI 赛道
    ('track_001_ai', 'org_demo_internal', 'AI  Agent 开发', 'AI-001', 'ai', 'active', 'high', 
     500000.00, '2026-01-01', '2026-12-31', 'user_001_super', 'AI Agent 和自动化系统开发'),
    
    -- 自媒体赛道
    ('track_002_media', 'org_demo_internal', '自媒体运营', 'MEDIA-001', 'media', 'active', 'medium',
     100000.00, '2026-01-01', '2026-12-31', 'user_001_super', '抖音、小红书内容创作'),
    
    -- A 股炒股赛道
    ('track_003_stock', 'org_demo_internal', 'A 股投资', 'STOCK-001', 'stock', 'active', 'critical',
     1000000.00, '2026-01-01', '2026-12-31', 'user_001_super', 'A 股市场投资交易'),
    
    -- 客户项目 A
    ('track_004_customer_a', 'org_demo_customer_1', '客户 A-数字化转型', 'CUST-A-001', 'customer', 'active', 'high',
     2000000.00, '2026-02-01', '2026-08-31', 'user_003_customer_a', '客户 A 的数字化转型项目'),
    
    -- 客户项目 B
    ('track_005_customer_b', 'org_demo_customer_2', '客户 B-数据平台建设', 'CUST-B-001', 'customer', 'planning', 'high',
     1500000.00, '2026-04-01', '2026-10-31', 'user_006_customer_b', '客户 B 的数据平台建设项目'),
    
    -- 内部工具开发
    ('track_006_internal', 'org_demo_internal', '内部工具开发', 'INT-001', 'internal', 'active', 'medium',
     200000.00, '2026-03-01', '2026-06-30', 'user_002_internal', '内部运维工具和监控系统'),
    
    -- 已暂停的赛道
    ('track_007_paused', 'org_demo_customer_1', '客户 A-移动端开发', 'CUST-A-002', 'customer', 'paused', 'low',
     300000.00, '2025-10-01', '2026-03-31', 'user_003_customer_a', '因需求变更暂停'),
    
    -- 已完成的赛道
    ('track_008_completed', 'org_demo_internal', '2025 年度系统迁移', 'MIG-2025', 'internal', 'completed', 'critical',
     800000.00, '2025-01-01', '2025-12-31', 'user_001_super', '已完成的历史项目');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 验证表创建
-- SELECT COUNT(*) FROM tracks;

-- 验证索引
-- SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='tracks';

-- 验证触发器
-- SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='tracks';

-- 查询某组织的所有活跃赛道
-- SELECT track_id, name, code, status, priority FROM tracks WHERE org_id = 'org_demo_internal' AND status = 'active';

-- 查询即将到期的赛道
-- SELECT * FROM v_tracks_expiring_soon WHERE expiry_status IN ('expiring_7days', 'expiring_30days');

-- 查询各组织的赛道统计
-- SELECT * FROM v_active_tracks_summary;

COMMIT;
