# TOOLS.md - 本地工具与配置

## 🖥️ 服务器部署

### 主控服务器
- **服务器**: OpenCloudOS 9.4
- **IP**: 43.166.175.41
- **运行目录**: `/root/.openclaw/workspace/agents/master`
- **OpenClaw Gateway**: systemd 服务 (18789端口)
- **服务状态**: `systemctl --user status openclaw-gateway`

### 备份策略
- **统一备份目录**: `/root/.openclaw/backups-unified/`
- **保留策略**: 最多4份，自动清理旧备份
- **备份内容**: 所有 agents、配置、memory、skills
- **备份方式**: 本地 + GitHub (双备份)

---

## 🤖 Agent 工具链

### 任务分类与路由
| 工具 | 路径 | 用途 |
|------|------|------|
| 任务分类器 | `/root/.openclaw/workspace/agents/master/scripts/task-classifier.sh` | 判断任务复杂度 |
| 任务路由器 | `/root/.openclaw/workspace/agents/master/scripts/task-router.sh` | 自动转发复杂任务 |
| 结果获取器 | `/root/.openclaw/workspace/agents/master/scripts/get-assistant-results.sh` | 获取助手处理结果 |

### Assistant Agent 工具
| 工具 | 路径 | 用途 |
|------|------|------|
| 任务监听器 | `/root/.openclaw/workspace/agents/assistant/scripts/task-listener.sh` | 守护进程，监听任务 |
| 单次扫描 | `/root/.openclaw/workspace/agents/assistant/scripts/task-scan-once.sh` | 手动触发一次扫描 |
| 启动脚本 | `/root/.openclaw/workspace/agents/assistant/scripts/start.sh` | 启动Assistant服务 |

---

## 📁 目录结构

```
/root/.openclaw/
├── openclaw.json                    # 全局配置
├── backups-unified/                 # 统一备份目录
└── workspace/
    └── agents/
        ├── master/                  # 主控 Agent
        │   ├── AGENT.md             # 配置说明
        │   ├── AGENTS.md            # 系统规则（当前文档）
        │   ├── scripts/             # Master 工具脚本
        │   │   ├── task-classifier.sh
        │   │   ├── task-router.sh
        │   │   └── get-assistant-results.sh
        │   └── memory/              # Master 记忆
        │       ├── master/
        │       │   ├── long_term/
        │       │   ├── short_term/
        │       │   └── tasks/
        │       └── shared/          # 共享记忆
        ├── assistant/               # 助手 Agent
        │   ├── .openclaw/
        │   │   └── agent.json      # 模型配置
        │   ├── AGENT.md
        │   ├── AGENT_RULES.md      # 详细规则
        │   ├── scripts/             # Assistant 脚本
        │   │   ├── task-listener.sh (守护进程)
        │   │   ├── task-scan-once.sh (单次扫描)
        │   │   └── start.sh (启动脚本)
        │   └── memory/
        │       └── assistant/
        │           ├── long_term/
        │           ├── short_term/
        │           └── tasks/       # 接收的任务 + completed
        ├── monitoring/
        ├── backup/
        ├── analysis/
        └── ... (其他功能 Agents)
```

---

## 🔧 常用命令

### 系统管理
```bash
# 检查 OpenClaw Gateway 状态
systemctl --user status openclaw-gateway

# 重启 Gateway (需维护窗口)
openclaw gateway restart

# 查看可用的模型
openclaw models list

# 检查 agent 状态
sessions_list

# 发送消息到其他 agent
sessions_send <session_key> "<message>"
```

### 任务处理
```bash
# 分类任务 (测试用)
/root/.openclaw/workspace/agents/master/scripts/task-classifier.sh "任务描述" "任务标题"

# 路由任务 (自动转发或自处理)
/root/.openclaw/workspace/agents/master/scripts/task-router.sh "任务描述" "任务标题" [元数据]

# 获取助手处理结果
/root/.openclaw/workspace/agents/master/scripts/get-assistant-results.sh
```

### Assistant 服务管理
```bash
# 启动 Assistant 服务
/root/.openclaw/workspace/agents/assistant/scripts/start.sh

# 手动触发任务扫描（如果监听器未运行）
/root/.openclaw/workspace/agents/assistant/scripts/task-scan-once.sh

# 查看日志
tail -f /root/.openclaw/workspace/agents/assistant/logs/task-listener.log

# 停止服务
pkill -f task-listener.sh
rm -f /tmp/assistant-agent.pid
```

### 记忆管理
```bash
# 搜索记忆
memory_search "关键词"

# 读取特定记忆文件
memory_get --path memory/daily/2026-03-18.md --lines 50

# 编辑记忆（使用备份脚本）
./scripts/edit-memory.sh edit "新增内容"

# 清理短期记忆
find agents/master/memory/master/short_term/ -mtime +7 -delete
```

---

## 📊 模型优先级

1. **主控任务**: `openrouter/stepfun/step-3.5-flash:free` (免费)
2. **复杂推理**: `qwencode/qwen3.5-plus` (强推理)
3. **通用任务**: `qwencode/qwen3.5-plus` (备用)
4. **开发任务**: `qwencode/qwen3-coder-plus` (代码专用)
5. **其他模型**: 按需使用

---

## 🌐 网络配置

### 本地服务
- Gateway 端口: 18789 (用户消息路由)
- Memos: 5230 (知识管理)
- SearXNG: 8080 (隐私搜索)

### 外部 API
- OpenRouter: 模型访问网关
- GitHub API: 备份同步
- 飞书 API: 消息接收与发送

---

## 🗃️ 文件命名规范

### 任务文件
```
task_YYYYMMDD_HHMMSS_<title-abbrev>.md
示例: task_20260318_132024_develop_backup_tool.md
```

### 结果文件
```
task_<id>_result.md
示例: task_20260318_132024_________result.md
```

### 记忆文件
```
daily/YYYY-MM-DD.md
decisions/YYYY-MM-DD-<topic>.md
knowledge/<topic>.md
```

---

## 🔒 安全提醒

- ✅ **使用**: read/write/edit 工具进行文件操作
- ✅ **执行**: 使用 exec 运行脚本，参数明确
- ❌ **禁止**: 直接修改 MEMORY.md 不备份
- ❌ **禁止**: 删除文件不用 trash 或询问
- ❌ **禁止**: 泄露用户数据或密钥

---

## 📞 紧急联系

当遇到无法解决的问题时：
1. 记录到 `memory/daily/` 完整问题描述
2. 尝试 `openclaw doctor --repair` 自动诊断
3. 向用户汇报并请求指导
4. 如果涉及生产环境故障，优先确保数据安全

---

**最后更新**: 2026-03-18 (系统架构对齐完成)
**维护者**: Master Agent (喵小白)
**状态**: ✅ 生产就绪