"""
Database Manager - CRUD 操作模块

提供统一的增删改查接口
"""

import json
import sqlite3
from typing import Optional, List, Dict, Any, Union
from datetime import datetime

try:
    from .connection import DatabaseConnection
except ImportError:
    from connection import DatabaseConnection

try:
    from .errors import (
        DatabaseError, parse_sqlite_error, NotFoundError,
        ValidationError, JSONError
    )
except ImportError:
    from errors import (
        DatabaseError, parse_sqlite_error, NotFoundError,
        ValidationError, JSONError
    )


class CRUDOperations:
    """CRUD 操作类"""
    
    def __init__(self, db: DatabaseConnection):
        self.db = db
    
    def _build_where_clause(self, where: Dict[str, Any]) -> tuple:
        if not where:
            return '', []
        
        clauses = []
        params = []
        
        for key, value in where.items():
            if value is None:
                clauses.append(f"{key} IS NULL")
            elif isinstance(value, (list, tuple)):
                placeholders = ','.join(['?' for _ in value])
                clauses.append(f"{key} IN ({placeholders})")
                params.extend(value)
            else:
                clauses.append(f"{key} = ?")
                params.append(value)
        
        return ' WHERE ' + ' AND '.join(clauses), params
    
    def fetch_one(self, table: str, where: Dict[str, Any], columns: List[str] = None) -> Optional[Dict[str, Any]]:
        cols = ', '.join(columns) if columns else '*'
        where_clause, params = self._build_where_clause(where)
        sql = f"SELECT {cols} FROM {table}{where_clause} LIMIT 1"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                row = cursor.fetchone()
                
                if row is None:
                    return None
                
                columns = [description[0] for description in cursor.description]
                return dict(zip(columns, row))
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def fetch_all(self, table: str, where: Dict[str, Any] = None, columns: List[str] = None,
                  order_by: str = None, limit: int = None, offset: int = None) -> List[Dict[str, Any]]:
        cols = ', '.join(columns) if columns else '*'
        where_clause, params = self._build_where_clause(where)
        
        sql = f"SELECT {cols} FROM {table}{where_clause}"
        
        if order_by:
            sql += f" ORDER BY {order_by}"
        
        if limit:
            sql += f" LIMIT {limit}"
        
        if offset:
            sql += f" OFFSET {offset}"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                
                columns = [description[0] for description in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def insert(self, table: str, data: Dict[str, Any]) -> str:
        data = self._validate_json_fields(data)
        
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        values = list(data.values())
        
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, values)
                self.db.conn.commit()
                return cursor.lastrowid
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def update(self, table: str, data: Dict[str, Any], where: Dict[str, Any]) -> int:
        data = self._validate_json_fields(data)
        
        set_clause = ', '.join([f"{key} = ?" for key in data.keys()])
        where_clause, params = self._build_where_clause(where)
        
        values = list(data.values()) + params
        sql = f"UPDATE {table} SET {set_clause}{where_clause}"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, values)
                self.db.conn.commit()
                return cursor.rowcount
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def delete(self, table: str, where: Dict[str, Any], soft: bool = True) -> int:
        if soft:
            data = {'deleted_at': datetime.now().isoformat()}
            return self.update(table, data, where)
        else:
            where_clause, params = self._build_where_clause(where)
            sql = f"DELETE FROM {table}{where_clause}"
            
            try:
                with self.db.cursor() as cursor:
                    cursor.execute(sql, params)
                    self.db.conn.commit()
                    return cursor.rowcount
                    
            except sqlite3.Error as e:
                raise parse_sqlite_error(e, sql)
    
    def _validate_json_fields(self, data: Dict[str, Any]) -> Dict[str, Any]:
        validated = {}
        
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                try:
                    validated[key] = json.dumps(value, ensure_ascii=False)
                except (TypeError, ValueError) as e:
                    raise JSONError(message=f"JSON 序列化失败：{key}", field=key)
            else:
                validated[key] = value
        
        return validated
    
    def count(self, table: str, where: Dict[str, Any] = None) -> int:
        where_clause, params = self._build_where_clause(where)
        sql = f"SELECT COUNT(*) as count FROM {table}{where_clause}"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                result = cursor.fetchone()
                return result[0] if result else 0
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
    
    def exists(self, table: str, where: Dict[str, Any]) -> bool:
        where_clause, params = self._build_where_clause(where)
        sql = f"SELECT 1 FROM {table}{where_clause} LIMIT 1"
        
        try:
            with self.db.cursor() as cursor:
                cursor.execute(sql, params)
                return cursor.fetchone() is not None
                
        except sqlite3.Error as e:
            raise parse_sqlite_error(e, sql)
