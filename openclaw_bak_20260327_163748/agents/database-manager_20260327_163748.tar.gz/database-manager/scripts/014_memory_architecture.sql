-- Migration: 014_memory_architecture
-- Created: 2026-03-27 15:16
-- Task: 记忆架构优化 - Phase 1
-- Description: 创建三层记忆架构表 (工作记忆/语义记忆/事实记忆/验证日志)
-- Dependencies: 002_users_schema.sql

BEGIN TRANSACTION;

-- ============================================================================
-- 表名：memory_working
-- 描述：工作记忆表 (L1 - 短期缓存，24 小时自动过期)
-- ============================================================================

CREATE TABLE IF NOT EXISTS memory_working (
    memory_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    user_id TEXT,
    content TEXT NOT NULL,
    role TEXT NOT NULL,  -- user/assistant/system
    metadata JSON DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,  -- 默认 24 小时后过期
    
    CHECK (role IN ('user', 'assistant', 'system'))
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_memory_working_session ON memory_working(session_id);
CREATE INDEX IF NOT EXISTS idx_memory_working_expires ON memory_working(expires_at);
CREATE INDEX IF NOT EXISTS idx_memory_working_created ON memory_working(created_at);

-- 自动清理触发器
CREATE TRIGGER IF NOT EXISTS cleanup_working_memory
AFTER INSERT ON memory_working
BEGIN
    DELETE FROM memory_working 
    WHERE expires_at < CURRENT_TIMESTAMP;
END;

-- ============================================================================
-- 表名：memory_semantic
-- 描述：语义记忆表 (L2 - 向量检索 + 元数据)
-- ============================================================================

CREATE TABLE IF NOT EXISTS memory_semantic (
    memory_id TEXT PRIMARY KEY,
    vector_id TEXT,  -- LanceDB 向量 ID
    
    -- 内容
    content TEXT NOT NULL,
    summary TEXT,  -- 摘要
    
    -- 元数据
    category TEXT DEFAULT 'general',  -- fact/opinion/preference/context/emotion
    confidence REAL DEFAULT 1.0,  -- 置信度 (0-1)
    
    -- 来源追溯
    source_session_id TEXT,
    source_message_id TEXT,
    
    -- 时间信息
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at TIMESTAMP,
    access_count INTEGER DEFAULT 0,
    
    -- 验证状态
    verified BOOLEAN DEFAULT FALSE,
    verified_by TEXT,  -- user_id 或 'system'
    verified_at TIMESTAMP,
    
    -- 软删除
    deleted_at TIMESTAMP NULL,
    
    -- 约束
    CHECK (category IN ('fact', 'opinion', 'preference', 'context', 'emotion', 'general')),
    CHECK (confidence >= 0 AND confidence <= 1)
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_memory_semantic_category ON memory_semantic(category);
CREATE INDEX IF NOT EXISTS idx_memory_semantic_confidence ON memory_semantic(confidence);
CREATE INDEX IF NOT EXISTS idx_memory_semantic_verified ON memory_semantic(verified);
CREATE INDEX IF NOT EXISTS idx_memory_semantic_access ON memory_semantic(last_accessed_at);
CREATE INDEX IF NOT EXISTS idx_memory_semantic_source ON memory_semantic(source_session_id);

-- ============================================================================
-- 表名：memory_facts
-- 描述：事实记忆表 (L3 - 已验证事实，结构化存储)
-- ============================================================================

CREATE TABLE IF NOT EXISTS memory_facts (
    fact_id TEXT PRIMARY KEY,
    
    -- 事实内容 (结构化：主谓宾)
    subject TEXT NOT NULL,  -- 主体
    predicate TEXT NOT NULL,  -- 关系/动作
    object TEXT NOT NULL,  -- 客体
    
    -- 示例：
    -- subject: "用户"
    -- predicate: "喜欢"
    -- object: "Python"
    
    -- 元数据
    category TEXT DEFAULT 'general',  -- personal/professional/preference/skill/context
    confidence REAL DEFAULT 1.0,
    
    -- 来源
    source_memory_id TEXT,
    FOREIGN KEY (source_memory_id) REFERENCES memory_semantic(memory_id),
    
    -- 验证
    verified BOOLEAN DEFAULT TRUE,  -- 事实必须经过验证
    verified_by TEXT,
    verified_at TIMESTAMP,
    
    -- 时间有效性
    valid_from DATE DEFAULT (DATE('now')),
    valid_until DATE,  -- NULL 表示永久有效
    
    -- 软删除
    deleted_at TIMESTAMP NULL,
    
    -- 约束
    CHECK (category IN ('personal', 'professional', 'preference', 'skill', 'context', 'general')),
    CHECK (confidence >= 0 AND confidence <= 1)
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_memory_facts_subject ON memory_facts(subject);
CREATE INDEX IF NOT EXISTS idx_memory_facts_category ON memory_facts(category);
CREATE INDEX IF NOT EXISTS idx_memory_facts_validity ON memory_facts(valid_from, valid_until);
CREATE INDEX IF NOT EXISTS idx_memory_facts_verified ON memory_facts(verified);

-- ============================================================================
-- 表名：memory_verification_log
-- 描述：记忆验证日志表 (记录验证历史)
-- ============================================================================

CREATE TABLE IF NOT EXISTS memory_verification_log (
    log_id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL,
    memory_type TEXT NOT NULL,  -- semantic/fact
    
    -- 验证类型
    verification_type TEXT NOT NULL,  -- user_confirm/auto_verify/conflict_detect/cross_validate
    
    -- 验证内容
    original_content TEXT,
    verified_content TEXT,
    
    -- 结果
    result TEXT NOT NULL,  -- confirmed/corrected/rejected
    reason TEXT,
    confidence_before REAL,
    confidence_after REAL,
    
    -- 审计
    verified_by TEXT,
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 外键
    FOREIGN KEY (memory_id) REFERENCES memory_semantic(memory_id),
    
    -- 约束
    CHECK (memory_type IN ('semantic', 'fact')),
    CHECK (verification_type IN ('user_confirm', 'auto_verify', 'conflict_detect', 'cross_validate')),
    CHECK (result IN ('confirmed', 'corrected', 'rejected'))
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_memory_verification_memory ON memory_verification_log(memory_id);
CREATE INDEX IF NOT EXISTS idx_memory_verification_type ON memory_verification_log(verification_type);
CREATE INDEX IF NOT EXISTS idx_memory_verification_result ON memory_verification_log(result);
CREATE INDEX IF NOT EXISTS idx_memory_verification_time ON memory_verification_log(verified_at);

-- ============================================================================
-- 视图：活跃工作记忆
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_active_working_memory AS
SELECT 
    memory_id,
    session_id,
    user_id,
    content,
    role,
    created_at,
    expires_at,
    (julianday(expires_at) - julianday('now')) * 24 as hours_until_expiry
FROM memory_working
WHERE expires_at > CURRENT_TIMESTAMP
ORDER BY created_at DESC;

-- ============================================================================
-- 视图：已验证事实
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_verified_facts AS
SELECT 
    fact_id,
    subject,
    predicate,
    object,
    category,
    confidence,
    verified_by,
    verified_at,
    valid_from,
    valid_until,
    CASE 
        WHEN valid_until IS NULL THEN 'permanent'
        WHEN valid_until < DATE('now') THEN 'expired'
        WHEN valid_until <= DATE('now', '+30 days') THEN 'expiring_soon'
        ELSE 'valid'
    END as validity_status
FROM memory_facts
WHERE deleted_at IS NULL 
  AND verified = TRUE
ORDER BY verified_at DESC;

-- ============================================================================
-- 视图：高置信度语义记忆
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_high_confidence_semantic AS
SELECT 
    memory_id,
    content,
    summary,
    category,
    confidence,
    source_session_id,
    access_count,
    verified,
    last_accessed_at
FROM memory_semantic
WHERE deleted_at IS NULL 
  AND confidence >= 0.8
  AND verified = TRUE
ORDER BY confidence DESC, access_count DESC;

-- ============================================================================
-- 视图：记忆验证统计
-- ============================================================================

CREATE VIEW IF NOT EXISTS v_verification_stats AS
SELECT 
    memory_type,
    verification_type,
    result,
    COUNT(*) as count,
    AVG(confidence_after - confidence_before) as avg_confidence_change
FROM memory_verification_log
GROUP BY memory_type, verification_type, result;

-- ============================================================================
-- 触发器：更新语义记忆访问时间
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS update_semantic_access
AFTER SELECT ON memory_semantic
BEGIN
    UPDATE memory_semantic 
    SET last_accessed_at = CURRENT_TIMESTAMP,
        access_count = access_count + 1
    WHERE memory_id = NEW.memory_id;
END;

-- ============================================================================
-- 触发器：事实冲突检测
-- ============================================================================

CREATE TRIGGER IF NOT EXISTS detect_fact_conflicts
AFTER INSERT ON memory_facts
WHEN NEW.verified = TRUE
BEGIN
    -- 检测冲突事实
    INSERT INTO memory_verification_log (log_id, memory_id, memory_type, verification_type, original_content, result, reason, verified_by, verified_at)
    SELECT 
        'log_conflict_' || datetime('now') || '_' || NEW.fact_id,
        NEW.fact_id,
        'fact',
        'conflict_detect',
        NEW.subject || ' ' || NEW.predicate || ' ' || NEW.object,
        'rejected',
        '与已验证事实冲突：' || mf.subject || ' ' || mf.predicate || ' ' || mf.object,
        'system',
        CURRENT_TIMESTAMP
    FROM memory_facts mf
    WHERE mf.subject = NEW.subject 
      AND mf.predicate = NEW.predicate 
      AND mf.object != NEW.object
      AND mf.verified = TRUE
      AND mf.deleted_at IS NULL
    LIMIT 1;
END;

-- ============================================================================
-- 示例数据
-- ============================================================================

-- 工作记忆示例
INSERT OR IGNORE INTO memory_working (memory_id, session_id, user_id, content, role, expires_at) VALUES
    ('wm_001', 'session_demo', 'user_demo', '用户询问如何配置数据库', 'user', datetime('now', '+24 hours')),
    ('wm_002', 'session_demo', 'assistant', '提供数据库配置步骤', 'assistant', datetime('now', '+24 hours'));

-- 语义记忆示例
INSERT OR IGNORE INTO memory_semantic (memory_id, content, summary, category, confidence, source_session_id, verified) VALUES
    ('sm_001', '用户喜欢 Python 编程', '用户偏好', 'preference', 0.9, 'session_demo', TRUE),
    ('sm_002', '用户是智算服务器硬件运维经理', '用户职业', 'context', 0.95, 'session_demo', TRUE);

-- 事实记忆示例
INSERT OR IGNORE INTO memory_facts (fact_id, subject, predicate, object, category, confidence, verified, verified_by) VALUES
    ('fact_001', '用户', '职业是', '智算服务器硬件运维经理', 'professional', 1.0, TRUE, 'user_confirm'),
    ('fact_002', '用户', '喜欢', 'Python 编程', 'preference', 1.0, TRUE, 'user_confirm');

-- ============================================================================
-- 验证查询
-- ============================================================================

-- 查询活跃工作记忆
-- SELECT * FROM v_active_working_memory WHERE session_id = 'session_demo';

-- 查询已验证事实
-- SELECT * FROM v_verified_facts WHERE category = 'professional';

-- 查询高置信度语义记忆
-- SELECT * FROM v_high_confidence_semantic LIMIT 10;

-- 查询验证统计
-- SELECT * FROM v_verification_stats;

COMMIT;
