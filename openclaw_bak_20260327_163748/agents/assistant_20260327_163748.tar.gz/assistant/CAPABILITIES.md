# Assistant Agent - 完整能力定义

**版本**: 2.0 (项目管理能力增强版)  
**生效日期**: 2026-03-26  
**适用范围**: 任务处理 + 项目管理 + Subagent 调度

---

## 🎯 核心能力矩阵

| 能力域 | 能力项 | 状态 | 说明 |
|--------|--------|------|------|
| **任务处理** | 复杂任务执行 | ✅ 已有 | 推理密集型任务 |
| | 系统升级 | ✅ 已有 | OpenClaw 版本更新 |
| | 代码开发 | ✅ 已有 | 脚本/工具开发 |
| **项目管理** | 任务分解 | 🆕 新增 | Milestone → Slice → Task |
| | 进度跟踪 | 🆕 新增 | 状态文件管理 |
| | Subagent 调度 | 🆕 新增 | sessions_spawn |
| | 会议组织 | 🆕 新增 | 站会/周报/回顾 |

---

## 🔧 新增能力详细说明

### 能力 5: 任务分解 (Task Breakdown)

#### 分解层级

```
Milestone (里程碑)
    ↓
Slice (切片)
    ↓
Task (任务)
    ↓
Subagent 执行单元
```

#### 分解规则

| 层级 | 数量 | 周期 | 说明 |
|------|------|------|------|
| Milestone | 4 个/项目 | 2-3 周 | 重大交付节点 |
| Slice | 2-3 个/Milestone | 3-5 天 | 功能模块 |
| Task | 5-8 个/Slice | 30-60 分钟 | 可执行单元 |

#### 分解模板

```markdown
# {Milestone 名称}

## Slice 1: {Slice 名称}

### Task 1.1.1: {Task 名称}
- **描述**: {一句话描述}
- **预计时长**: 30-60 分钟
- **验收标准**:
  - [ ] 标准 1
  - [ ] 标准 2
- **Subagent**: {agent_type}

### Task 1.1.2: {Task 名称}
...
```

---

### 能力 6: 进度跟踪 (Progress Tracking)

#### 状态文件管理

**文件位置**:
```
/root/.openclaw/workspace/agents/master/memory/tasks/active/
├── task_{task_id}.json          # 任务状态
├── current_milestone.md          # 当前 Milestone
├── current_slice.md              # 当前 Slice
├── current_task.md               # 当前 Task
└── session_checkpoint.json       # 会话检查点
```

#### 状态文件结构

```json
{
  "task_id": "task_20260326_104600_enterprise_data_rag_architecture",
  "status": "in_progress",
  "created_at": "2026-03-26T10:46:00+08:00",
  "updated_at": "2026-03-26T12:40:00+08:00",
  
  "current_position": {
    "milestone": 1,
    "slice": 1,
    "task": 3,
    "task_id": "1.1.3"
  },
  
  "completed_tasks": [
    {
      "task_id": "1.1.1",
      "completed_at": "2026-03-26T12:00:00+08:00",
      "commit_hash": "abc123",
      "review_status": "approved"
    }
  ],
  
  "metrics": {
    "total_commits": 2,
    "total_tests": 15,
    "test_coverage": 0.82,
    "ai_hallucination_detected": 0,
    "review_rejections": 0
  }
}
```

#### 进度报告模板

```markdown
## 每日站会 - {date}

### 昨日完成
- Task 1.1.1: ✅ 完成
- Task 1.1.2: ✅ 完成

### 今日计划
- Task 1.1.3: 设计 tracks 表
- Task 1.1.4: 设计 records 表

### 阻塞项
- 无

### 风险预警
- 无
```

---

### 能力 7: Subagent 调度 (Subagent Dispatch)

#### 调度流程

```
1. 读取 Task 详情
2. 生成 Subagent Prompt (<1KB)
3. sessions_spawn 创建 Subagent
4. 等待完成 (timeout: 1h)
5. 收集结果
6. 触发审查 (Analysis Agent)
```

#### Prompt 模板

```python
def generate_subagent_prompt(task):
    """
    生成 Subagent Prompt (控制在 1KB 以内)
    """
    prompt = f"""
# 任务：{task['task_id']}

## 目标 (1 句话)
{task['one_sentence_goal']}

## 文件 (最多 3 个)
- {task['file_1']}
- {task['file_2']}

## 约束
- TDD mandatory: 先写测试，再实现功能
- 不得范围蔓延：仅实现当前 Task 要求的功能
- 完成后等待审查：Spec Review + Code Quality Review

## 验收标准 (3-5 条)
- [ ] {task['acceptance_criteria'][0]}
- [ ] {task['acceptance_criteria'][1]}
- [ ] {task['acceptance_criteria'][2]}

## 任务详情
{task['description']}
"""
    
    # 验证 Prompt 大小
    assert len(prompt.encode('utf-8')) < 1024, "Prompt 超过 1KB"
    
    return prompt
```

#### sessions_spawn 调用

```python
def dispatch_subagent(agent_type, task_prompt, timeout=3600):
    """
    调度 Subagent
    
    Args:
        agent_type: Agent 类型 (database-manager, file-processor, analysis)
        task_prompt: 任务 Prompt (<1KB)
        timeout: 超时时间 (秒)，默认 1 小时
    
    Returns:
        session_id: Subagent 会话 ID
    """
    session = sessions_spawn(
        agent_id=agent_type,
        task=task_prompt,
        mode="run",
        timeout_seconds=timeout,
        cleanup="keep"  # 保留会话记录
    )
    
    return session['session_id']
```

---

### 能力 8: 会议组织 (Meeting Facilitation)

#### 每日站会

**时间**: 每日 09:00 (5 分钟)

**议程**:
```markdown
1. 昨日完成 (2min)
2. 今日计划 (2min)
3. 阻塞项 (1min)
```

**输出**:
```markdown
## 站会纪要 - {date}

**参会**: Master, Assistant, Database-Manager, File-Processor

### 昨日完成
- Task 1.1.1: ✅
- Task 1.1.2: ✅

### 今日计划
- Task 1.1.3
- Task 1.1.4

### 阻塞项
- 无

### 行动项
- 无
```

#### 每周汇报

**时间**: 周一 10:00 (15 分钟)

**议程**:
```markdown
1. 上周完成情况 (5min)
2. 本周计划 (5min)
3. 风险与问题 (5min)
```

#### Milestone 回顾

**时间**: 每个 Milestone 结束 (30 分钟)

**议程**:
```markdown
1. 目标达成情况 (10min)
2. 经验教训 (10min)
3. 流程优化 (10min)
```

---

## 🛠️ 工具接口

### 任务分解工具

```python
def break_down_milestone(milestone_doc):
    """
    Milestone 分解为 Slice 和 Task
    
    Args:
        milestone_doc: Milestone 设计文档
    
    Returns:
        {
            'slices': [
                {
                    'slice_id': '1.1',
                    'name': 'Slice 名称',
                    'tasks': [
                        {
                            'task_id': '1.1.1',
                            'name': 'Task 名称',
                            'estimated_duration': 30,  # 分钟
                            'agent_type': 'database-manager'
                        }
                    ]
                }
            ]
        }
    """
    # 分解逻辑
    pass
```

### Subagent 调度工具

```python
def manage_subagent_lifecycle(task_id, agent_type, task_prompt):
    """
    管理 Subagent 生命周期
    
    Args:
        task_id: 任务 ID
        agent_type: Agent 类型
        task_prompt: 任务 Prompt
    
    Returns:
        {
            'status': 'completed|failed|timeout',
            'result': {...},
            'duration': 1800  # 秒
        }
    """
    # 1. 创建 Subagent
    session_id = dispatch_subagent(agent_type, task_prompt)
    
    # 2. 等待完成
    result = wait_for_session(session_id, timeout=3600)
    
    # 3. 更新状态
    update_task_status(task_id, result['status'])
    
    return result
```

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 新增能力定义完成
