#!/bin/bash
# Monitoring Agent Heartbeat
# Checks if monitoring agent is running properly

AGENT_ID="monitoring"
WORKSPACE="/root/.openclaw/workspace/agents/monitoring"
LOG_FILE="$WORKSPACE/logs/heartbeat.log"

# Log heartbeat
echo "$(date '+%Y-%m-%d %H:%M:%S') - $AGENT_ID heartbeat OK" >> "$LOG_FILE"

# Check if required directories exist
if [ ! -d "$WORKSPACE/memory" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: memory directory missing" >> "$LOG_FILE"
    exit 1
fi

# Check if AGENT.md exists
if [ ! -f "$WORKSPACE/AGENT.md" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: AGENT.md missing" >> "$LOG_FILE"
    exit 1
fi

exit 0