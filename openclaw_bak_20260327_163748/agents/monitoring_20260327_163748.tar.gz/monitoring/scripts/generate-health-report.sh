#!/bin/bash
# Monitoring Agent - 健康报告生成脚本
# 每日 8:30 执行，分析系统健康状态

set -euo pipefail

LOG_DIR="/root/.openclaw/logs"
HEALTH_LOG="$LOG_DIR/health-guardian.log"
GATEWAY_LOG="$LOG_DIR/gateway.log"
BACKUP_LOG="/root/.openclaw/backups-unified/logs/backup.log"
REPORT_DIR="/root/.openclaw/workspace/agents/monitoring/reports"
REPORT_FILE="$REPORT_DIR/health-report-$(date +%Y%m%d).md"

mkdir -p "$REPORT_DIR"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }

# 分析健康守护日志
analyze_health_guardian() {
    log "分析 Health Guardian 日志..."
    
    if [ ! -f "$HEALTH_LOG" ]; then
        echo "### Health Guardian 日志\n\n⚠ 日志文件不存在：$HEALTH_LOG\n"
        return
    fi
    
    local total_lines=$(wc -l < "$HEALTH_LOG")
    local error_count=$(grep -c "ERROR\|FAILED" "$HEALTH_LOG" 2>/dev/null || echo 0)
    local restart_count=$(grep -c "Restarting\|修复" "$HEALTH_LOG" 2>/dev/null || echo 0)
    local last_check=$(tail -1 "$HEALTH_LOG" | grep -oP '\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}' || echo "未知")
    
    cat << EOF
### Health Guardian 状态

| 指标 | 数值 |
|------|------|
| 日志总行数 | $total_lines |
| 错误次数 | $error_count |
| 重启次数 | $restart_count |
| 最后检查时间 | $last_check |

EOF
    
    # 最近 5 条错误
    if [ "$error_count" -gt 0 ]; then
        echo "#### 最近错误"
        echo '```'
        grep "ERROR\|FAILED" "$HEALTH_LOG" | tail -5
        echo '```'
        echo ""
    fi
}

# 分析 Gateway 日志
analyze_gateway() {
    log "分析 Gateway 日志..."
    
    if [ ! -f "$GATEWAY_LOG" ]; then
        echo "### Gateway 状态\n\n⚠ 日志文件不存在：$GATEWAY_LOG\n"
        return
    fi
    
    local total_lines=$(wc -l < "$GATEWAY_LOG")
    local error_count=$(grep -c "ERROR\|FailoverError" "$GATEWAY_LOG" 2>/dev/null || echo 0)
    local rate_limit_count=$(grep -c "rate limit\|429" "$GATEWAY_LOG" 2>/dev/null || echo 0)
    local last_message=$(tail -1 "$GATEWAY_LOG" | grep -oP '\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}' || echo "未知")
    
    cat << EOF
### Gateway 状态

| 指标 | 数值 |
|------|------|
| 日志总行数 | $total_lines |
| 错误次数 | $error_count |
| Rate Limit 次数 | $rate_limit_count |
| 最后消息时间 | $last_message |

EOF
    
    # 检查 Gateway 服务状态
    local gateway_status=$(systemctl --user is-active openclaw-gateway.service 2>/dev/null || echo "unknown")
    echo "**服务状态**: \`$gateway_status\`"
    echo ""
}

# 分析备份日志
analyze_backup() {
    log "分析备份日志..."
    
    if [ ! -f "$BACKUP_LOG" ]; then
        echo "### 备份状态\n\n⚠ 日志文件不存在：$BACKUP_LOG\n"
        return
    fi
    
    local last_backup=$(grep "Unified backup completed" "$BACKUP_LOG" | tail -1 || echo "无备份记录")
    local backup_errors=$(grep -c "FAILED\|ERROR" "$BACKUP_LOG" 2>/dev/null || echo 0)
    
    # 检查最新备份 bundle
    local latest_bundle=$(ls -td /root/.openclaw/backups-unified/openclaw_bak_* 2>/dev/null | head -1 || echo "无")
    local bundle_age="未知"
    if [ -n "$latest_bundle" ] && [ "$latest_bundle" != "无" ]; then
        local bundle_time=$(stat -c %Y "$latest_bundle" 2>/dev/null || echo 0)
        local now=$(date +%s)
        local age_seconds=$((now - bundle_time))
        local age_hours=$((age_seconds / 3600))
        bundle_age="${age_hours}小时前"
    fi
    
    cat << EOF
### 备份状态

| 指标 | 数值 |
|------|------|
| 最新备份 | $(basename "$latest_bundle") |
| 备份延迟 | $bundle_age |
| 备份错误次数 | $backup_errors |
| 最后备份记录 | $last_backup |

EOF
}

# 检查系统资源
check_system_resources() {
    log "检查系统资源..."
    
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1 || echo "未知")
    local mem_total=$(free -h | awk '/^Mem:/{print $2}')
    local mem_used=$(free -h | awk '/^Mem:/{print $3}')
    local mem_percent=$(free -h | awk '/^Mem:/{printf "%.1f", $3/$2*100}')
    local disk_usage=$(df -h / | awk 'NR==2{print $5}')
    
    cat << EOF
### 系统资源

| 资源 | 使用量 |
|------|--------|
| CPU 使用率 | ${cpu_usage}% |
| 内存使用 | ${mem_used}/${mem_total} (${mem_percent}%) |
| 磁盘使用率 | $disk_usage |

EOF
}

# 生成健康评分
calculate_health_score() {
    log "计算健康评分..."
    
    local score=100
    local issues=""
    
    # Gateway 服务状态
    local gateway_status=$(systemctl --user is-active openclaw-gateway.service 2>/dev/null || echo "inactive")
    if [ "$gateway_status" != "active" ]; then
        score=$((score - 30))
        issues="$issues\n- Gateway 服务未运行"
    fi
    
    # Health Guardian 状态
    local guardian_status=$(systemctl --user is-active openclaw-health-guardian.service 2>/dev/null || echo "inactive")
    if [ "$guardian_status" != "active" ]; then
        score=$((score - 20))
        issues="$issues\n- Health Guardian 未运行"
    fi
    
    # 备份延迟
    local latest_bundle=$(ls -td /root/.openclaw/backups-unified/openclaw_bak_* 2>/dev/null | head -1)
    if [ -n "$latest_bundle" ]; then
        local bundle_time=$(stat -c %Y "$latest_bundle")
        local now=$(date +%s)
        local age_hours=$(( (now - bundle_time) / 3600 ))
        if [ "$age_hours" -gt 25 ]; then
            score=$((score - 15))
            issues="$issues\n- 备份延迟超过 25 小时"
        fi
    fi
    
    # 错误计数
    if [ -f "$HEALTH_LOG" ]; then
        local recent_errors=$(grep -c "ERROR\|FAILED" "$HEALTH_LOG" 2>/dev/null || echo 0)
        if [ "$recent_errors" -gt 10 ]; then
            score=$((score - 10))
            issues="$issues\n- 最近错误次数过多 ($recent_errors)"
        fi
    fi
    
    # 输出评分
    local level="优秀"
    if [ "$score" -lt 80 ]; then level="良好"
    elif [ "$score" -lt 60 ]; then level="一般"
    elif [ "$score" -lt 40 ]; then level="较差"
    elif [ "$score" -lt 20 ]; then level="严重"
    fi
    
    cat << EOF
### 健康评分

**总分**: $score/100 ($level)

EOF
    
    if [ -n "$issues" ]; then
        echo "**问题**:"
        echo -e "$issues"
        echo ""
    fi
}

# 生成完整报告
generate_report() {
    log "生成健康报告..."
    
    {
        echo "# OpenClaw 系统健康报告"
        echo ""
        echo "**生成时间**: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "**报告周期**: 过去 24 小时"
        echo ""
        echo "---"
        echo ""
        
        calculate_health_score
        check_system_resources
        analyze_health_guardian
        analyze_gateway
        analyze_backup
        
        echo "---"
        echo ""
        echo "## 建议操作"
        echo ""
        echo "1. 查看完整日志：\`tail -100 $HEALTH_LOG\`"
        echo "2. 检查服务状态：\`systemctl --user status openclaw-*.service\`"
        echo "3. 验证备份完整性：\`ls -la /root/.openclaw/backups-unified/openclaw_bak_*/\`"
        echo ""
        echo "---"
        echo "*报告由 Monitoring Agent 自动生成*"
        
    } > "$REPORT_FILE"
    
    log "✓ 健康报告已生成：$REPORT_FILE"
}

# 主函数
main() {
    log "=========================================="
    log "Monitoring Agent 健康报告生成开始"
    log "=========================================="
    
    generate_report
    
    log "=========================================="
    log "Monitoring Agent 健康报告生成完成"
    log "=========================================="
}

# 执行
main "$@"
