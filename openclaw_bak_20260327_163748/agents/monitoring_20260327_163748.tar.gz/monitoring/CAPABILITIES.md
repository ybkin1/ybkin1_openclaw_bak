# Monitoring Agent - 完整能力定义

**版本**: 2.0 (开发监控能力增强版)  
**生效日期**: 2026-03-26  
**适用范围**: 系统监控 + 应用性能监控 + 开发指标监控

---

## 🎯 核心能力矩阵

| 能力域 | 能力项 | 状态 | 说明 |
|--------|--------|------|------|
| **系统监控** | 服务状态监控 | ✅ 已有 | Gateway/Health Guardian |
| | 资源使用监控 | ✅ 已有 | CPU/内存/磁盘 |
| | 告警配置 | ✅ 已有 | 飞书告警 |
| **应用性能监控** | API 延迟监控 | 🆕 新增 | CRUD/RAG 检索延迟 |
| | 数据库性能 | 🆕 新增 | 查询延迟/连接池 |
| | 向量检索性能 | 🆕 新增 | LanceDB 查询延迟 |
| **开发指标监控** | 测试覆盖率趋势 | 🆕 新增 | 覆盖率变化趋势 |
| | 代码审查通过率 | 🆕 新增 | 审查拒绝率统计 |
| | Task 完成速率 | 🆕 新增 | 每日 Task 完成数 |

---

## 🔧 新增能力详细说明

### 能力 4: 应用性能监控 (APM)

#### API 延迟监控

**监控指标**:
| 接口 | P95 阈值 | P99 阈值 | 告警级别 |
|------|---------|---------|---------|
| db_create | >100ms | >200ms | 警告 |
| db_query | >100ms | >200ms | 警告 |
| rag_search | >500ms | >1000ms | 严重 |
| file_upload | >2s | >5s | 警告 |
| ocr_extract | >10s | >20s | 警告 |

**监控脚本**:
```python
def monitor_api_latency():
    """
    API 延迟监控
    """
    metrics = {
        'db_create': measure_latency('db_create'),
        'db_query': measure_latency('db_query'),
        'rag_search': measure_latency('rag_search'),
    }
    
    alerts = []
    for api, latency in metrics.items():
        if latency['p95'] > get_threshold(api, 'p95'):
            alerts.append({
                'api': api,
                'metric': 'p95_latency',
                'value': latency['p95'],
                'threshold': get_threshold(api, 'p95')
            })
    
    if alerts:
        send_alert(alerts)
    
    return metrics
```

---

#### 数据库性能监控

**监控指标**:
| 指标 | 阈值 | 说明 |
|------|------|------|
| 查询延迟 (P95) | >50ms | 单条件查询 |
| 连接池使用率 | >80% | 活跃连接/最大连接 |
| 事务等待时间 | >1s | 锁等待时间 |
| 慢查询数量 | >10/小时 | 执行时间>1s 的查询 |

**监控查询**:
```sql
-- 慢查询统计
SELECT 
    COUNT(*) as slow_query_count,
    AVG(execution_time) as avg_time,
    MAX(execution_time) as max_time
FROM query_log
WHERE execution_time > 1000  -- ms
  AND timestamp > datetime('now', '-1 hour');

-- 连接池使用率
SELECT 
    COUNT(*) as active_connections,
    (SELECT COUNT(*) FROM connections) as max_connections,
    COUNT(*) * 100.0 / (SELECT COUNT(*) FROM connections) as usage_percent
FROM connections
WHERE status = 'active';
```

---

#### 向量检索性能监控

**监控指标**:
| 指标 | 阈值 | 说明 |
|------|------|------|
| 检索延迟 (P95) | >100ms | 向量相似度检索 |
| 索引大小 | >10GB | LanceDB 索引文件大小 |
| 召回率 | >0.9 | Top-K 召回质量 |

---

### 能力 5: 开发指标监控

#### 测试覆盖率趋势

**监控指标**:
| 模块 | 覆盖率阈值 | 趋势告警 |
|------|-----------|---------|
| 核心 CRUD | >90% | 下降>5% 告警 |
| RAG 检索 | >85% | 下降>5% 告警 |
| 文件处理 | >80% | 下降>5% 告警 |
| 权限控制 | >95% | 下降>2% 告警 |

**监控脚本**:
```python
def monitor_test_coverage():
    """
    测试覆盖率监控
    """
    # 获取当前覆盖率
    current_coverage = get_coverage_from_report()
    
    # 获取历史覆盖率 (7 天前)
    historical_coverage = get_coverage_from_report(days_ago=7)
    
    alerts = []
    for module, current in current_coverage.items():
        historical = historical_coverage.get(module, 0)
        change = current - historical
        
        if change < -5:  # 下降超过 5%
            alerts.append({
                'module': module,
                'current': current,
                'historical': historical,
                'change': change,
                'severity': 'warning'
            })
        
        if current < get_coverage_threshold(module):
            alerts.append({
                'module': module,
                'current': current,
                'threshold': get_coverage_threshold(module),
                'severity': 'critical'
            })
    
    return alerts
```

---

#### 代码审查通过率

**监控指标**:
| 指标 | 阈值 | 说明 |
|------|------|------|
| 审查拒绝率 | >20% | 拒绝次数/总审查次数 |
| AI 幻觉检测率 | >5% | 幻觉次数/总审查次数 |
| 平均审查时间 | >30 分钟 | 单次审查平均时间 |

**监控脚本**:
```python
def monitor_code_review():
    """
    代码审查指标监控
    """
    # 获取审查统计 (今日)
    today_stats = get_review_stats(date=today)
    
    rejection_rate = today_stats['rejected'] / today_stats['total']
    hallucination_rate = today_stats['hallucination_detected'] / today_stats['total']
    avg_review_time = today_stats['total_time'] / today_stats['total']
    
    alerts = []
    
    if rejection_rate > 0.2:
        alerts.append({
            'metric': 'rejection_rate',
            'value': rejection_rate,
            'threshold': 0.2,
            'severity': 'warning'
        })
    
    if hallucination_rate > 0.05:
        alerts.append({
            'metric': 'hallucination_rate',
            'value': hallucination_rate,
            'threshold': 0.05,
            'severity': 'critical'
        })
    
    return alerts
```

---

#### Task 完成速率

**监控指标**:
| 指标 | 目标值 | 告警条件 |
|------|--------|---------|
| 每日 Task 完成数 | 4-6 个 | <3 个/天告警 |
| Task 平均完成时间 | 30-60 分钟 | >90 分钟告警 |
| Task 延期率 | <10% | >20% 告警 |

---

### 能力 6: 告警规则配置

#### 告警级别

| 级别 | 颜色 | 响应时间 | 说明 |
|------|------|---------|------|
| **信息** | 🔵 蓝色 | 无需响应 | 正常通知 |
| **警告** | 🟡 黄色 | <1 小时 | 需要关注 |
| **严重** | 🟠 橙色 | <15 分钟 | 需要立即处理 |
| **致命** | 🔴 红色 | <5 分钟 | 系统故障 |

#### 告警渠道

| 级别 | 飞书 | 邮件 | 短信 |
|------|------|------|------|
| 信息 | ✅ | ❌ | ❌ |
| 警告 | ✅ | ❌ | ❌ |
| 严重 | ✅ | ✅ | ❌ |
| 致命 | ✅ | ✅ | ✅ |

#### 告警模板

```markdown
🔴 严重告警：{metric_name}

**指标**: {metric_name}
**当前值**: {current_value}
**阈值**: {threshold}
**时间**: {timestamp}

**影响范围**:
- 受影响模块：{affected_modules}
- 受影响用户：{affected_users}

**建议措施**:
1. {action_1}
2. {action_2}

**详细信息**: {detail_url}
```

---

## 🛠️ 工具接口

### 性能监控工具

```python
def monitor_performance():
    """
    性能监控入口
    
    Returns:
        {
            'api_latency': {...},
            'database': {...},
            'vector_search': {...},
            'alerts': [...]
        }
    """
    metrics = {
        'api_latency': monitor_api_latency(),
        'database': monitor_database_performance(),
        'vector_search': monitor_vector_search(),
    }
    
    alerts = collect_alerts(metrics)
    
    return {
        **metrics,
        'alerts': alerts
    }
```

### 开发指标监控工具

```python
def monitor_development_metrics():
    """
    开发指标监控
    
    Returns:
        {
            'test_coverage': {...},
            'code_review': {...},
            'task_velocity': {...},
            'alerts': [...]
        }
    """
    metrics = {
        'test_coverage': monitor_test_coverage(),
        'code_review': monitor_code_review(),
        'task_velocity': monitor_task_velocity(),
    }
    
    alerts = collect_alerts(metrics)
    
    return {
        **metrics,
        'alerts': alerts
    }
```

---

## 📊 监控报告模板

```markdown
# 性能监控报告

**报告时间**: {timestamp}  
**报告周期**: {period}

---

## API 延迟

| 接口 | P95 | P99 | 状态 |
|------|-----|-----|------|
| db_create | 45ms | 80ms | ✅ |
| db_query | 40ms | 75ms | ✅ |
| rag_search | 450ms | 800ms | ✅ |

---

## 数据库性能

- 查询延迟 (P95): 35ms ✅
- 连接池使用率：45% ✅
- 慢查询数量：2/小时 ✅

---

## 开发指标

- 测试覆盖率：82% ✅
- 审查拒绝率：8% ✅
- Task 完成速率：5 个/天 ✅

---

## 告警汇总

**今日告警**: 0 个

---

**监控 Agent**: monitoring  
**报告生成时间**: {generation_time}
```

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 新增能力定义完成
