#!/bin/bash
# Analysis Agent Heartbeat
# Checks if analysis agent is running properly

set -euo pipefail

AGENT_ID="analysis"
WORKSPACE="/root/.openclaw/workspace/agents/analysis"
LOG_FILE="$WORKSPACE/logs/heartbeat.log"

# Create logs directory if not exists
mkdir -p "$WORKSPACE/logs"

# Log heartbeat
echo "[$(date '+%Y-%m-%d %H:%M:%S')] $AGENT_ID agent heartbeat - OK" >> "$LOG_FILE"

# Check if required directories exist
if [ ! -d "$WORKSPACE/memory" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: memory directory missing" >> "$LOG_FILE"
    exit 1
fi

if [ ! -d "$WORKSPACE/skills" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: skills directory missing" >> "$LOG_FILE"
    exit 1
fi

# Check configuration
if [ ! -f "$WORKSPACE/AGENT.md" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: AGENT.md missing" >> "$LOG_FILE"
    exit 1
fi

# Check if analysis-specific directories exist
if [ ! -d "$WORKSPACE/memory/analysis_reports" ]; then
    mkdir -p "$WORKSPACE/memory/analysis_reports"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] INFO: Created analysis_reports directory" >> "$LOG_FILE"
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S')] $AGENT_ID agent health check passed" >> "$LOG_FILE"
exit 0