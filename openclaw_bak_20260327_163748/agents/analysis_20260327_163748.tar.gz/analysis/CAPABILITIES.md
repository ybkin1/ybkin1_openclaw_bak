# Analysis Agent - 完整能力定义

**版本**: 2.0 (开发能力增强版)  
**生效日期**: 2026-03-26  
**适用范围**: 数据分析 + 代码审查 + 测试验证

---

## 🎯 核心能力矩阵

| 能力域 | 能力项 | 状态 | 说明 |
|--------|--------|------|------|
| **数据分析** | 日志分析 | ✅ 已有 | Guardian3.0 log_analyzer |
| | 故障根因分析 | ✅ 已有 | Guardian3.0 root_cause_analyzer |
| | 趋势分析 | ✅ 已有 | 周期性数据分析 |
| **代码审查** | Spec Review | 🆕 新增 | 检查代码是否符合设计 |
| | Code Quality Review | 🆕 新增 | 检查代码质量 |
| | AI 幻觉检测 | 🆕 新增 | 验证函数调用、导入存在性 |
| **测试验证** | TDD 验证 | 🆕 新增 | 确认测试先于实现 |
| | 覆盖率检查 | 🆕 新增 | pytest --cov >80% |
| | 边界条件测试 | 🆕 新增 | 边缘情况验证 |
| **性能测试** | 基准测试 | 🆕 新增 | CRUD/RAG 延迟测试 |
| | 压力测试 | 🆕 新增 | 并发/QPS 测试 |
| | 性能报告 | 🆕 新增 | P95/P99 统计 |

---

## 🔧 新增能力详细说明

### 能力 3: 代码审查 (Code Review)

#### 3.1 Spec Review (设计符合性审查)

**审查清单**:
```markdown
□ 功能完整性
  - 是否实现了所有要求的功能
  - 是否有遗漏的需求项

□ 范围控制
  - 是否添加了多余功能 (范围蔓延)
  - 是否简化了需求 (偷工减料)

□ 架构符合性
  - 是否符合架构设计文档
  - 是否遵循设计模式

□ 元数据完整性
  - org_id 是否自动注入
  - track_id 是否正确关联
  - permission_level 是否检查
```

**审查流程**:
```python
def spec_review(task_id, code_changes, design_doc):
    """
    Spec Review 流程
    """
    # 1. 读取设计文档
    requirements = parse_design_doc(design_doc)
    
    # 2. 分析代码变更
    implemented_features = extract_features(code_changes)
    
    # 3. 对比需求与实现
    missing = requirements - implemented_features
    extra = implemented_features - requirements
    
    # 4. 生成审查报告
    report = {
        'task_id': task_id,
        'status': 'approved' if not missing and not extra else 'rejected',
        'missing_features': list(missing),
        'extra_features': list(extra),
        'issues': []
    }
    
    return report
```

**输出模板**:
```markdown
## Spec Review 报告

**任务**: {task_id}  
**审查时间**: {timestamp}  
**审查结果**: ✅ 通过 / ❌ 拒绝

### 发现的问题
1. [严重] 缺少功能：{feature_name}
2. [警告] 多余功能：{feature_name}

### 修改建议
- 建议 1
- 建议 2
```

---

#### 3.2 Code Quality Review (代码质量审查)

**审查清单**:
```markdown
□ 测试覆盖
  - 测试覆盖率 >80%
  - 关键函数有单元测试
  - 边界条件有测试

□ 代码规范
  - 符合 PEP8 规范
  - 命名清晰 (变量、函数、类)
  - 代码注释适当

□ 错误处理
  - 异常捕获完整
  - 错误日志适当
  - 恢复机制合理

□ 安全性
  - 无 SQL 注入风险
  - 无权限绕过风险
  - 敏感数据已脱敏

□ 可维护性
  - 函数长度 <50 行
  - 无重复代码 (DRY)
  - 模块职责清晰 (单一职责)
```

**自动化检查工具**:
```bash
# PEP8 检查
pylint --errors-only module.py

# 类型检查
mypy --strict module.py

# 测试覆盖率
pytest --cov=module --cov-report=html

# 复杂度检查
pylint --disable=all --enable=complexity module.py
```

---

#### 3.3 AI 幻觉检测 (AI Hallucination Detection)

**检测清单**:
```markdown
□ 函数调用验证
  - 所有定义的函数都有调用处
  - 无孤立函数 (定义了但从未使用)

□ 导入验证
  - 所有 import 的模块都存在
  - 无幻觉导入 (模块名不存在)

□ 变量定义验证
  - 所有使用的变量都有定义
  - 无未定义变量

□ 逻辑路径验证
  - 所有代码路径都可追溯
  - 无死代码 (无法执行的代码)
```

**检测方法**:
```python
def detect_ai_hallucination(code):
    """
    AI 幻觉检测
    """
    issues = []
    
    # 1. 提取所有导入
    imports = extract_imports(code)
    for imp in imports:
        try:
            __import__(imp)
        except ImportError:
            issues.append(f"幻觉导入：{imp} 不存在")
    
    # 2. 提取所有函数定义
    functions = extract_functions(code)
    for func in functions:
        if not has_caller(func, code):
            issues.append(f"孤立函数：{func} 无调用处")
    
    # 3. 提取所有变量使用
    variables = extract_variables(code)
    for var in variables:
        if not is_defined(var, code):
            issues.append(f"未定义变量：{var}")
    
    return {
        'status': 'approved' if not issues else 'rejected',
        'issues': issues
    }
```

---

### 能力 4: 测试验证 (Test Verification)

#### 4.1 TDD 验证

**验证流程**:
```
1. 检查测试文件提交时间 vs 实现文件提交时间
   - 测试提交时间 < 实现提交时间 → ✅ TDD
   - 测试提交时间 > 实现提交时间 → ❌ 后补测试

2. 检查 Git 提交历史
   - 第一次提交：测试文件 (失败)
   - 第二次提交：实现文件 (通过)
   → ✅ TDD 流程正确

3. 检查测试内容
   - 测试是否针对具体需求
   - 测试是否可执行
```

**验证脚本**:
```bash
#!/bin/bash
# 验证 TDD 流程

verify_tdd() {
    local task_id=$1
    
    # 获取测试文件提交时间
    test_commit_time=$(git log --diff-filter=A --name-only --pretty=format:"%ai" | grep "test.*.py" | head -1 | cut -d' ' -f1-2)
    
    # 获取实现文件提交时间
    impl_commit_time=$(git log --diff-filter=A --name-only --pretty=format:"%ai" | grep -v "test.*.py" | head -1 | cut -d' ' -f1-2)
    
    # 比较时间
    if [[ "$test_commit_time" < "$impl_commit_time" ]]; then
        echo "✅ TDD 流程正确"
        return 0
    else
        echo "❌ 测试后补，非 TDD"
        return 1
    fi
}
```

---

#### 4.2 覆盖率检查

**检查标准**:
| 模块类型 | 覆盖率要求 | 测量方式 |
|---------|-----------|---------|
| 核心 CRUD | >90% | pytest --cov |
| RAG 检索 | >85% | pytest --cov |
| 文件处理 | >80% | pytest --cov |
| 权限控制 | >95% | pytest --cov |
| 工具函数 | >80% | pytest --cov |

**检查命令**:
```bash
# 生成覆盖率报告
pytest --cov=module --cov-report=html --cov-report=term-missing

# 检查覆盖率阈值
coverage report --fail-under=80
```

---

### 能力 5: 性能测试 (Performance Testing)

#### 5.1 基准测试

**测试指标**:
| 接口 | P95 延迟 | P99 延迟 | 说明 |
|------|---------|---------|------|
| db_create | <50ms | <100ms | 单条记录创建 |
| db_query | <50ms | <100ms | 单条件查询 |
| rag_search | <500ms | <1000ms | 语义检索 + 重排序 |
| file_upload | <1s | <2s | 10MB 文件上传 |
| ocr_extract | <5s | <10s | A4 图片 OCR |

**测试脚本模板**:
```python
import pytest
import time

def test_db_create_performance():
    """db_create 性能测试"""
    start_time = time.time()
    
    # 执行 100 次创建
    for i in range(100):
        db_create('test_table', {'data': f'value_{i}'})
    
    end_time = time.time()
    avg_latency = (end_time - start_time) / 100 * 1000  # ms
    
    assert avg_latency < 50, f"平均延迟 {avg_latency}ms > 50ms"
```

---

#### 5.2 压力测试

**测试场景**:
| 场景 | 并发数 | 持续时间 | 通过标准 |
|------|--------|---------|---------|
| 正常负载 | 10 QPS | 5 分钟 | 无错误，延迟<阈值 |
| 峰值负载 | 100 QPS | 5 分钟 | 错误率<1% |
| 极限负载 | 1000 QPS | 5 分钟 | 系统不崩溃 |

**测试工具**:
```bash
# 使用 locust 进行压力测试
locust -f load_tests.py --host=http://localhost:15527 --users 100 --spawn-rate 10
```

---

## 🛠️ 工具接口

### 代码审查工具

```python
# Analysis Agent 提供的审查工具

def review_code(task_id, code_changes, design_doc):
    """
    代码审查入口
    
    Args:
        task_id: 任务 ID
        code_changes: 代码变更 (git diff)
        design_doc: 设计文档路径
    
    Returns:
        {
            'status': 'approved|rejected',
            'spec_review': {...},
            'quality_review': {...},
            'hallucination_check': {...}
        }
    """
    # 1. Spec Review
    spec_result = spec_review(task_id, code_changes, design_doc)
    
    # 2. Code Quality Review
    quality_result = code_quality_review(code_changes)
    
    # 3. AI 幻觉检测
    hallucination_result = detect_ai_hallucination(code_changes)
    
    # 4. 综合判断
    all_approved = all([
        spec_result['status'] == 'approved',
        quality_result['status'] == 'approved',
        hallucination_result['status'] == 'approved'
    ])
    
    return {
        'status': 'approved' if all_approved else 'rejected',
        'spec_review': spec_result,
        'quality_review': quality_result,
        'hallucination_check': hallucination_result
    }
```

---

## 📊 审查报告模板

```markdown
# 代码审查报告

**任务 ID**: {task_id}  
**审查时间**: {timestamp}  
**审查 Agent**: analysis  
**审查类型**: Spec Review + Quality Review + AI 幻觉检测

---

## 审查结果

**总体状态**: ✅ 通过 / ❌ 拒绝

### Spec Review
- 状态：✅/❌
- 缺失功能：[]
- 多余功能：[]

### Code Quality Review
- 状态：✅/❌
- 测试覆盖率：82%
- PEP8 违规：0
- 安全问题：0

### AI 幻觉检测
- 状态：✅/❌
- 幻觉导入：0
- 孤立函数：0
- 未定义变量：0

---

## 问题列表

### 严重问题 (必须修复)
1. [问题描述]

### 警告问题 (建议修复)
1. [问题描述]

---

## 审查结论

□ 通过，可合并  
□ 需要修改 (见问题列表)  
□ 拒绝，需重新实现

**审查人**: analysis Agent  
**审查日期**: {date}
```

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 新增能力定义完成
