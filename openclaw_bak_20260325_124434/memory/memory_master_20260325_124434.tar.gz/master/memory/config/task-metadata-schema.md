# 任务元数据格式规范

## 基础字段
- `id`: 任务唯一标识符 (UUID)
- `title`: 任务标题
- `description`: 任务描述
- `status`: 任务状态 (active/completed/archived/pending_confirmation)
- `created_at`: 创建时间 (ISO 8601)
- `updated_at`: 最后更新时间 (ISO 8601)
- `completed_at`: 完成时间 (ISO 8601, 可选)
- `user_id`: 用户ID
- `agent_id`: 执行Agent ID
- `estimated_duration`: 预计耗时 (分钟)
- `actual_duration`: 实际耗时 (分钟, 可选)

## 状态管理
- `active`: 任务正在进行中
- `completed`: 任务已完成但未确认
- `pending_confirmation`: 等待用户确认完成
- `archived`: 任务已归档（确认完成且超过保留期）

## 标签系统
- `type`: 任务类型 (configuration/installation/backup/analysis/monitoring)
- `priority`: 优先级 (high/medium/low)
- `category`: 分类标签
- `dependencies`: 依赖任务ID列表

## 生命周期管理
- 自动清理: completed状态超过3天的任务标记为pending_deletion
- 用户确认: pending_deletion状态触发删除询问
- 归档策略: confirmed状态超过30天自动归档