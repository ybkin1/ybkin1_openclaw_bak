# 系统清理和统一计划

## 1. 配置文件统一
- [ ] 保留 `/root/.openclaw/openclaw.json` 作为唯一全局配置
- [ ] 删除 `/root/.openclaw/workspace/openclaw.json`
- [ ] 删除 `/root/.openclaw/backups-repo/configs/openclaw/openclaw.json`

## 2. 备份文件统一
- [ ] 将所有备份文件移动到 `/root/.openclaw/backups-unified/`
- [ ] 清理其他目录中的备份文件
- [ ] 建立备份管理规范

## 3. Workspace 结构优化
- [ ] 删除 `/root/.openclaw/workspace-main/`（已迁移到多 agent 架构）
- [ ] 清理 workspace 根目录中的冗余文件
- [ ] 确保所有 agent 配置在 `/root/.openclaw/workspace/agents/` 下

## 4. 记忆分层架构完善
- [ ] 按照优化建议完善 memory 目录结构
- [ ] 确保每个 agent 有独立的记忆空间
- [ ] 建立用户记忆隔离机制