# 长期记忆架构设计

## 核心原则
1. **分层存储**: 按重要性、时效性、类型分层
2. **快速检索**: 建立索引和标签系统
3. **自动维护**: 定期清理、归档、优化
4. **语义关联**: 支持跨领域知识关联

## 目录结构

```
memory/knowledge/
├── core/                    # 核心知识 (永久保存)
│   ├── system_architecture/ # 系统架构文档
│   ├── agent_capabilities/  # Agent 能力说明  
│   └── user_preferences/    # 用户偏好设置
├── temporal/                # 时效性知识
│   ├── daily/              # 日常知识 (保留7天)
│   ├── weekly/             # 周度知识 (保留30天)  
│   └── monthly/            # 月度知识 (保留90天)
├── domain/                  # 领域知识
│   ├── ai_research/        # AI 研究进展
│   ├── system_admin/       # 系统管理知识
│   ├── troubleshooting/    # 故障排除案例
│   └── best_practices/     # 最佳实践文档
├── learning/               # 学习成果
│   ├── skill_improvements/ # 技能改进建议
│   ├── error_analysis/     # 错误分析报告
│   └── success_cases/      # 成功案例总结
└── archive/                # 归档知识 (压缩存储)
    ├── quarterly/          # 季度归档
    └── annual/             # 年度归档
```

## 元数据标准

每个知识文件包含以下元数据:

```yaml
---
title: "知识标题"
category: "core|temporal|domain|learning|archive"
importance: "critical|high|medium|low"
created_at: "2026-03-18T00:15:00+08:00"
last_accessed: "2026-03-18T00:15:00+08:00"
tags: ["tag1", "tag2", "tag3"]
related_knowledge: ["knowledge_id_1", "knowledge_id_2"]
source: "user_input|auto_learning|external_research"
retention_days: 30
---
```

## 索引机制

### 1. 全局索引文件
- `memory/knowledge/INDEX.md`: 所有知识的全局索引
- `memory/knowledge/TAGS.md`: 标签到知识的映射

### 2. 语义搜索支持
- 关键词提取和存储
- 向量嵌入预计算 (用于快速相似性搜索)

## 自动维护策略

### 清理规则
- **daily/**: 保留7天，自动删除
- **weekly/**: 保留30天，自动归档到 monthly
- **monthly/**: 保留90天，自动归档到 archive
- **archive/**: 永久保存，但压缩存储

### 归档流程
1. 检测过期知识
2. 移动到 archive 目录
3. 更新全局索引
4. 发送归档通知

## 访问控制

- **master agent**: 完全读写权限
- **功能 agents**: 只读权限，按需访问
- **用户**: 通过 master agent 代理访问

## 性能优化

- **缓存机制**: 频繁访问的知识缓存到内存
- **懒加载**: 大文件按需加载
- **增量更新**: 只更新变更的部分