# Task Memory System

## Directory Structure
- `active/` - Currently active tasks (status: active)
- `completed/` - Completed tasks (status: completed, cleanup after 3+ days)
- `archived/` - Archived tasks (manually archived or auto-archived)

## Task Lifecycle
1. **Creation**: Task identified from user request (configuration, upgrade, installation, backup, etc.)
2. **Active**: Task progresses with regular updates
3. **Completion Check**: When progress reaches 100%, ask user: "Current [task type] is complete. Any additional requirements? If not, can we close this task?"
4. **Completed**: Move to completed directory with completion timestamp
5. **Cleanup**: After 3+ days in completed, ask user: "Task [name] completed over 3 days ago. Can we delete related records?"

## Task File Format
Each task is stored as a JSON file with the following structure:
{
  "task_id": "unique_identifier",
  "user_id": "user_uuid", 
  "created_at": "timestamp",
  "updated_at": "timestamp",
  "status": "active|completed|archived",
  "type": "configuration|upgrade|installation|backup|other",
  "description": "brief description",
  "progress": "percentage or status text",
  "messages": [
    {
      "timestamp": "message_timestamp",
      "content": "original message", 
      "summary": "AI-generated summary"
    }
  ],
  "completion_asked": "boolean",
  "delete_asked": "boolean"
}