# Short-term Memory System

## Purpose
Stores the last 10 conversation messages per user to maintain context across session boundaries.

## File Format
Each user's short-term memory is stored as:
`{user_uuid}_last_10.json`

File structure:
{
  "user_id": "user_uuid",
  "messages": [
    {
      "timestamp": "ISO8601_timestamp",
      "message_id": "original_message_id", 
      "channel": "feishu|dingtalk|etc",
      "content": "message_content",
      "summary": "AI-generated brief summary"
    }
  ],
  "last_updated": "timestamp",
  "retention_days": 7
}

## Heartbeat Integration
- Daily at 23:50: Automatically summarize day's conversations and update short-term memory
- New session start: Load short-term memory + active tasks to provide context continuity
- Automatic cleanup: Remove entries older than 7 days

## Session Recovery Workflow
1. User starts new session
2. Identify user (map channel ID to user UUID)  
3. Load short-term memory (last 10 messages)
4. Load active tasks for user
5. Generate summary: "Yesterday you had X active tasks: [list with progress]"
6. Present to user for confirmation of understanding