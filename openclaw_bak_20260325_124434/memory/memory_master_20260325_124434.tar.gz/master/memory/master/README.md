# Master Agent Memory Architecture

This directory contains the memory structure for the master agent, implementing the user's requirements for task management, user profiles, and learning capabilities.

## Structure Overview

- `users/` - User profiles and permission management
- `short_term/` - Recent conversation history (last 10 messages per user)
- `long_term/` - Persistent knowledge and learning data
- `tasks/` - Task tracking and management system

## Design Principles

1. **User Isolation**: Each user's data is completely isolated using UUID-based directories
2. **Permission Levels**: 5-level permission system with routing and sandbox isolation
3. **Task Lifecycle**: Tasks are tracked from creation to completion with automatic cleanup
4. **Learning Continuity**: All non-temporary learning is stored in long-term memory
5. **Session Resilience**: Heartbeat tasks ensure no memory loss across session boundaries