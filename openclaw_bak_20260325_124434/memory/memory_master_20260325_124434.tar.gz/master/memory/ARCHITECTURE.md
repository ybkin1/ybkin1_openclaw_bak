# 记忆分层架构

**版本**: 2.0  
**更新日期**: 2026-03-17  
**状态**: 已启用

---

## 架构概述

```
memory/
├── shared/                     # 共享记忆层 (所有 agent 可访问)
│   ├── users/                  # 用户档案库
│   │   ├── ou_b46467cc1563871aab03ac1d4f9216f0.md  # 俞斌
│   │   └── template.md         # 用户档案模板
│   └── knowledge/              # 共享知识库
│       ├── ai-ops/             # AI 运维知识
│       ├── feishu/             # 飞书集成知识
│       └── system/             # 系统知识
│
├── master/                     # Master Agent 专属记忆
│   ├── short_term/             # 短期记忆 (7 天内)
│   │   └── YYYY-MM-DD.md
│   ├── long_term/              # 长期记忆 (永久)
│   │   ├── projects/           # 项目记忆
│   │   ├── decisions/          # 重要决策
│   │   └── learnings/          # 经验教训
│   └── tasks/                  # 任务记忆
│       ├── active/             # 活跃任务
│       ├── completed/          # 已完成任务
│       └── archived/           # 归档任务
│
├── monitoring/                 # Monitoring Agent 专属记忆
│   └── health_logs/            # 健康检查日志
│
├── backup/                     # Backup Agent 专属记忆
│   └── backup_logs/            # 备份操作日志
│
└── analysis/                   # Analysis Agent 专属记忆
    └── analysis_reports/       # 分析报告
```

---

## 用户记忆隔离机制

### 用户识别
- **ID 来源**: 飞书 `ou_` 开头的用户 ID
- **档案位置**: `memory/shared/users/{user_id}.md`

### 访问控制
- **master agent**: 可访问所有用户记忆
- **子 agent**: 仅可访问当前任务相关用户的记忆
- **共享知识**: 所有 agent 可访问

### 用户档案模板

```markdown
# 用户档案 - {user_name}

**用户 ID**: {user_id}  
**创建时间**: {date}  
**最后更新**: {date}

## 基本信息
- 姓名：
- 职业：
- 偏好：

## 项目关联
- 项目 1:
- 项目 2:

## 记忆索引
- 短期记忆：`memory/master/short_term/{user_id}/`
- 任务历史：`memory/master/tasks/completed/{user_id}/`
```

---

## 记忆写入规则

### 何时写入
1. **用户明确指令**: "记住这个..."
2. **任务完成**: 记录任务结果和经验
3. **配置变更**: 记录系统配置变化
4. **错误学习**: 记录错误和解决方案
5. **周期性总结**: 每日/每周总结

### 写入位置
| 内容类型 | 存储位置 | 保留周期 |
|----------|----------|----------|
| 日常对话 | `short_term/YYYY-MM-DD.md` | 7 天 |
| 项目进展 | `long_term/projects/{name}.md` | 项目周期 |
| 配置变更 | `shared/knowledge/system/` | 永久 |
| 经验教训 | `long_term/learnings/` | 永久 |
| 任务记录 | `tasks/{status}/{task_id}.json` | 永久 |

---

## 学习能力配置

### 自动学习机制
1. **错误捕获**: 记录所有意外错误
2. **用户纠正**: 记录用户的纠正和反馈
3. **成功模式**: 记录成功的解决方案
4. **周期性回顾**: 每周回顾并提炼知识

### 学习文件位置
- **即时学习**: `agents/master/.learnings/{date}.md`
- **知识提炼**: `memory/shared/knowledge/`
- **技能更新**: `skills/{skill}/LEARNINGS.md`

---

## 任务跟踪机制

### 任务队列
- **文件**: `memory/master/tasks/task_queue_{date}.md`
- **更新频率**: 实时
- **审查周期**: 每日

### 任务状态
- `pending`: 等待执行
- `in_progress`: 执行中
- `completed`: 已完成
- `failed`: 失败
- `blocked`: 阻塞 (等待外部输入)

### 进度汇报
- **简单任务**: 完成后一次性汇报
- **复杂任务**: 每 1/3 进度汇报一次
- **多日任务**: 每日汇报进展

---

## 实施状态

| 组件 | 状态 | 完成度 |
|------|------|--------|
| 目录结构 | ✅ 已创建 | 100% |
| 用户档案 | 🟡 部分完成 | 50% |
| 任务队列 | 🟡 部分完成 | 50% |
| 学习机制 | 🔴 未开始 | 0% |
| 自动化 | 🔴 未开始 | 0% |

---

## 下一步
1. 创建用户档案模板
2. 迁移现有记忆到新架构
3. 配置自动化学习机制
4. 建立定期审查流程
