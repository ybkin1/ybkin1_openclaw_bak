# OpenClaw System Guardian - 问题记录与经验

## 2026-03-12 13:00 UTC 健康扫描发现的问题

### 1. 配置文件问题
- **钉钉插件残留**: `openclaw.json` 中 plugins.allow 包含不存在的 "dingtalk" 插件，但实际配置中未找到相关条目
- **配置文件权限**: `/root/.openclaw/openclaw.json` 权限为 644（世界可读），应改为 600
- **Gateway绑定**: Gateway 绑定到 "lan" (0.0.0.0)，存在安全风险

### 2. 安全审计发现的高危问题
- **插件代码安全问题**:
  - adp-openclaw 插件: 环境变量访问结合网络发送(可能凭证泄露)、shell命令执行
  - qqbot 插件: shell命令执行
- **技能代码安全问题**:
  - Self-Evolving Skill: shell命令执行
  - tavily: 环境变量访问结合网络发送
  - notebooklm: shell命令执行

### 3. 系统环境问题
- **Node版本**: 系统Node 18.20.8低于要求的Node 22+，虽然使用了NVM的Node 22.22.0，但存在不一致性
- **Gateway服务配置**: 使用版本管理器的Node路径，升级后可能中断
- **内存搜索**: 未配置嵌入提供者，语义回忆功能不可用

### 4. 临时规避方案
1. 修复配置文件权限: `chmod 600 /root/.openclaw/openclaw.json`
2. 移除不存在的插件引用: 从plugins.allow中移除"dingtalk"
3. 限制Gateway绑定: 改为loopback或使用SSH隧道
4. 审查高危插件和技能代码，确认是否可信

### 5. 优化解决方案
1. 升级系统Node到22+版本，避免版本管理器依赖
2. 配置嵌入提供者以启用语义回忆功能
3. 定期运行安全审计，监控新安装的插件和技能
4. 建立插件和技能审核流程，确保代码安全