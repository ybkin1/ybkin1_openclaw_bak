#!/usr/bin/env python3
"""
集成测试脚本

测试所有核心模块的协同工作能力
"""

import sys
import os

# 添加项目路径
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from src.security.encryption import EncryptionService
from src.security.rbac import Role, User, Permission
from src.security.auth import AuthenticationService
from src.agents.master_sla import MasterAgent, TaskType
from src.agents.file_processor_agent import FileProcessorAgent
from src.agents.monitoring_agent import MonitoringAgent


def test_encryption():
    """测试加密服务"""
    print("\n🔐 测试加密服务...")
    enc = EncryptionService()
    
    # 测试加密解密
    data = {'sn': 'SN12345678', 'config': 'GPU: A100'}
    encrypted = enc.encrypt_sensitive_data(data)
    decrypted = enc.decrypt_sensitive_data(encrypted)
    
    assert data == decrypted, "加密解密不一致"
    print(f"  ✅ 加密解密测试通过")
    
    # 测试密码哈希
    hashed = enc.hash_password('TestPass123!')
    assert enc.verify_password('TestPass123!', hashed), "密码验证失败"
    print(f"  ✅ 密码哈希测试通过")
    
    return True


def test_rbac():
    """测试 RBAC 权限系统"""
    print("\n👥 测试 RBAC 权限系统...")
    
    # 创建用户
    user = User(id='u1', tenant_id='t1', role=Role.OPERATIONS)
    assert user.has_permission(Permission.FAULT_ANALYZE), "运维应有故障分析权限"
    assert not user.has_permission(Permission.SENSITIVE_EXPORT), "运维不应有敏感数据导出权限"
    print(f"  ✅ 权限检查测试通过")
    
    # 测试角色权限
    from src.security.rbac import ROLE_PERMISSIONS
    for role in Role:
        perms = len(ROLE_PERMISSIONS.get(role, set()))
        assert perms > 0, f"角色 {role.value} 应有权限"
    print(f"  ✅ 角色权限测试通过")
    
    return True


def test_jwt():
    """测试 JWT 认证"""
    print("\n🔑 测试 JWT 认证...")
    auth = AuthenticationService()
    
    # 创建模拟用户
    class MockUser:
        id = 'test123'
        tenant_id = 'tenant456'
        role = Role.OPERATIONS
    
    user = MockUser()
    
    # 测试 Token 生成
    tokens = auth.create_token_pair(user)
    assert tokens.access_token, "Access Token 应为非空"
    assert tokens.refresh_token, "Refresh Token 应为非空"
    print(f"  ✅ Token 生成测试通过")
    
    # 测试 Token 验证
    payload = auth.verify_token(tokens.access_token)
    assert payload.sub == 'test123', "用户 ID 不匹配"
    assert payload.tenant_id == 'tenant456', "租户 ID 不匹配"
    print(f"  ✅ Token 验证测试通过")
    
    return True


def test_master_agent():
    """测试 Master Agent SLA 调度"""
    print("\n📋 测试 Master Agent SLA 调度...")
    master = MasterAgent()
    
    # 创建任务
    user = {'id': 'user1', 'tenant_id': 'tenant1', 'role': 'operations'}
    task_data = {'title': 'GPU 故障分析', 'description': '服务器报错'}
    
    task_id = master.receive_task(task_data, user)
    assert task_id.startswith('TASK-'), "任务 ID 格式错误"
    print(f"  ✅ 任务创建测试通过：{task_id}")
    
    # 测试调度
    scheduled = master.schedule_tasks()
    print(f"  ✅ 任务调度测试通过：调度 {scheduled} 个任务")
    
    # 测试 SLA 监控
    violations = master.sla_monitor.check_violations()
    warnings = master.sla_monitor.check_warnings()
    assert len(violations) == 0, "不应有违规"
    print(f"  ✅ SLA 监控测试通过")
    
    return True


def test_file_processor():
    """测试 File Processor 敏感检测"""
    print("\n📁 测试 File Processor 敏感检测...")
    agent = FileProcessorAgent()
    
    # 测试敏感信息检测
    test_content = '''
    服务器 SN 号：SN12345678ABC
    IP 地址：192.168.1.100
    密码：password=SecretPass123
    '''
    
    user = {'id': 'user1', 'tenant_id': 'tenant1', 'role': 'operations'}
    result = agent.upload_file(test_content, 'test.log', user)
    
    assert result.success, "文件处理失败"
    assert len(result.file_metadata.sensitive_items) > 0, "应检测到敏感信息"
    print(f"  ✅ 敏感检测测试通过：检测到 {len(result.file_metadata.sensitive_items)} 项")
    
    # 测试脱敏
    assert result.processed_content != test_content, "内容应被脱敏"
    print(f"  ✅ 敏感脱敏测试通过")
    
    return True


def test_monitoring():
    """测试 Monitoring Agent 质量监控"""
    print("\n📊 测试 Monitoring Agent 质量监控...")
    agent = MonitoringAgent()
    tenant_id = 'tenant456'
    
    # 测试指标记录
    alerts = agent.record_sla(tenant_id, 99.5)
    assert len(alerts) == 0, "99.5% SLA 不应告警"
    print(f"  ✅ SLA 记录测试通过")
    
    # 测试反馈
    agent.submit_feedback('user1', tenant_id, rating=5, comment='很好')
    agent.submit_feedback('user2', tenant_id, rating=4, comment='不错')
    print(f"  ✅ 反馈提交测试通过")
    
    # 测试报告生成
    report = agent.generate_report(tenant_id, period_days=7)
    assert report.overall_score > 0, "总体评分应为正数"
    print(f"  ✅ 质量报告测试通过：评分 {report.overall_score:.1f}/100")
    
    return True


def run_all_tests():
    """运行所有测试"""
    print("=" * 60)
    print("🧪 智能运维团队架构改造 - 集成测试")
    print("=" * 60)
    
    tests = [
        ("加密服务", test_encryption),
        ("RBAC 权限", test_rbac),
        ("JWT 认证", test_jwt),
        ("Master Agent", test_master_agent),
        ("File Processor", test_file_processor),
        ("Monitoring", test_monitoring),
    ]
    
    passed = 0
    failed = 0
    
    for name, test_func in tests:
        try:
            if test_func():
                passed += 1
        except Exception as e:
            print(f"  ❌ {name} 测试失败：{e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"📊 测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60)
    
    if failed == 0:
        print("\n✅ 所有测试通过！系统可以投入生产。")
        return 0
    else:
        print(f"\n❌ {failed} 个测试失败，请修复后重试。")
        return 1


if __name__ == '__main__':
    sys.exit(run_all_tests())
