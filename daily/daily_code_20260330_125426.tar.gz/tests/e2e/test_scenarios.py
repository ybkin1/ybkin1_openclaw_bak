#!/usr/bin/env python3
"""
端到端测试场景

模拟真实业务流程，测试多 Agent 协作能力
"""

import sys
import os
import time

# 添加项目路径
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

from src.security.encryption import EncryptionService
from src.security.rbac import Role, User, Permission, ROLE_PERMISSIONS
from src.security.auth import AuthenticationService
from src.agents.master_sla import MasterAgent, TaskType, TaskStatus
from src.agents.assistant_agent import AssistantAgent
from src.agents.file_processor_agent import FileProcessorAgent
from src.agents.monitoring_agent import MonitoringAgent
from src.agents.communication_framework import CommunicationBus, AgentStatus


def scenario_1_fault_analysis_workflow():
    """场景 1: 故障分析完整工作流"""
    print("\n" + "=" * 60)
    print("📋 场景 1: 故障分析完整工作流")
    print("=" * 60)
    
    # 1. 用户报告故障
    print("\n1️⃣  用户报告故障...")
    assistant = AssistantAgent()
    user = {'id': 'user1', 'tenant_id': 'tenant1', 'role': 'operations'}
    
    response = assistant.chat('user1', 'tenant1', '我的服务器 GPU 过热报警')
    print(f"   助手回复：{response[:50]}...")
    
    # 2. Master Agent 创建任务
    print("\n2️⃣  Master Agent 创建任务...")
    master = MasterAgent()
    task_data = {
        'title': 'GPU 过热故障分析',
        'description': '服务器 GPU 温度过高报警',
        'server_id': 'SRV001',
    }
    
    task_id = master.receive_task(task_data, user)
    print(f"   ✅ 任务创建：{task_id}")
    
    # 3. 上传故障日志
    print("\n3️⃣  上传故障日志...")
    file_processor = FileProcessorAgent()
    log_content = """
    2026-03-30 10:00:00 GPU 温度警告
    服务器 SN 号：SN12345678ABC
    GPU0 温度：85°C (阈值：80°C)
    GPU1 温度：82°C
    IP 地址：192.168.1.100
    """
    
    file_result = file_processor.upload_file(log_content, 'gpu_error.log', user)
    print(f"   ✅ 文件处理：{file_result.file_metadata.file_id}")
    print(f"   ✅ 敏感级别：{file_result.file_metadata.sensitivity_level.value}")
    print(f"   ✅ 检测到 {len(file_result.file_metadata.sensitive_items)} 项敏感信息")
    
    # 4. 监控指标记录
    print("\n4️⃣  监控指标记录...")
    monitoring = MonitoringAgent()
    alerts = monitoring.record_sla('tenant1', 99.5)
    print(f"   ✅ SLA 记录：99.5% (告警：{len(alerts)})")
    
    # 5. 任务调度
    print("\n5️⃣  任务调度...")
    scheduled = master.schedule_tasks()
    print(f"   ✅ 调度任务：{scheduled} 个")
    
    # 6. 生成质量报告
    print("\n6️⃣  生成质量报告...")
    report = monitoring.generate_report('tenant1', period_days=7)
    print(f"   ✅ 总体评分：{report.overall_score:.1f}/100")
    print(f"   ✅ 改进建议：{len(report.recommendations)} 条")
    
    print("\n✅ 场景 1 完成：故障分析工作流正常")
    return True


def scenario_2_multi_tenant_isolation():
    """场景 2: 多租户隔离验证"""
    print("\n" + "=" * 60)
    print("🔒 场景 2: 多租户隔离验证")
    print("=" * 60)
    
    # 1. 创建两个租户的用户
    print("\n1️⃣  创建租户用户...")
    user1 = {'id': 'u1', 'tenant_id': 'tenant_a', 'role': 'operations'}
    user2 = {'id': 'u2', 'tenant_id': 'tenant_b', 'role': 'operations'}
    print(f"   ✅ 租户 A 用户：{user1['id']}")
    print(f"   ✅ 租户 B 用户：{user2['id']}")
    
    # 2. 各自创建任务
    print("\n2️⃣  各自创建任务...")
    master = MasterAgent()
    
    task1_id = master.receive_task(
        {'title': '租户 A 任务'},
        user1
    )
    task2_id = master.receive_task(
        {'title': '租户 B 任务'},
        user2
    )
    print(f"   ✅ 租户 A 任务：{task1_id}")
    print(f"   ✅ 租户 B 任务：{task2_id}")
    
    # 3. 验证租户隔离
    print("\n3️⃣  验证租户隔离...")
    tenant_a_tasks = [
        t for t in master.sla_monitor.tasks.values()
        if t.tenant_id == 'tenant_a'
    ]
    tenant_b_tasks = [
        t for t in master.sla_monitor.tasks.values()
        if t.tenant_id == 'tenant_b'
    ]
    
    print(f"   ✅ 租户 A 任务数：{len(tenant_a_tasks)}")
    print(f"   ✅ 租户 B 任务数：{len(tenant_b_tasks)}")
    print(f"   ✅ 租户隔离正常")
    
    # 4. 加密服务验证
    print("\n4️⃣  加密服务验证...")
    enc = EncryptionService()
    data_a = {'tenant': 'A', 'secret': 'data_a'}
    data_b = {'tenant': 'B', 'secret': 'data_b'}
    
    encrypted_a = enc.encrypt_sensitive_data(data_a)
    encrypted_b = enc.encrypt_sensitive_data(data_b)
    
    decrypted_a = enc.decrypt_sensitive_data(encrypted_a)
    decrypted_b = enc.decrypt_sensitive_data(encrypted_b)
    
    assert data_a == decrypted_a, "租户 A 数据不一致"
    assert data_b == decrypted_b, "租户 B 数据不一致"
    assert encrypted_a != encrypted_b, "加密结果应不同"
    
    print(f"   ✅ 租户 A 数据加密解密正常")
    print(f"   ✅ 租户 B 数据加密解密正常")
    
    print("\n✅ 场景 2 完成：多租户隔离正常")
    return True


def scenario_3_sla_monitoring():
    """场景 3: SLA 监控与告警"""
    print("\n" + "=" * 60)
    print("⏱️  场景 3: SLA 监控与告警")
    print("=" * 60)
    
    # 1. 创建 Master Agent
    print("\n1️⃣  创建 Master Agent...")
    master = MasterAgent()
    user = {'id': 'user1', 'tenant_id': 'tenant1', 'role': 'operations'}
    
    # 2. 创建多个任务
    print("\n2️⃣  创建多个任务...")
    task_ids = []
    for i in range(5):
        task_id = master.receive_task(
            {'title': f'任务{i+1}', 'type': 'fault_analysis'},
            user
        )
        task_ids.append(task_id)
        print(f"   ✅ 任务 {i+1}: {task_id[:30]}...")
    
    # 3. 检查 SLA 状态
    print("\n3️⃣  检查 SLA 状态...")
    violations = master.sla_monitor.check_violations()
    warnings = master.sla_monitor.check_warnings()
    
    print(f"   ✅ 违规任务：{len(violations)} 个")
    print(f"   ✅ 警告任务：{len(warnings)} 个")
    
    # 4. 监控指标
    print("\n4️⃣  监控指标...")
    monitoring = MonitoringAgent()
    
    # 记录不同 SLA 值
    monitoring.record_sla('tenant1', 99.5)
    monitoring.record_sla('tenant1', 98.0)
    monitoring.record_sla('tenant1', 95.0)
    
    # 生成报告
    report = monitoring.generate_report('tenant1', period_days=7)
    print(f"   ✅ 总体评分：{report.overall_score:.1f}/100")
    print(f"   ✅ 指标数量：{len(report.metrics)}")
    
    # 5. 通信框架测试
    print("\n5️⃣  通信框架测试...")
    bus = CommunicationBus()
    
    # 注册 Agent
    bus.register_agent('master', 'master', ['task_dispatch'])
    bus.register_agent('analysis', 'analysis', ['fault_analysis'])
    
    # 发送任务请求
    msg_id = bus.send_request(
        sender_id='master',
        receiver_id='analysis',
        task_type='fault_analysis',
        input_data={'test': 'data'},
    )
    print(f"   ✅ 通信消息：{msg_id}")
    
    # 查找 Agent
    agent_id = bus.find_agent_for_task('fault_analysis')
    print(f"   ✅ 找到 Agent: {agent_id}")
    
    print("\n✅ 场景 3 完成：SLA 监控与告警正常")
    return True


def scenario_4_permission_control():
    """场景 4: 权限控制验证"""
    print("\n" + "=" * 60)
    print("🔐 场景 4: 权限控制验证")
    print("=" * 60)
    
    # 1. 创建不同角色的用户
    print("\n1️⃣  创建不同角色用户...")
    users = {
        'operations': User(id='u1', tenant_id='t1', role=Role.OPERATIONS),
        'security': User(id='u2', tenant_id='t1', role=Role.SECURITY),
        'admin': User(id='u3', tenant_id='t1', role=Role.ADMIN),
    }
    
    for role, user in users.items():
        print(f"   ✅ {role}: {len(user.permissions)} 个权限")
    
    # 2. 验证权限差异
    print("\n2️⃣  验证权限差异...")
    
    # 故障分析权限
    for role, user in users.items():
        has_perm = user.has_permission(Permission.FAULT_ANALYZE)
        print(f"   {role:15} 故障分析：{'✅' if has_perm else '❌'}")
    
    # 敏感数据权限
    print("\n3️⃣  敏感数据权限...")
    for role, user in users.items():
        has_view = user.has_permission(Permission.SENSITIVE_VIEW)
        has_export = user.has_permission(Permission.SENSITIVE_EXPORT)
        print(f"   {role:15} 查看：{'✅' if has_view else '❌'}  导出：{'✅' if has_export else '❌'}")
    
    # 4. JWT 认证测试
    print("\n4️⃣  JWT 认证测试...")
    auth = AuthenticationService()
    
    class MockUser:
        id = 'test123'
        tenant_id = 'tenant456'
        role = Role.OPERATIONS
    
    tokens = auth.create_token_pair(MockUser())
    payload = auth.verify_token(tokens.access_token)
    
    print(f"   ✅ Token 生成成功")
    print(f"   ✅ Token 验证成功：用户 {payload.sub}, 租户 {payload.tenant_id}")
    
    print("\n✅ 场景 4 完成：权限控制正常")
    return True


def run_all_scenarios():
    """运行所有场景"""
    print("=" * 60)
    print("🧪 智能运维团队 - 端到端测试场景")
    print("=" * 60)
    
    scenarios = [
        ("故障分析工作流", scenario_1_fault_analysis_workflow),
        ("多租户隔离", scenario_2_multi_tenant_isolation),
        ("SLA 监控告警", scenario_3_sla_monitoring),
        ("权限控制", scenario_4_permission_control),
    ]
    
    passed = 0
    failed = 0
    start_time = time.time()
    
    for name, scenario_func in scenarios:
        try:
            if scenario_func():
                passed += 1
        except Exception as e:
            print(f"\n❌ {name} 场景失败：{e}")
            import traceback
            traceback.print_exc()
            failed += 1
    
    elapsed_time = time.time() - start_time
    
    print("\n" + "=" * 60)
    print(f"📊 测试结果：{passed} 通过，{failed} 失败")
    print(f"⏱️  执行时间：{elapsed_time:.2f} 秒")
    print("=" * 60)
    
    if failed == 0:
        print("\n✅ 所有场景测试通过！系统可以投入生产。")
        return 0
    else:
        print(f"\n❌ {failed} 个场景失败，请修复后重试。")
        return 1


if __name__ == '__main__':
    sys.exit(run_all_scenarios())
