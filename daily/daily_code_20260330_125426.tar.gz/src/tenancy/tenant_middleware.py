"""
多租户中间件

提供租户隔离、租户路由、租户上下文管理等功能
"""

from typing import Optional, Dict, Any
from contextvars import ContextVar
from dataclasses import dataclass
import json

# 当前租户上下文 (线程安全)
current_tenant_id: ContextVar[Optional[str]] = ContextVar(
    'current_tenant_id',
    default=None
)


@dataclass
class TenantContext:
    """租户上下文"""
    tenant_id: str
    tenant_name: str
    tenant_type: str  # internal/customer
    user_id: str
    user_role: str
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'tenant_id': self.tenant_id,
            'tenant_name': self.tenant_name,
            'tenant_type': self.tenant_type,
            'user_id': self.user_id,
            'user_role': self.user_role,
        }


class TenantIsolationError(Exception):
    """租户隔离异常"""
    pass


class TenantNotFoundError(Exception):
    """租户不存在异常"""
    pass


class TenantMiddleware:
    """租户中间件
    
    自动从请求中提取 tenant_id，设置到上下文
    所有数据库查询自动添加 tenant_id 过滤
    
    Attributes:
        app: FastAPI 应用
        db_pool: 数据库连接池
    
    Example:
        from fastapi import FastAPI
        app = FastAPI()
        app.add_middleware(TenantMiddleware, db_pool=db_pool)
    """
    
    def __init__(self, app, db_pool=None):
        """初始化租户中间件
        
        Args:
            app: FastAPI 应用
            db_pool: 数据库连接池 (可选)
        """
        self.app = app
        self.db_pool = db_pool
    
    async def __call__(self, scope, receive, send):
        """中间件调用"""
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        
        from starlette.requests import Request
        request = Request(scope, receive=receive)
        
        # 从 Token 中提取 tenant_id
        token = self._extract_token(request)
        if token:
            try:
                # 验证 Token 并提取 tenant_id
                from src.security.auth import AuthenticationService
                auth_service = AuthenticationService(self.db_pool)
                payload = auth_service.verify_token(token)
                tenant_id = payload.tenant_id
                
                # 设置到上下文
                token_var = current_tenant_id.set(tenant_id)
                
                try:
                    return await self.app(scope, receive, send)
                finally:
                    current_tenant_id.reset(token_var)
                    
            except Exception as e:
                from starlette.responses import JSONResponse
                return JSONResponse(
                    status_code=401,
                    content={"detail": f"认证失败：{e}"}
                )
        else:
            from starlette.responses import JSONResponse
            return JSONResponse(
                status_code=401,
                content={"detail": "缺少认证令牌"}
            )
    
    def _extract_token(self, request) -> Optional[str]:
        """从请求中提取 Token
        
        Args:
            request: HTTP 请求
        
        Returns:
            Token 字符串或 None
        """
        auth_header = request.headers.get('Authorization', '')
        if auth_header.startswith('Bearer '):
            return auth_header[7:]
        return None


class TenantAwareDatabase:
    """租户感知数据库连接
    
    所有查询自动添加 tenant_id 过滤
    防止跨租户访问
    
    Attributes:
        conn: 数据库连接
    
    Example:
        db = TenantAwareDatabase(conn)
        results = db.query('fault_cases', {'status': 'pending'})
        # 自动添加 WHERE tenant_id = 'xxx' AND status = 'pending'
    """
    
    def __init__(self, conn):
        """初始化租户感知数据库
        
        Args:
            conn: 数据库连接
        """
        self.conn = conn
    
    def query(self, table: str, filters: Dict[str, Any] = None) -> list:
        """查询数据 (自动添加 tenant_id 过滤)
        
        Args:
            table: 表名
            filters: 过滤条件字典
        
        Returns:
            查询结果列表
        
        Raises:
            TenantIsolationError: 尝试跨租户访问时抛出
        """
        tenant_id = current_tenant_id.get()
        
        if not tenant_id:
            # 允许系统表查询 (无租户隔离)
            system_tables = ['tenants', 'users', 'roles', 'permissions']
            if table not in system_tables:
                raise TenantIsolationError(
                    f"未设置租户上下文，无法查询 {table} 表"
                )
            filters = filters or {}
        else:
            # 自动添加租户过滤
            filters = filters or {}
            filters['tenant_id'] = tenant_id
        
        # 构建 WHERE 子句
        where_clauses = []
        params = []
        for key, value in filters.items():
            where_clauses.append(f"{key} = %s")
            params.append(value)
        
        where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
        
        # 执行查询
        sql = f"SELECT * FROM {table} WHERE {where_sql}"
        cursor = self.conn.cursor()
        cursor.execute(sql, params)
        columns = [desc[0] for desc in cursor.description]
        results = []
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row)))
        return results
    
    def query_one(self, table: str, filters: Dict[str, Any] = None) -> Optional[Dict]:
        """查询单条数据
        
        Args:
            table: 表名
            filters: 过滤条件
        
        Returns:
            查询结果或 None
        """
        results = self.query(table, filters)
        return results[0] if results else None
    
    def insert(self, table: str, data: Dict[str, Any]) -> str:
        """插入数据 (自动添加 tenant_id)
        
        Args:
            table: 表名
            data: 插入数据字典
        
        Returns:
            插入的 ID
        
        Raises:
            TenantIsolationError: 未设置租户上下文时抛出
        """
        tenant_id = current_tenant_id.get()
        
        if not tenant_id:
            # 允许插入系统表
            system_tables = ['tenants', 'users']
            if table not in system_tables:
                raise TenantIsolationError(
                    f"未设置租户上下文，无法插入 {table} 表"
                )
        else:
            # 自动添加租户 ID
            if 'tenant_id' not in data and self._table_has_tenant_column(table):
                data['tenant_id'] = tenant_id
        
        # 执行插入
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['%s'] * len(data))
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders}) RETURNING id"
        cursor = self.conn.cursor()
        cursor.execute(sql, list(data.values()))
        result = cursor.fetchone()
        self.conn.commit()
        return result[0] if result else None
    
    def update(self, table: str, data: Dict[str, Any], filters: Dict[str, Any]) -> int:
        """更新数据 (自动添加 tenant_id 过滤)
        
        Args:
            table: 表名
            data: 更新数据
            filters: 过滤条件
        
        Returns:
            更新的行数
        """
        tenant_id = current_tenant_id.get()
        
        if tenant_id:
            filters = filters or {}
            filters['tenant_id'] = tenant_id
        
        # 构建 SET 子句
        set_clauses = []
        params = []
        for key, value in data.items():
            set_clauses.append(f"{key} = %s")
            params.append(value)
        
        # 构建 WHERE 子句
        where_clauses = []
        for key, value in filters.items():
            where_clauses.append(f"{key} = %s")
            params.append(value)
        
        where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
        set_sql = ", ".join(set_clauses)
        
        # 执行更新
        sql = f"UPDATE {table} SET {set_sql} WHERE {where_sql}"
        cursor = self.conn.cursor()
        cursor.execute(sql, params)
        self.conn.commit()
        return cursor.rowcount
    
    def delete(self, table: str, filters: Dict[str, Any]) -> int:
        """删除数据 (自动添加 tenant_id 过滤)
        
        Args:
            table: 表名
            filters: 过滤条件
        
        Returns:
            删除的行数
        """
        tenant_id = current_tenant_id.get()
        
        if tenant_id:
            filters = filters or {}
            filters['tenant_id'] = tenant_id
        
        # 构建 WHERE 子句
        where_clauses = []
        params = []
        for key, value in filters.items():
            where_clauses.append(f"{key} = %s")
            params.append(value)
        
        where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
        
        # 执行删除
        sql = f"DELETE FROM {table} WHERE {where_sql}"
        cursor = self.conn.cursor()
        cursor.execute(sql, params)
        self.conn.commit()
        return cursor.rowcount
    
    def _table_has_tenant_column(self, table: str) -> bool:
        """检查表是否有 tenant_id 列
        
        Args:
            table: 表名
        
        Returns:
            是否有 tenant_id 列
        """
        tables_with_tenant = [
            'users', 'fault_cases', 'fault_logs', 'approvals',
            'reports', 'tickets', 'ticket_comments', 'knowledge_base',
            'audit_logs', 'sla_violations'
        ]
        return table in tables_with_tenant


# 全局数据库实例
_db_instance: Optional[TenantAwareDatabase] = None


def get_tenant_db(conn) -> TenantAwareDatabase:
    """获取租户感知数据库实例"""
    global _db_instance
    if _db_instance is None:
        _db_instance = TenantAwareDatabase(conn)
    return _db_instance


def get_current_tenant_id() -> Optional[str]:
    """获取当前租户 ID"""
    return current_tenant_id.get()


def set_current_tenant_id(tenant_id: str):
    """设置当前租户 ID"""
    current_tenant_id.set(tenant_id)


# 命令行工具
if __name__ == '__main__':
    import sys
    
    print("租户中间件模块")
    print("用法：在 FastAPI 应用中添加中间件")
    print("")
    print("示例:")
    print("  from fastapi import FastAPI")
    print("  from src.tenancy.tenant_middleware import TenantMiddleware")
    print("  app = FastAPI()")
    print("  app.add_middleware(TenantMiddleware, db_pool=db_pool)")
    print("")
    print("当前租户上下文:", current_tenant_id.get())
