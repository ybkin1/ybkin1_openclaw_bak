"""
Monitoring Agent - 质量监控与满意度管理

提供服务质量监控、满意度调查、报告审核、性能基线等功能
"""

from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
import json
import os
import statistics


# ==================== 枚举类 ====================

class MetricType(Enum):
    """指标类型"""
    SLA_COMPLIANCE = "sla_compliance"       # SLA 合规率
    RESPONSE_TIME = "response_time"         # 响应时间
    TASK_SUCCESS_RATE = "task_success_rate" # 任务成功率
    CUSTOMER_SATISFACTION = "csat"          # 客户满意度
    ERROR_RATE = "error_rate"               # 错误率
    THROUGHPUT = "throughput"               # 吞吐量


class AlertLevel(Enum):
    """告警级别"""
    INFO = "info"               # 信息
    WARNING = "warning"         # 警告
    CRITICAL = "critical"       # 严重
    EMERGENCY = "emergency"     # 紧急


class FeedbackCategory(Enum):
    """反馈分类"""
    QUALITY = "quality"         # 质量
    SPEED = "speed"             # 速度
    ACCURACY = "accuracy"       # 准确性
    COMPLETENESS = "completeness"  # 完整性
    USABILITY = "usability"     # 易用性
    OTHER = "other"             # 其他


# ==================== 数据类 ====================

@dataclass
class Metric:
    """监控指标"""
    metric_id: str
    metric_type: MetricType
    value: float
    target: float
    unit: str
    timestamp: datetime = field(default_factory=datetime.now)
    tenant_id: str = ""
    tags: Dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'metric_id': self.metric_id,
            'metric_type': self.metric_type.value,
            'value': self.value,
            'target': self.target,
            'unit': self.unit,
            'timestamp': self.timestamp.isoformat(),
            'tenant_id': self.tenant_id,
            'tags': self.tags,
            'achievement_rate': self.value / self.target if self.target > 0 else 0,
        }


@dataclass
class Alert:
    """告警"""
    alert_id: str
    alert_level: AlertLevel
    title: str
    message: str
    metric_type: Optional[MetricType]
    current_value: Optional[float]
    threshold: Optional[float]
    tenant_id: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'alert_id': self.alert_id,
            'alert_level': self.alert_level.value,
            'title': self.title,
            'message': self.message,
            'metric_type': self.metric_type.value if self.metric_type else None,
            'current_value': self.current_value,
            'threshold': self.threshold,
            'tenant_id': self.tenant_id,
            'created_at': self.created_at.isoformat(),
            'acknowledged': self.acknowledged,
            'acknowledged_by': self.acknowledged_by,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
        }


@dataclass
class Feedback:
    """用户反馈"""
    feedback_id: str
    user_id: str
    tenant_id: str
    rating: int  # 1-5
    category: FeedbackCategory
    comment: str
    task_id: Optional[str] = None
    report_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'feedback_id': self.feedback_id,
            'user_id': self.user_id,
            'tenant_id': self.tenant_id,
            'rating': self.rating,
            'category': self.category.value,
            'comment': self.comment,
            'task_id': self.task_id,
            'report_id': self.report_id,
            'created_at': self.created_at.isoformat(),
        }


@dataclass
class QualityReport:
    """质量报告"""
    report_id: str
    tenant_id: str
    period_start: datetime
    period_end: datetime
    metrics: List[Metric]
    alerts: List[Alert]
    feedback_summary: Dict[str, Any]
    overall_score: float
    recommendations: List[str]
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'report_id': self.report_id,
            'tenant_id': self.tenant_id,
            'period_start': self.period_start.isoformat(),
            'period_end': self.period_end.isoformat(),
            'metrics': [m.to_dict() for m in self.metrics],
            'alerts': [a.to_dict() for a in self.alerts],
            'feedback_summary': self.feedback_summary,
            'overall_score': self.overall_score,
            'recommendations': self.recommendations,
            'created_at': self.created_at.isoformat(),
        }


# ==================== 指标收集器 ====================

class MetricCollector:
    """指标收集器
    
    收集各类质量指标
    
    Example:
        >>> collector = MetricCollector()
        >>> collector.record(MetricType.SLA_COMPLIANCE, 99.5, target=99.0)
    """
    
    def __init__(self):
        """初始化收集器"""
        self.metrics: List[Metric] = []
        self.baseline: Dict[MetricType, float] = {
            MetricType.SLA_COMPLIANCE: 99.0,
            MetricType.RESPONSE_TIME: 1000,  # ms
            MetricType.TASK_SUCCESS_RATE: 95.0,
            MetricType.CUSTOMER_SATISFACTION: 4.0,
            MetricType.ERROR_RATE: 1.0,
            MetricType.THROUGHPUT: 100,  # tasks/hour
        }
    
    def record(
        self,
        metric_type: MetricType,
        value: float,
        tenant_id: str = "",
        tags: Dict[str, str] = None
    ) -> Metric:
        """记录指标
        
        Args:
            metric_type: 指标类型
            value: 指标值
            tenant_id: 租户 ID
            tags: 标签
        
        Returns:
            记录的指标
        """
        metric = Metric(
            metric_id=f"metric_{datetime.now().strftime('%Y%m%d%H%M%S')}_{os.getpid()}",
            metric_type=metric_type,
            value=value,
            target=self.baseline.get(metric_type, 100.0),
            unit=self._get_unit(metric_type),
            tenant_id=tenant_id,
            tags=tags or {},
        )
        self.metrics.append(metric)
        return metric
    
    def get_latest(
        self,
        metric_type: MetricType,
        tenant_id: str = None
    ) -> Optional[Metric]:
        """获取最新指标"""
        filtered = [m for m in self.metrics if m.metric_type == metric_type]
        if tenant_id:
            filtered = [m for m in filtered if m.tenant_id == tenant_id]
        return filtered[-1] if filtered else None
    
    def get_average(
        self,
        metric_type: MetricType,
        period_hours: int = 24,
        tenant_id: str = None
    ) -> Optional[float]:
        """获取平均值"""
        cutoff = datetime.now() - timedelta(hours=period_hours)
        filtered = [
            m for m in self.metrics
            if m.metric_type == metric_type
            and m.timestamp > cutoff
        ]
        if tenant_id:
            filtered = [m for m in filtered if m.tenant_id == tenant_id]
        
        if not filtered:
            return None
        
        return statistics.mean([m.value for m in filtered])
    
    def _get_unit(self, metric_type: MetricType) -> str:
        """获取单位"""
        units = {
            MetricType.SLA_COMPLIANCE: "%",
            MetricType.RESPONSE_TIME: "ms",
            MetricType.TASK_SUCCESS_RATE: "%",
            MetricType.CUSTOMER_SATISFACTION: "stars",
            MetricType.ERROR_RATE: "%",
            MetricType.THROUGHPUT: "tasks/hour",
        }
        return units.get(metric_type, "")


# ==================== 告警管理器 ====================

class AlertManager:
    """告警管理器
    
    管理告警生成、通知、确认等
    
    Example:
        >>> manager = AlertManager()
        >>> manager.check_threshold(metric, warning=95, critical=90)
    """
    
    def __init__(self):
        """初始化管理器"""
        self.alerts: List[Alert] = []
        
        # 告警阈值配置
        self.thresholds = {
            MetricType.SLA_COMPLIANCE: {
                'warning': 98.0,
                'critical': 95.0,
                'emergency': 90.0,
                'check': 'below',  # 低于阈值告警
            },
            MetricType.RESPONSE_TIME: {
                'warning': 2000,
                'critical': 5000,
                'emergency': 10000,
                'check': 'above',  # 高于阈值告警
            },
            MetricType.TASK_SUCCESS_RATE: {
                'warning': 95.0,
                'critical': 90.0,
                'emergency': 80.0,
                'check': 'below',
            },
            MetricType.CUSTOMER_SATISFACTION: {
                'warning': 3.5,
                'critical': 3.0,
                'emergency': 2.5,
                'check': 'below',
            },
            MetricType.ERROR_RATE: {
                'warning': 2.0,
                'critical': 5.0,
                'emergency': 10.0,
                'check': 'above',
            },
        }
    
    def check_threshold(self, metric: Metric) -> List[Alert]:
        """检查阈值
        
        Args:
            metric: 指标
        
        Returns:
            生成的告警列表
        """
        alerts = []
        config = self.thresholds.get(metric.metric_type)
        
        if not config:
            return alerts
        
        check_type = config.get('check')
        value = metric.value
        
        # 检查紧急级别
        if self._should_alert(value, config.get('emergency'), check_type):
            alerts.append(self._create_alert(
                metric=metric,
                level=AlertLevel.EMERGENCY,
                threshold=config.get('emergency'),
            ))
        # 检查严重级别
        elif self._should_alert(value, config.get('critical'), check_type):
            alerts.append(self._create_alert(
                metric=metric,
                level=AlertLevel.CRITICAL,
                threshold=config.get('critical'),
            ))
        # 检查警告级别
        elif self._should_alert(value, config.get('warning'), check_type):
            alerts.append(self._create_alert(
                metric=metric,
                level=AlertLevel.WARNING,
                threshold=config.get('warning'),
            ))
        
        self.alerts.extend(alerts)
        return alerts
    
    def _should_alert(
        self,
        value: float,
        threshold: float,
        check_type: str
    ) -> bool:
        """判断是否应该告警"""
        if threshold is None:
            return False
        
        if check_type == 'above':
            return value > threshold
        else:  # below
            return value < threshold
    
    def _create_alert(
        self,
        metric: Metric,
        level: AlertLevel,
        threshold: float
    ) -> Alert:
        """创建告警"""
        return Alert(
            alert_id=f"alert_{datetime.now().strftime('%Y%m%d%H%M%S')}_{os.getpid()}",
            alert_level=level,
            title=f"{metric.metric_type.value} {level.value}",
            message=f"{metric.metric_type.value} = {metric.value}{metric.unit} (阈值：{threshold})",
            metric_type=metric.metric_type,
            current_value=metric.value,
            threshold=threshold,
            tenant_id=metric.tenant_id,
        )
    
    def acknowledge_alert(
        self,
        alert_id: str,
        user_id: str
    ) -> bool:
        """确认告警"""
        for alert in self.alerts:
            if alert.alert_id == alert_id:
                alert.acknowledged = True
                alert.acknowledged_by = user_id
                alert.acknowledged_at = datetime.now()
                return True
        return False
    
    def get_unacknowledged(
        self,
        tenant_id: str = None,
        level: AlertLevel = None
    ) -> List[Alert]:
        """获取未确认告警"""
        alerts = [a for a in self.alerts if not a.acknowledged]
        
        if tenant_id:
            alerts = [a for a in alerts if a.tenant_id == tenant_id]
        
        if level:
            alerts = [a for a in alerts if a.alert_level == level]
        
        return alerts


# ==================== 反馈收集器 ====================

class FeedbackCollector:
    """反馈收集器
    
    收集用户反馈和满意度评分
    
    Example:
        >>> collector = FeedbackCollector()
        >>> collector.submit(user_id, tenant_id, rating=5, comment="很好")
    """
    
    def __init__(self):
        """初始化收集器"""
        self.feedback_list: List[Feedback] = []
    
    def submit(
        self,
        user_id: str,
        tenant_id: str,
        rating: int,
        category: FeedbackCategory = FeedbackCategory.QUALITY,
        comment: str = "",
        task_id: str = None,
        report_id: str = None
    ) -> Feedback:
        """提交反馈
        
        Args:
            user_id: 用户 ID
            tenant_id: 租户 ID
            rating: 评分 (1-5)
            category: 分类
            comment: 评论
            task_id: 关联任务 ID
            report_id: 关联报告 ID
        
        Returns:
            反馈对象
        """
        feedback = Feedback(
            feedback_id=f"feedback_{datetime.now().strftime('%Y%m%d%H%M%S')}_{os.getpid()}",
            user_id=user_id,
            tenant_id=tenant_id,
            rating=rating,
            category=category,
            comment=comment,
            task_id=task_id,
            report_id=report_id,
        )
        self.feedback_list.append(feedback)
        return feedback
    
    def get_average_rating(
        self,
        tenant_id: str = None,
        category: FeedbackCategory = None,
        period_days: int = 30
    ) -> Optional[float]:
        """获取平均评分"""
        cutoff = datetime.now() - timedelta(days=period_days)
        filtered = [f for f in self.feedback_list if f.created_at > cutoff]
        
        if tenant_id:
            filtered = [f for f in filtered if f.tenant_id == tenant_id]
        
        if category:
            filtered = [f for f in filtered if f.category == category]
        
        if not filtered:
            return None
        
        return statistics.mean([f.rating for f in filtered])
    
    def get_summary(
        self,
        tenant_id: str = None,
        period_days: int = 30
    ) -> Dict[str, Any]:
        """获取反馈摘要"""
        cutoff = datetime.now() - timedelta(days=period_days)
        filtered = [f for f in self.feedback_list if f.created_at > cutoff]
        
        if tenant_id:
            filtered = [f for f in filtered if f.tenant_id == tenant_id]
        
        if not filtered:
            return {'count': 0}
        
        # 按分类统计
        by_category = {}
        for f in filtered:
            cat = f.category.value
            if cat not in by_category:
                by_category[cat] = {'count': 0, 'total_rating': 0}
            by_category[cat]['count'] += 1
            by_category[cat]['total_rating'] += f.rating
        
        # 计算平均分
        for cat in by_category:
            by_category[cat]['average'] = (
                by_category[cat]['total_rating'] / by_category[cat]['count']
                if by_category[cat]['count'] > 0 else 0
            )
        
        return {
            'count': len(filtered),
            'average_rating': statistics.mean([f.rating for f in filtered]),
            'by_category': by_category,
            'rating_distribution': self._get_distribution(filtered),
        }
    
    def _get_distribution(self, feedback_list: List[Feedback]) -> Dict[str, int]:
        """获取评分分布"""
        dist = {'1': 0, '2': 0, '3': 0, '4': 0, '5': 0}
        for f in feedback_list:
            dist[str(f.rating)] = dist.get(str(f.rating), 0) + 1
        return dist


# ==================== Monitoring Agent ====================

class MonitoringAgent:
    """质量监控 Agent
    
    整合指标收集、告警管理、反馈收集等功能
    
    Example:
        >>> agent = MonitoringAgent()
        >>> agent.record_sla(tenant_id, 99.5)
        >>> report = agent.generate_report(tenant_id)
    """
    
    def __init__(self):
        """初始化 Monitoring Agent"""
        self.collector = MetricCollector()
        self.alert_manager = AlertManager()
        self.feedback_collector = FeedbackCollector()
    
    def record_sla(
        self,
        tenant_id: str,
        compliance_rate: float,
        tags: Dict[str, str] = None
    ) -> List[Alert]:
        """记录 SLA 合规率"""
        metric = self.collector.record(
            metric_type=MetricType.SLA_COMPLIANCE,
            value=compliance_rate,
            tenant_id=tenant_id,
            tags=tags,
        )
        return self.alert_manager.check_threshold(metric)
    
    def record_response_time(
        self,
        tenant_id: str,
        response_time_ms: float,
        tags: Dict[str, str] = None
    ) -> List[Alert]:
        """记录响应时间"""
        metric = self.collector.record(
            metric_type=MetricType.RESPONSE_TIME,
            value=response_time_ms,
            tenant_id=tenant_id,
            tags=tags,
        )
        return self.alert_manager.check_threshold(metric)
    
    def record_task_success(
        self,
        tenant_id: str,
        success_rate: float,
        tags: Dict[str, str] = None
    ) -> List[Alert]:
        """记录任务成功率"""
        metric = self.collector.record(
            metric_type=MetricType.TASK_SUCCESS_RATE,
            value=success_rate,
            tenant_id=tenant_id,
            tags=tags,
        )
        return self.alert_manager.check_threshold(metric)
    
    def submit_feedback(
        self,
        user_id: str,
        tenant_id: str,
        rating: int,
        category: str = "quality",
        comment: str = "",
        task_id: str = None
    ) -> Feedback:
        """提交反馈"""
        return self.feedback_collector.submit(
            user_id=user_id,
            tenant_id=tenant_id,
            rating=rating,
            category=FeedbackCategory(category),
            comment=comment,
            task_id=task_id,
        )
    
    def generate_report(
        self,
        tenant_id: str,
        period_days: int = 7
    ) -> QualityReport:
        """生成质量报告"""
        period_end = datetime.now()
        period_start = period_end - timedelta(days=period_days)
        
        # 收集指标
        metrics = []
        for metric_type in MetricType:
            metric = self.collector.get_latest(metric_type, tenant_id)
            if metric:
                metrics.append(metric)
        
        # 收集告警
        alerts = self.alert_manager.get_unacknowledged(tenant_id)
        
        # 收集反馈摘要
        feedback_summary = self.feedback_collector.get_summary(tenant_id, period_days)
        
        # 计算总体评分
        overall_score = self._calculate_overall_score(metrics, feedback_summary)
        
        # 生成建议
        recommendations = self._generate_recommendations(metrics, alerts)
        
        return QualityReport(
            report_id=f"report_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            tenant_id=tenant_id,
            period_start=period_start,
            period_end=period_end,
            metrics=metrics,
            alerts=alerts,
            feedback_summary=feedback_summary,
            overall_score=overall_score,
            recommendations=recommendations,
        )
    
    def _calculate_overall_score(
        self,
        metrics: List[Metric],
        feedback_summary: Dict[str, Any]
    ) -> float:
        """计算总体评分"""
        scores = []
        
        # 指标得分 (权重 60%)
        for metric in metrics:
            if metric.target > 0:
                achievement = min(1.0, metric.value / metric.target)
                # 对于错误率和响应时间，越低越好
                if metric.metric_type in [MetricType.ERROR_RATE, MetricType.RESPONSE_TIME]:
                    achievement = min(1.0, metric.target / metric.value) if metric.value > 0 else 1.0
                scores.append(achievement * 100)
        
        # 反馈得分 (权重 40%)
        if feedback_summary.get('average_rating'):
            feedback_score = (feedback_summary['average_rating'] / 5.0) * 100
            scores.append(feedback_score)
        
        if not scores:
            return 0.0
        
        # 加权平均
        return statistics.mean(scores)
    
    def _generate_recommendations(
        self,
        metrics: List[Metric],
        alerts: List[Alert]
    ) -> List[str]:
        """生成改进建议"""
        recommendations = []
        
        # 根据告警生成建议
        for alert in alerts:
            if alert.metric_type == MetricType.SLA_COMPLIANCE:
                recommendations.append("SLA 合规率低于目标，建议增加资源或优化流程")
            elif alert.metric_type == MetricType.RESPONSE_TIME:
                recommendations.append("响应时间过长，建议优化查询或增加缓存")
            elif alert.metric_type == MetricType.ERROR_RATE:
                recommendations.append("错误率偏高，建议加强测试和监控")
        
        # 根据指标生成建议
        for metric in metrics:
            if metric.metric_type == MetricType.CUSTOMER_SATISFACTION:
                if metric.value < 4.0:
                    recommendations.append("客户满意度有待提升，建议收集更多反馈并改进")
        
        # 去重
        return list(set(recommendations))
    
    def get_dashboard_data(
        self,
        tenant_id: str
    ) -> Dict[str, Any]:
        """获取仪表盘数据"""
        return {
            'sla_compliance': self.collector.get_latest(MetricType.SLA_COMPLIANCE, tenant_id),
            'response_time': self.collector.get_latest(MetricType.RESPONSE_TIME, tenant_id),
            'task_success_rate': self.collector.get_latest(MetricType.TASK_SUCCESS_RATE, tenant_id),
            'customer_satisfaction': self.collector.get_latest(MetricType.CUSTOMER_SATISFACTION, tenant_id),
            'unacknowledged_alerts': len(self.alert_manager.get_unacknowledged(tenant_id)),
            'feedback_summary': self.feedback_collector.get_summary(tenant_id, 7),
        }


# ==================== 命令行工具 ====================

if __name__ == '__main__':
    agent = MonitoringAgent()
    
    print("=" * 60)
    print("质量监控 Monitoring Agent")
    print("=" * 60)
    
    tenant_id = "tenant456"
    
    # 记录指标
    print("\n📊 记录指标...")
    alerts = agent.record_sla(tenant_id, 99.5)
    print(f"   SLA 合规率：99.5% (告警：{len(alerts)})")
    
    alerts = agent.record_response_time(tenant_id, 850)
    print(f"   响应时间：850ms (告警：{len(alerts)})")
    
    alerts = agent.record_task_success(tenant_id, 98.0)
    print(f"   任务成功率：98.0% (告警：{len(alerts)})")
    
    # 提交反馈
    print("\n💬 提交反馈...")
    agent.submit_feedback("user1", tenant_id, rating=5, comment="非常好！")
    agent.submit_feedback("user2", tenant_id, rating=4, comment="不错")
    
    # 生成报告
    print("\n📋 生成质量报告...")
    report = agent.generate_report(tenant_id, period_days=7)
    print(f"   总体评分：{report.overall_score:.1f}/100")
    print(f"   指标数量：{len(report.metrics)}")
    print(f"   未确认告警：{len(report.alerts)}")
    print(f"   改进建议：{len(report.recommendations)} 条")
    
    for rec in report.recommendations[:3]:
        print(f"   - {rec}")
    
    print("\n" + "=" * 60)
