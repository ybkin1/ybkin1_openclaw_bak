"""
Agent 通信框架

提供 Agent 间消息传递、任务协作、结果返回等功能
支持同步和异步通信模式
"""

from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Callable
import json
import uuid
import hashlib
from collections import defaultdict


# ==================== 枚举类 ====================

class MessageType(Enum):
    """消息类型"""
    TASK_REQUEST = "task_request"       # 任务请求
    TASK_RESPONSE = "task_response"     # 任务响应
    STATUS_QUERY = "status_query"       # 状态查询
    STATUS_RESPONSE = "status_response" # 状态响应
    ERROR = "error"                     # 错误通知
    HEARTBEAT = "heartbeat"             # 心跳


class MessagePriority(Enum):
    """消息优先级"""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    URGENT = 3


class AgentStatus(Enum):
    """Agent 状态"""
    ONLINE = "online"
    BUSY = "busy"
    OFFLINE = "offline"
    ERROR = "error"


# ==================== 数据类 ====================

@dataclass
class Message:
    """消息数据类"""
    message_id: str
    message_type: MessageType
    priority: MessagePriority
    sender_id: str
    receiver_id: str
    payload: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)
    timeout_seconds: int = 300
    correlation_id: Optional[str] = None
    reply_to: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'message_id': self.message_id,
            'message_type': self.message_type.value,
            'priority': self.priority.value,
            'sender_id': self.sender_id,
            'receiver_id': self.receiver_id,
            'payload': self.payload,
            'timestamp': self.timestamp.isoformat(),
            'timeout_seconds': self.timeout_seconds,
            'correlation_id': self.correlation_id,
            'reply_to': self.reply_to,
        }
    
    def is_expired(self) -> bool:
        """检查是否过期"""
        expiry = self.timestamp + timedelta(seconds=self.timeout_seconds)
        return datetime.now() > expiry
    
    def create_reply(
        self,
        sender_id: str,
        message_type: MessageType,
        payload: Dict[str, Any]
    ) -> 'Message':
        """创建回复消息"""
        return Message(
            message_id=f"msg_{uuid.uuid4().hex[:16]}",
            message_type=message_type,
            priority=self.priority,
            sender_id=sender_id,
            receiver_id=self.sender_id,
            payload=payload,
            correlation_id=self.message_id,
            reply_to=self.message_id,
        )


@dataclass
class TaskRequest:
    """任务请求"""
    task_id: str
    task_type: str
    input_data: Dict[str, Any]
    timeout_seconds: int = 3600
    callback_url: Optional[str] = None
    
    def to_message(self, sender_id: str, receiver_id: str) -> Message:
        """转换为消息"""
        return Message(
            message_id=f"msg_{uuid.uuid4().hex[:16]}",
            message_type=MessageType.TASK_REQUEST,
            priority=MessagePriority.NORMAL,
            sender_id=sender_id,
            receiver_id=receiver_id,
            payload={
                'task_id': self.task_id,
                'task_type': self.task_type,
                'input_data': self.input_data,
                'timeout_seconds': self.timeout_seconds,
                'callback_url': self.callback_url,
            },
        )


@dataclass
class TaskResponse:
    """任务响应"""
    task_id: str
    success: bool
    result: Optional[Any] = None
    error_message: Optional[str] = None
    execution_time_ms: float = 0.0
    
    def to_message(
        self,
        sender_id: str,
        receiver_id: str,
        correlation_id: str
    ) -> Message:
        """转换为消息"""
        return Message(
            message_id=f"msg_{uuid.uuid4().hex[:16]}",
            message_type=MessageType.TASK_RESPONSE,
            priority=MessagePriority.NORMAL,
            sender_id=sender_id,
            receiver_id=receiver_id,
            payload={
                'task_id': self.task_id,
                'success': self.success,
                'result': self.result,
                'error_message': self.error_message,
                'execution_time_ms': self.execution_time_ms,
            },
            correlation_id=correlation_id,
        )


@dataclass
class AgentInfo:
    """Agent 信息"""
    agent_id: str
    agent_type: str
    status: AgentStatus
    capabilities: List[str]
    last_heartbeat: datetime = field(default_factory=datetime.now)
    load: float = 0.0  # 0-1, 负载
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'agent_id': self.agent_id,
            'agent_type': self.agent_type,
            'status': self.status.value,
            'capabilities': self.capabilities,
            'last_heartbeat': self.last_heartbeat.isoformat(),
            'load': self.load,
        }
    
    def is_available(self) -> bool:
        """检查是否可用"""
        if self.status != AgentStatus.ONLINE:
            return False
        
        # 检查心跳是否过期 (5 分钟)
        expiry = self.last_heartbeat + timedelta(minutes=5)
        if datetime.now() > expiry:
            return False
        
        # 检查负载
        return self.load < 0.9


# ==================== 消息队列 ====================

class MessageQueue:
    """消息队列
    
    管理消息的存储、检索、过期清理
    """
    
    def __init__(self, max_size: int = 10000):
        """初始化队列
        
        Args:
            max_size: 最大队列大小
        """
        self.max_size = max_size
        self.queues: Dict[str, List[Message]] = defaultdict(list)
        self.message_index: Dict[str, Message] = {}
    
    def enqueue(self, message: Message) -> bool:
        """入队消息
        
        Args:
            message: 消息对象
        
        Returns:
            是否成功
        """
        receiver = message.receiver_id
        queue = self.queues[receiver]
        
        if len(queue) >= self.max_size:
            # 队列已满，移除最早的消息
            old_message = queue.pop(0)
            self.message_index.pop(old_message.message_id, None)
        
        queue.append(message)
        self.message_index[message.message_id] = message
        return True
    
    def dequeue(self, receiver_id: str, max_messages: int = 10) -> List[Message]:
        """出队消息
        
        Args:
            receiver_id: 接收者 ID
            max_messages: 最大消息数
        
        Returns:
            消息列表
        """
        queue = self.queues[receiver_id]
        messages = []
        
        while queue and len(messages) < max_messages:
            message = queue.pop(0)
            
            # 跳过过期消息
            if message.is_expired():
                self.message_index.pop(message.message_id, None)
                continue
            
            messages.append(message)
            self.message_index.pop(message.message_id, None)
        
        return messages
    
    def get_message(self, message_id: str) -> Optional[Message]:
        """获取消息
        
        Args:
            message_id: 消息 ID
        
        Returns:
            消息对象或 None
        """
        return self.message_index.get(message_id)
    
    def remove_message(self, message_id: str) -> bool:
        """移除消息
        
        Args:
            message_id: 消息 ID
        
        Returns:
            是否成功
        """
        message = self.message_index.pop(message_id, None)
        if message:
            queue = self.queues[message.receiver_id]
            try:
                queue.remove(message)
            except ValueError:
                pass
            return True
        return False
    
    def size(self, receiver_id: str) -> int:
        """获取队列大小"""
        return len(self.queues.get(receiver_id, []))
    
    def cleanup_expired(self) -> int:
        """清理过期消息
        
        Returns:
            清理的消息数
        """
        count = 0
        for receiver_id, queue in list(self.queues.items()):
            expired = [m for m in queue if m.is_expired()]
            for message in expired:
                self.message_index.pop(message.message_id, None)
                queue.remove(message)
                count += 1
        return count


# ==================== Agent 注册表 ====================

class AgentRegistry:
    """Agent 注册表
    
    管理 Agent 的注册、发现、状态监控
    """
    
    def __init__(self):
        """初始化注册表"""
        self.agents: Dict[str, AgentInfo] = {}
        self.capability_index: Dict[str, List[str]] = defaultdict(list)
    
    def register(self, agent: AgentInfo) -> bool:
        """注册 Agent
        
        Args:
            agent: Agent 信息
        
        Returns:
            是否成功
        """
        self.agents[agent.agent_id] = agent
        
        # 更新能力索引
        for capability in agent.capabilities:
            if agent.agent_id not in self.capability_index[capability]:
                self.capability_index[capability].append(agent.agent_id)
        
        return True
    
    def unregister(self, agent_id: str) -> bool:
        """注销 Agent
        
        Args:
            agent_id: Agent ID
        
        Returns:
            是否成功
        """
        agent = self.agents.pop(agent_id, None)
        if agent:
            for capability in agent.capabilities:
                if agent_id in self.capability_index[capability]:
                    self.capability_index[capability].remove(agent_id)
            return True
        return False
    
    def get_agent(self, agent_id: str) -> Optional[AgentInfo]:
        """获取 Agent 信息"""
        return self.agents.get(agent_id)
    
    def update_status(self, agent_id: str, status: AgentStatus, load: float = None):
        """更新 Agent 状态
        
        Args:
            agent_id: Agent ID
            status: 状态
            load: 负载
        """
        agent = self.agents.get(agent_id)
        if agent:
            agent.status = status
            agent.last_heartbeat = datetime.now()
            if load is not None:
                agent.load = load
    
    def find_agents_by_capability(self, capability: str) -> List[AgentInfo]:
        """根据能力查找 Agent
        
        Args:
            capability: 能力名称
        
        Returns:
            Agent 列表
        """
        agent_ids = self.capability_index.get(capability, [])
        return [
            self.agents[aid]
            for aid in agent_ids
            if self.agents.get(aid) and self.agents[aid].is_available()
        ]
    
    def get_available_agents(self) -> List[AgentInfo]:
        """获取所有可用 Agent"""
        return [a for a in self.agents.values() if a.is_available()]
    
    def heartbeat(self, agent_id: str, load: float = None):
        """心跳更新
        
        Args:
            agent_id: Agent ID
            load: 负载
        """
        agent = self.agents.get(agent_id)
        if agent:
            agent.last_heartbeat = datetime.now()
            if load is not None:
                agent.load = load


# ==================== 通信总线 ====================

class CommunicationBus:
    """通信总线
    
    提供 Agent 间通信的核心功能
    支持同步和异步通信模式
    """
    
    def __init__(self):
        """初始化通信总线"""
        self.message_queue = MessageQueue()
        self.registry = AgentRegistry()
        self.handlers: Dict[MessageType, Callable] = {}
        self.pending_responses: Dict[str, Message] = {}
    
    def register_handler(
        self,
        message_type: MessageType,
        handler: Callable[[Message], Message]
    ):
        """注册消息处理器
        
        Args:
            message_type: 消息类型
            handler: 处理函数
        """
        self.handlers[message_type] = handler
    
    def send_message(self, message: Message) -> bool:
        """发送消息
        
        Args:
            message: 消息对象
        
        Returns:
            是否成功
        """
        # 检查接收者是否存在
        receiver = self.registry.get_agent(message.receiver_id)
        if not receiver:
            return False
        
        # 入队消息
        return self.message_queue.enqueue(message)
    
    def receive_messages(
        self,
        agent_id: str,
        max_messages: int = 10
    ) -> List[Message]:
        """接收消息
        
        Args:
            agent_id: Agent ID
            max_messages: 最大消息数
        
        Returns:
            消息列表
        """
        return self.message_queue.dequeue(agent_id, max_messages)
    
    def send_request(
        self,
        sender_id: str,
        receiver_id: str,
        task_type: str,
        input_data: Dict[str, Any],
        timeout_seconds: int = 3600
    ) -> str:
        """发送任务请求
        
        Args:
            sender_id: 发送者 ID
            receiver_id: 接收者 ID
            task_type: 任务类型
            input_data: 输入数据
            timeout_seconds: 超时时间
        
        Returns:
            消息 ID
        """
        task_request = TaskRequest(
            task_id=f"task_{uuid.uuid4().hex[:16]}",
            task_type=task_type,
            input_data=input_data,
            timeout_seconds=timeout_seconds,
        )
        
        message = task_request.to_message(sender_id, receiver_id)
        self.send_message(message)
        
        return message.message_id
    
    def send_response(
        self,
        sender_id: str,
        original_message: Message,
        success: bool,
        result: Any = None,
        error_message: str = None,
        execution_time_ms: float = 0.0
    ) -> bool:
        """发送任务响应
        
        Args:
            sender_id: 发送者 ID
            original_message: 原始消息
            success: 是否成功
            result: 结果
            error_message: 错误消息
            execution_time_ms: 执行时间
        
        Returns:
            是否成功
        """
        task_response = TaskResponse(
            task_id=original_message.payload.get('task_id', ''),
            success=success,
            result=result,
            error_message=error_message,
            execution_time_ms=execution_time_ms,
        )
        
        message = task_response.to_message(
            sender_id,
            original_message.sender_id,
            original_message.message_id,
        )
        
        return self.send_message(message)
    
    def process_messages(self, agent_id: str) -> List[Message]:
        """处理消息
        
        Args:
            agent_id: Agent ID
        
        Returns:
            响应消息列表
        """
        messages = self.receive_messages(agent_id)
        responses = []
        
        for message in messages:
            handler = self.handlers.get(message.message_type)
            
            if handler:
                try:
                    response = handler(message)
                    if response:
                        self.send_message(response)
                        responses.append(response)
                except Exception as e:
                    # 发送错误响应
                    error_response = message.create_reply(
                        sender_id=agent_id,
                        message_type=MessageType.ERROR,
                        payload={'error': str(e)},
                    )
                    self.send_message(error_response)
        
        return responses
    
    def register_agent(
        self,
        agent_id: str,
        agent_type: str,
        capabilities: List[str]
    ) -> bool:
        """注册 Agent
        
        Args:
            agent_id: Agent ID
            agent_type: Agent 类型
            capabilities: 能力列表
        
        Returns:
            是否成功
        """
        agent = AgentInfo(
            agent_id=agent_id,
            agent_type=agent_type,
            status=AgentStatus.ONLINE,
            capabilities=capabilities,
        )
        return self.registry.register(agent)
    
    def update_agent_status(
        self,
        agent_id: str,
        status: AgentStatus,
        load: float = None
    ):
        """更新 Agent 状态"""
        self.registry.update_status(agent_id, status, load)
    
    def find_agent_for_task(self, task_type: str) -> Optional[str]:
        """为任务查找合适的 Agent
        
        Args:
            task_type: 任务类型
        
        Returns:
            Agent ID 或 None
        """
        agents = self.registry.find_agents_by_capability(task_type)
        
        if not agents:
            return None
        
        # 选择负载最低的 Agent
        best_agent = min(agents, key=lambda a: a.load)
        return best_agent.agent_id
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息
        
        Returns:
            统计字典
        """
        return {
            'total_agents': len(self.registry.agents),
            'available_agents': len(self.registry.get_available_agents()),
            'pending_messages': sum(
                len(q) for q in self.message_queue.queues.values()
            ),
            'capabilities': len(self.registry.capability_index),
        }


# ==================== 命令行工具 ====================

if __name__ == '__main__':
    import sys
    
    print("=" * 60)
    print("Agent 通信框架")
    print("=" * 60)
    
    # 创建通信总线
    bus = CommunicationBus()
    
    # 注册 Agent
    print("\n📋 注册 Agent...")
    bus.register_agent('master', 'master', ['task_dispatch', 'sla_monitoring'])
    bus.register_agent('assistant', 'assistant', ['customer_service', 'dialogue'])
    bus.register_agent('analysis', 'analysis', ['fault_analysis', 'log_parsing'])
    bus.register_agent('file-processor', 'file_processor', ['file_processing', 'sensitive_detection'])
    bus.register_agent('database', 'database', ['data_query', 'multi_tenant'])
    bus.register_agent('monitoring', 'monitoring', ['quality_monitoring', 'alerting'])
    
    print(f"  ✅ 已注册 {len(bus.registry.agents)} 个 Agent")
    
    # 显示 Agent 状态
    print("\n📊 Agent 状态:")
    for agent in bus.registry.get_available_agents():
        print(f"  - {agent.agent_id}: {agent.status.value} (负载：{agent.load:.1%})")
    
    # 测试任务请求
    print("\n📤 测试任务请求...")
    message_id = bus.send_request(
        sender_id='master',
        receiver_id='analysis',
        task_type='fault_analysis',
        input_data={'server_id': 'SRV001', 'error': 'GPU 过热'},
        timeout_seconds=3600,
    )
    print(f"  ✅ 任务请求发送：{message_id}")
    
    # 查找合适的 Agent
    print("\n🔍 查找合适的 Agent...")
    agent_id = bus.find_agent_for_task('fault_analysis')
    print(f"  ✅ 找到 Agent: {agent_id}")
    
    # 显示统计
    print("\n📈 统计信息:")
    stats = bus.get_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    print("\n" + "=" * 60)
