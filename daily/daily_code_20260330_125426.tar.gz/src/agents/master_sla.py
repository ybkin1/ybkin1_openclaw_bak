"""
Master Agent - SLA 感知调度器

提供任务优先级调度、SLA 监控、违规告警等功能
确保所有任务在 SLA 时限内完成
"""

from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import heapq
import json
import os

# ==================== 枚举类 ====================

class TaskType(Enum):
    """任务类型"""
    FAULT_ANALYSIS = "fault_analysis"       # 故障分析 (1 小时)
    REPORT_GENERATION = "report_generation"  # 报告生成 (1 小时)
    FILE_PROCESSING = "file_processing"      # 文件处理 (12 小时)
    DATA_EXTRACTION = "data_extraction"      # 数据提取 (12 小时)
    SYSTEM_TASK = "system_task"              # 系统任务 (1 小时)
    CUSTOMER_REQUEST = "customer_request"    # 客户请求 (0.5 天)


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(Enum):
    """任务优先级"""
    CRITICAL = 100  # 紧急故障
    HIGH = 75       # 高优先级
    MEDIUM = 50     # 普通任务
    LOW = 25        # 低优先级


# ==================== 数据类 ====================

@dataclass(order=True)
class Task:
    """任务数据类
    
    Attributes:
        priority: 优先级 (数字越大优先级越高)
        task_id: 任务 ID
        task_type: 任务类型
        payload: 任务数据
        created_at: 创建时间
        sla_timeout: SLA 时限 (秒)
        assigned_agent: 分配的 Agent
        status: 任务状态
        tenant_id: 租户 ID
        created_by: 创建人 ID
    """
    priority: int
    task_id: str = field(compare=False, default="")
    task_type: TaskType = field(compare=False, default=TaskType.SYSTEM_TASK)
    payload: Dict[str, Any] = field(compare=False, default_factory=dict)
    created_at: datetime = field(compare=False, default_factory=datetime.now)
    sla_timeout: int = field(compare=False, default=3600)  # 秒
    assigned_agent: str = field(compare=False, default="")
    status: TaskStatus = field(compare=False, default=TaskStatus.PENDING)
    tenant_id: str = field(compare=False, default="")
    created_by: str = field(compare=False, default="")
    started_at: Optional[datetime] = field(compare=False, default=None)
    completed_at: Optional[datetime] = field(compare=False, default=None)
    
    def is_sla_violated(self) -> bool:
        """检查是否 SLA 违规"""
        elapsed = self.get_elapsed_time()
        return elapsed > self.sla_timeout
    
    def get_elapsed_time(self) -> float:
        """获取已用时间 (秒)"""
        if not self.created_at:
            return 0
        return (datetime.now() - self.created_at).total_seconds()
    
    def get_remaining_time(self) -> float:
        """获取剩余时间 (秒)"""
        elapsed = self.get_elapsed_time()
        return max(0, self.sla_timeout - elapsed)
    
    def get_progress_percent(self) -> float:
        """获取进度百分比"""
        elapsed = self.get_elapsed_time()
        if elapsed <= 0:
            return 0
        return min(100, (elapsed / self.sla_timeout) * 100)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'task_id': self.task_id,
            'task_type': self.task_type.value,
            'priority': self.priority,
            'status': self.status.value,
            'tenant_id': self.tenant_id,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'sla_timeout': self.sla_timeout,
            'elapsed_time': self.get_elapsed_time(),
            'remaining_time': self.get_remaining_time(),
            'progress_percent': self.get_progress_percent(),
            'assigned_agent': self.assigned_agent,
            'payload': self.payload,
        }


@dataclass
class SLAConfig:
    """SLA 配置"""
    task_type: TaskType
    timeout_seconds: int
    warning_threshold: float = 0.8  # 80% 时告警
    critical_threshold: float = 0.9  # 90% 时紧急告警


# ==================== 优先级队列 ====================

class PriorityTaskQueue:
    """优先级任务队列
    
    使用最大堆实现，优先级高的任务先出队
    
    Example:
        >>> queue = PriorityTaskQueue()
        >>> queue.push(task1)
        >>> queue.push(task2)
        >>> task = queue.pop()
    """
    
    def __init__(self):
        """初始化队列"""
        self._queue = []
        self._counter = 0
        self._task_ids = set()
    
    def push(self, task: Task):
        """添加任务到队列
        
        Args:
            task: 任务对象
        """
        if task.task_id in self._task_ids:
            return  # 避免重复
        
        # 使用负优先级实现最大堆
        heapq.heappush(self._queue, (-task.priority, self._counter, task))
        self._counter += 1
        self._task_ids.add(task.task_id)
    
    def pop(self) -> Optional[Task]:
        """弹出最高优先级任务
        
        Returns:
            任务对象或 None
        """
        while self._queue:
            _, _, task = heapq.heappop(self._queue)
            if task.task_id in self._task_ids:
                self._task_ids.discard(task.task_id)
                return task
        return None
    
    def peek(self) -> Optional[Task]:
        """查看最高优先级任务 (不弹出)
        
        Returns:
            任务对象或 None
        """
        while self._queue:
            _, _, task = self._queue[0]
            if task.task_id in self._task_ids:
                return task
            heapq.heappop(self._queue)
        return None
    
    def remove(self, task_id: str) -> bool:
        """移除任务 (懒删除)
        
        Args:
            task_id: 任务 ID
        
        Returns:
            是否成功移除
        """
        if task_id in self._task_ids:
            self._task_ids.discard(task_id)
            return True
        return False
    
    def size(self) -> int:
        """队列大小"""
        return len(self._task_ids)
    
    def is_empty(self) -> bool:
        """是否为空"""
        return self.size() == 0
    
    def get_all_tasks(self) -> List[Task]:
        """获取所有任务 (用于监控)
        
        Returns:
            任务列表
        """
        return [task for _, _, task in self._queue if task.task_id in self._task_ids]


# ==================== SLA 监控器 ====================

class SLAMonitor:
    """SLA 监控器
    
    监控所有任务的 SLA 状态，及时发送告警
    
    Example:
        >>> monitor = SLAMonitor()
        >>> monitor.add_task(task)
        >>> violations = monitor.check_violations()
    """
    
    def __init__(self):
        """初始化监控器"""
        self.tasks: Dict[str, Task] = {}
        self.violations: List[Dict[str, Any]] = []
        self.warnings: List[Dict[str, Any]] = []
        
        # SLA 配置
        self.sla_configs = {
            TaskType.FAULT_ANALYSIS: SLAConfig(TaskType.FAULT_ANALYSIS, 3600),
            TaskType.REPORT_GENERATION: SLAConfig(TaskType.REPORT_GENERATION, 3600),
            TaskType.FILE_PROCESSING: SLAConfig(TaskType.FILE_PROCESSING, 43200),  # 12 小时
            TaskType.DATA_EXTRACTION: SLAConfig(TaskType.DATA_EXTRACTION, 43200),
            TaskType.SYSTEM_TASK: SLAConfig(TaskType.SYSTEM_TASK, 3600),
            TaskType.CUSTOMER_REQUEST: SLAConfig(TaskType.CUSTOMER_REQUEST, 43200),
        }
    
    def add_task(self, task: Task):
        """添加任务到监控
        
        Args:
            task: 任务对象
        """
        self.tasks[task.task_id] = task
    
    def remove_task(self, task_id: str):
        """移除任务
        
        Args:
            task_id: 任务 ID
        """
        if task_id in self.tasks:
            del self.tasks[task_id]
    
    def check_violations(self) -> List[Task]:
        """检查 SLA 违规任务
        
        Returns:
            违规任务列表
        """
        violations = []
        for task in self.tasks.values():
            if task.status in [TaskStatus.COMPLETED, TaskStatus.CANCELLED]:
                continue
            
            if task.is_sla_violated():
                violations.append(task)
                self._record_violation(task)
        
        return violations
    
    def check_warnings(self) -> List[Task]:
        """检查 SLA 警告任务 (接近违规)
        
        Returns:
            警告任务列表
        """
        warnings = []
        for task in self.tasks.values():
            if task.status in [TaskStatus.COMPLETED, TaskStatus.CANCELLED]:
                continue
            
            config = self.sla_configs.get(task.task_type)
            if not config:
                continue
            
            elapsed_percent = task.get_progress_percent()
            if elapsed_percent >= config.critical_threshold * 100:
                warnings.append(task)
                self._record_warning(task, 'critical')
            elif elapsed_percent >= config.warning_threshold * 100:
                warnings.append(task)
                self._record_warning(task, 'warning')
        
        return warnings
    
    def _record_violation(self, task: Task):
        """记录违规"""
        self.violations.append({
            'task_id': task.task_id,
            'task_type': task.task_type.value,
            'tenant_id': task.tenant_id,
            'violated_at': datetime.now().isoformat(),
            'elapsed_time': task.get_elapsed_time(),
            'sla_timeout': task.sla_timeout,
        })
    
    def _record_warning(self, task: Task, level: str):
        """记录警告"""
        self.warnings.append({
            'task_id': task.task_id,
            'task_type': task.task_type.value,
            'tenant_id': task.tenant_id,
            'level': level,
            'remaining_time': task.get_remaining_time(),
            'checked_at': datetime.now().isoformat(),
        })
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息
        
        Returns:
            统计字典
        """
        active_tasks = [t for t in self.tasks.values() 
                       if t.status not in [TaskStatus.COMPLETED, TaskStatus.CANCELLED]]
        
        return {
            'total_tasks': len(self.tasks),
            'active_tasks': len(active_tasks),
            'violations': len(self.violations),
            'warnings': len(self.warnings),
            'by_type': self._count_by_type(active_tasks),
            'by_status': self._count_by_status(active_tasks),
        }
    
    def _count_by_type(self, tasks: List[Task]) -> Dict[str, int]:
        """按类型统计"""
        counts = {}
        for task in tasks:
            type_name = task.task_type.value
            counts[type_name] = counts.get(type_name, 0) + 1
        return counts
    
    def _count_by_status(self, tasks: List[Task]) -> Dict[str, int]:
        """按状态统计"""
        counts = {}
        for task in tasks:
            status = task.status.value
            counts[status] = counts.get(status, 0) + 1
        return counts


# ==================== Master Agent ====================

class MasterAgent:
    """主控 Agent (SLA 感知调度)
    
    负责任务接收、优先级调度、Agent 分配、SLA 监控
    
    Example:
        >>> master = MasterAgent(db_pool, agent_registry)
        >>> task_id = master.receive_task(task_data, user)
        >>> master.schedule_tasks()
    """
    
    def __init__(self, db_pool=None, agent_registry=None):
        """初始化 Master Agent
        
        Args:
            db_pool: 数据库连接池
            agent_registry: Agent 注册表
        """
        self.db_pool = db_pool
        self.agent_registry = agent_registry
        self.task_queue = PriorityTaskQueue()
        self.sla_monitor = SLAMonitor()
        
        # SLA 配置
        self.sla_configs = {
            TaskType.FAULT_ANALYSIS: 3600,
            TaskType.REPORT_GENERATION: 3600,
            TaskType.FILE_PROCESSING: 43200,
            TaskType.DATA_EXTRACTION: 43200,
            TaskType.SYSTEM_TASK: 3600,
            TaskType.CUSTOMER_REQUEST: 43200,
        }
        
        # Agent 映射
        self.agent_mapping = {
            TaskType.FAULT_ANALYSIS: 'analysis',
            TaskType.REPORT_GENERATION: 'file-processor',
            TaskType.FILE_PROCESSING: 'file-processor',
            TaskType.DATA_EXTRACTION: 'database-manager',
            TaskType.SYSTEM_TASK: 'assistant',
            TaskType.CUSTOMER_REQUEST: 'customer-service',
        }
    
    def receive_task(self, task_data: Dict[str, Any], user: Dict[str, Any]) -> str:
        """接收任务
        
        Args:
            task_data: 任务数据
            user: 用户信息
        
        Returns:
            任务 ID
        """
        # 1. 识别任务类型
        task_type = self.classify_task(task_data)
        
        # 2. 计算优先级
        priority = self.calculate_priority(task_type, user)
        
        # 3. 创建任务对象
        task = Task(
            priority=priority,
            task_id=self.generate_task_id(),
            task_type=task_type,
            payload=task_data,
            created_at=datetime.now(),
            sla_timeout=self.sla_configs.get(task_type, 3600),
            tenant_id=user.get('tenant_id', ''),
            created_by=user.get('id', ''),
        )
        
        # 4. 加入调度队列
        self.task_queue.push(task)
        
        # 5. 加入 SLA 监控
        self.sla_monitor.add_task(task)
        
        # 6. 记录到数据库
        if self.db_pool:
            self._save_task_to_db(task)
        
        # 7. 触发调度
        self.schedule_tasks()
        
        return task.task_id
    
    def classify_task(self, task_data: Dict[str, Any]) -> TaskType:
        """识别任务类型
        
        Args:
            task_data: 任务数据
        
        Returns:
            任务类型
        """
        task_title = task_data.get('title', '').lower()
        task_description = task_data.get('description', '').lower()
        
        # 故障分析
        if any(kw in task_title or kw in task_description 
               for kw in ['故障', '分析', '诊断', '报错', 'error', 'fault']):
            return TaskType.FAULT_ANALYSIS
        
        # 报告生成
        if any(kw in task_title or kw in task_description 
               for kw in ['报告', 'report', '生成', 'generate']):
            return TaskType.REPORT_GENERATION
        
        # 文件处理
        if any(kw in task_title or kw in task_description 
               for kw in ['文件', 'file', '文档', 'document']):
            return TaskType.FILE_PROCESSING
        
        # 数据提取
        if any(kw in task_title or kw in task_description 
               for kw in ['数据', 'data', '提取', 'extract', '查询']):
            return TaskType.DATA_EXTRACTION
        
        # 客户请求
        if any(kw in task_title or kw in task_description 
               for kw in ['客户', 'customer', '请求', 'request']):
            return TaskType.CUSTOMER_REQUEST
        
        # 默认系统任务
        return TaskType.SYSTEM_TASK
    
    def calculate_priority(self, task_type: TaskType, user: Dict[str, Any]) -> int:
        """计算任务优先级
        
        优先级 = SLA 紧急度 (40%) + 用户角色 (30%) + 任务类型 (30%)
        
        Args:
            task_type: 任务类型
            user: 用户信息
        
        Returns:
            优先级分数
        """
        priority = 0
        
        # SLA 紧急度 (40%)
        sla_timeout = self.sla_configs.get(task_type, 3600)
        if sla_timeout <= 3600:
            priority += 40
        elif sla_timeout <= 43200:
            priority += 20
        else:
            priority += 10
        
        # 用户角色 (30%)
        role_priority = {
            'management': 30,
            'security': 25,
            'operations': 20,
            'technical': 20,
            'customer_service': 15,
            'marketing': 10,
            'admin': 25,
        }
        user_role = user.get('role', '')
        priority += role_priority.get(user_role, 0)
        
        # 任务类型 (30%)
        type_priority = {
            TaskType.FAULT_ANALYSIS: 30,
            TaskType.REPORT_GENERATION: 25,
            TaskType.FILE_PROCESSING: 15,
            TaskType.DATA_EXTRACTION: 15,
            TaskType.CUSTOMER_REQUEST: 20,
            TaskType.SYSTEM_TASK: 10,
        }
        priority += type_priority.get(task_type, 0)
        
        return priority
    
    def schedule_tasks(self):
        """调度任务"""
        scheduled_count = 0
        
        while not self.task_queue.is_empty():
            task = self.task_queue.peek()
            
            if not task:
                break
            
            # 检查 SLA
            if task.is_sla_violated():
                # SLA 违规，升级处理
                self.task_queue.pop()
                self.escalate_task(task)
                continue
            
            # 选择合适的 Agent
            agent = self.select_agent(task)
            if not agent:
                break
            
            # 分配任务
            self.task_queue.pop()
            task.assigned_agent = agent
            task.status = TaskStatus.ASSIGNED
            
            # 发送任务
            self.send_to_agent(task, agent)
            scheduled_count += 1
        
        return scheduled_count
    
    def select_agent(self, task: Task) -> Optional[str]:
        """选择合适的 Agent
        
        Args:
            task: 任务对象
        
        Returns:
            Agent ID 或 None
        """
        agent_id = self.agent_mapping.get(task.task_type)
        if not agent_id:
            return None
        
        # TODO: 检查 Agent 可用性
        # if self.agent_registry:
        #     agent = self.agent_registry.get_agent(agent_id)
        #     if not agent or not agent.is_available():
        #         return None
        
        return agent_id
    
    def send_to_agent(self, task: Task, agent_id: str):
        """发送任务到 Agent
        
        Args:
            task: 任务对象
            agent_id: Agent ID
        """
        # TODO: 实现 Agent 通信
        print(f"📤 发送任务 {task.task_id} 到 Agent: {agent_id}")
        
        # 更新任务状态
        task.started_at = datetime.now()
        task.status = TaskStatus.IN_PROGRESS
    
    def escalate_task(self, task: Task):
        """升级 SLA 违规任务
        
        Args:
            task: 任务对象
        """
        print(f"🚨 SLA 违规：任务 {task.task_id} 超时")
        
        # 1. 记录违规
        if self.db_pool:
            self._save_violation_to_db(task)
        
        # 2. 发送告警
        self.send_alert(f"SLA 违规：任务 {task.task_id} 超时")
        
        # 3. 通知管理员
        self.notify_admins(task)
    
    def send_alert(self, message: str):
        """发送告警
        
        Args:
            message: 告警消息
        """
        print(f"⚠️  告警：{message}")
        # TODO: 实现飞书/邮件告警
    
    def notify_admins(self, task: Task):
        """通知管理员
        
        Args:
            task: 违规任务
        """
        print(f"📧 通知管理员：任务 {task.task_id} SLA 违规")
        # TODO: 实现管理员通知
    
    def generate_task_id(self) -> str:
        """生成任务 ID
        
        Returns:
            任务 ID
        """
        return f"TASK-{datetime.now().strftime('%Y%m%d%H%M%S')}-{os.getpid()}"
    
    def _save_task_to_db(self, task: Task):
        """保存任务到数据库"""
        # TODO: 实现数据库保存
        pass
    
    def _save_violation_to_db(self, task: Task):
        """保存违规记录到数据库"""
        # TODO: 实现数据库保存
        pass
    
    def get_queue_stats(self) -> Dict[str, Any]:
        """获取队列统计
        
        Returns:
            统计字典
        """
        return {
            'queue_size': self.task_queue.size(),
            'sla_stats': self.sla_monitor.get_stats(),
        }


# ==================== 命令行工具 ====================

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python master_agent.py <command> [args]")
        print("命令:")
        print("  create-task <type> <user_id> <tenant_id>  创建测试任务")
        print("  schedule                                  执行调度")
        print("  check-sla                               检查 SLA")
        print("  stats                                     显示统计")
        sys.exit(1)
    
    master = MasterAgent()
    command = sys.argv[1]
    
    if command == 'create-task':
        if len(sys.argv) < 5:
            print("错误：请提供 type, user_id, tenant_id")
            sys.exit(1)
        
        task_type = TaskType(sys.argv[2])
        user = {
            'id': sys.argv[3],
            'tenant_id': sys.argv[4],
            'role': 'operations',
        }
        
        task_data = {
            'title': f'测试任务 - {task_type.value}',
            'description': '这是一个测试任务',
        }
        
        task_id = master.receive_task(task_data, user)
        print(f"✅ 任务创建成功：{task_id}")
    
    elif command == 'schedule':
        count = master.schedule_tasks()
        print(f"📅 调度完成：{count} 个任务已分配")
    
    elif command == 'check-sla':
        violations = master.sla_monitor.check_violations()
        warnings = master.sla_monitor.check_warnings()
        
        if violations:
            print(f"🚨 SLA 违规：{len(violations)} 个任务")
            for task in violations:
                print(f"  - {task.task_id}: {task.get_elapsed_time():.0f}s / {task.sla_timeout}s")
        else:
            print("✅ 无 SLA 违规")
        
        if warnings:
            print(f"⚠️  SLA 警告：{len(warnings)} 个任务")
            for task in warnings:
                print(f"  - {task.task_id}: 剩余 {task.get_remaining_time():.0f}s")
    
    elif command == 'stats':
        stats = master.get_queue_stats()
        print(json.dumps(stats, indent=2, default=str))
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
