"""
Assistant Agent - 智能客服

提供多轮对话管理、工单处理、需求理解等功能
作为用户与系统的交互接口
"""

from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import json
import re


# ==================== 枚举类 ====================

class IntentType(Enum):
    """意图类型"""
    FAULT_REPORT = "fault_report"           # 故障报告
    PROGRESS_QUERY = "progress_query"       # 进度查询
    REPORT_REQUEST = "report_request"       # 报告请求
    DATA_QUERY = "data_query"               # 数据查询
    DOCUMENT_REQUEST = "document_request"   # 文档请求
    GENERAL_INQUIRY = "general_inquiry"     # 一般咨询
    COMPLAINT = "complaint"                 # 投诉
    FEEDBACK = "feedback"                   # 反馈
    UNKNOWN = "unknown"                     # 未知


class ConversationState(Enum):
    """对话状态"""
    GREETING = "greeting"               # 问候
    COLLECTING_INFO = "collecting_info" # 收集信息
    CLARIFYING = "clarifying"           # 澄清确认
    PROCESSING = "processing"           # 处理中
    PROVIDING_RESULT = "providing_result"  # 提供结果
    CLOSING = "closing"                 # 结束对话


class TicketStatus(Enum):
    """工单状态"""
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    PENDING_CUSTOMER = "pending_customer"
    RESOLVED = "resolved"
    CLOSED = "closed"


# ==================== 数据类 ====================

@dataclass
class Message:
    """消息数据类"""
    content: str
    sender: str  # user/assistant
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'content': self.content,
            'sender': self.sender,
            'timestamp': self.timestamp.isoformat(),
            'metadata': self.metadata,
        }


@dataclass
class Conversation:
    """对话数据类"""
    conversation_id: str
    user_id: str
    tenant_id: str
    messages: List[Message] = field(default_factory=list)
    state: ConversationState = ConversationState.GREETING
    intent: Optional[IntentType] = None
    slot_values: Dict[str, Any] = field(default_factory=dict)
    ticket_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def add_message(self, content: str, sender: str, metadata: Dict[str, Any] = None):
        """添加消息"""
        message = Message(
            content=content,
            sender=sender,
            metadata=metadata or {}
        )
        self.messages.append(message)
        self.updated_at = datetime.now()
    
    def get_last_message(self) -> Optional[Message]:
        """获取最后一条消息"""
        return self.messages[-1] if self.messages else None
    
    def get_context(self, max_messages: int = 5) -> str:
        """获取对话上下文"""
        recent = self.messages[-max_messages:] if self.messages else []
        context_lines = []
        for msg in recent:
            prefix = "用户" if msg.sender == "user" else "助手"
            context_lines.append(f"{prefix}: {msg.content}")
        return "\n".join(context_lines)


@dataclass
class Intent:
    """意图数据类"""
    type: IntentType
    confidence: float
    slots: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Intent':
        """从字典创建"""
        return cls(
            type=IntentType(data['type']),
            confidence=data.get('confidence', 1.0),
            slots=data.get('slots', {})
        )


# ==================== 意图识别器 ====================

class IntentRecognizer:
    """意图识别器
    
    基于规则和关键词识别用户意图
    
    Example:
        >>> recognizer = IntentRecognizer()
        >>> intent = recognizer.recognize("我的服务器报错了")
        >>> print(intent.type)
        IntentType.FAULT_REPORT
    """
    
    def __init__(self):
        """初始化识别器"""
        # 关键词映射
        self.keyword_mapping = {
            IntentType.FAULT_REPORT: [
                '故障', '报错', '错误', '异常', '问题', '坏了', '不能用',
                'error', 'fault', 'issue', 'problem', 'broken'
            ],
            IntentType.PROGRESS_QUERY: [
                '进度', '状态', '完成', '做好', '什么时候', '多久',
                'progress', 'status', 'complete', 'finish'
            ],
            IntentType.REPORT_REQUEST: [
                '报告', '报表', '分析', '总结',
                'report', 'analysis', 'summary'
            ],
            IntentType.DATA_QUERY: [
                '查询', '数据', '信息', '查看', '统计',
                'query', 'data', 'info', 'check', 'statistics'
            ],
            IntentType.DOCUMENT_REQUEST: [
                '文档', '文件', '下载', '获取',
                'document', 'file', 'download', 'get'
            ],
            IntentType.COMPLAINT: [
                '投诉', '不满', '太差', '慢', '不满意',
                'complaint', 'unhappy', 'slow', 'dissatisfied'
            ],
            IntentType.FEEDBACK: [
                '建议', '反馈', '希望', '改进',
                'feedback', 'suggestion', 'improve'
            ],
        }
    
    def recognize(self, text: str) -> Intent:
        """识别用户意图
        
        Args:
            text: 用户输入文本
        
        Returns:
            识别的意图
        """
        text_lower = text.lower()
        
        # 计算每个意图的匹配分数
        scores = {}
        for intent_type, keywords in self.keyword_mapping.items():
            score = sum(1 for kw in keywords if kw in text_lower)
            scores[intent_type] = score
        
        # 找出最高分
        max_score = max(scores.values()) if scores else 0
        
        if max_score == 0:
            return Intent(type=IntentType.UNKNOWN, confidence=0.0)
        
        # 计算置信度
        total_keywords = sum(len(kws) for kws in self.keyword_mapping.values())
        confidence = min(1.0, max_score / 5.0)  # 最多 5 个关键词匹配
        
        # 提取槽位
        slots = self._extract_slots(text)
        
        # 返回最高分的意图
        best_intent = max(scores, key=scores.get)
        return Intent(type=best_intent, confidence=confidence, slots=slots)
    
    def _extract_slots(self, text: str) -> Dict[str, Any]:
        """提取槽位信息
        
        Args:
            text: 用户输入文本
        
        Returns:
            槽位字典
        """
        slots = {}
        
        # 提取服务器 ID
        server_id_match = re.search(r'服务器\s*(\S+)', text)
        if server_id_match:
            slots['server_id'] = server_id_match.group(1)
        
        # 提取时间
        time_patterns = [
            r'今天', r'昨天', r'明天',
            r'\d{4}-\d{2}-\d{2}',
            r'\d{2}:\d{2}'
        ]
        for pattern in time_patterns:
            if re.search(pattern, text):
                slots['time'] = True
                break
        
        # 提取紧急程度
        if any(kw in text for kw in ['紧急', '急', 'critical', 'urgent']):
            slots['urgency'] = 'high'
        elif any(kw in text for kw in ['普通', '一般', 'normal']):
            slots['urgency'] = 'normal'
        
        return slots


# ==================== 对话管理器 ====================

class DialogueManager:
    """对话管理器
    
    管理多轮对话状态，决定下一步行动
    
    Example:
        >>> dm = DialogueManager()
        >>> response = dm.process(conversation, user_input)
    """
    
    def __init__(self):
        """初始化对话管理器"""
        self.intent_recognizer = IntentRecognizer()
        
        # 问候语
        self.greetings = [
            "您好！我是智能运维助手，请问有什么可以帮您？",
            "您好！很高兴为您服务，请问您需要什么帮助？",
            "欢迎！我是您的智能运维助手，请问有什么可以帮您？",
        ]
        
        # 澄清话术
        self.clarification_templates = {
            IntentType.FAULT_REPORT: [
                "请问是哪台服务器出现了故障？请提供服务器 ID 或名称。",
                "能详细描述一下故障现象吗？比如错误提示、影响范围等。",
                "故障是什么时候开始的？是否影响了业务？",
            ],
            IntentType.PROGRESS_QUERY: [
                "请问您想查询哪个任务的进度？请提供任务 ID 或关键词。",
                "能告诉我任务的类型吗？比如故障分析、报告生成等。",
            ],
            IntentType.REPORT_REQUEST: [
                "请问您需要什么类型的报告？比如故障分析报告、统计报告等。",
                "报告需要包含哪些内容？有时间范围要求吗？",
            ],
        }
    
    def process(self, conversation: Conversation, user_input: str) -> str:
        """处理用户输入
        
        Args:
            conversation: 对话对象
            user_input: 用户输入
        
        Returns:
            助手回复
        """
        # 添加用户消息
        conversation.add_message(user_input, "user")
        
        # 识别意图
        intent = self.intent_recognizer.recognize(user_input)
        
        # 更新对话状态
        if conversation.state == ConversationState.GREETING:
            conversation.intent = intent
            conversation.state = ConversationState.COLLECTING_INFO
        
        # 根据状态和意图生成回复
        response = self._generate_response(conversation, intent, user_input)
        
        # 添加助手回复
        conversation.add_message(response, "assistant")
        
        return response
    
    def _generate_response(
        self,
        conversation: Conversation,
        intent: Intent,
        user_input: str
    ) -> str:
        """生成回复
        
        Args:
            conversation: 对话对象
            intent: 识别的意图
            user_input: 用户输入
        
        Returns:
            助手回复
        """
        # 根据对话状态处理
        if conversation.state == ConversationState.GREETING:
            import random
            return random.choice(self.greetings)
        
        elif conversation.state == ConversationState.COLLECTING_INFO:
            return self._handle_collecting_info(conversation, intent)
        
        elif conversation.state == ConversationState.CLARIFYING:
            return self._handle_clarifying(conversation, intent)
        
        elif conversation.state == ConversationState.PROCESSING:
            return "正在为您处理，请稍候..."
        
        elif conversation.state == ConversationState.PROVIDING_RESULT:
            return self._handle_providing_result(conversation)
        
        elif conversation.state == ConversationState.CLOSING:
            return "感谢您的咨询，如有其他问题请随时联系我。祝您工作顺利！"
        
        return "抱歉，我没有理解您的意思。能再详细说明一下吗？"
    
    def _handle_collecting_info(
        self,
        conversation: Conversation,
        intent: Intent
    ) -> str:
        """处理信息收集阶段"""
        import random
        
        # 根据意图类型回复
        if intent.type == IntentType.FAULT_REPORT:
            templates = self.clarification_templates.get(IntentType.FAULT_REPORT, [])
            return random.choice(templates) if templates else "请提供更多信息。"
        
        elif intent.type == IntentType.PROGRESS_QUERY:
            templates = self.clarification_templates.get(IntentType.PROGRESS_QUERY, [])
            return random.choice(templates) if templates else "请提供任务信息。"
        
        elif intent.type == IntentType.REPORT_REQUEST:
            templates = self.clarification_templates.get(IntentType.REPORT_REQUEST, [])
            return random.choice(templates) if templates else "请说明报告需求。"
        
        elif intent.type == IntentType.UNKNOWN:
            return "抱歉，我没有理解您的意思。请问您是想报告故障、查询进度，还是其他需求？"
        
        return "收到，正在为您处理..."
    
    def _handle_clarifying(
        self,
        conversation: Conversation,
        intent: Intent
    ) -> str:
        """处理澄清确认阶段"""
        # TODO: 实现澄清逻辑
        return "好的，明白了。正在为您处理..."
    
    def _handle_providing_result(
        self,
        conversation: Conversation
    ) -> str:
        """处理结果提供阶段"""
        # TODO: 实现结果提供逻辑
        return "处理完成，请问还有什么可以帮您？"


# ==================== Assistant Agent ====================

class AssistantAgent:
    """智能客服 Agent
    
    整合意图识别、对话管理、工单处理等功能
    
    Example:
        >>> assistant = AssistantAgent(db_pool)
        >>> response = assistant.chat(user_id, tenant_id, "我的服务器报错了")
    """
    
    def __init__(self, db_pool=None):
        """初始化 Assistant Agent
        
        Args:
            db_pool: 数据库连接池
        """
        self.db_pool = db_pool
        self.dialogue_manager = DialogueManager()
        self.conversations: Dict[str, Conversation] = {}
    
    def chat(
        self,
        user_id: str,
        tenant_id: str,
        message: str
    ) -> str:
        """聊天接口
        
        Args:
            user_id: 用户 ID
            tenant_id: 租户 ID
            message: 用户消息
        
        Returns:
            助手回复
        """
        # 获取或创建对话
        conversation_key = f"{user_id}:{tenant_id}"
        if conversation_key not in self.conversations:
            self.conversations[conversation_key] = Conversation(
                conversation_id=f"conv_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                user_id=user_id,
                tenant_id=tenant_id,
            )
        
        conversation = self.conversations[conversation_key]
        
        # 处理对话
        response = self.dialogue_manager.process(conversation, message)
        
        # 检查是否需要创建工单
        if conversation.intent and conversation.intent.type == IntentType.FAULT_REPORT:
            if len(conversation.messages) >= 4:  # 收集足够信息后
                self._create_ticket(conversation)
        
        return response
    
    def _create_ticket(self, conversation: Conversation):
        """创建工单
        
        Args:
            conversation: 对话对象
        """
        # TODO: 实现工单创建逻辑
        print(f"📝 创建工单：{conversation.conversation_id}")
        
        # 更新对话状态
        conversation.state = ConversationState.PROCESSING
    
    def get_conversation_history(
        self,
        user_id: str,
        tenant_id: str,
        max_messages: int = 10
    ) -> List[Dict[str, Any]]:
        """获取对话历史
        
        Args:
            user_id: 用户 ID
            tenant_id: 租户 ID
            max_messages: 最大消息数
        
        Returns:
            消息列表
        """
        conversation_key = f"{user_id}:{tenant_id}"
        conversation = self.conversations.get(conversation_key)
        
        if not conversation:
            return []
        
        recent = conversation.messages[-max_messages:]
        return [msg.to_dict() for msg in recent]
    
    def close_conversation(self, user_id: str, tenant_id: str):
        """关闭对话
        
        Args:
            user_id: 用户 ID
            tenant_id: 租户 ID
        """
        conversation_key = f"{user_id}:{tenant_id}"
        conversation = self.conversations.get(conversation_key)
        
        if conversation:
            conversation.state = ConversationState.CLOSING


# ==================== 命令行工具 ====================

if __name__ == '__main__':
    import sys
    
    assistant = AssistantAgent()
    
    print("=" * 60)
    print("智能客服 Assistant Agent")
    print("=" * 60)
    print("输入 'quit' 或 'exit' 退出")
    print("输入 'clear' 清空对话历史")
    print("输入 'history' 查看对话历史")
    print("=" * 60)
    
    user_id = "test_user"
    tenant_id = "test_tenant"
    
    while True:
        try:
            user_input = input("\n👤 您：").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() in ['quit', 'exit']:
                print("🤖 助手：感谢您的咨询，再见！")
                break
            
            if user_input.lower() == 'clear':
                assistant.conversations.clear()
                print("🤖 助手：对话历史已清空")
                continue
            
            if user_input.lower() == 'history':
                history = assistant.get_conversation_history(user_id, tenant_id)
                print(f"🤖 助手：共 {len(history)} 条消息")
                for msg in history:
                    prefix = "👤" if msg['sender'] == 'user' else "🤖"
                    print(f"  {prefix} {msg['content'][:50]}...")
                continue
            
            response = assistant.chat(user_id, tenant_id, user_input)
            print(f"🤖 助手：{response}")
            
        except KeyboardInterrupt:
            print("\n🤖 助手：再见！")
            break
        except Exception as e:
            print(f"🤖 助手：抱歉，出现错误：{e}")
