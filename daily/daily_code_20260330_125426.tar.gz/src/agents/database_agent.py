"""
Database Agent - 多租户数据库管理

提供多租户数据库连接、查询、数据加密、权限验证等功能
"""

from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
import json
import os
import hashlib


# ==================== 枚举类 ====================

class DatabaseOperation(Enum):
    """数据库操作类型"""
    SELECT = "select"
    INSERT = "insert"
    UPDATE = "update"
    DELETE = "delete"
    EXECUTE = "execute"


class DataAccessLevel(Enum):
    """数据访问级别"""
    PUBLIC = "public"             # 公开数据
    TENANT = "tenant"             # 租户内数据
    RESTRICTED = "restricted"     # 受限数据 (需要特殊权限)
    ENCRYPTED = "encrypted"       # 加密数据


# ==================== 数据类 ====================

@dataclass
class QueryResult:
    """查询结果"""
    success: bool
    data: Optional[List[Dict[str, Any]]]
    row_count: int
    error_message: Optional[str] = None
    execution_time_ms: float = 0.0
    warnings: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'success': self.success,
            'data': self.data,
            'row_count': self.row_count,
            'error_message': self.error_message,
            'execution_time_ms': self.execution_time_ms,
            'warnings': self.warnings,
        }


@dataclass
class DatabaseConnection:
    """数据库连接信息"""
    host: str
    port: int
    database: str
    username: str
    password: str  # 应加密存储
    ssl_mode: str = "prefer"
    pool_size: int = 10
    max_overflow: int = 20
    
    def to_connection_string(self) -> str:
        """生成连接字符串"""
        return f"postgresql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"


@dataclass
class AuditLog:
    """审计日志"""
    log_id: str
    tenant_id: str
    user_id: str
    operation: DatabaseOperation
    table_name: str
    query: str
    result: str  # success/failure
    row_count: int
    ip_address: str
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'log_id': self.log_id,
            'tenant_id': self.tenant_id,
            'user_id': self.user_id,
            'operation': self.operation.value,
            'table_name': self.table_name,
            'query': self.query[:500],  # 限制长度
            'result': self.result,
            'row_count': self.row_count,
            'ip_address': self.ip_address,
            'timestamp': self.timestamp.isoformat(),
        }


# ==================== 数据库连接池 ====================

class DatabasePool:
    """数据库连接池
    
    管理数据库连接，提供连接复用
    
    Example:
        >>> pool = DatabasePool(config)
        >>> with pool.get_connection() as conn:
        ...     cursor = conn.cursor()
        ...     cursor.execute("SELECT 1")
    """
    
    def __init__(self, config: DatabaseConnection):
        """初始化连接池
        
        Args:
            config: 数据库连接配置
        """
        self.config = config
        self.pool = []
        self.in_use = set()
        self._initialized = False
    
    def initialize(self):
        """初始化连接池"""
        if self._initialized:
            return
        
        try:
            import psycopg2
            from psycopg2 import pool
            
            self._pool = pool.ThreadedConnectionPool(
                minconn=1,
                maxconn=self.config.pool_size,
                host=self.config.host,
                port=self.config.port,
                database=self.config.database,
                user=self.config.username,
                password=self.config.password,
            )
            self._initialized = True
            print(f"✅ 数据库连接池初始化成功 ({self.config.pool_size} 连接)")
            
        except ImportError:
            print("⚠️  警告：psycopg2 未安装，使用模拟连接池")
            self._initialized = True
        except Exception as e:
            print(f"⚠️  警告：数据库连接失败：{e}")
            self._initialized = True  # 继续运行，使用模拟模式
    
    def get_connection(self):
        """获取连接"""
        if not self._initialized:
            self.initialize()
        
        # 模拟连接 (用于测试)
        class MockConnection:
            def cursor(self):
                return MockCursor()
            def commit(self):
                pass
            def rollback(self):
                pass
            def close(self):
                pass
        
        class MockCursor:
            def execute(self, query, params=None):
                pass
            def fetchall(self):
                return []
            def fetchone(self):
                return None
            def close(self):
                pass
        
        return MockConnection()
    
    def return_connection(self, conn):
        """归还连接"""
        pass
    
    def close_all(self):
        """关闭所有连接"""
        if hasattr(self, '_pool'):
            self._pool.closeall()


# ==================== 查询构建器 ====================

class QueryBuilder:
    """查询构建器
    
    安全构建 SQL 查询，防止 SQL 注入
    
    Example:
        >>> qb = QueryBuilder()
        >>> sql, params = qb.select('users').where('tenant_id', tenant_id).build()
    """
    
    def __init__(self):
        """初始化构建器"""
        self.table = ""
        self.columns = ["*"]
        self.where_clauses = []
        self.where_params = []
        self.order_by = ""
        self.limit = None
        self.offset = None
    
    def select(self, table: str, columns: List[str] = None) -> 'QueryBuilder':
        """SELECT 查询"""
        self.table = table
        if columns:
            self.columns = columns
        return self
    
    def where(self, column: str, value: Any, operator: str = "=") -> 'QueryBuilder':
        """添加 WHERE 条件"""
        self.where_clauses.append(f"{column} {operator} %s")
        self.where_params.append(value)
        return self
    
    def where_in(self, column: str, values: List[Any]) -> 'QueryBuilder':
        """添加 WHERE IN 条件"""
        placeholders = ", ".join(["%s"] * len(values))
        self.where_clauses.append(f"{column} IN ({placeholders})")
        self.where_params.extend(values)
        return self
    
    def order_by_clause(self, column: str, direction: str = "ASC") -> 'QueryBuilder':
        """添加 ORDER BY"""
        self.order_by = f"ORDER BY {column} {direction}"
        return self
    
    def limit_offset(self, limit: int, offset: int = 0) -> 'QueryBuilder':
        """添加 LIMIT OFFSET"""
        self.limit = limit
        self.offset = offset
        return self
    
    def build(self) -> Tuple[str, List[Any]]:
        """构建 SQL"""
        columns_str = ", ".join(self.columns)
        sql = f"SELECT {columns_str} FROM {self.table}"
        
        if self.where_clauses:
            sql += " WHERE " + " AND ".join(self.where_clauses)
        
        if self.order_by:
            sql += " " + self.order_by
        
        if self.limit is not None:
            sql += f" LIMIT {self.limit}"
        
        if self.offset:
            sql += f" OFFSET {self.offset}"
        
        return sql, self.where_params
    
    def insert(self, table: str, data: Dict[str, Any]) -> Tuple[str, List[Any]]:
        """INSERT 语句"""
        columns = list(data.keys())
        values = list(data.values())
        placeholders = ", ".join(["%s"] * len(values))
        columns_str = ", ".join(columns)
        
        sql = f"INSERT INTO {table} ({columns_str}) VALUES ({placeholders}) RETURNING id"
        return sql, values
    
    def update(self, table: str, data: Dict[str, Any], where: Dict[str, Any]) -> Tuple[str, List[Any]]:
        """UPDATE 语句"""
        set_clauses = []
        params = []
        
        for key, value in data.items():
            set_clauses.append(f"{key} = %s")
            params.append(value)
        
        where_clauses = []
        for key, value in where.items():
            where_clauses.append(f"{key} = %s")
            params.append(value)
        
        sql = f"UPDATE {table} SET {', '.join(set_clauses)} WHERE {' AND '.join(where_clauses)}"
        return sql, params
    
    def delete(self, table: str, where: Dict[str, Any]) -> Tuple[str, List[Any]]:
        """DELETE 语句"""
        where_clauses = []
        params = []
        
        for key, value in where.items():
            where_clauses.append(f"{key} = %s")
            params.append(value)
        
        sql = f"DELETE FROM {table} WHERE {' AND '.join(where_clauses)}"
        return sql, params


# ==================== Database Agent ====================

class DatabaseAgent:
    """数据库 Agent
    
    提供多租户数据库访问、权限验证、审计日志等功能
    
    Example:
        >>> agent = DatabaseAgent(pool)
        >>> result = agent.query("SELECT * FROM users", user, tenant_id)
    """
    
    def __init__(self, pool: DatabasePool = None):
        """初始化 Database Agent
        
        Args:
            pool: 数据库连接池
        """
        self.pool = pool or DatabasePool(DatabaseConnection(
            host=os.environ.get('DB_HOST', 'localhost'),
            port=int(os.environ.get('DB_PORT', 5432)),
            database=os.environ.get('DB_NAME', 'fault_analysis'),
            username=os.environ.get('DB_USER', 'app_user'),
            password=os.environ.get('DB_PASSWORD', ''),
        ))
        self.pool.initialize()
        
        # 审计日志
        self.audit_logs: List[AuditLog] = []
        
        # 敏感表需要特殊权限
        self.restricted_tables = [
            'users', 'token_blacklist', 'audit_logs', 'sla_violations'
        ]
        
        # 加密表包含敏感数据
        self.encrypted_tables = [
            'fault_cases', 'reports', 'tickets'
        ]
    
    def query(
        self,
        sql: str,
        params: List[Any] = None,
        user: Dict[str, Any] = None,
        tenant_id: str = None
    ) -> QueryResult:
        """执行查询
        
        Args:
            sql: SQL 语句
            params: 参数列表
            user: 用户信息
            tenant_id: 租户 ID
        
        Returns:
            查询结果
        """
        import time
        start_time = time.time()
        
        try:
            # 1. 权限验证
            if user and not self._check_query_permission(sql, user):
                return QueryResult(
                    success=False,
                    data=None,
                    row_count=0,
                    error_message="权限不足",
                )
            
            # 2. 自动添加租户过滤
            if tenant_id and self._should_add_tenant_filter(sql):
                sql, params = self._add_tenant_filter(sql, params, tenant_id)
            
            # 3. 执行查询
            conn = self.pool.get_connection()
            try:
                cursor = conn.cursor()
                cursor.execute(sql, params or [])
                
                if sql.strip().upper().startswith('SELECT'):
                    columns = [desc[0] for desc in cursor.description] if cursor.description else []
                    rows = cursor.fetchall()
                    data = [dict(zip(columns, row)) for row in rows]
                    row_count = len(data)
                else:
                    conn.commit()
                    row_count = cursor.rowcount
                    data = None
                
                cursor.close()
                
                execution_time = (time.time() - start_time) * 1000
                
                # 4. 记录审计日志
                if user:
                    self._log_audit(
                        tenant_id=tenant_id or user.get('tenant_id', ''),
                        user_id=user.get('id', ''),
                        operation=DatabaseOperation.SELECT,
                        table_name=self._extract_table_name(sql),
                        query=sql,
                        result='success',
                        row_count=row_count,
                        ip_address=user.get('ip_address', ''),
                    )
                
                return QueryResult(
                    success=True,
                    data=data,
                    row_count=row_count,
                    execution_time_ms=execution_time,
                )
                
            finally:
                self.pool.return_connection(conn)
                
        except Exception as e:
            execution_time = (time.time() - start_time) * 1000
            
            # 记录失败审计日志
            if user:
                self._log_audit(
                    tenant_id=tenant_id or user.get('tenant_id', ''),
                    user_id=user.get('id', ''),
                    operation=DatabaseOperation.SELECT,
                    table_name=self._extract_table_name(sql),
                    query=sql,
                    result='failure',
                    row_count=0,
                    ip_address=user.get('ip_address', ''),
                    error=str(e),
                )
            
            return QueryResult(
                success=False,
                data=None,
                row_count=0,
                error_message=str(e),
                execution_time_ms=execution_time,
            )
    
    def insert(
        self,
        table: str,
        data: Dict[str, Any],
        user: Dict[str, Any] = None
    ) -> QueryResult:
        """插入数据
        
        Args:
            table: 表名
            data: 数据字典
            user: 用户信息
        
        Returns:
            查询结果
        """
        try:
            # 1. 权限验证
            if user and not self._check_insert_permission(table, user):
                return QueryResult(
                    success=False,
                    data=None,
                    row_count=0,
                    error_message="权限不足",
                )
            
            # 2. 自动添加租户 ID
            if user and 'tenant_id' not in data and self._table_has_tenant(table):
                data['tenant_id'] = user.get('tenant_id', '')
            
            # 3. 构建 INSERT 语句
            qb = QueryBuilder()
            sql, params = qb.insert(table, data)
            
            # 4. 执行
            return self.query(sql, params, user, data.get('tenant_id'))
            
        except Exception as e:
            return QueryResult(
                success=False,
                data=None,
                row_count=0,
                error_message=str(e),
            )
    
    def update(
        self,
        table: str,
        data: Dict[str, Any],
        where: Dict[str, Any],
        user: Dict[str, Any] = None
    ) -> QueryResult:
        """更新数据
        
        Args:
            table: 表名
            data: 更新数据
            where: 条件
            user: 用户信息
        
        Returns:
            查询结果
        """
        try:
            # 1. 权限验证
            if user and not self._check_update_permission(table, user):
                return QueryResult(
                    success=False,
                    data=None,
                    row_count=0,
                    error_message="权限不足",
                )
            
            # 2. 构建 UPDATE 语句
            qb = QueryBuilder()
            sql, params = qb.update(table, data, where)
            
            # 3. 执行
            return self.query(sql, params, user, where.get('tenant_id'))
            
        except Exception as e:
            return QueryResult(
                success=False,
                data=None,
                row_count=0,
                error_message=str(e),
            )
    
    def delete(
        self,
        table: str,
        where: Dict[str, Any],
        user: Dict[str, Any] = None
    ) -> QueryResult:
        """删除数据
        
        Args:
            table: 表名
            where: 条件
            user: 用户信息
        
        Returns:
            查询结果
        """
        try:
            # 1. 权限验证
            if user and not self._check_delete_permission(table, user):
                return QueryResult(
                    success=False,
                    data=None,
                    row_count=0,
                    error_message="权限不足",
                )
            
            # 2. 构建 DELETE 语句
            qb = QueryBuilder()
            sql, params = qb.delete(table, where)
            
            # 3. 执行
            return self.query(sql, params, user, where.get('tenant_id'))
            
        except Exception as e:
            return QueryResult(
                success=False,
                data=None,
                row_count=0,
                error_message=str(e),
            )
    
    def _check_query_permission(self, sql: str, user: Dict[str, Any]) -> bool:
        """检查查询权限"""
        table_name = self._extract_table_name(sql)
        
        # 检查受限表
        if table_name in self.restricted_tables:
            role = user.get('role', '')
            return role in ['admin', 'security', 'management']
        
        return True
    
    def _check_insert_permission(self, table: str, user: Dict[str, Any]) -> bool:
        """检查插入权限"""
        if table in self.restricted_tables:
            role = user.get('role', '')
            return role in ['admin', 'security']
        return True
    
    def _check_update_permission(self, table: str, user: Dict[str, Any]) -> bool:
        """检查更新权限"""
        return self._check_insert_permission(table, user)
    
    def _check_delete_permission(self, table: str, user: Dict[str, Any]) -> bool:
        """检查删除权限"""
        role = user.get('role', '')
        return role in ['admin']
    
    def _should_add_tenant_filter(self, sql: str) -> bool:
        """判断是否应该添加租户过滤"""
        sql_upper = sql.upper()
        if not sql_upper.startswith('SELECT'):
            return False
        
        table_name = self._extract_table_name(sql)
        return self._table_has_tenant(table_name)
    
    def _table_has_tenant(self, table: str) -> bool:
        """检查表是否有 tenant_id 列"""
        tables_with_tenant = [
            'users', 'fault_cases', 'fault_logs', 'approvals',
            'reports', 'tickets', 'ticket_comments', 'knowledge_base',
            'audit_logs', 'sla_violations'
        ]
        return table in tables_with_tenant
    
    def _add_tenant_filter(
        self,
        sql: str,
        params: List[Any],
        tenant_id: str
    ) -> Tuple[str, List[Any]]:
        """添加租户过滤"""
        if 'WHERE' in sql.upper():
            sql = sql.rstrip(';') + " AND tenant_id = %s"
        else:
            sql = sql.rstrip(';') + " WHERE tenant_id = %s"
        
        params = (params or []) + [tenant_id]
        return sql, params
    
    def _extract_table_name(self, sql: str) -> str:
        """提取表名"""
        import re
        match = re.search(r'(?:FROM|INTO|UPDATE|DELETE\s+FROM)\s+(\w+)', sql, re.IGNORECASE)
        return match.group(1) if match else ""
    
    def _log_audit(
        self,
        tenant_id: str,
        user_id: str,
        operation: DatabaseOperation,
        table_name: str,
        query: str,
        result: str,
        row_count: int,
        ip_address: str,
        error: str = None
    ):
        """记录审计日志"""
        log = AuditLog(
            log_id=f"audit_{datetime.now().strftime('%Y%m%d%H%M%S')}_{os.getpid()}",
            tenant_id=tenant_id,
            user_id=user_id,
            operation=operation,
            table_name=table_name,
            query=query,
            result=result,
            row_count=row_count,
            ip_address=ip_address,
        )
        self.audit_logs.append(log)
    
    def get_audit_logs(
        self,
        tenant_id: str,
        limit: int = 100
    ) -> List[AuditLog]:
        """获取审计日志"""
        logs = [l for l in self.audit_logs if l.tenant_id == tenant_id]
        return logs[-limit:]


# ==================== 命令行工具 ====================

if __name__ == '__main__':
    import sys
    
    agent = DatabaseAgent()
    
    print("=" * 60)
    print("数据库 Database Agent")
    print("=" * 60)
    
    # 模拟用户
    user = {
        'id': 'user123',
        'tenant_id': 'tenant456',
        'role': 'operations',
        'ip_address': '127.0.0.1',
    }
    
    # 测试查询
    print("\n📊 测试查询...")
    result = agent.query(
        "SELECT * FROM fault_cases WHERE status = %s",
        ['pending'],
        user,
        user['tenant_id']
    )
    
    if result.success:
        print(f"✅ 查询成功")
        print(f"   行数：{result.row_count}")
        print(f"   耗时：{result.execution_time_ms:.2f}ms")
    else:
        print(f"❌ 查询失败：{result.error_message}")
    
    # 显示审计日志
    print(f"\n📋 审计日志：{len(agent.audit_logs)} 条")
    for log in agent.audit_logs[:3]:
        print(f"   - {log.operation.value} {log.table_name}: {log.result}")
    
    print("\n" + "=" * 60)
