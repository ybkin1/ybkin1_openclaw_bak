"""
File Processor Agent - 文件处理与敏感信息检测

提供文件上传、敏感信息检测、报告生成、文件安全处理等功能
"""

from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
import re
import os
import json
import hashlib


# ==================== 枚举类 ====================

class FileType(Enum):
    """文件类型"""
    LOG_BMC = "log_bmc"           # BMC 日志
    LOG_SYSTEM = "log_system"     # 系统日志
    LOG_DCGM = "log_dcgm"         # DCGM 日志
    LOG_PROMETHEUS = "log_prometheus"  # Prometheus 指标
    REPORT_HTML = "report_html"   # HTML 报告
    REPORT_PDF = "report_pdf"     # PDF 报告
    DATA_JSON = "data_json"       # JSON 数据
    DATA_CSV = "data_csv"         # CSV 数据
    OTHER = "other"               # 其他


class SensitivityLevel(Enum):
    """敏感级别"""
    PUBLIC = "public"         # 公开
    INTERNAL = "internal"     # 内部
    CONFIDENTIAL = "confidential"  # 机密
    RESTRICTED = "restricted" # 受限


class SensitiveDataType(Enum):
    """敏感数据类型"""
    SERVER_SN = "server_sn"           # 服务器 SN 号
    CUSTOMER_INFO = "customer_info"   # 客户信息
    IP_ADDRESS = "ip_address"         # IP 地址
    CREDENTIAL = "credential"         # 凭证密码
    HARDWARE_CONFIG = "hardware_config"  # 硬件配置
    PERFORMANCE_DATA = "performance_data"  # 性能数据


# ==================== 数据类 ====================

@dataclass
class SensitiveItem:
    """敏感信息项"""
    type: SensitiveDataType
    value: str
    position: Tuple[int, int]  # (start, end)
    confidence: float
    action: str = "mask"  # mask/remove/encrypt
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'type': self.type.value,
            'value': self.value,
            'position': self.position,
            'confidence': self.confidence,
            'action': self.action,
        }


@dataclass
class FileMetadata:
    """文件元数据"""
    file_id: str
    file_name: str
    file_type: FileType
    file_size: int
    file_hash: str
    sensitivity_level: SensitivityLevel
    sensitive_items: List[SensitiveItem] = field(default_factory=list)
    tenant_id: str = ""
    uploaded_by: str = ""
    uploaded_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'file_id': self.file_id,
            'file_name': self.file_name,
            'file_type': self.file_type.value,
            'file_size': self.file_size,
            'file_hash': self.file_hash,
            'sensitivity_level': self.sensitivity_level.value,
            'sensitive_items': [item.to_dict() for item in self.sensitive_items],
            'tenant_id': self.tenant_id,
            'uploaded_by': self.uploaded_by,
            'uploaded_at': self.uploaded_at.isoformat(),
        }


@dataclass
class ProcessingResult:
    """处理结果"""
    success: bool
    file_metadata: Optional[FileMetadata]
    processed_content: Optional[str]
    error_message: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'success': self.success,
            'file_metadata': self.file_metadata.to_dict() if self.file_metadata else None,
            'processed_content': self.processed_content,
            'error_message': self.error_message,
            'warnings': self.warnings,
        }


# ==================== 敏感信息检测器 ====================

class SensitiveDataDetector:
    """敏感信息检测器
    
    检测文件中的敏感信息
    
    Example:
        >>> detector = SensitiveDataDetector()
        >>> items = detector.detect("服务器 SN 号：SN123456")
        >>> print(items)
        [SensitiveItem(type=SERVER_SN, value='SN123456', ...)]
    """
    
    def __init__(self):
        """初始化检测器"""
        # 正则表达式模式
        self.patterns = {
            SensitiveDataType.SERVER_SN: [
                r'\bSN[0-9A-Za-z]{6,20}\b',
                r'\bS/N[0-9A-Za-z]{6,20}\b',
                r'\b序列号 [：:]\s*[0-9A-Za-z]{6,20}\b',
            ],
            SensitiveDataType.IP_ADDRESS: [
                r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
                r'\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b',  # IPv6
            ],
            SensitiveDataType.CREDENTIAL: [
                r'\b(?:password|passwd|pwd)[\s:：=]+[^\s]{4,}\b',
                r'\b(?:token|api_key|apikey)[\s:：=]+[^\s]{8,}\b',
                r'\b(?:secret|密钥)[\s:：=]+[^\s]{8,}\b',
            ],
            SensitiveDataType.HARDWARE_CONFIG: [
                r'\b(?:CPU|GPU|内存 | 硬盘)[\s:：=]+[^\n]{10,100}\b',
                r'\b(?:型号 | 规格 | 配置)[\s:：=]+[^\n]{10,200}\b',
            ],
            SensitiveDataType.CUSTOMER_INFO: [
                r'\b(?:客户 | 公司 | 单位)[\s:：=]+[^\n]{2,50}\b',
                r'\b(?:联系人 | 电话 | 邮箱)[\s:：=]+[^\n]{5,50}\b',
            ],
        }
        
        # 关键词
        self.keywords = {
            SensitiveDataType.SERVER_SN: ['SN 号', '序列号', '设备号', '机身号'],
            SensitiveDataType.CUSTOMER_INFO: ['客户', '公司', '单位', '联系人'],
            SensitiveDataType.HARDWARE_CONFIG: ['硬件配置', '服务器配置', 'GPU 配置'],
        }
    
    def detect(self, text: str) -> List[SensitiveItem]:
        """检测敏感信息
        
        Args:
            text: 文本内容
        
        Returns:
            敏感信息列表
        """
        sensitive_items = []
        
        # 正则匹配
        for data_type, patterns in self.patterns.items():
            for pattern in patterns:
                for match in re.finditer(pattern, text, re.IGNORECASE):
                    item = SensitiveItem(
                        type=data_type,
                        value=match.group(),
                        position=(match.start(), match.end()),
                        confidence=self._calculate_confidence(match.group(), data_type),
                    )
                    sensitive_items.append(item)
        
        # 关键词匹配
        for data_type, keywords in self.keywords.items():
            for keyword in keywords:
                if keyword in text:
                    # 查找关键词附近的敏感信息
                    start = text.find(keyword)
                    if start != -1:
                        # 提取关键词后 100 个字符
                        end = min(start + 100, len(text))
                        snippet = text[start:end]
                        
                        item = SensitiveItem(
                            type=data_type,
                            value=keyword,
                            position=(start, start + len(keyword)),
                            confidence=0.7,
                        )
                        sensitive_items.append(item)
        
        # 去重
        return self._deduplicate(sensitive_items)
    
    def _calculate_confidence(self, value: str, data_type: SensitiveDataType) -> float:
        """计算置信度
        
        Args:
            value: 匹配值
            data_type: 数据类型
        
        Returns:
            置信度 (0-1)
        """
        confidence = 0.5
        
        # 长度判断
        if len(value) >= 10:
            confidence += 0.2
        if len(value) >= 20:
            confidence += 0.1
        
        # 格式判断
        if data_type == SensitiveDataType.SERVER_SN:
            if re.match(r'^SN[0-9A-Za-z]{8,}$', value):
                confidence += 0.2
        elif data_type == SensitiveDataType.IP_ADDRESS:
            if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', value):
                confidence += 0.2
        
        return min(1.0, confidence)
    
    def _deduplicate(self, items: List[SensitiveItem]) -> List[SensitiveItem]:
        """去重
        
        Args:
            items: 敏感信息列表
        
        Returns:
            去重后的列表
        """
        seen = set()
        unique = []
        
        for item in items:
            key = (item.type, item.value, item.position)
            if key not in seen:
                seen.add(key)
                unique.append(item)
        
        return unique
    
    def mask_sensitive_data(self, text: str, items: List[SensitiveItem]) -> str:
        """脱敏敏感数据
        
        Args:
            text: 原始文本
            items: 敏感信息列表
        
        Returns:
            脱敏后的文本
        """
        # 按位置倒序排序，避免替换影响后续位置
        sorted_items = sorted(items, key=lambda x: x.position[0], reverse=True)
        
        result = text
        for item in sorted_items:
            start, end = item.position
            masked = self._mask_value(item.value, item.type)
            result = result[:start] + masked + result[end:]
        
        return result
    
    def _mask_value(self, value: str, data_type: SensitiveDataType) -> str:
        """脱敏值
        
        Args:
            value: 原始值
            data_type: 数据类型
        
        Returns:
            脱敏后的值
        """
        if len(value) <= 4:
            return '*' * len(value)
        
        # 保留前 2 位和后 2 位
        if data_type == SensitiveDataType.SERVER_SN:
            return value[:2] + '*' * (len(value) - 4) + value[-2:]
        elif data_type == SensitiveDataType.IP_ADDRESS:
            parts = value.split('.')
            if len(parts) == 4:
                return f"{parts[0]}.{parts[1]}.*.*"
        
        # 默认脱敏
        return value[:2] + '*' * (len(value) - 4) + value[-2:]


# ==================== 文件处理器 ====================

class FileProcessor:
    """文件处理器
    
    处理文件上传、类型识别、内容处理等
    
    Example:
        >>> processor = FileProcessor()
        >>> result = processor.process_file(content, "server.log")
    """
    
    def __init__(self):
        """初始化处理器"""
        self.detector = SensitiveDataDetector()
        
        # 文件扩展名映射
        self.extension_mapping = {
            '.log': FileType.LOG_SYSTEM,
            '.bmc': FileType.LOG_BMC,
            '.dcgm': FileType.LOG_DCGM,
            '.prom': FileType.LOG_PROMETHEUS,
            '.html': FileType.REPORT_HTML,
            '.pdf': FileType.REPORT_PDF,
            '.json': FileType.DATA_JSON,
            '.csv': FileType.DATA_CSV,
        }
        
        # 文件类型关键词
        self.type_keywords = {
            FileType.LOG_BMC: ['bmc', 'ipmi', 'baseboard'],
            FileType.LOG_DCGM: ['dcgm', 'nvidia', 'gpu', 'nvml'],
            FileType.LOG_PROMETHEUS: ['prometheus', 'metrics', 'prom'],
        }
    
    def process_file(
        self,
        content: str,
        file_name: str,
        tenant_id: str = "",
        uploaded_by: str = ""
    ) -> ProcessingResult:
        """处理文件
        
        Args:
            content: 文件内容
            file_name: 文件名
            tenant_id: 租户 ID
            uploaded_by: 上传人
        
        Returns:
            处理结果
        """
        try:
            # 1. 识别文件类型
            file_type = self._identify_file_type(content, file_name)
            
            # 2. 计算文件哈希
            file_hash = hashlib.sha256(content.encode('utf-8')).hexdigest()
            
            # 3. 检测敏感信息
            sensitive_items = self.detector.detect(content)
            
            # 4. 确定敏感级别
            sensitivity_level = self._determine_sensitivity(sensitive_items)
            
            # 5. 创建文件元数据
            file_id = f"file_{datetime.now().strftime('%Y%m%d%H%M%S')}_{os.getpid()}"
            metadata = FileMetadata(
                file_id=file_id,
                file_name=file_name,
                file_type=file_type,
                file_size=len(content),
                file_hash=file_hash,
                sensitivity_level=sensitivity_level,
                sensitive_items=sensitive_items,
                tenant_id=tenant_id,
                uploaded_by=uploaded_by,
            )
            
            # 6. 处理内容 (脱敏)
            if sensitive_items:
                processed_content = self.detector.mask_sensitive_data(content, sensitive_items)
            else:
                processed_content = content
            
            return ProcessingResult(
                success=True,
                file_metadata=metadata,
                processed_content=processed_content,
            )
            
        except Exception as e:
            return ProcessingResult(
                success=False,
                file_metadata=None,
                processed_content=None,
                error_message=str(e),
            )
    
    def _identify_file_type(self, content: str, file_name: str) -> FileType:
        """识别文件类型
        
        Args:
            content: 文件内容
            file_name: 文件名
        
        Returns:
            文件类型
        """
        # 1. 检查扩展名
        ext = os.path.splitext(file_name)[1].lower()
        if ext in self.extension_mapping:
            return self.extension_mapping[ext]
        
        # 2. 检查内容关键词
        content_lower = content.lower()[:1000]  # 只检查前 1000 字符
        for file_type, keywords in self.type_keywords.items():
            if any(kw in content_lower for kw in keywords):
                return file_type
        
        # 3. 默认返回其他
        return FileType.OTHER
    
    def _determine_sensitivity(
        self,
        sensitive_items: List[SensitiveItem]
    ) -> SensitivityLevel:
        """确定敏感级别
        
        Args:
            sensitive_items: 敏感信息列表
        
        Returns:
            敏感级别
        """
        if not sensitive_items:
            return SensitivityLevel.PUBLIC
        
        # 检查是否有高敏感类型
        high_sensitivity_types = [
            SensitiveDataType.CREDENTIAL,
            SensitiveDataType.CUSTOMER_INFO,
            SensitiveDataType.SERVER_SN,
        ]
        
        if any(item.type in high_sensitivity_types for item in sensitive_items):
            return SensitivityLevel.CONFIDENTIAL
        
        # 检查是否有中敏感类型
        medium_sensitivity_types = [
            SensitiveDataType.HARDWARE_CONFIG,
            SensitiveDataType.IP_ADDRESS,
        ]
        
        if any(item.type in medium_sensitivity_types for item in sensitive_items):
            return SensitivityLevel.INTERNAL
        
        return SensitivityLevel.PUBLIC


# ==================== File Processor Agent ====================

class FileProcessorAgent:
    """文件处理 Agent
    
    整合文件处理、敏感检测、报告生成等功能
    
    Example:
        >>> agent = FileProcessorAgent(db_pool)
        >>> result = agent.upload_file(content, "server.log", user)
    """
    
    def __init__(self, db_pool=None):
        """初始化 Agent
        
        Args:
            db_pool: 数据库连接池
        """
        self.db_pool = db_pool
        self.processor = FileProcessor()
        self.file_store: Dict[str, FileMetadata] = {}
    
    def upload_file(
        self,
        content: str,
        file_name: str,
        user: Dict[str, Any]
    ) -> ProcessingResult:
        """上传文件
        
        Args:
            content: 文件内容
            file_name: 文件名
            user: 用户信息
        
        Returns:
            处理结果
        """
        # 处理文件
        result = self.processor.process_file(
            content=content,
            file_name=file_name,
            tenant_id=user.get('tenant_id', ''),
            uploaded_by=user.get('id', ''),
        )
        
        if result.success and result.file_metadata:
            # 存储元数据
            self.file_store[result.file_metadata.file_id] = result.file_metadata
            
            # 保存到数据库
            if self.db_pool:
                self._save_to_db(result.file_metadata)
        
        return result
    
    def get_file_metadata(self, file_id: str) -> Optional[FileMetadata]:
        """获取文件元数据
        
        Args:
            file_id: 文件 ID
        
        Returns:
            文件元数据
        """
        return self.file_store.get(file_id)
    
    def list_files(
        self,
        tenant_id: str,
        file_type: Optional[FileType] = None
    ) -> List[FileMetadata]:
        """列出文件
        
        Args:
            tenant_id: 租户 ID
            file_type: 文件类型 (可选)
        
        Returns:
            文件列表
        """
        files = [f for f in self.file_store.values() if f.tenant_id == tenant_id]
        
        if file_type:
            files = [f for f in files if f.file_type == file_type]
        
        return files
    
    def export_file(
        self,
        file_id: str,
        user: Dict[str, Any],
        include_sensitive: bool = False
    ) -> Optional[str]:
        """导出文件
        
        Args:
            file_id: 文件 ID
            user: 用户信息
            include_sensitive: 是否包含敏感信息
        
        Returns:
            文件内容或 None
        """
        metadata = self.file_store.get(file_id)
        if not metadata:
            return None
        
        # 检查权限
        if metadata.sensitivity_level == SensitivityLevel.CONFIDENTIAL:
            if not include_sensitive:
                # 需要脱敏
                return self._get_processed_content(file_id)
            else:
                # 需要权限检查
                if not self._has_sensitive_access(user):
                    return None
        
        return self._get_processed_content(file_id)
    
    def _save_to_db(self, metadata: FileMetadata):
        """保存到数据库"""
        # TODO: 实现数据库保存
        pass
    
    def _get_processed_content(self, file_id: str) -> Optional[str]:
        """获取处理后的内容"""
        # TODO: 从存储获取内容
        return None
    
    def _has_sensitive_access(self, user: Dict[str, Any]) -> bool:
        """检查是否有敏感数据访问权限"""
        # TODO: 实现权限检查
        role = user.get('role', '')
        return role in ['security', 'admin', 'management']


# ==================== 命令行工具 ====================

if __name__ == '__main__':
    import sys
    
    agent = FileProcessorAgent()
    
    print("=" * 60)
    print("文件处理 File Processor Agent")
    print("=" * 60)
    
    if len(sys.argv) < 2:
        print("用法：python file_processor.py <file> [user_id] [tenant_id]")
        print("示例：python file_processor.py server.log user1 tenant1")
        sys.exit(1)
    
    file_path = sys.argv[1]
    user_id = sys.argv[2] if len(sys.argv) > 2 else "test_user"
    tenant_id = sys.argv[3] if len(sys.argv) > 3 else "test_tenant"
    
    # 读取文件
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"❌ 读取文件失败：{e}")
        sys.exit(1)
    
    # 处理文件
    user = {'id': user_id, 'tenant_id': tenant_id, 'role': 'operations'}
    result = agent.upload_file(content, os.path.basename(file_path), user)
    
    if result.success:
        print(f"✅ 文件处理成功")
        print(f"文件 ID: {result.file_metadata.file_id}")
        print(f"文件类型：{result.file_metadata.file_type.value}")
        print(f"敏感级别：{result.file_metadata.sensitivity_level.value}")
        print(f"敏感项数量：{len(result.file_metadata.sensitive_items)}")
        
        if result.file_metadata.sensitive_items:
            print("\n敏感信息:")
            for item in result.file_metadata.sensitive_items[:5]:
                print(f"  - {item.type.value}: {item.value[:30]}... (置信度：{item.confidence:.2f})")
        
        print("\n处理后内容 (前 200 字符):")
        print(result.processed_content[:200])
    else:
        print(f"❌ 文件处理失败：{result.error_message}")
