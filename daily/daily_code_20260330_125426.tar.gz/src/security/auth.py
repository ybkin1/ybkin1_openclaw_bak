"""
JWT 认证系统

提供用户认证、令牌生成、令牌验证等功能
符合 OAuth 2.0 和 JWT 标准
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from jose import jwt, JWTError, JWSError
from passlib.context import CryptContext
from dataclasses import dataclass
import os
import secrets

# ==================== 配置 ====================

# JWT 配置
JWT_SECRET_KEY = os.environ.get("JWT_SECRET") or secrets.token_urlsafe(32)
JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
REFRESH_TOKEN_EXPIRE_DAYS = 7

# 密码加密配置
PASSWORD_CONTEXT = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ==================== 数据类 ====================

@dataclass
class TokenPair:
    """令牌对"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "token_type": self.token_type,
        }


@dataclass
class TokenPayload:
    """令牌载荷"""
    sub: str  # 用户 ID
    tenant_id: str
    role: str
    exp: datetime
    iat: datetime
    type: str  # "access" 或 "refresh"
    
    @classmethod
    def from_dict(cls, data: dict) -> 'TokenPayload':
        """从字典创建"""
        return cls(
            sub=data['sub'],
            tenant_id=data['tenant_id'],
            role=data['role'],
            exp=datetime.fromtimestamp(data['exp']),
            iat=datetime.fromtimestamp(data['iat']),
            type=data['type'],
        )


# ==================== 异常类 ====================

class AuthenticationError(Exception):
    """认证异常"""
    pass


class TokenExpiredError(AuthenticationError):
    """令牌过期异常"""
    pass


class TokenInvalidError(AuthenticationError):
    """令牌无效异常"""
    pass


class TokenClaimsError(AuthenticationError):
    """令牌声明错误"""
    pass


class TokenExpiredError(AuthenticationError):
    """令牌过期异常"""
    pass


# ==================== 认证服务 ====================

class AuthenticationService:
    """认证服务类
    
    提供用户认证、令牌生成、令牌验证等功能
    
    Attributes:
        db: 数据库连接
    
    Example:
        >>> auth = AuthenticationService(db)
        >>> user = auth.authenticate_user("admin", "password123")
        >>> tokens = auth.create_token_pair(user)
        >>> print(tokens.access_token)
    """
    
    def __init__(self, db=None):
        """初始化认证服务
        
        Args:
            db: 数据库连接 (可选)
        """
        self.db = db
    
    def authenticate_user(
        self,
        username: str,
        password: str
    ) -> Optional['User']:
        """认证用户
        
        Args:
            username: 用户名
            password: 密码
        
        Returns:
            认证通过返回 User 对象，失败返回 None
        
        Example:
            >>> auth = AuthenticationService(db)
            >>> user = auth.authenticate_user("admin", "password123")
            >>> if user:
            ...     print(f"欢迎，{user.username}")
        """
        if not self.db:
            raise AuthenticationError("数据库未连接")
        
        # 查询用户
        user = self.db.get_user_by_username(username)
        if not user:
            return None
        
        # 验证密码
        if not self.verify_password(password, user.hashed_password):
            return None
        
        return user
    
    def create_access_token(
        self,
        user: 'User',
        expires_delta: Optional[timedelta] = None
    ) -> str:
        """创建访问令牌
        
        Args:
            user: 用户对象
            expires_delta: 过期时间增量
        
        Returns:
            JWT 访问令牌
        
        Example:
            >>> auth = AuthenticationService(db)
            >>> token = auth.create_access_token(user)
            >>> print(token)
        """
        expire = datetime.utcnow() + (
            expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )
        
        payload = {
            "sub": user.id,
            "tenant_id": user.tenant_id,
            "role": user.role.value if hasattr(user.role, 'value') else str(user.role),
            "exp": expire,
            "iat": datetime.utcnow(),
            "type": "access",
        }
        
        return jwt.encode(
            payload,
            JWT_SECRET_KEY,
            algorithm=JWT_ALGORITHM
        )
    
    def create_refresh_token(self, user: 'User') -> str:
        """创建刷新令牌
        
        Args:
            user: 用户对象
        
        Returns:
            JWT 刷新令牌
        """
        expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
        
        payload = {
            "sub": user.id,
            "tenant_id": user.tenant_id,
            "role": user.role.value if hasattr(user.role, 'value') else str(user.role),
            "exp": expire,
            "iat": datetime.utcnow(),
            "type": "refresh",
        }
        
        return jwt.encode(
            payload,
            JWT_SECRET_KEY,
            algorithm=JWT_ALGORITHM
        )
    
    def create_token_pair(self, user: 'User') -> TokenPair:
        """创建令牌对
        
        Args:
            user: 用户对象
        
        Returns:
            包含访问令牌和刷新令牌的 TokenPair
        
        Example:
            >>> auth = AuthenticationService(db)
            >>> tokens = auth.create_token_pair(user)
            >>> print(tokens.access_token)
            >>> print(tokens.refresh_token)
        """
        return TokenPair(
            access_token=self.create_access_token(user),
            refresh_token=self.create_refresh_token(user),
        )
    
    def verify_token(self, token: str, token_type: str = "access") -> TokenPayload:
        """验证令牌
        
        Args:
            token: JWT 令牌
            token_type: 令牌类型 ("access" 或 "refresh")
        
        Returns:
            令牌载荷
        
        Raises:
            TokenExpiredError: 令牌过期
            TokenInvalidError: 令牌无效
            TokenClaimsError: 令牌声明错误
        
        Example:
            >>> auth = AuthenticationService(db)
            >>> try:
            ...     payload = auth.verify_token(token)
            ...     print(f"用户 ID: {payload.sub}")
            ... except TokenExpiredError:
            ...     print("令牌已过期")
        """
        try:
            payload = jwt.decode(
                token,
                JWT_SECRET_KEY,
                algorithms=[JWT_ALGORITHM]
            )
            
            # 验证令牌类型
            if payload.get("type") != token_type:
                raise TokenClaimsError(f"令牌类型错误：需要 {token_type}")
            
            # 验证必要字段
            required_fields = ["sub", "tenant_id", "role", "exp", "iat"]
            for field in required_fields:
                if field not in payload:
                    raise TokenClaimsError(f"令牌缺少必要字段：{field}")
            
            return TokenPayload.from_dict(payload)
            
        except JWSError as e:
            if "expired" in str(e).lower():
                raise TokenExpiredError(f"令牌已过期：{e}")
            raise TokenInvalidError(f"令牌无效：{e}")
        except JWTError as e:
            if "expired" in str(e).lower():
                raise TokenExpiredError(f"令牌已过期：{e}")
            raise TokenInvalidError(f"令牌无效：{e}")
    
    def refresh_access_token(self, refresh_token: str) -> TokenPair:
        """刷新访问令牌
        
        Args:
            refresh_token: 刷新令牌
        
        Returns:
            新的令牌对
        
        Raises:
            TokenExpiredError: 刷新令牌过期
            TokenInvalidError: 刷新令牌无效
        
        Example:
            >>> auth = AuthenticationService(db)
            >>> new_tokens = auth.refresh_access_token(refresh_token)
        """
        # 验证刷新令牌
        payload = self.verify_token(refresh_token, token_type="refresh")
        
        # 从数据库获取用户
        if not self.db:
            raise AuthenticationError("数据库未连接")
        
        user = self.db.get_user(payload.sub)
        if not user:
            raise AuthenticationError("用户不存在")
        
        # 创建新令牌对
        return self.create_token_pair(user)
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """验证密码
        
        Args:
            plain_password: 明文密码
            hashed_password: bcrypt 哈希密码
        
        Returns:
            验证是否通过
        """
        return PASSWORD_CONTEXT.verify(plain_password, hashed_password)
    
    def hash_password(self, password: str) -> str:
        """密码哈希
        
        Args:
            password: 明文密码
        
        Returns:
            bcrypt 哈希密码
        """
        return PASSWORD_CONTEXT.hash(password)
    
    def revoke_token(self, token: str) -> bool:
        """撤销令牌
        
        Args:
            token: 要撤销的令牌
        
        Returns:
            是否成功
        
        Note:
            实际实现需要将令牌加入黑名单
            这里仅做接口定义
        """
        # TODO: 实现令牌黑名单机制
        # 可以将令牌 ID 存入 Redis，设置过期时间
        return True


# ==================== FastAPI 依赖注入 ====================

async def get_current_user(
    token: str,  # 从 Authorization header 获取
    auth_service: AuthenticationService
) -> 'User':
    """获取当前用户 (FastAPI 依赖注入)
    
    Args:
        token: JWT 令牌
        auth_service: 认证服务实例
    
    Returns:
        当前用户对象
    
    Raises:
        AuthenticationError: 认证失败
    
    Example:
        @app.get("/users/me")
        async def get_me(current_user: User = Depends(get_current_user)):
            return current_user
    """
    try:
        payload = auth_service.verify_token(token)
    except TokenExpiredError:
        raise AuthenticationError("令牌已过期")
    except TokenInvalidError:
        raise AuthenticationError("令牌无效")
    except TokenClaimsError:
        raise AuthenticationError("令牌声明错误")
    
    # 从数据库获取用户
    if not auth_service.db:
        raise AuthenticationError("数据库未连接")
    
    user = auth_service.db.get_user(payload.sub)
    if not user:
        raise AuthenticationError("用户不存在")
    
    return user


# ==================== 工具函数 ====================

def generate_secure_password(length: int = 16) -> str:
    """生成安全密码
    
    Args:
        length: 密码长度
    
    Returns:
        随机生成的安全密码
    """
    import string
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    password = ''.join(secrets.choice(alphabet) for _ in range(length))
    
    # 确保包含至少一个大写字母、一个小写字母、一个数字和一个特殊字符
    if not any(c.isupper() for c in password):
        password = password[:-1] + secrets.choice(string.ascii_uppercase)
    if not any(c.islower() for c in password):
        password = password[:-1] + secrets.choice(string.ascii_lowercase)
    if not any(c.isdigit() for c in password):
        password = password[:-1] + secrets.choice(string.digits)
    if not any(c in "!@#$%^&*" for c in password):
        password = password[:-1] + secrets.choice("!@#$%^&*")
    
    return password


# ==================== 命令行工具 ====================

if __name__ == '__main__':
    import sys
    import json
    
    if len(sys.argv) < 2:
        print("用法：python auth.py <command> [args]")
        print("命令:")
        print("  generate-token <user_id> <tenant_id> <role>  生成测试令牌")
        print("  verify-token <token>                         验证令牌")
        print("  refresh-token <refresh_token>                刷新令牌")
        print("  hash-password <password>                     密码哈希")
        print("  generate-password                            生成随机密码")
        print("  show-config                                  显示配置")
        sys.exit(1)
    
    auth = AuthenticationService()
    command = sys.argv[1]
    
    if command == 'generate-token':
        if len(sys.argv) < 5:
            print("错误：请提供 user_id, tenant_id, role")
            sys.exit(1)
        
        # 创建模拟用户 (简化版，不依赖 rbac 模块)
        class MockRole:
            def __init__(self, value):
                self.value = value
        class MockUser:
            def __init__(self, id, tenant_id, role):
                self.id = id
                self.tenant_id = tenant_id
                self.role = MockRole(role)
        
        user = MockUser(sys.argv[2], sys.argv[3], sys.argv[4])
        tokens = auth.create_token_pair(user)
        print(json.dumps(tokens.to_dict(), indent=2))
    
    elif command == 'verify-token':
        if len(sys.argv) < 3:
            print("错误：请提供令牌")
            sys.exit(1)
        
        try:
            payload = auth.verify_token(sys.argv[2])
            print(f"令牌有效:")
            print(f"  用户 ID: {payload.sub}")
            print(f"  租户 ID: {payload.tenant_id}")
            print(f"  角色：{payload.role}")
            print(f"  过期时间：{payload.exp}")
        except AuthenticationError as e:
            print(f"令牌无效：{e}")
            sys.exit(1)
    
    elif command == 'refresh-token':
        if len(sys.argv) < 3:
            print("错误：请提供刷新令牌")
            sys.exit(1)
        
        try:
            new_tokens = auth.refresh_access_token(sys.argv[2])
            print(json.dumps(new_tokens.to_dict(), indent=2))
        except AuthenticationError as e:
            print(f"刷新失败：{e}")
            sys.exit(1)
    
    elif command == 'hash-password':
        if len(sys.argv) < 3:
            print("错误：请提供密码")
            sys.exit(1)
        
        hashed = auth.hash_password(sys.argv[2])
        print(f"哈希结果：{hashed}")
    
    elif command == 'generate-password':
        password = generate_secure_password()
        print(f"生成的密码：{password}")
        print(f"哈希结果：{auth.hash_password(password)}")
    
    elif command == 'show-config':
        print("JWT 配置:")
        print(f"  密钥：{JWT_SECRET_KEY[:20]}...")
        print(f"  算法：{JWT_ALGORITHM}")
        print(f"  Access Token 过期：{ACCESS_TOKEN_EXPIRE_MINUTES}分钟")
        print(f"  Refresh Token 过期：{REFRESH_TOKEN_EXPIRE_DAYS}天")
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
