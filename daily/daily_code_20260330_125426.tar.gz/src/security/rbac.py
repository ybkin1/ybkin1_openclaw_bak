"""
RBAC 权限管理系统

提供角色定义、权限矩阵、权限检查等功能
"""

from enum import Enum
from functools import wraps
from typing import List, Set, Optional
from dataclasses import dataclass, field
import json


class Permission(Enum):
    """权限枚举"""
    # 故障分析
    FAULT_ANALYZE = "fault:analyze"
    FAULT_REVIEW = "fault:review"
    FAULT_APPROVE = "fault:approve"
    
    # 报告管理
    REPORT_VIEW = "report:view"
    REPORT_EXPORT = "report:export"
    REPORT_DELETE = "report:delete"
    
    # 敏感数据
    SENSITIVE_VIEW = "sensitive:view"
    SENSITIVE_EXPORT = "sensitive:export"
    SENSITIVE_APPROVE = "sensitive:approve"
    
    # 工单管理
    TICKET_CREATE = "ticket:create"
    TICKET_VIEW = "ticket:view"
    TICKET_CLOSE = "ticket:close"
    
    # 系统管理
    USER_MANAGE = "user:manage"
    SYSTEM_CONFIG = "system:config"
    AUDIT_VIEW = "audit:view"


class Role(Enum):
    """角色枚举"""
    OPERATIONS = "operations"           # 运维领导
    MARKETING = "marketing"             # 市场领导
    MANAGEMENT = "management"           # 管理领导
    CUSTOMER_SERVICE = "customer_service"  # 客服领导
    TECHNICAL = "technical"             # 技术领导
    SECURITY = "security"               # 安全领导
    ADMIN = "admin"                     # 系统管理员


# 角色 - 权限映射
ROLE_PERMISSIONS: dict[Role, Set[Permission]] = {
    Role.OPERATIONS: {
        Permission.FAULT_ANALYZE,
        Permission.FAULT_REVIEW,
        Permission.REPORT_VIEW,
        Permission.REPORT_EXPORT,
        Permission.TICKET_VIEW,
    },
    Role.MARKETING: {
        Permission.REPORT_VIEW,
        Permission.REPORT_EXPORT,
        Permission.TICKET_CREATE,
        Permission.TICKET_VIEW,
    },
    Role.MANAGEMENT: {
        Permission.FAULT_REVIEW,
        Permission.FAULT_APPROVE,
        Permission.REPORT_VIEW,
        Permission.REPORT_EXPORT,
        Permission.SENSITIVE_VIEW,
        Permission.TICKET_VIEW,
    },
    Role.CUSTOMER_SERVICE: {
        Permission.TICKET_CREATE,
        Permission.TICKET_VIEW,
        Permission.TICKET_CLOSE,
        Permission.REPORT_VIEW,
    },
    Role.TECHNICAL: {
        Permission.FAULT_ANALYZE,
        Permission.FAULT_REVIEW,
        Permission.REPORT_VIEW,
    },
    Role.SECURITY: {
        Permission.SENSITIVE_VIEW,
        Permission.SENSITIVE_EXPORT,
        Permission.SENSITIVE_APPROVE,
        Permission.AUDIT_VIEW,
        Permission.REPORT_VIEW,
    },
    Role.ADMIN: {
        Permission.USER_MANAGE,
        Permission.SYSTEM_CONFIG,
        Permission.AUDIT_VIEW,
        Permission.SENSITIVE_VIEW,
        Permission.REPORT_VIEW,
    },
}


@dataclass
class User:
    """用户数据类
    
    Attributes:
        id: 用户 ID
        tenant_id: 租户 ID
        role: 用户角色
        permissions: 用户权限集合
        username: 用户名
    """
    id: str
    tenant_id: str
    role: Role
    permissions: Set[Permission] = field(default_factory=set)
    username: str = ""
    
    def __post_init__(self):
        """初始化后处理"""
        if not self.permissions:
            self.permissions = ROLE_PERMISSIONS.get(self.role, set())
        if not self.username:
            self.username = f"{self.role.value}_{self.id[:8]}"
    
    def has_permission(self, permission: Permission) -> bool:
        """检查是否有权限
        
        Args:
            permission: 要检查的权限
        
        Returns:
            是否有该权限
        """
        return permission in self.permissions
    
    def has_any_permission(self, permissions: List[Permission]) -> bool:
        """检查是否有任一权限
        
        Args:
            permissions: 权限列表
        
        Returns:
            是否有任一权限
        """
        return any(p in self.permissions for p in permissions)
    
    def has_all_permissions(self, permissions: List[Permission]) -> bool:
        """检查是否有所有权限
        
        Args:
            permissions: 权限列表
        
        Returns:
            是否有所有权限
        """
        return all(p in self.permissions for p in permissions)
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            'id': self.id,
            'tenant_id': self.tenant_id,
            'role': self.role.value,
            'permissions': [p.value for p in self.permissions],
            'username': self.username,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'User':
        """从字典创建"""
        return cls(
            id=data['id'],
            tenant_id=data['tenant_id'],
            role=Role(data['role']),
            permissions={Permission(p) for p in data.get('permissions', [])},
            username=data.get('username', ''),
        )


class AuthorizationError(Exception):
    """授权异常"""
    pass


class AuthenticationError(Exception):
    """认证异常"""
    pass


# 权限检查装饰器
def require_permission(permission: Permission):
    """权限检查装饰器
    
    Args:
        permission: 需要的权限
    
    Returns:
        装饰器函数
    
    Example:
        @require_permission(Permission.FAULT_ANALYZE)
        def analyze_fault(case_id: str):
            pass
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 从上下文获取当前用户
            user = get_current_user()
            if not user:
                raise AuthenticationError("用户未认证")
            if not user.has_permission(permission):
                raise AuthorizationError(
                    f"权限不足：需要 {permission.value}"
                )
            return func(*args, **kwargs)
        return wrapper
    return decorator


def require_role(roles: List[Role]):
    """角色检查装饰器
    
    Args:
        roles: 允许的角色列表
    
    Returns:
        装饰器函数
    
    Example:
        @require_role([Role.SECURITY, Role.ADMIN])
        def view_audit_logs():
            pass
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            user = get_current_user()
            if not user:
                raise AuthenticationError("用户未认证")
            if user.role not in roles:
                raise AuthorizationError(
                    f"角色不符：需要 {[r.value for r in roles]}"
                )
            return func(*args, **kwargs)
        return wrapper
    return decorator


def require_any_permission(permissions: List[Permission]):
    """任一权限检查装饰器
    
    Args:
        permissions: 权限列表 (有任一即可)
    
    Returns:
        装饰器函数
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            user = get_current_user()
            if not user:
                raise AuthenticationError("用户未认证")
            if not user.has_any_permission(permissions):
                raise AuthorizationError(
                    f"权限不足：需要 {[p.value for p in permissions]} 之一"
                )
            return func(*args, **kwargs)
        return wrapper
    return decorator


# 全局用户上下文 (线程安全)
from contextvars import ContextVar
_current_user: ContextVar[Optional[User]] = ContextVar('current_user', default=None)


def set_current_user(user: User):
    """设置当前用户"""
    _current_user.set(user)


def get_current_user() -> Optional[User]:
    """获取当前用户"""
    return _current_user.get()


def clear_current_user():
    """清除当前用户"""
    _current_user.set(None)


# 权限管理工具类
class PermissionManager:
    """权限管理器"""
    
    @staticmethod
    def get_role_permissions(role: Role) -> Set[Permission]:
        """获取角色的所有权限
        
        Args:
            role: 角色
        
        Returns:
            权限集合
        """
        return ROLE_PERMISSIONS.get(role, set())
    
    @staticmethod
    def add_permission_to_role(role: Role, permission: Permission):
        """给角色添加权限
        
        Args:
            role: 角色
            permission: 权限
        """
        if role not in ROLE_PERMISSIONS:
            ROLE_PERMISSIONS[role] = set()
        ROLE_PERMISSIONS[role].add(permission)
    
    @staticmethod
    def remove_permission_from_role(role: Role, permission: Permission):
        """从角色移除权限
        
        Args:
            role: 角色
            permission: 权限
        """
        if role in ROLE_PERMISSIONS:
            ROLE_PERMISSIONS[role].discard(permission)
    
    @staticmethod
    def export_permissions() -> str:
        """导出权限配置为 JSON
        
        Returns:
            JSON 字符串
        """
        data = {
            role.value: [p.value for p in perms]
            for role, perms in ROLE_PERMISSIONS.items()
        }
        return json.dumps(data, indent=2)
    
    @staticmethod
    def import_permissions(json_str: str):
        """从 JSON 导入权限配置
        
        Args:
            json_str: JSON 字符串
        """
        data = json.loads(json_str)
        ROLE_PERMISSIONS.clear()
        for role_value, perm_values in data.items():
            role = Role(role_value)
            ROLE_PERMISSIONS[role] = {Permission(p) for p in perm_values}


# 命令行工具
if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python rbac.py <command> [args]")
        print("命令:")
        print("  list-roles            列出所有角色")
        print("  list-permissions      列出所有权限")
        print("  show-role <role>      显示角色权限")
        print("  export                导出权限配置")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'list-roles':
        print("可用角色:")
        for role in Role:
            print(f"  {role.value:20} - {role.name}")
    
    elif command == 'list-permissions':
        print("可用权限:")
        for perm in Permission:
            print(f"  {perm.value:25} - {perm.name}")
    
    elif command == 'show-role':
        if len(sys.argv) < 3:
            print("错误：请指定角色名")
            sys.exit(1)
        role_name = sys.argv[2]
        try:
            role = Role(role_name)
            perms = ROLE_PERMISSIONS.get(role, set())
            print(f"角色 {role.value} 的权限:")
            for perm in sorted(perms, key=lambda x: x.value):
                print(f"  - {perm.value}")
        except ValueError:
            print(f"错误：未知角色 {role_name}")
            sys.exit(1)
    
    elif command == 'export':
        print(PermissionManager.export_permissions())
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
