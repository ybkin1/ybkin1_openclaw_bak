"""
加密服务模块

提供敏感数据加密、解密、哈希等功能
符合等保 2.0 三级加密要求
"""

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.backends import default_backend
import base64
import os
import json
from typing import Dict, Any, Optional
from datetime import datetime


class SecurityError(Exception):
    """安全异常类"""
    pass


class DecryptionError(SecurityError):
    """解密异常类"""
    pass


class EncryptionService:
    """加密服务类
    
    提供敏感数据加密、解密、哈希等功能
    
    Attributes:
        key: 加密密钥 (32 字节 Base64 编码)
        cipher: Fernet 加密器实例
    
    Example:
        >>> enc = EncryptionService()
        >>> encrypted = enc.encrypt_sensitive_data({'sn': 'SN123'})
        >>> decrypted = enc.decrypt_sensitive_data(encrypted)
        >>> print(decrypted)
        {'sn': 'SN123'}
    """
    
    def __init__(self, encryption_key: str = None):
        """初始化加密服务
        
        Args:
            encryption_key: 加密密钥 (32 字节 Base64 编码)
                           如不提供，从环境变量 ENCRYPTION_KEY 读取
        
        Raises:
            SecurityError: 密钥未配置时抛出
        """
        self.key = encryption_key or os.environ.get('ENCRYPTION_KEY')
        if not self.key:
            # 生成新密钥 (仅用于开发环境)
            self.key = Fernet.generate_key().decode()
            print(f"⚠️  警告：使用临时加密密钥，请设置 ENCRYPTION_KEY 环境变量")
            print(f"临时密钥：{self.key}")
        
        self.cipher = Fernet(self.key)
        self.backend = default_backend()
    
    def encrypt_sensitive_data(self, data: Dict[str, Any]) -> str:
        """加密敏感数据
        
        Args:
            data: 包含敏感信息的字典
                  如：{'sn': 'SN123456', 'config': 'CPU:xxx'}
        
        Returns:
            Base64 编码的加密字符串
        
        Example:
            >>> enc = EncryptionService()
            >>> encrypted = enc.encrypt_sensitive_data({'sn': 'SN123'})
            >>> print(encrypted)
            'gAAAAABhZ...'
        """
        plaintext = json.dumps(data, ensure_ascii=False, default=str)
        ciphertext = self.cipher.encrypt(plaintext.encode('utf-8'))
        return base64.b64encode(ciphertext).decode('utf-8')
    
    def decrypt_sensitive_data(self, encrypted_data: str) -> Dict[str, Any]:
        """解密敏感数据
        
        Args:
            encrypted_data: Base64 编码的加密字符串
        
        Returns:
            解密后的字典
        
        Raises:
            DecryptionError: 解密失败时抛出
        
        Example:
            >>> enc = EncryptionService()
            >>> decrypted = enc.decrypt_sensitive_data('gAAAAABhZ...')
            >>> print(decrypted)
            {'sn': 'SN123'}
        """
        try:
            ciphertext = base64.b64decode(encrypted_data.encode('utf-8'))
            plaintext = self.cipher.decrypt(ciphertext).decode('utf-8')
            return json.loads(plaintext)
        except Exception as e:
            raise DecryptionError(f"解密失败：{e}")
    
    def hash_password(self, password: str) -> str:
        """密码哈希 (bcrypt)
        
        Args:
            password: 明文密码
        
        Returns:
            bcrypt 哈希字符串
        
        Example:
            >>> enc = EncryptionService()
            >>> hashed = enc.hash_password('MyPassword123')
            >>> print(hashed)
            '$2b$12$...'
        """
        import bcrypt
        salt = bcrypt.gensalt(rounds=12)
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """验证密码
        
        Args:
            password: 明文密码
            hashed: bcrypt 哈希字符串
        
        Returns:
            验证是否通过
        
        Example:
            >>> enc = EncryptionService()
            >>> hashed = enc.hash_password('MyPassword123')
            >>> enc.verify_password('MyPassword123', hashed)
            True
        """
        import bcrypt
        return bcrypt.checkpw(
            password.encode('utf-8'),
            hashed.encode('utf-8')
        )
    
    def generate_encryption_key(self) -> str:
        """生成新的加密密钥
        
        Returns:
            Base64 编码的 32 字节密钥
        
        Example:
            >>> enc = EncryptionService()
            >>> key = enc.generate_encryption_key()
            >>> print(key)
            'abcdefghijklmnopqrstuvwxyz1234567890ABCDEF='
        """
        return Fernet.generate_key().decode()


# 全局加密服务实例
_encryption_service: Optional[EncryptionService] = None


def get_encryption_service() -> EncryptionService:
    """获取全局加密服务实例"""
    global _encryption_service
    if _encryption_service is None:
        _encryption_service = EncryptionService()
    return _encryption_service


def encrypt_data(data: Dict[str, Any]) -> str:
    """便捷函数：加密数据"""
    return get_encryption_service().encrypt_sensitive_data(data)


def decrypt_data(encrypted: str) -> Dict[str, Any]:
    """便捷函数：解密数据"""
    return get_encryption_service().decrypt_sensitive_data(encrypted)


def hash_password(password: str) -> str:
    """便捷函数：密码哈希"""
    return get_encryption_service().hash_password(password)


def verify_password(password: str, hashed: str) -> bool:
    """便捷函数：验证密码"""
    return get_encryption_service().verify_password(password, hashed)


# 命令行工具
if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python encryption.py <command> [args]")
        print("命令:")
        print("  generate-key          生成新密钥")
        print("  encrypt <json>        加密数据")
        print("  decrypt <encrypted>   解密数据")
        print("  hash <password>       密码哈希")
        print("  verify <pass> <hash>  验证密码")
        sys.exit(1)
    
    service = EncryptionService()
    command = sys.argv[1]
    
    if command == 'generate-key':
        key = service.generate_encryption_key()
        print(f"新密钥：{key}")
        print(f"请设置环境变量：export ENCRYPTION_KEY='{key}'")
    
    elif command == 'encrypt':
        if len(sys.argv) < 3:
            print("错误：请提供 JSON 数据")
            sys.exit(1)
        data = json.loads(sys.argv[2])
        encrypted = service.encrypt_sensitive_data(data)
        print(f"加密结果：{encrypted}")
    
    elif command == 'decrypt':
        if len(sys.argv) < 3:
            print("错误：请提供加密字符串")
            sys.exit(1)
        decrypted = service.decrypt_sensitive_data(sys.argv[2])
        print(f"解密结果：{decrypted}")
    
    elif command == 'hash':
        if len(sys.argv) < 3:
            print("错误：请提供密码")
            sys.exit(1)
        hashed = service.hash_password(sys.argv[2])
        print(f"哈希结果：{hashed}")
    
    elif command == 'verify':
        if len(sys.argv) < 4:
            print("错误：请提供密码和哈希值")
            sys.exit(1)
        result = service.verify_password(sys.argv[2], sys.argv[3])
        print(f"验证结果：{'通过' if result else '失败'}")
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
