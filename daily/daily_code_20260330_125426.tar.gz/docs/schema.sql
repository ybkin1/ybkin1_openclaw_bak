-- =====================================================
-- 智能运维团队数据库表结构
-- =====================================================
-- 数据库：PostgreSQL 14+
-- 字符集：UTF-8
-- 创建日期：2026-03-30
-- =====================================================

-- ==================== 扩展 ====================

-- UUID 扩展
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 时间戳扩展
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==================== 基础表 ====================

-- 租户表
CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL DEFAULT 'internal', -- internal/customer
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- active/inactive/suspended
    config JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- 索引
    INDEX idx_tenants_status (status),
    INDEX idx_tenants_type (type)
);

-- 用户表
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255),
    hashed_password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL, -- operations/marketing/management/etc
    permissions JSONB DEFAULT '[]',
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- active/inactive/locked
    last_login_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- 索引
    INDEX idx_users_tenant (tenant_id),
    INDEX idx_users_username (username),
    INDEX idx_users_status (status),
    INDEX idx_users_role (role),
    
    -- 约束
    CONSTRAINT chk_user_status CHECK (status IN ('active', 'inactive', 'locked'))
);

-- 令牌黑名单表 (用于令牌撤销)
CREATE TABLE token_blacklist (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_jti VARCHAR(255) NOT NULL UNIQUE, -- JWT ID
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- 索引
    INDEX idx_token_blacklist_jti (token_jti),
    INDEX idx_token_blacklist_expires (expires_at)
);

-- ==================== 故障管理表 ====================

-- 故障案例表
CREATE TABLE fault_cases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    case_number VARCHAR(100) NOT NULL UNIQUE, -- FA-2026-000001
    server_id VARCHAR(100),
    status VARCHAR(50) NOT NULL DEFAULT 'pending', -- pending/analyzing/reviewing/completed/closed
    priority VARCHAR(20) DEFAULT 'medium', -- low/medium/high/critical
    title VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- 分析结果
    analysis_result JSONB DEFAULT '{}',
    root_cause TEXT,
    solution TEXT,
    recommendations JSONB DEFAULT '[]',
    
    -- 敏感数据 (加密存储)
    sensitive_data_encrypted BYTEA,
    
    -- 审计字段
    created_by UUID REFERENCES users(id),
    assigned_to UUID REFERENCES users(id),
    reviewed_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    
    -- 索引
    INDEX idx_fault_cases_tenant (tenant_id),
    INDEX idx_fault_cases_status (status),
    INDEX idx_fault_cases_created (created_at DESC),
    INDEX idx_fault_cases_case_number (case_number),
    INDEX idx_fault_cases_server (server_id),
    
    -- 约束
    CONSTRAINT chk_case_status CHECK (status IN ('pending', 'analyzing', 'reviewing', 'completed', 'closed')),
    CONSTRAINT chk_case_priority CHECK (priority IN ('low', 'medium', 'high', 'critical'))
);

-- 故障日志文件表
CREATE TABLE fault_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fault_case_id UUID NOT NULL REFERENCES fault_cases(id) ON DELETE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(50), -- bmc/system/other
    file_size BIGINT NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_hash VARCHAR(64), -- SHA-256
    is_sensitive BOOLEAN DEFAULT FALSE,
    sensitive_items JSONB DEFAULT '[]',
    uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- 索引
    INDEX idx_fault_logs_case (fault_case_id),
    INDEX idx_fault_logs_type (file_type)
);

-- 审批流程表
CREATE TABLE approvals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fault_case_id UUID NOT NULL REFERENCES fault_cases(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL, -- fault_report/sensitive_data_export/uncertain_question
    status VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending/approved/rejected
    approver_id UUID REFERENCES users(id),
    comments TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    decided_at TIMESTAMP WITH TIME ZONE,
    
    -- 索引
    INDEX idx_approvals_case (fault_case_id),
    INDEX idx_approvals_status (status),
    INDEX idx_approvals_approver (approver_id),
    
    -- 约束
    CONSTRAINT chk_approval_status CHECK (status IN ('pending', 'approved', 'rejected'))
);

-- ==================== 报告表 ====================

-- 报告表
CREATE TABLE reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    fault_case_id UUID NOT NULL REFERENCES fault_cases(id) ON DELETE CASCADE,
    report_number VARCHAR(100) NOT NULL UNIQUE, -- RPT-2026-000001
    content TEXT NOT NULL,
    format VARCHAR(20) DEFAULT 'html', -- html/pdf/json
    status VARCHAR(20) NOT NULL DEFAULT 'draft', -- draft/pending_review/approved/published
    file_path VARCHAR(500),
    file_size BIGINT,
    
    -- 反馈评价
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    feedback TEXT,
    feedback_categories JSONB DEFAULT '{}',
    
    -- 审计字段
    created_by UUID REFERENCES users(id),
    reviewed_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    published_at TIMESTAMP WITH TIME ZONE,
    
    -- 索引
    INDEX idx_reports_case (fault_case_id),
    INDEX idx_reports_status (status),
    INDEX idx_reports_created (created_at DESC),
    INDEX idx_reports_rating (rating),
    
    -- 约束
    CONSTRAINT chk_report_status CHECK (status IN ('draft', 'pending_review', 'approved', 'published')),
    CONSTRAINT chk_report_rating CHECK (rating IS NULL OR (rating >= 1 AND rating <= 5))
);

-- ==================== 工单表 ====================

-- 工单表
CREATE TABLE tickets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    ticket_number VARCHAR(100) NOT NULL UNIQUE, -- TKT-2026-000001
    type VARCHAR(50) NOT NULL, -- fault_report/document_request/data_extraction/etc
    status VARCHAR(20) NOT NULL DEFAULT 'open', -- open/in_progress/pending_customer/resolved/closed
    priority VARCHAR(20) DEFAULT 'medium',
    title VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- 关联
    fault_case_id UUID REFERENCES fault_cases(id),
    
    -- 审计字段
    created_by UUID REFERENCES users(id),
    assigned_to UUID REFERENCES users(id),
    closed_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    closed_at TIMESTAMP WITH TIME ZONE,
    
    -- 索引
    INDEX idx_tickets_tenant (tenant_id),
    INDEX idx_tickets_status (status),
    INDEX idx_tickets_created (created_at DESC),
    INDEX idx_tickets_assigned (assigned_to),
    
    -- 约束
    CONSTRAINT chk_ticket_status CHECK (status IN ('open', 'in_progress', 'pending_customer', 'resolved', 'closed')),
    CONSTRAINT chk_ticket_priority CHECK (priority IN ('low', 'medium', 'high', 'critical'))
);

-- 工单评论表
CREATE TABLE ticket_comments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_id UUID NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    content TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT FALSE, -- 是否仅内部可见
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- 索引
    INDEX idx_ticket_comments_ticket (ticket_id),
    INDEX idx_ticket_comments_user (user_id)
);

-- ==================== 知识表 ====================

-- 知识库表
CREATE TABLE knowledge_base (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE, -- NULL 表示共享知识
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(50), -- fault_case/best_practice/sop/product_info
    tags JSONB DEFAULT '[]',
    is_public BOOLEAN DEFAULT FALSE, -- 是否对客户公开
    view_count INTEGER DEFAULT 0,
    useful_count INTEGER DEFAULT 0,
    
    -- 审计字段
    created_by UUID REFERENCES users(id),
    reviewed_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- 索引
    INDEX idx_knowledge_tenant (tenant_id),
    INDEX idx_knowledge_category (category),
    INDEX idx_knowledge_tags USING GIN (tags),
    INDEX idx_knowledge_public (is_public)
);

-- ==================== 审计表 ====================

-- 审计日志表
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL, -- create/read/update/delete/approve/export
    resource_type VARCHAR(50) NOT NULL, -- fault_case/report/user/sensitive_data
    resource_id UUID,
    result VARCHAR(20) NOT NULL, -- success/failure
    ip_address INET,
    user_agent TEXT,
    details JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- 索引
    INDEX idx_audit_logs_tenant (tenant_id),
    INDEX idx_audit_logs_user (user_id),
    INDEX idx_audit_logs_action (action),
    INDEX idx_audit_logs_resource (resource_type, resource_id),
    INDEX idx_audit_logs_created (created_at DESC),
    INDEX idx_audit_logs_result (result)
);

-- SLA 违例表
CREATE TABLE sla_violations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    task_id UUID NOT NULL,
    task_type VARCHAR(50) NOT NULL,
    tenant_id UUID REFERENCES tenants(id),
    violated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    elapsed_time DOUBLE PRECISION NOT NULL, -- 秒
    sla_timeout DOUBLE PRECISION NOT NULL, -- 秒
    reason TEXT,
    notified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- 索引
    INDEX idx_sla_violations_task (task_id),
    INDEX idx_sla_violations_tenant (tenant_id),
    INDEX idx_sla_violations_created (created_at DESC)
);

-- ==================== 视图 ====================

-- 故障案例统计视图
CREATE VIEW fault_case_stats AS
SELECT
    tenant_id,
    status,
    priority,
    COUNT(*) as case_count,
    AVG(EXTRACT(EPOCH FROM (completed_at - created_at))) as avg_resolution_seconds
FROM fault_cases
WHERE completed_at IS NOT NULL
GROUP BY tenant_id, status, priority;

-- 用户活动视图
CREATE VIEW user_activity_stats AS
SELECT
    u.id as user_id,
    u.username,
    u.role,
    COUNT(DISTINCT fc.id) as cases_handled,
    COUNT(DISTINCT r.id) as reports_created,
    COUNT(DISTINCT t.id) as tickets_handled,
    MAX(u.last_login_at) as last_login
FROM users u
LEFT JOIN fault_cases fc ON u.id = fc.assigned_to
LEFT JOIN reports r ON u.id = r.created_by
LEFT JOIN tickets t ON u.id = t.assigned_to
GROUP BY u.id, u.username, u.role;

-- ==================== 触发器 ====================

-- 自动更新 updated_at 触发器
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 为需要自动更新的表添加触发器
CREATE TRIGGER update_tenants_updated_at
    BEFORE UPDATE ON tenants
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_fault_cases_updated_at
    BEFORE UPDATE ON fault_cases
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tickets_updated_at
    BEFORE UPDATE ON tickets
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_knowledge_base_updated_at
    BEFORE UPDATE ON knowledge_base
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ==================== 初始数据 ====================

-- 插入默认租户
INSERT INTO tenants (id, name, type, status) VALUES
    ('00000000-0000-0000-0000-000000000001', '默认租户', 'internal', 'active');

-- 插入测试用户 (密码：Admin123!)
INSERT INTO users (id, tenant_id, username, email, hashed_password, role, status) VALUES
    ('00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000001', 'admin', 'admin@example.com',
     '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYzS3MebAJu', 'admin', 'active');

-- ==================== 权限 ====================

-- 创建应用用户
CREATE USER app_user WITH PASSWORD 'YourSecurePassword123!';

-- 授予权限
GRANT CONNECT ON DATABASE fault_analysis TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;

-- ==================== 备注 ====================

-- 密码哈希说明:
-- 默认密码 Admin123! 的 bcrypt 哈希 (rounds=12)
-- 生产环境请修改默认密码

-- 敏感数据加密说明:
-- sensitive_data_encrypted 字段存储 AES-256 加密的数据
-- 加密密钥通过环境变量 ENCRYPTION_KEY 管理
-- 解密需要相应权限 (SENSITIVE_VIEW)

-- 性能优化建议:
-- 1. 定期清理 audit_logs (保留 90 天)
-- 2. 定期清理 token_blacklist (过期令牌)
-- 3. 为 fault_cases 添加分区 (按 created_at)
-- 4. 监控慢查询并添加适当索引
