# 数据库记忆架构设计

**版本**: v1.0  
**创建日期**: 2026-04-01  
**状态**: ✅ 设计完成

---

## 🎯 架构目标

1. **分离存储**：customer-service 的记忆写入数据库，而非 memory/ 文件系统
2. **结构化**：用户信息、会话记录、工单数据、知识库分别存储
3. **权限隔离**：飞书（内部）和企业微信（外部）的数据访问隔离
4. **可查询**：支持按用户、时间、主题快速检索

---

## 📊 整体架构

```
┌────────────────────────────────────────────────────────────────┐
│                     应用层 (Agents)                            │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌──────────────┐              ┌────────────────────┐         │
│  │   master     │              │ customer-service   │         │
│  │  (飞书)      │              │   (企业微信)       │         │
│  └──────┬───────┘              └─────────┬──────────┘         │
│         │                                │                     │
│         └──────────┬─────────────────────┘                     │
│                    ↓                                           │
│         ┌──────────────────────┐                              │
│         │  database-manager    │                              │
│         │  (统一数据访问层)    │                              │
│         └──────────┬───────────┘                              │
│                    ↓                                           │
├────────────────────────────────────────────────────────────────┤
│                     数据存储层                                 │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │   SQLite     │  │   LanceDB    │  │   文件系统   │        │
│  │  结构化数据  │  │  向量索引    │  │  大文件存储  │        │
│  │              │  │              │  │              │        │
│  │ • 用户信息   │  │ • 知识文档   │  │ • 图片       │        │
│  │ • 会话记录   │  │ • 语义检索   │  │ • 日志       │        │
│  │ • 工单数据   │  │ • 案例库     │  │ • 视频       │        │
│  │ • 产品知识   │  │ • 故障库     │  │ • 压缩包     │        │
│  └──────────────┘  └──────────────┘  └──────────────┘        │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

---

## 🗄️ 数据库表设计

### 1. 用户信息表 (users)

```sql
CREATE TABLE users (
    user_id TEXT PRIMARY KEY,
    
    -- 基本信息
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    company TEXT,
    
    -- 权限控制
    user_type TEXT NOT NULL CHECK (user_type IN ('internal', 'maintenance', 'regular')),
    org_id TEXT,  -- 租户 ID（内部员工所属部门）
    permission_level INTEGER DEFAULT 1,  -- 1=普通，2=维保，3=内部
    
    -- 渠道信息
    channel TEXT NOT NULL CHECK (channel IN ('feishu', 'wecom')),
    channel_user_id TEXT NOT NULL,  -- 飞书/企业微信用户 ID
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active_at TIMESTAMP,
    
    -- 软删除
    deleted_at TIMESTAMP NULL,
    
    -- 索引
    UNIQUE(channel, channel_user_id)
);

CREATE INDEX idx_users_type ON users(user_type);
CREATE INDEX idx_users_org ON users(org_id);
CREATE INDEX idx_users_channel ON users(channel, channel_user_id);
```

**字段说明**:
- `user_type`: 
  - `internal`: 内部员工（可访问所有信息）
  - `maintenance`: 维保客户（可访问维保内容）
  - `regular`: 普通客户（仅基础支持）

---

### 2. 会话记录表 (conversations)

```sql
CREATE TABLE conversations (
    conversation_id TEXT PRIMARY KEY,
    
    -- 关联信息
    user_id TEXT NOT NULL REFERENCES users(user_id),
    channel TEXT NOT NULL,
    
    -- 会话内容
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content TEXT NOT NULL,
    
    -- 上下文
    parent_message_id TEXT,  -- 父消息 ID（用于对话树）
    thread_id TEXT,  -- 会话线程 ID
    
    -- 元数据
    metadata JSON DEFAULT '{}',  -- 结构化数据（如意图、实体）
    tokens_used INTEGER DEFAULT 0,
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 软删除
    deleted_at TIMESTAMP NULL
);

CREATE INDEX idx_conversations_user ON conversations(user_id);
CREATE INDEX idx_conversations_channel ON conversations(channel);
CREATE INDEX idx_conversations_created ON conversations(created_at);
CREATE INDEX idx_conversations_thread ON conversations(thread_id);

-- 分区表（按月）
CREATE TABLE conversations_2026_04 AS 
SELECT * FROM conversations WHERE 1=0;  -- 空表结构
```

**字段说明**:
- `metadata`: 存储提取的结构化信息
  ```json
  {
    "intent": "fault_analysis",
    "entities": {
      "server_model": "M4",
      "fault_type": "GPU_overheat"
    },
    "sentiment": "urgent"
  }
  ```

---

### 3. 工单表 (tickets)

```sql
CREATE TABLE tickets (
    ticket_id TEXT PRIMARY KEY,
    
    -- 关联信息
    user_id TEXT NOT NULL REFERENCES users(user_id),
    assigned_to TEXT,  -- 处理人 user_id
    
    -- 工单内容
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'pending' 
      CHECK (status IN ('pending', 'confirmed', 'in_progress', 'reviewing', 'completed', 'cancelled')),
    priority INTEGER DEFAULT 2 CHECK (priority BETWEEN 1 AND 5),  -- 1=紧急，5=低
    
    -- 分类
    category TEXT,  -- fault/consultation/upgrade/other
    subcategory TEXT,
    
    -- 处理过程
    solution TEXT,  -- 解决方案
    resolution_time INTEGER,  -- 解决时长（分钟）
    
    -- 元数据
    metadata JSON DEFAULT '{}',
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confirmed_at TIMESTAMP,  -- 用户确认时间
    started_at TIMESTAMP,    -- 开始处理时间
    completed_at TIMESTAMP,  -- 完成时间
    
    -- 软删除
    deleted_at TIMESTAMP NULL
);

CREATE INDEX idx_tickets_user ON tickets(user_id);
CREATE INDEX idx_tickets_status ON tickets(status);
CREATE INDEX idx_tickets_created ON tickets(created_at);
CREATE INDEX idx_tickets_assigned ON tickets(assigned_to);

-- 工单评论表
CREATE TABLE ticket_comments (
    comment_id TEXT PRIMARY KEY,
    ticket_id TEXT NOT NULL REFERENCES tickets(ticket_id),
    user_id TEXT NOT NULL REFERENCES users(user_id),
    content TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT FALSE,  -- 内部备注（不对外显示）
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

### 4. 用户记忆表 (user_memories)

```sql
CREATE TABLE user_memories (
    memory_id TEXT PRIMARY KEY,
    
    -- 关联信息
    user_id TEXT NOT NULL REFERENCES users(user_id),
    
    -- 记忆内容
    memory_type TEXT NOT NULL CHECK (memory_type IN ('fact', 'preference', 'context', 'emotion')),
    subject TEXT NOT NULL,  -- 主题（如：server_preference, contact_info）
    predicate TEXT,  -- 关系（如：prefers, has, likes）
    object TEXT,  -- 内容（如：M4 servers, 13800000000）
    
    -- 置信度
    confidence REAL DEFAULT 1.0 CHECK (confidence BETWEEN 0 AND 1),
    
    -- 验证状态
    verified BOOLEAN DEFAULT FALSE,
    verified_by TEXT,
    verified_at TIMESTAMP,
    
    -- 来源
    source_conversation_id TEXT REFERENCES conversations(conversation_id),
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at TIMESTAMP,
    access_count INTEGER DEFAULT 0,
    
    -- 软删除
    deleted_at TIMESTAMP NULL
);

CREATE INDEX idx_memories_user ON user_memories(user_id);
CREATE INDEX idx_memories_type ON user_memories(memory_type);
CREATE INDEX idx_memories_subject ON user_memories(subject);

-- 记忆验证日志
CREATE TABLE memory_verification_log (
    log_id TEXT PRIMARY KEY,
    memory_id TEXT NOT NULL REFERENCES user_memories(memory_id),
    action TEXT NOT NULL CHECK (action IN ('created', 'verified', 'rejected', 'updated', 'deleted')),
    actor_id TEXT,  -- 执行者 user_id
    old_value TEXT,
    new_value TEXT,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**字段说明**:
- `memory_type`:
  - `fact`: 事实（如：用户有 3 台 M4 服务器）
  - `preference`: 偏好（如：喜欢简洁的回复）
  - `context`: 上下文（如：正在进行故障分析）
  - `emotion`: 情绪（如：用户很着急）

---

### 5. 知识库表 (knowledge_base)

```sql
CREATE TABLE knowledge_base (
    knowledge_id TEXT PRIMARY KEY,
    
    -- 分类
    category TEXT NOT NULL,  -- product/fault/case/guideline
    subcategory TEXT,
    
    -- 内容
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    content_type TEXT CHECK (content_type IN ('text', 'markdown', 'json')),
    
    -- 向量索引
    vector_id TEXT,  -- LanceDB 向量 ID
    
    -- 权限控制
    min_permission_level INTEGER DEFAULT 1,  -- 最小访问权限
    user_types TEXT,  -- JSON 数组：["internal", "maintenance"]
    
    -- 版本管理
    version INTEGER DEFAULT 1,
    parent_knowledge_id TEXT,  -- 父版本 ID
    
    -- 质量评分
    quality_score REAL DEFAULT 0.0,  -- 0-5 分
    usage_count INTEGER DEFAULT 0,
    
    -- 元数据
    metadata JSON DEFAULT '{}',
    tags TEXT,  -- 逗号分隔的标签
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- 软删除
    deleted_at TIMESTAMP NULL
);

CREATE INDEX idx_knowledge_category ON knowledge_base(category, subcategory);
CREATE INDEX idx_knowledge_permission ON knowledge_base(min_permission_level);
CREATE INDEX idx_knowledge_tags ON knowledge_base(tags);

-- 知识库使用日志
CREATE TABLE knowledge_usage_log (
    log_id TEXT PRIMARY KEY,
    knowledge_id TEXT NOT NULL REFERENCES knowledge_base(knowledge_id),
    user_id TEXT NOT NULL REFERENCES users(user_id),
    action TEXT NOT NULL CHECK (action IN ('viewed', 'used', 'rated')),
    rating INTEGER,  -- 1-5 分
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**字段说明**:
- `category`:
  - `product`: 产品知识（服务器型号、配置）
  - `fault`: 故障库（常见故障及解决方案）
  - `case`: 案例库（历史工单案例）
  - `guideline`: 操作指南（升级流程、维护规范）

---

### 6. 数据访问日志表 (access_logs)

```sql
CREATE TABLE access_logs (
    log_id TEXT PRIMARY KEY,
    
    -- 访问者
    user_id TEXT NOT NULL REFERENCES users(user_id),
    agent_id TEXT NOT NULL,  -- 调用 agent
    
    -- 访问对象
    table_name TEXT NOT NULL,
    record_id TEXT,
    action TEXT NOT NULL CHECK (action IN ('create', 'read', 'update', 'delete')),
    
    -- 访问结果
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    
    -- 审计信息
    ip_address TEXT,
    channel TEXT,
    
    -- 时间戳
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_access_user ON access_logs(user_id);
CREATE INDEX idx_access_table ON access_logs(table_name, record_id);
CREATE INDEX idx_access_created ON access_logs(created_at);

-- 自动清理：保留 90 天
CREATE TRIGGER cleanup_old_access_logs
AFTER INSERT ON access_logs
BEGIN
    DELETE FROM access_logs 
    WHERE created_at < datetime('now', '-90 days');
END;
```

---

## 🔐 权限控制矩阵

| 表 | internal | maintenance | regular | 说明 |
|----|----------|-------------|---------|------|
| users | ✅ 全部 | ✅ 脱敏 | ✅ 自身 | 内部可见全部，维保脱敏，普通仅自身 |
| conversations | ✅ 全部 | ✅ 自身 | ✅ 自身 | 会话记录隔离 |
| tickets | ✅ 全部 | ✅ 全部 | ✅ 自身 | 工单可见性 |
| user_memories | ✅ 全部 | ✅ 自身 | ✅ 自身 | 记忆隔离 |
| knowledge_base | ✅ 全部 | ✅ 维保级 | ✅ 基础级 | 知识库分级 |
| access_logs | ✅ 全部 | ❌ | ❌ | 仅内部可见 |

---

## 🚀 customer-service 数据流

### 场景 1: 新用户首次咨询

```
1. 用户发送消息
   ↓
2. customer-service 识别新用户
   ↓
3. 调用 database-manager:
   db_create('users', {
     user_id: 'ou_xxx',
     name: '张三',
     user_type: 'regular',
     channel: 'wecom',
     channel_user_id: 'ou_xxx'
   })
   ↓
4. 创建会话记录:
   db_create('conversations', {
     user_id: 'ou_xxx',
     role: 'user',
     content: '服务器报错了...',
     metadata: {intent: 'fault_analysis'}
   })
   ↓
5. 创建工单:
   db_create('tickets', {
     user_id: 'ou_xxx',
     title: '服务器故障分析',
     status: 'pending',
     category: 'fault'
   })
```

### 场景 2: 提取用户记忆

```
1. 对话中用户提供信息：
   "我有 3 台 M4 服务器，主要用于 AI 训练"
   
2. customer-service 提取记忆:
   db_create('user_memories', {
     user_id: 'ou_xxx',
     memory_type: 'fact',
     subject: 'server_assets',
     predicate: 'owns',
     object: '3x M4 servers for AI training',
     source_conversation_id: 'conv_xxx',
     confidence: 0.95
   })
   
3. 后续对话可查询:
   db_query('user_memories', {
     user_id: 'ou_xxx',
     subject: 'server_assets'
   })
```

### 场景 3: 知识库检索

```
1. 用户问题：
   "M4 服务器 GPU 过热怎么处理？"
   
2. customer-service 检索知识库:
   db_query('knowledge_base', {
     category: 'fault',
     subcategory: 'gpu_overheat',
     min_permission_level: 1  -- 用户权限
   })
   
3. 同时检索 LanceDB 向量:
   lancedb_search(
     query: "M4 GPU 过热 解决方案",
     filter: {user_type: ['internal', 'maintenance']}
   )
   
4. 整合答案返回用户
```

---

## 📝 实施步骤

### Phase 1: 数据库初始化（本周）

1. **创建表结构**
   ```bash
   /root/.openclaw/workspace/agents/database-manager/scripts/init-schema.sql
   ```

2. **迁移现有数据**
   - 从 memory/ 文件迁移用户信息
   - 从工单系统迁移历史工单

3. **测试 CRUD 接口**
   - database-manager 提供标准 API
   - customer-service 调用测试

### Phase 2: customer-service 集成（下周）

1. **修改 AGENT_RULES.md**
   - 明确记忆写入数据库
   - 禁止写入 memory/ 文件系统

2. **实现数据提取逻辑**
   - 从对话中提取结构化信息
   - 自动创建 user_memories

3. **工单流程对接**
   - 工单创建 → database-manager
   - 工单状态更新 → database-manager

### Phase 3: 知识库建设（2 周）

1. **导入产品知识**
   - 服务器型号、配置
   - 常见故障及解决方案

2. **构建向量索引**
   - 文档分块
   - LanceDB 向量化

3. **权限配置**
   - 内部 vs 外部可见性
   - 用户等级过滤

---

## 🔍 查询示例

### 查询用户完整信息

```sql
SELECT 
  u.*,
  COUNT(DISTINCT t.ticket_id) as total_tickets,
  COUNT(DISTINCT CASE WHEN t.status = 'completed' THEN t.ticket_id END) as completed_tickets,
  COUNT(DISTINCT c.conversation_id) as total_conversations
FROM users u
LEFT JOIN tickets t ON u.user_id = t.user_id
LEFT JOIN conversations c ON u.user_id = c.user_id
WHERE u.user_id = 'ou_xxx'
GROUP BY u.user_id;
```

### 查询用户记忆

```sql
SELECT 
  memory_type,
  subject,
  predicate,
  object,
  confidence,
  verified,
  created_at
FROM user_memories
WHERE user_id = 'ou_xxx'
  AND deleted_at IS NULL
  AND (verified = TRUE OR confidence >= 0.8)
ORDER BY 
  verified DESC,
  confidence DESC,
  created_at DESC;
```

### 查询工单统计

```sql
SELECT 
  status,
  COUNT(*) as count,
  AVG(resolution_time) as avg_resolution_minutes
FROM tickets
WHERE user_id = 'ou_xxx'
  AND created_at >= datetime('now', '-30 days')
GROUP BY status;
```

### 检索相关知识库

```sql
SELECT 
  kb.*,
  ul.rating as user_rating,
  ul.usage_count
FROM knowledge_base kb
LEFT JOIN (
  SELECT knowledge_id, AVG(rating) as rating, COUNT(*) as usage_count
  FROM knowledge_usage_log
  GROUP BY knowledge_id
) ul ON kb.knowledge_id = ul.knowledge_id
WHERE kb.category = 'fault'
  AND kb.min_permission_level <= (
    SELECT permission_level FROM users WHERE user_id = 'ou_xxx'
  )
ORDER BY 
  kb.quality_score DESC,
  ul.rating DESC,
  kb.usage_count DESC
LIMIT 5;
```

---

## 📊 监控指标

| 指标 | 说明 | 告警阈值 |
|------|------|---------|
| 数据库大小 | SQLite 文件大小 | > 1GB |
| 会话记录增长 | 每日新增会话数 | > 1000/天 |
| 记忆验证率 | verified/total 比率 | < 50% |
| 工单解决率 | completed/total 比率 | < 80% |
| 知识库使用率 | usage_count/total 比率 | < 10% |
| 查询响应时间 | P95 查询延迟 | > 500ms |

---

## 🔒 安全机制

### 1. 数据隔离

- **渠道隔离**: wecom 用户无法访问 feishu 数据
- **用户隔离**: 每个用户只能访问自己的数据
- **权限隔离**: 用户等级决定可见范围

### 2. 审计日志

- 所有数据库操作记录到 `access_logs`
- 敏感操作（delete、update）记录旧值和新值
- 日志保留 90 天

### 3. 软删除

- 所有表使用 `deleted_at` 字段
- 查询自动过滤 `deleted_at IS NULL`
- 支持数据恢复

---

## 📁 文件位置

| 文件 | 路径 |
|------|------|
| 数据库 Schema | `/root/.openclaw/workspace/agents/database-manager/scripts/init-schema.sql` |
| 数据库文件 | `/root/.openclaw/workspace/agents/database-manager/data/customer-service.db` |
| 架构文档 | `/root/.openclaw/workspace/agents/master/memory/config/database-memory-architecture.md` |
| customer-service 规则 | `/root/.openclaw/workspace/agents/customer-service/AGENT_RULES.md` |

---

## 📅 审查周期

- **每日**: 检查数据库增长、错误日志
- **每周**: 审查记忆验证率、工单解决率
- **每月**: 优化查询性能、清理过期数据

---

**批准**: 俞斌  
**设计**: master agent  
**执行**: database-manager + customer-service
