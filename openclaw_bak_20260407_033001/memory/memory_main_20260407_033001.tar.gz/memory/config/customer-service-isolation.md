# 会话隔离架构 - 飞书 vs 企业微信

**版本**: v2.0（简化方案 - 不依赖 bindings）  
**创建日期**: 2026-04-01  
**状态**: ✅ 生产就绪

---

## 核心设计

**渠道路由 + Agent 自律** = 权限隔离

```
飞书 → channels.feishu.defaultAccount = "default" → master agent
企业微信 → channels.wecom.defaultAccount = "customer-service" → customer-service agent
```

**权限限制**：通过 `customer-service/AGENT_RULES.md` 定义红线（不依赖 config）

---

## 架构图

```
┌────────────────────────────────────────────────────────────┐
│                    OpenClaw Gateway                        │
└────────────────────────────────────────────────────────────┘
        │                            │
        ▼                            ▼
┌──────────────────┐      ┌─────────────────────┐
│  飞书渠道         │      │  企业微信渠道        │
│  default=default │      │  default=customer-  │
│                  │      │       service       │
└──────────────────┘      └─────────────────────┘
        │                            │
        ▼                            ▼
┌──────────────────┐      ┌─────────────────────┐
│  master agent    │      │  customer-service   │
│  (主控)          │      │  (智能客服)         │
│                  │      │                     │
│  ✅ 完整权限     │      │  ❌ 禁止修改配置    │
│  ✅ 可调用所有   │      │  ✅ 仅调用 3 个 agent │
│  ✅ 可写 memory/ │      │  ✅ 数据写入数据库  │
└──────────────────┘      └─────────────────────┘
```

---

## 权限对比

| 能力 | 飞书 (master) | 企业微信 (customer-service) |
|------|---------------|----------------------------|
| 读取配置 | ✅ | ✅ |
| 修改配置 | ✅ | ❌ |
| 执行命令 | ✅ | ⚠️ (仅诊断) |
| 写入 memory/ | ✅ | ❌ |
| 写入数据库 | ✅ | ✅ |
| 调用 agent | 全部 | 3 个授权 |
| 创建工单 | 可选 | 强制 |

---

## customer-service 授权 Agent

```
customer-service
    ├── ✅ database-manager    (数据查询与存储)
    ├── ✅ file-processor      (文件解析与日志处理)
    └── ✅ server-maintenance  (故障分析与诊断报告)
```

**禁止调用**: master、assistant、backup、monitoring、analysis、memory-manager

---

## 配置位置

| 文件 | 路径 |
|------|------|
| 渠道配置 | `/root/.openclaw/openclaw.json` |
| 权限规则 | `/root/.openclaw/workspace/agents/customer-service/AGENT_RULES.md` |
| 权限边界 | `/root/.openclaw/workspace/agents/customer-service/docs/permission-boundary.md` |
| 架构文档 | `/root/.openclaw/workspace/agents/master/memory/config/customer-service-isolation.md` |

---

## 验证方法

```bash
# 1. 检查渠道配置
jq '.channels.wecom.defaultAccount' /root/.openclaw/openclaw.json
# 输出："customer-service"

# 2. 检查 Gateway 状态
openclaw gateway status
# 输出：Runtime: running

# 3. 检查 agent 规则
grep -A5 "禁止操作" /root/.openclaw/workspace/agents/customer-service/AGENT_RULES.md
```

---

## 安全机制

1. **工单强制**：所有企业微信请求必须创建工单
2. **审计日志**：记录到 `customer-service-audit.log`
3. **违规检测**：检测配置修改、未授权调用

---

## 变更记录

| 版本 | 日期 | 变更 | 说明 |
|------|------|------|------|
| v1.0 | 2026-04-01 | 使用 bindings | 导致 config invalid ❌ |
| v2.0 | 2026-04-01 | 移除 bindings | 改用 channel defaultAccount + AGENT_RULES.md ✅ |

---

**批准**: 俞斌  
**执行**: 所有 agent  
**审查**: 每月 1 日
