# 🤖 File Agent 自动化工作流完整方案

**版本**: 1.0.0  
**创建日期**: 2026-03-30  
**状态**: ✅ 生产就绪

---

## 📋 工作流总览

| 工作流 | 触发条件 | 执行内容 | 频率 |
|--------|----------|----------|------|
| CI/CD 流水线 | 代码提交/PR | 测试 + 构建 + 部署 | 实时 |
| 代码质量检查 | 每次提交 | flake8/black/isort/pylint | 实时 |
| 单元测试 | 每次提交 | pytest + 覆盖率 | 实时 |
| 集成测试 | 单元测试通过后 | 场景测试 + E2E | 实时 |
| 性能基准 | 定时/手动 | 性能测试 + 回归检查 | 每日 |
| 自动部署 | main 分支推送 | 部署 + 健康检查 | 实时 |
| 监控告警 | 持续运行 | 指标收集 + 告警 | 持续 |

---

## 🔄 工作流 1: CI/CD 流水线

### 配置文件
`.github/workflows/ci-cd-pipeline.yml`

### 执行流程

```
代码提交
    ↓
┌─────────────────┐
│ 1. 代码质量检查 │
│ - flake8        │
│ - black         │
│ - isort         │
│ - pylint        │
└────────┬────────┘
         ↓
┌─────────────────┐
│ 2. 单元测试     │
│ - pytest        │
│ - 覆盖率检查    │
│ - 覆盖率报告    │
└────────┬────────┘
         ↓
┌─────────────────┐
│ 3. 集成测试     │
│ - 场景测试      │
│ - E2E 测试       │
└────────┬────────┘
         ↓
┌─────────────────┐
│ 4. 性能测试     │
│ - 基准测试      │
│ - 回归检查      │
└────────┬────────┘
         ↓
┌─────────────────┐
│ 5. 自动部署     │
│ - 部署脚本      │
│ - 健康检查      │
│ - 创建标签      │
└────────┬────────┘
         ↓
┌─────────────────┐
│ 6. 通知报告     │
│ - 结果通知      │
│ - 报告生成      │
└─────────────────┘
```

### 门禁条件

| 检查项 | 通过条件 | 失败动作 |
|--------|----------|----------|
| 代码质量 | pylint ≥ 7.0 | 阻止合并 |
| 单元测试 | 通过率 100% | 阻止合并 |
| 覆盖率 | ≥ 85% | 阻止合并 |
| 集成测试 | 通过率 100% | 阻止合并 |
| 性能回归 | < 20% 下降 | 告警 |

---

## 🧪 工作流 2: 测试自动化

### 测试分类

```
tests/
├── unit/                    # 单元测试 (70%)
│   ├── test_*.py           # 各模块测试
│   └── ...
├── integration/             # 集成测试 (25%)
│   ├── test_real_scenarios.py
│   └── ...
└── benchmark/               # 性能测试 (5%)
    ├── test_performance.py
    └── ...
```

### 测试执行命令

```bash
# 快速测试 (开发时)
pytest tests/ -m "not slow" -v

# 完整测试 (CI/CD)
pytest tests/ -v --cov=src --cov-fail-under=85

# 集成测试 (发布前)
pytest tests/integration/ -v

# 性能测试 (定期)
pytest tests/benchmark/ -v --benchmark-only
```

### 覆盖率检查脚本

`scripts/generate_coverage_report.py`

```bash
# 生成覆盖率报告
python scripts/generate_coverage_report.py coverage.xml -o coverage-report.txt

# CI/CD 中自动执行
pytest tests/ --cov=src --cov-report=xml
python scripts/generate_coverage_report.py coverage.xml
```

---

## ⚡ 工作流 3: 性能基准自动化

### 性能基线配置

| 测试项 | 基线 (ms) | 回归阈值 |
|--------|-----------|----------|
| 小日志解析 (1MB) | 100 | 20% |
| 中日志解析 (10MB) | 500 | 20% |
| 大日志解析 (100MB) | 3000 | 20% |
| 并行处理 | 1000 | 20% |
| 流式处理 | 2000 | 20% |

### 性能回归检查脚本

`scripts/check_performance_regression.py`

```bash
# 运行性能测试
pytest tests/benchmark/ -v --benchmark-only --benchmark-json=benchmark.json

# 检查回归
python scripts/check_performance_regression.py benchmark.json -o performance-report.txt
```

### 性能趋势图

```
性能趋势 (ms, 越低越好):

test_small_log_parsing:
Week 1: ████████ 95ms
Week 2: ███████ 90ms ↓
Week 3: █████████ 105ms ↑
Week 4: ████████ 98ms ↓
```

---

## 🚀 工作流 4: 自动部署

### 部署脚本

`deploy-auto.sh` (增强版)

```bash
# 自动部署
./deploy-auto.sh

# 健康检查
./deploy-auto.sh health-check

# 回滚
./deploy-auto.sh rollback
```

### 部署流程

```
1. 前置检查
   ├── Python 版本检查
   ├── pip 检查
   └── 磁盘空间检查

2. 备份现有版本
   ├── 创建备份目录
   ├── 复制当前安装
   └── 清理旧备份 (>5 个)

3. 安装依赖
   ├── 升级 pip
   ├── 安装 pytest
   └── 检查可选依赖

4. 运行测试
   ├── 单元测试
   └── 失败则回滚

5. 健康检查
   ├── CLI 工具检查
   ├── 核心模块检查
   └── 快速测试

6. 创建符号链接
   └── file-agent 命令
```

### 部署验证

```bash
# 验证 CLI
file-agent --version
file-agent --help

# 验证核心功能
file-agent analyze test.log -o test-report.html

# 验证批量处理
file-agent batch *.log -o reports/
```

---

## 📊 工作流 5: 监控告警

### 监控脚本

`scripts/monitor.py`

```bash
# 启动监控
python scripts/monitor.py start

# 检查状态
python scripts/monitor.py check

# 查看历史指标
python scripts/monitor.py metrics
```

### 监控指标

| 指标 | 告警阈值 | 检查频率 |
|------|----------|----------|
| CPU 使用率 | > 80% | 60 秒 |
| 内存使用 | > 85% | 60 秒 |
| 磁盘使用 | > 90% | 60 秒 |
| 错误率 | > 5% | 60 秒 |
| 响应时间 | > 5000ms | 60 秒 |
| 服务健康 | 失败 | 60 秒 |

### 告警通知

| 渠道 | 配置 | 状态 |
|------|------|------|
| 邮件 | SMTP 配置 | ⏳ 待配置 |
| Webhook | URL 配置 | ⏳ 待配置 |
| 日志 | 本地文件 | ✅ 已启用 |

### 监控面板

```
File Agent 监控面板
========================================
系统资源:
  CPU:    45% ████████░░░░░░░░░░░░░
  内存：1.2GB ██████░░░░░░░░░░░░░░░
  磁盘：65% ███████████░░░░░░░░░░░

服务健康:
  CLI:    ✅ 正常
  模块：  ✅ 正常
  测试：  ✅ 正常

错误统计:
  错误数：12
  错误率：0.02%
  最后错误：2026-03-30 08:15:23
========================================
```

---

## 📁 文件清单

### CI/CD 配置

| 文件 | 用途 | 位置 |
|------|------|------|
| ci-cd-pipeline.yml | 主流水线 | .github/workflows/ |
| check_performance_regression.py | 性能回归检查 | scripts/ |
| generate_coverage_report.py | 覆盖率报告 | scripts/ |
| monitor.py | 监控告警 | scripts/ |
| deploy-auto.sh | 自动部署 | 根目录 |

### 测试配置

| 文件 | 用途 | 位置 |
|------|------|------|
| pytest.ini | pytest 配置 | 根目录 |
| .coveragerc | 覆盖率配置 | 根目录 |
| conftest.py | 测试夹具 | tests/ |

### 文档

| 文件 | 用途 | 位置 |
|------|------|------|
| AUTOMATION-WORKFLOW.md | 本文档 | memory/config/ |
| DEPLOYMENT.md | 部署指南 | docs/ |
| MONITORING.md | 监控指南 | docs/ |

---

## 🔧 配置指南

### 1. GitHub Actions 配置

```yaml
# 在仓库设置中启用 Actions
Settings → Actions → General → Allow all actions
```

### 2. 覆盖率检查配置

```ini
# .coveragerc
[run]
source = src
omit = 
    tests/*
    */__init__.py

[report]
fail_under = 85
show_missing = True
```

### 3. 监控配置

```python
# scripts/monitor.py 配置
CONFIG = {
    'check_interval': 60,  # 检查间隔 (秒)
    'thresholds': {
        'cpu_percent': 80,
        'memory_percent': 85,
        'disk_percent': 90,
    },
    'notifications': {
        'email': {'enabled': False},
        'webhook': {'enabled': False},
    }
}
```

### 4. 部署配置

```bash
# 环境变量
export INSTALL_DIR=/opt/file-agent
export BACKUP_DIR=/opt/file-agent-backups
export LOG_FILE=/var/log/file-agent-deploy.log
```

---

## 📊 执行计划

### 立即执行 (本周)

| 任务 | 负责人 | 状态 |
|------|--------|------|
| 配置 GitHub Actions | 运维 | ⏳ 待执行 |
| 安装 pytest-benchmark | 运维 | ⏳ 待执行 |
| 配置覆盖率检查 | 运维 | ⏳ 待执行 |
| 测试部署脚本 | 运维 | ⏳ 待执行 |

### 短期改进 (本月)

| 任务 | 负责人 | 状态 |
|------|--------|------|
| 配置邮件告警 | 运维 | ⏳ 待执行 |
| 配置 Webhook 通知 | 运维 | ⏳ 待执行 |
| 建立性能基线 | 运维 | ⏳ 待执行 |
| 配置监控面板 | 运维 | ⏳ 待执行 |

### 长期规划 (下季度)

| 任务 | 负责人 | 状态 |
|------|--------|------|
| 混沌工程测试 | 开发 | ⏳ 规划中 |
| 安全测试集成 | 安全 | ⏳ 规划中 |
| 自动化回滚 | 运维 | ⏳ 规划中 |

---

## 🎯 成功标准

| 指标 | 目标 | 当前状态 |
|------|------|----------|
| CI/CD 通过率 | 100% | ⏳ 待配置 |
| 测试覆盖率 | ≥85% | ✅ 85%+ |
| 部署成功率 | 100% | ⏳ 待验证 |
| 平均部署时间 | <5 分钟 | ⏳ 待测量 |
| 故障恢复时间 | <10 分钟 | ⏳ 待测量 |
| 告警响应时间 | <5 分钟 | ⏳ 待配置 |

---

## 📞 联系与支持

| 角色 | 职责 | 联系方式 |
|------|------|----------|
| 开发负责人 | 代码质量 | GitHub Issues |
| 运维负责人 | 部署监控 | 内部 IM |
| 安全负责人 | 安全测试 | 内部邮件 |

---

**文档状态**: ✅ 完成  
**最后更新**: 2026-03-30  
**维护者**: 喵小白 (Master Agent)
