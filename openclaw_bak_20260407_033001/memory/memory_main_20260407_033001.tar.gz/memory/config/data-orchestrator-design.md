# 数据调度器设计方案

**设计时间**: 2026-03-31 09:15  
**设计师**: 喵小白 (Master Agent)  
**版本**: v1.0

---

## 📋 设计目标

### 核心目标
1. **自动化任务执行**: 解决 task-executor.sh 未被调用的问题
2. **防 AI 幻觉**: 集成验证机制，确保汇报基于真实进展
3. **多层监督**: 心跳、进度、健康检查三层防御
4. **可扩展**: 支持未来新增任务类型和 Agent

### 设计原则
- **验证优先**: 所有状态变更必须基于可验证证据
- **自动化**: 减少人工干预，自动化监控和恢复
- **透明**: 所有操作记录日志，可追溯可审计
- **容错**: 单点故障不影响整体系统

---

## 🏗️ 架构设计

### 整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                     数据调度器 (Orchestrator)                │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  任务发现器  │  │  状态验证器  │  │  资源管理器  │      │
│  │  (Finder)    │  │  (Validator) │  │  (Manager)   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  执行引擎    │  │  监控中心    │  │  告警系统    │      │
│  │  (Engine)    │  │  (Monitor)   │  │  (Alerter)   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
        ▼                   ▼                   ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│ Subagent 池   │  │  任务存储     │  │  日志系统     │
│ - assistant   │  │  - active/    │  │  - 操作日志   │
│ - analysis    │  │  - paused/    │  │  - 审计日志   │
│ - database    │  │  - completed/ │  │  - 错误日志   │
└───────────────┘  └───────────────┘  └───────────────┘
```

---

## 🔧 核心模块设计

### 模块 1: 任务发现器 (Task Finder)

**职责**: 发现需要执行的任务

**输入**: 
- 任务目录 (`memory/tasks/active/*.json`)
- 任务状态过滤器

**输出**:
- 待执行任务列表
- 任务优先级排序

**逻辑**:
```python
def find_tasks():
    tasks = []
    for task_file in active_dir.glob("*.json"):
        task = load_task(task_file)
        
        # 过滤条件
        if task.status != "in_progress":
            continue
        if task.is_suspected_zombie():
            continue
        if task.has_agent_running():
            continue
            
        tasks.append(task)
    
    # 按优先级排序
    return sorted(tasks, key=lambda t: t.priority, reverse=True)
```

---

### 模块 2: 状态验证器 (State Validator)

**职责**: 验证任务状态真实性（防 AI 幻觉）

**验证项**:
1. **Checkpoint 验证**: 检查最近 3 条记录是否有真实进展
2. **输出文件验证**: 检查 `output_files` 是否存在
3. **Git 提交验证**: 检查是否有相关 Git 提交
4. **进度合理性**: 检查进度百分比与时间匹配度

**逻辑**:
```python
def validate_task(task):
    checks = {
        "checkpoint": check_checkpoint(task),
        "output_files": check_output_files(task),
        "git_commits": check_git_commits(task),
        "progress_reasonable": check_progress(task)
    }
    
    # 所有检查必须通过
    is_valid = all(checks.values())
    
    if not is_valid:
        log_hallucination_alert(task, checks)
    
    return is_valid, checks
```

**验证清单**:
```markdown
- [ ] checkpoint 最近 3 条记录包含真实进展（非"等待中"）
- [ ] 所有 output_files 存在
- [ ] 过去 24 小时有 Git 提交（如适用）
- [ ] 进度百分比与已用时间匹配（±20% 容差）
- [ ] 状态与最后活动时间一致（<30 分钟）
```

---

### 模块 3: 资源管理器 (Resource Manager)

**职责**: 管理 Subagent 并发和资源分配

**功能**:
1. **并发控制**: 限制同时运行的 Subagent 数量（默认 3 个）
2. **资源配额**: CPU、内存、磁盘使用限制
3. **优先级队列**: 高优先级任务优先执行
4. **冷却机制**: 失败任务冷却期（5 分钟）

**配置**:
```yaml
concurrency:
  max_subagents: 3
  max_per_task: 1
  
resources:
  cpu_limit: 80%
  memory_limit: 4GB
  disk_limit: 10GB
  
queue:
  priority_levels: [P0, P1, P2, P3]
  cooldown_minutes: 5
```

---

### 模块 4: 执行引擎 (Execution Engine)

**职责**: 启动和管理 Subagent 执行

**流程**:
```
1. 从队列获取任务
2. 验证任务状态
3. 分配资源
4. 启动 Subagent
5. 监控执行
6. 更新状态
7. 记录日志
```

**伪代码**:
```python
def execute_task(task):
    # 1. 验证
    is_valid, checks = validate_task(task)
    if not is_valid:
        mark_as_hallucination(task)
        return False
    
    # 2. 分配资源
    if not resource_manager.allocate(task):
        return False
    
    # 3. 启动 Subagent
    pid = launch_subagent(task)
    
    # 4. 监控
    while is_running(pid):
        update_heartbeat(task)
        sleep(300)  # 5 分钟
    
    # 5. 更新状态
    update_task_status(task, "completed")
    
    return True
```

---

### 模块 5: 监控中心 (Monitor Center)

**职责**: 实时监控任务和系统健康

**监控项**:
| 指标 | 阈值 | 动作 |
|------|------|------|
| 任务无心跳 | >5 分钟 | 记录警告 |
| 任务无进展 | >30 分钟 | 标记疑似僵尸 |
| 任务超时 | >预估时间 50% | 发送告警 |
| Subagent 崩溃 | 任何 | 自动重启（最多 3 次） |
| 系统资源 | CPU>90% 或 内存>85% | 暂停新任务 |

**仪表盘**:
```
任务执行概览:
├── 活跃任务：3
├── 等待中：5
├── 已完成 (今日): 12
└── 僵尸任务：0

系统资源:
├── CPU: 45%
├── 内存：3.2GB / 8GB
└── 磁盘：120GB / 500GB
```

---

### 模块 6: 告警系统 (Alert System)

**告警级别**:
| 级别 | 条件 | 通知方式 |
|------|------|---------|
| **INFO** | 任务完成、状态变更 | 日志 |
| **WARN** | 进度延迟、资源紧张 | 日志 + 飞书 |
| **ERROR** | 任务失败、AI 幻觉 | 日志 + 飞书 + 邮件 |
| **CRITICAL** | 系统故障、数据丢失 | 日志 + 飞书 + 邮件 + 短信 |

**告警冷却**:
- 同一任务相同告警：1 小时内不重复
- 系统级告警：5 分钟内不重复

---

## 📁 文件结构

```
/root/.openclaw/workspace/agents/master/scripts/
├── orchestrator/
│   ├── __init__.py
│   ├── main.py                 # 主入口
│   ├── task_finder.py          # 任务发现器
│   ├── state_validator.py      # 状态验证器
│   ├── resource_manager.py     # 资源管理器
│   ├── execution_engine.py     # 执行引擎
│   ├── monitor.py              # 监控中心
│   └── alerter.py              # 告警系统
│
├── cron/
│   ├── orchestrator.cron       # Cron 配置
│   ├── install_cron.sh         # 安装脚本
│   └── health_check.sh         # 健康检查
│
└── config/
    ├── orchestrator.yaml       # 配置文件
    └── alert_rules.yaml        # 告警规则
```

---

## ⏰ Cron 配置

### 安装脚本 (`install_cron.sh`)

```bash
#!/bin/bash
# 安装数据调度器 Cron 配置

CRON_FILE="/etc/cron.d/data-orchestrator"

cat > "$CRON_FILE" <<'EOF'
# 数据调度器 - Cron 配置
# 安装时间：$(date)

# 主调度器 - 每 5 分钟执行一次
*/5 * * * * root /root/.openclaw/workspace/agents/master/scripts/orchestrator/main.py >> /root/.openclaw/logs/orchestrator.log 2>&1

# 心跳检查 - 每分钟执行一次
* * * * * root /root/.openclaw/workspace/agents/master/scripts/task-heartbeat.sh >> /root/.openclaw/logs/task-heartbeat.log 2>&1

# 进度汇报 - 每 10 分钟执行一次
*/10 * * * * root /root/.openclaw/workspace/agents/master/scripts/task-progress-reporter.sh >> /root/.openclaw/logs/progress-reporter.log 2>&1

# 僵尸检测 - 每 10 分钟执行一次
*/10 * * * * root /root/.openclaw/workspace/agents/master/scripts/zombie-task-detector.sh >> /root/.openclaw/logs/zombie-detector.log 2>&1

# AI 幻觉检测 - 每 30 分钟执行一次
*/30 * * * * root /root/.openclaw/workspace/agents/master/scripts/ai-hallucination-detector.sh >> /root/.openclaw/logs/ai-hallucination.log 2>&1

# 健康检查 - 每周一 09:00 执行
0 9 * * 1 root /root/.openclaw/workspace/agents/master/scripts/task-health-check.sh >> /root/.openclaw/logs/health-check.log 2>&1
EOF

chmod 644 "$CRON_FILE"
echo "✅ Cron 配置已安装：$CRON_FILE"
```

---

## 🧪 测试计划

### 单元测试
- [ ] 任务发现器：验证过滤逻辑
- [ ] 状态验证器：验证各项检查
- [ ] 资源管理器：验证并发控制
- [ ] 执行引擎：验证 Subagent 启动
- [ ] 监控中心：验证指标采集
- [ ] 告警系统：验证告警触发

### 集成测试
- [ ] 完整任务执行流程
- [ ] AI 幻觉检测与处理
- [ ] 僵尸任务恢复
- [ ] 跨天暂停与恢复
- [ ] 系统故障恢复

### 压力测试
- [ ] 100 个并发任务
- [ ] 长时间运行（24 小时+）
- [ ] 资源限制场景
- [ ] 网络中断恢复

---

## 📊 实施计划

| 阶段 | 任务 | 预计时间 | 优先级 |
|------|------|---------|--------|
| **阶段 1** | 核心模块开发 | 60 分钟 | P0 |
| **阶段 2** | Cron 配置安装 | 10 分钟 | P0 |
| **阶段 3** | AI 幻觉检测器 | 20 分钟 | P0 |
| **阶段 4** | 监控仪表盘 | 30 分钟 | P1 |
| **阶段 5** | 测试与验证 | 30 分钟 | P1 |
| **阶段 6** | 文档更新 | 10 分钟 | P2 |

---

## ✅ 验收标准

### P0 验收标准
- [ ] 调度器每 5 分钟自动执行
- [ ] 任务状态验证通过后才汇报
- [ ] AI 幻觉能被自动检测
- [ ] 僵尸任务能被自动标记
- [ ] 所有操作有日志记录

### P1 验收标准
- [ ] 监控仪表盘可用
- [ ] 告警系统正常工作
- [ ] 健康检查每周执行
- [ ] 所有测试通过

---

## 📝 经验教训

### 设计原则
1. **验证优先**: 所有状态变更必须基于可验证证据
2. **多层防御**: 单一监控点会失效，需要多层验证
3. **自动化**: 减少人工干预，但保留人工覆盖能力
4. **透明**: 所有操作可追溯可审计

### 避免的陷阱
1. ❌ 不要只更新时间戳而不验证进展
2. ❌ 不要依赖单一监控机制
3. ❌ 不要忽略日志和审计
4. ❌ 不要过度设计，保持简单

---

**设计完成时间**: 2026-03-31 09:15  
**下次审查**: 2026-04-07 (周一)
