# AI 幻觉根因分析与任务跟踪优化方案

**分析时间**: 2026-03-31 09:05  
**分析师**: 喵小白 (Master Agent)  
**问题类型**: P0 系统性缺陷

---

## 🔍 问题描述

**现象**: 数据库底座开发任务（task_20260327_221600_database_dev）产生 AI 幻觉，虚报任务进度

**具体表现**:
- 任务 JSON 状态显示 `in_progress`
- Checkpoint 文件显示"等待中"（持续数天）
- 实际脚本已创建但未执行
- 进度汇报机制未检测到异常

---

## 🧬 根因分析（5 Why 法）

### Why 1: 为什么任务进度是虚假的？
**答**: 因为 checkpoint 文件只记录心跳时间，不验证实际进展

**证据**:
```bash
# task-heartbeat.sh 只更新时间戳，不验证进度
jq --arg time "$current_time" '.lastActivity = $time' "$task_file"
echo "{\"timestamp\": \"$current_time\", \"progress\": null, \"step\": \"等待中\"}" >> checkpoint
```

---

### Why 2: 为什么心跳机制不验证实际进展？
**答**: 因为心跳脚本设计目标是"防止误判僵尸"，而非"验证真实进度"

**代码位置**: `task-heartbeat.sh:60-70`
```bash
# 只更新时间戳，progress 从任务 JSON 读取（可能过时）
current_progress=$(jq -r '.progress' "$task_file" 2>/dev/null || echo "0")
current_step=$(jq -r '.currentStep // "等待中"' "$task_file" 2>/dev/null || echo "等待中")
```

---

### Why 3: 为什么进度汇报机制未检测到异常？
**答**: 因为进度汇报只计算时间流逝，不验证 checkpoint 内容

**代码位置**: `task-progress-reporter.sh:40-60`
```bash
# 只检查时间是否到达 1/3、2/3 阈值
if [ $elapsed_minutes -ge $report_1_3 ]; then
    generate_report "$task_file" "1/3_progress"
fi
```

**缺陷**: 汇报生成不检查 checkpoint 是否有实际进展

---

### Why 4: 为什么任务执行脚本未实际调用？
**答**: 因为 task-executor.sh 没有调度器定期调用

**证据**:
```bash
# task-executor.sh 存在但无 cron 配置
$ grep -r "task-executor.sh" /var/spool/cron/*  # 无结果
```

**设计缺陷**:
- ✅ 脚本已创建（task-executor.sh, subagent-launcher.py）
- ❌ 无调度器调用这些脚本
- ❌ 无验证机制确保脚本被执行

---

### Why 5: 为什么系统性缺陷未被提前发现？
**答**: 因为缺少任务状态健康检查机制

**缺失的监控**:
1. ❌ 无 checkpoint 内容验证
2. ❌ 无脚本执行日志审计
3. ❌ 无任务进度与时间匹配度检查
4. ❌ 无 AI 幻觉检测机制

---

## 📋 缺陷清单

| 缺陷类型 | 位置 | 严重性 | 影响 |
|---------|------|--------|------|
| **心跳机制缺陷** | task-heartbeat.sh | 🔴 P0 | 无法区分真实进展与虚假心跳 |
| **进度汇报缺陷** | task-progress-reporter.sh | 🔴 P0 | 汇报不验证实际进展 |
| **任务执行缺陷** | task-executor.sh | 🔴 P0 | 脚本存在但未被调用 |
| **调度器缺失** | crontab | 🔴 P0 | 无自动化任务执行 |
| **健康检查缺失** | 全局 | 🟡 P1 | 无法提前发现问题 |
| **AI 幻觉检测缺失** | 全局 | 🟡 P1 | 无法识别虚假进度 |

---

## 🛠️ 优化方案

### 方案 1: 心跳机制增强（P0 - 立即执行）

**目标**: 心跳必须包含真实进展验证

**修改文件**: `task-heartbeat.sh`

**新增逻辑**:
```bash
# 1. 检查 checkpoint 最后 3 条记录
check_checkpoint_progress() {
    local checkpoint_file="${task_file%.json}.checkpoint"
    
    # 读取最近 3 条记录
    local recent=$(tail -3 "$checkpoint_file" 2>/dev/null)
    
    # 检查是否都是"等待中"
    local wait_count=$(echo "$recent" | grep -c '"step": "等待中"' || echo "0")
    
    if [ "$wait_count" -eq 3 ]; then
        log_warn "⚠️ 任务可能卡死：$task_name (连续 3 次心跳无进展)"
        
        # 标记为疑似僵尸
        jq '.status = "suspected_zombie" | .suspectedAt = "'$(date -Iseconds)'"' \
           "$task_file" > "${task_file}.tmp" && mv "${task_file}.tmp" "$task_file"
        
        return 1
    fi
    
    return 0
}

# 2. 检查输出文件是否存在
check_output_files() {
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    
    for file in $output_files; do
        if [ ! -f "$file" ]; then
            log_warn "⚠️ 输出文件不存在：$file"
            return 1
        fi
    done
    
    return 0
}
```

---

### 方案 2: 进度汇报验证增强（P0 - 立即执行）

**目标**: 汇报前必须验证实际进展

**修改文件**: `task-progress-reporter.sh`

**新增逻辑**:
```bash
# 汇报前强制验证
validate_before_report() {
    local task_file="$1"
    local checkpoint_file="${task_file%.json}.checkpoint"
    
    # 1. 检查 checkpoint 是否有实际进展
    local has_progress=false
    if [ -f "$checkpoint_file" ]; then
        # 检查是否有非"等待中"的记录
        if grep -q '"step": "等待中"' "$checkpoint_file"; then
            local total=$(wc -l < "$checkpoint_file")
            local wait_count=$(grep -c '"step": "等待中"' "$checkpoint_file")
            
            if [ "$total" -eq "$wait_count" ]; then
                log_error "❌ 拒绝汇报：checkpoint 全是等待中"
                return 1
            fi
        fi
        has_progress=true
    fi
    
    # 2. 检查输出文件
    if ! check_output_files "$task_file"; then
        log_error "❌ 拒绝汇报：输出文件缺失"
        return 1
    fi
    
    # 3. 检查 Git 提交（如适用）
    if [ -d ".git" ]; then
        local task_id=$(basename "$task_file" .json)
        local commits=$(git log --oneline --since="24 hours ago" -- "*${task_id}*" 2>/dev/null | wc -l)
        
        if [ "$commits" -eq 0 ]; then
            log_warn "⚠️ 无 Git 提交：$task_id"
            # 不阻止汇报，但记录警告
        fi
    fi
    
    return 0
}
```

---

### 方案 3: 任务执行调度器（P0 - 立即执行）

**目标**: 确保 task-executor.sh 定期执行

**新增文件**: `/etc/cron.d/task-executor`

```bash
# 每 5 分钟执行一次任务检查
*/5 * * * * root /root/.openclaw/workspace/agents/master/scripts/task-executor.sh >> /root/.openclaw/logs/task-executor.log 2>&1

# 每分钟检查一次心跳
* * * * * root /root/.openclaw/workspace/agents/master/scripts/task-heartbeat.sh >> /root/.openclaw/logs/task-heartbeat.log 2>&1

# 每 10 分钟检查一次进度汇报
*/10 * * * * root /root/.openclaw/workspace/agents/master/scripts/task-progress-reporter.sh >> /root/.openclaw/logs/progress-reporter.log 2>&1

# 每 10 分钟检查一次僵尸任务
*/10 * * * * root /root/.openclaw/workspace/agents/master/scripts/zombie-task-detector.sh >> /root/.openclaw/logs/zombie-detector.log 2>&1
```

---

### 方案 4: AI 幻觉检测机制（P1 - 今天执行）

**目标**: 自动识别虚假进度汇报

**新增文件**: `scripts/ai-hallucination-detector.sh`

```bash
#!/bin/bash
# AI 幻觉检测器 - 识别虚假任务进度

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
LOG_FILE="/root/.openclaw/logs/ai-hallucination-detector.log"

detect_hallucination() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    local checkpoint_file="${task_file%.json}.checkpoint"
    
    # 1. 检查 checkpoint 是否全是"等待中"
    if [ -f "$checkpoint_file" ]; then
        local total=$(wc -l < "$checkpoint_file")
        local wait_count=$(grep -c '"step": "等待中"' "$checkpoint_file" || echo "0")
        
        if [ "$total" -gt 5 ] && [ "$total" -eq "$wait_count" ]; then
            log_warn "🧠 AI 幻觉检测：$task_id (checkpoint 全是等待中)"
            return 1
        fi
    fi
    
    # 2. 检查输出文件是否存在
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    for file in $output_files; do
        if [ ! -f "$file" ]; then
            log_warn "🧠 AI 幻觉检测：$task_id (输出文件缺失：$file)"
            return 1
        fi
    done
    
    # 3. 检查进度百分比是否合理
    local progress=$(jq -r '.progress // 0' "$task_file")
    local status=$(jq -r '.status' "$task_file")
    
    if [ "$progress" -gt 90 ] && [ "$status" = "in_progress" ]; then
        log_warn "🧠 AI 幻觉检测：$task_id (进度>90% 但未完成)"
        return 1
    fi
    
    return 0
}

# 主循环
for task_file in "$TASKS_DIR"/*.json; do
    [ -f "$task_file" ] || continue
    detect_hallucination "$task_file"
done
```

---

### 方案 5: 任务状态健康检查（P1 - 每周执行）

**目标**: 定期审计任务状态健康度

**新增文件**: `scripts/task-health-check.sh`

**检查项**:
1. ✅ checkpoint 内容合理性
2. ✅ 输出文件存在性
3. ✅ Git 提交记录
4. ✅ 进度与时间匹配度
5. ✅ 状态与进展一致性

**执行频率**: 每周一 09:00

---

## 📊 实施计划

| 阶段 | 任务 | 预计时间 | 优先级 |
|------|------|---------|--------|
| **阶段 1** | 心跳机制增强 | 15 分钟 | P0 |
| **阶段 2** | 进度汇报验证增强 | 15 分钟 | P0 |
| **阶段 3** | 任务执行调度器配置 | 10 分钟 | P0 |
| **阶段 4** | AI 幻觉检测器 | 20 分钟 | P1 |
| **阶段 5** | 健康检查脚本 | 20 分钟 | P1 |
| **阶段 6** | 文档更新与培训 | 10 分钟 | P2 |

---

## ✅ 验收标准

### P0 验收标准
- [ ] 心跳机制能检测连续 3 次无进展
- [ ] 进度汇报前强制验证 checkpoint
- [ ] cron 调度器配置完成并生效
- [ ] 数据库底座任务状态正确更新

### P1 验收标准
- [ ] AI 幻觉检测器能识别虚假进度
- [ ] 健康检查脚本每周自动执行
- [ ] 所有历史任务完成状态审查

---

## 📝 经验教训

### 核心教训
1. **心跳≠进展**: 心跳只能证明任务"活着"，不能证明"在前进"
2. **验证优先**: 所有汇报必须基于可验证的证据（文件、Git 提交、日志）
3. **自动化监督**: 不能依赖人工检查，必须自动化监控
4. **多层防御**: 单一监控点会失效，需要多层验证机制

### 规则更新
**新增规则**: 
1. 所有任务汇报必须附带验证清单（文件存在、Git 提交、日志记录）
2. checkpoint 必须记录真实进展，不能只记录心跳
3. 每周执行一次任务健康检查
4. AI 幻觉检测器每周至少运行一次

---

**报告生成时间**: 2026-03-31 09:05  
**下次审查**: 2026-04-07 (周一)
