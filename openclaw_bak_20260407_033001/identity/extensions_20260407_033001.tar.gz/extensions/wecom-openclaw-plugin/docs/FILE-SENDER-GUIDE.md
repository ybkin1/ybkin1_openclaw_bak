# 企业微信文件发送功能 - 使用指南

**版本**: v1.0  
**创建时间**: 2026-03-31  
**状态**: 待配置

---

## 📋 目录

1. [功能概述](#1-功能概述)
2. [配置要求](#2-配置要求)
3. [使用方法](#3-使用方法)
4. [集成到智能客服 Agent](#4-集成到智能客服-agent)
5. [API 参考](#5-api 参考)
6. [故障排查](#6-故障排查)

---

## 1. 功能概述

**企业微信文件发送功能**允许通过企业微信机器人发送文件给用户，支持：

- ✅ 文件消息（PDF、Word、Excel 等）
- ✅ 图片消息（JPG、PNG、GIF 等）
- ✅ 语音消息（AMR、MP3）
- ✅ 不修改 openclaw.json 配置
- ✅ 独立模块实现

---

## 2. 配置要求

### 2.1 必要配置

| 配置项 | 说明 | 获取方式 |
|--------|------|---------|
| **corp_id** | 企业微信企业 ID | 企业微信管理后台 → 我的企业 → 企业信息 |
| **agent_id** | 应用 ID | 应用管理 → 机器人 → 查看 |
| **secret** | 应用 Secret | 应用管理 → 机器人 → 查看 |
| **default_user_id** | 默认接收用户 ID | 可选，企业微信用户 ID |

### 2.2 配置文件

**创建配置文件**: `/root/.openclaw/extensions/wecom-openclaw-plugin/config/file_sender.json`

```json
{
  "enabled": true,
  "corp_id": "wwxxxxxxxxxxxxx",
  "agent_id": "1000001",
  "secret": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
  "default_user_id": "user123",
  "file_size_limit_mb": 20,
  "allowed_file_types": ["pdf", "doc", "docx", "xls", "xlsx", "jpg", "png"]
}
```

---

## 3. 使用方法

### 3.1 命令行使用

```bash
# 发送文件
python3 /root/.openclaw/extensions/wecom-openclaw-plugin/src/file_sender.py \
  <corp_id> \
  <agent_id> \
  <secret> \
  <user_id> \
  <file_path>

# 示例
python3 /root/.openclaw/extensions/wecom-openclaw-plugin/src/file_sender.py \
  ww123456 \
  1000001 \
  abc123xyz \
  user123 \
  /tmp/report.pdf
```

### 3.2 Python 代码使用

```python
from wecom_openclaw_plugin.src.file_integration import WeComFileIntegration

# 配置
config = {
    'corp_id': 'ww123456',
    'agent_id': '1000001',
    'secret': 'abc123xyz',
    'default_user_id': 'user123'
}

# 初始化
integration = WeComFileIntegration(config)

# 发送文件
result = integration.handle_file_request(
    user_message='请查收报告',
    file_path='/tmp/report.pdf',
    user_id='user123'
)

if result['success']:
    print(f"✅ 文件发送成功：{result['file_name']}")
else:
    print(f"❌ 发送失败：{result['message']}")
```

### 3.3 通过智能客服 Agent 使用

**用户发送消息**:
```
发送文件 /tmp/report.pdf 给用户 user123
```

**智能客服 Agent 处理流程**:
1. 识别文件发送意图
2. 调用 WeComFileIntegration
3. 上传文件到企业微信素材库
4. 发送文件消息
5. 返回发送结果

---

## 4. 集成到智能客服 Agent

### 4.1 创建 Agent 工具

**文件**: `/root/.openclaw/workspace/agents/customer-service/tools/wecom_file_sender.py`

```python
#!/usr/bin/env python3
"""
智能客服 Agent - 企业微信文件发送工具
"""

import sys
sys.path.insert(0, '/root/.openclaw/extensions/wecom-openclaw-plugin/src')

from file_integration import WeComFileIntegration

# 加载配置
import json
with open('/root/.openclaw/extensions/wecom-openclaw-plugin/config/file_sender.json', 'r') as f:
    config = json.load(f)

integration = WeComFileIntegration(config)

def send_file(file_path: str, user_id: str = None) -> dict:
    """发送文件"""
    return integration.handle_file_request('', file_path, user_id)

# Agent 工具定义
TOOL_DEFINITION = {
    'name': 'wecom_send_file',
    'description': '通过企业微信发送文件给用户',
    'parameters': {
        'type': 'object',
        'properties': {
            'file_path': {
                'type': 'string',
                'description': '文件路径'
            },
            'user_id': {
                'type': 'string',
                'description': '接收用户 ID（可选）'
            }
        },
        'required': ['file_path']
    }
}
```

### 4.2 Agent 意图识别

**关键词路由**:
```python
FILE_SEND_KEYWORDS = [
    '发送文件', '发文件', '传文件',
    '发送 PDF', '发送 Word', '发送 Excel',
    '发给我', '传给我'
]

def is_file_send_intent(message: str) -> bool:
    """判断是否是文件发送意图"""
    return any(kw in message for kw in FILE_SEND_KEYWORDS)
```

---

## 5. API 参考

### 5.1 WeComFileSender

```python
class WeComFileSender:
    def __init__(self, corp_id: str, agent_id: str, secret: str)
    
    def get_access_token() -> Optional[str]
        """获取访问令牌"""
    
    def upload_file(file_path: str, file_type: str = 'file') -> Optional[str]
        """上传文件到素材库，返回 media_id"""
    
    def send_file_message(user_id: str, file_path: str, file_type: str = 'file') -> bool
        """发送文件消息"""
    
    def send_image_message(user_id: str, image_path: str) -> bool
        """发送图片消息"""
```

### 5.2 WeComFileIntegration

```python
class WeComFileIntegration:
    def __init__(self, config: Dict[str, Any])
    
    def handle_file_request(
        user_message: str,
        file_path: str,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]
        """处理文件发送请求"""
    
    def get_config_status() -> Dict[str, Any]
        """获取配置状态"""
```

---

## 6. 故障排查

### 6.1 常见问题

| 问题 | 可能原因 | 解决方案 |
|------|---------|---------|
| **获取 token 失败** | corp_id 或 secret 错误 | 检查企业微信后台配置 |
| **文件上传失败** | 文件超过 20MB | 压缩文件或分批发送 |
| **发送失败** | 用户 ID 不存在 | 检查企业微信通讯录 |
| **配置不完整** | 缺少必要配置项 | 创建 file_sender.json 配置文件 |

### 6.2 日志查看

```bash
# 查看文件发送日志
tail -f /root/.openclaw/logs/wecom_file_sender.log
```

### 6.3 测试工具

```bash
# 测试配置
python3 /root/.openclaw/extensions/wecom-openclaw-plugin/src/file_integration.py

# 测试发送
python3 /root/.openclaw/extensions/wecom-openclaw-plugin/src/file_sender.py \
  <corp_id> <agent_id> <secret> <user_id> <file_path>
```

---

## 7. 文件限制

| 类型 | 大小限制 | 有效期 |
|------|---------|--------|
| **文件** | <20MB | 3 天 |
| **图片** | <10MB | 3 天 |
| **语音** | <2MB | 3 天 |

**注意**: 上传到素材库的文件 3 天后会自动删除，需要重新上传。

---

## 8. 下一步

### 配置步骤

1. ⏳ 创建配置文件 `/root/.openclaw/extensions/wecom-openclaw-plugin/config/file_sender.json`
2. ⏳ 填写 corp_id、agent_id、secret
3. ⏳ 测试文件发送功能
4. ⏳ 集成到智能客服 Agent

### 需要提供的信息

**请提供以下信息以完成配置**:
- corp_id: 企业微信企业 ID
- agent_id: 应用 ID
- secret: 应用 Secret
- default_user_id: 默认接收用户 ID（可选）

---

**文档版本**: v1.0  
**创建时间**: 2026-03-31  
**下次审查**: 2026-04-30
