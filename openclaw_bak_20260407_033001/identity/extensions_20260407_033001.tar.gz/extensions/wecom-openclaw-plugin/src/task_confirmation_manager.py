#!/usr/bin/env python3
"""
任务确认管理器
功能：检测历史任务，询问用户是新任务还是继续上一次
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/root/.openclaw/logs/wecom-plugin.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('task_confirmation')

class TaskConfirmationManager:
    """任务确认管理器"""
    
    def __init__(self):
        self.sessions_dir = Path("/root/.openclaw/extensions/wecom-openclaw-plugin/sessions")
        self.tickets_dir = Path("/root/.openclaw/workspace/agents/customer-service/tickets")
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.tickets_dir.mkdir(parents=True, exist_ok=True)
    
    def check_similar_tasks(
        self,
        user_id: str,
        group_id: str,
        task_type: str,
        limit: int = 3
    ) -> List[Dict]:
        """
        检查相似任务
        
        Args:
            user_id: 用户 ID
            group_id: 群 ID
            task_type: 任务类型（fault_analysis/file_processing）
            limit: 返回数量限制
        
        Returns:
            相似任务列表
        """
        similar_tasks = []
        
        try:
            # 获取会话 ID
            session_id = self._get_session_id(user_id, group_id)
            
            # 查找该会话的所有工单
            session_ticket_dir = self.tickets_dir / session_id
            if not session_ticket_dir.exists():
                logger.info(f"会话工单目录不存在：{session_ticket_dir}")
                return similar_tasks
            
            # 遍历工单文件
            for ticket_file in session_ticket_dir.glob("TKT-*.json"):
                try:
                    with open(ticket_file, 'r', encoding='utf-8') as f:
                        ticket = json.load(f)
                    
                    # 检查任务类型
                    if ticket.get("task_type") != task_type:
                        continue
                    
                    # 检查状态（只检查已完成的任务）
                    if ticket.get("status") != "completed":
                        continue
                    
                    # 检查时间（最近 24 小时）
                    created_at = datetime.fromisoformat(ticket["created_at"])
                    if datetime.now() - created_at > timedelta(hours=24):
                        continue
                    
                    similar_tasks.append({
                        "ticket_id": ticket["ticket_id"],
                        "task_type": ticket["task_type"],
                        "status": ticket["status"],
                        "created_at": ticket["created_at"],
                        "completed_at": ticket.get("completed_at"),
                        "description": ticket.get("task_data", {}).get("description", ""),
                        "file": str(ticket_file)
                    })
                except Exception as e:
                    logger.error(f"读取工单文件失败 {ticket_file}: {e}")
                    continue
            
            # 按完成时间排序，返回最近的 N 个
            similar_tasks.sort(
                key=lambda x: x.get("completed_at", x["created_at"]),
                reverse=True
            )
            
            return similar_tasks[:limit]
        
        except Exception as e:
            logger.error(f"检查相似任务失败：{e}")
            return []
    
    def generate_confirmation_prompt(
        self,
        similar_tasks: List[Dict],
        task_type: str
    ) -> str:
        """
        生成确认提示
        
        Args:
            similar_tasks: 相似任务列表
            task_type: 任务类型
        
        Returns:
            确认提示文本
        """
        if not similar_tasks:
            return ""
        
        task_type_name = {
            "fault_analysis": "故障分析",
            "file_processing": "文件处理",
            "data_query": "数据查询"
        }.get(task_type, "任务")
        
        prompt = f"""⚠️ **检测到已完成的相似任务**

您最近有以下已完成的{task_type_name}任务：

"""
        
        for i, task in enumerate(similar_tasks, 1):
            created_time = datetime.fromisoformat(task["created_at"]).strftime("%m-%d %H:%M")
            completed_time = ""
            if task.get("completed_at"):
                completed_time = datetime.fromisoformat(task["completed_at"]).strftime("%H:%M")
                completed_time = f" → {completed_time} 完成"
            
            prompt += f"""**{i}. 工单 {task["ticket_id"]}**
   创建时间：{created_time}{completed_time}
   任务描述：{task["description"]}

"""
        
        prompt += f"""**请问您：**
**A)** 继续上一次任务（查看结果）
**B)** 开始新{task_type_name}（提供新数据）

**回复"A"或"B"选择**"""
        
        logger.info(f"生成确认提示，{len(similar_tasks)}个相似任务")
        return prompt
    
    def handle_user_choice(
        self,
        user_id: str,
        group_id: str,
        task_type: str,
        choice: str,
        similar_tasks: List[Dict]
    ) -> Dict:
        """
        处理用户选择
        
        Args:
            user_id: 用户 ID
            group_id: 群 ID
            task_type: 任务类型
            choice: 用户选择（A/B）
            similar_tasks: 相似任务列表
        
        Returns:
            处理结果
        """
        if not similar_tasks:
            return {
                "action": "new_task",
                "message": ""
            }
        
        last_ticket = similar_tasks[0]
        
        if choice.upper() == "A":
            # 继续上一次任务
            logger.info(f"用户选择继续上一次任务：{last_ticket['ticket_id']}")
            return {
                "action": "continue",
                "ticket_id": last_ticket["ticket_id"],
                "message": f"✅ 继续上一次任务：{last_ticket['ticket_id']}"
            }
        
        elif choice.upper() == "B":
            # 开始新任务
            logger.info("用户选择开始新任务")
            return {
                "action": "new_task",
                "message": "✅ 开始新任务，请提供数据"
            }
        
        else:
            # 无效选择
            logger.warning(f"用户无效选择：{choice}")
            return {
                "action": "invalid",
                "message": '❌ 无效选择，请回复"A"或"B"'
            }
    
    def is_confirmation_needed(
        self,
        user_id: str,
        group_id: str,
        task_type: str,
        has_new_data: bool
    ) -> bool:
        """
        判断是否需要确认
        
        Args:
            user_id: 用户 ID
            group_id: 群 ID
            task_type: 任务类型
            has_new_data: 是否有新数据
        
        Returns:
            是否需要确认
        """
        # 如果有新数据（文件、新日志），不需要确认
        if has_new_data:
            logger.info("有新数据，跳过确认")
            return False
        
        # 检查是否有相似任务
        similar_tasks = self.check_similar_tasks(user_id, group_id, task_type)
        
        needs_confirmation = len(similar_tasks) > 0
        if needs_confirmation:
            logger.info(f"需要确认，发现{len(similar_tasks)}个相似任务")
        
        return needs_confirmation
    
    def _get_session_id(self, user_id: str, group_id: str) -> str:
        """获取会话 ID"""
        import hashlib
        user_hash = hashlib.md5(user_id.encode()).hexdigest()[:8]
        group_hash = hashlib.md5(group_id.encode()).hexdigest()[:8] if group_id else "direct"
        return f"session_{user_hash}_{group_hash}"
    
    def get_last_ticket_result(self, ticket_id: str) -> Optional[Dict]:
        """
        获取上次任务结果
        
        Args:
            ticket_id: 工单 ID
        
        Returns:
            任务结果
        """
        try:
            # 在会话目录中查找工单
            for session_dir in self.tickets_dir.glob("session_*/"):
                ticket_file = session_dir / f"{ticket_id}.json"
                if ticket_file.exists():
                    with open(ticket_file, 'r', encoding='utf-8') as f:
                        ticket = json.load(f)
                    
                    return {
                        "ticket_id": ticket["ticket_id"],
                        "task_type": ticket["task_type"],
                        "status": ticket["status"],
                        "created_at": ticket["created_at"],
                        "completed_at": ticket.get("completed_at"),
                        "result": ticket.get("data", {}).get("analysis_result", ""),
                        "description": ticket.get("task_data", {}).get("description", "")
                    }
            
            logger.warning(f"未找到工单：{ticket_id}")
            return None
        
        except Exception as e:
            logger.error(f"获取任务结果失败 {ticket_id}: {e}")
            return None


# 全局实例
confirmation_manager = TaskConfirmationManager()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python task_confirmation_manager.py <command> [args]")
        print("命令:")
        print("  check <user_id> <group_id> <task_type> - 检查相似任务")
        print("  prompt <user_id> <group_id> <task_type> - 生成确认提示")
        print("  result <ticket_id> - 获取任务结果")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "check":
        if len(sys.argv) < 5:
            print("用法：check <user_id> <group_id> <task_type>")
            sys.exit(1)
        user_id = sys.argv[2]
        group_id = sys.argv[3]
        task_type = sys.argv[4]
        tasks = confirmation_manager.check_similar_tasks(user_id, group_id, task_type)
        print(json.dumps(tasks, ensure_ascii=False, indent=2))
    
    elif command == "prompt":
        if len(sys.argv) < 5:
            print("用法：prompt <user_id> <group_id> <task_type>")
            sys.exit(1)
        user_id = sys.argv[2]
        group_id = sys.argv[3]
        task_type = sys.argv[4]
        tasks = confirmation_manager.check_similar_tasks(user_id, group_id, task_type)
        prompt = confirmation_manager.generate_confirmation_prompt(tasks, task_type)
        print(prompt)
    
    elif command == "result":
        if len(sys.argv) < 3:
            print("用法：result <ticket_id>")
            sys.exit(1)
        ticket_id = sys.argv[2]
        result = confirmation_manager.get_last_ticket_result(ticket_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
