#!/usr/bin/env python3
"""
Python 桥接层 - 被 TypeScript 调用
功能：执行 Python 组件的消息处理逻辑
"""

import json
import sys
import os
from pathlib import Path

# 添加路径
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, '/root/.openclaw/workspace/agents/customer-service/src')
sys.path.insert(0, '/root/.openclaw/workspace/agents/master')

def handle_message(message: dict) -> dict:
    """
    处理消息
    
    Args:
        message: 消息字典 {
            "message_id": "...",
            "user_id": "...",
            "group_id": "...",
            "content": "...",
            "has_file": False,
            "file_path": "..."
        }
    
    Returns:
        响应字典
    """
    try:
        # 导入消息路由器（从 wecom-openclaw-plugin 目录）
        wecom_src = Path(__file__).parent
        sys.path.insert(0, str(wecom_src))
        
        from message_router import message_router
        
        # 路由消息
        result = message_router.route_message(message)
        
        return {
            "success": True,
            "data": result
        }
    
    except Exception as e:
        import logging
        logging.error(f"处理消息失败：{e}")
        import traceback
        traceback.print_exc()
        return {
            "success": False,
            "error": str(e)
        }

if __name__ == "__main__":
    # 从命令行读取消息
    if len(sys.argv) < 2:
        print(json.dumps({"error": "缺少消息参数"}))
        sys.exit(1)
    
    message_json = sys.argv[1]
    message = json.loads(message_json)
    
    result = handle_message(message)
    
    # 输出结果
    print(json.dumps(result, ensure_ascii=False))
