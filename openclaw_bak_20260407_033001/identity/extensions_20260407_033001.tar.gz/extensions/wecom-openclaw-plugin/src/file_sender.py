#!/usr/bin/env python3
"""
企业微信文件发送模块

实现文件上传到企业微信素材库并发送文件消息
不修改 openclaw.json 配置，通过独立模块实现
"""

import requests
import os
from typing import Optional, Dict, Any


class WeComFileSender:
    """企业微信文件发送器"""
    
    def __init__(self, corp_id: str, agent_id: str, secret: str):
        """
        初始化企业微信文件发送器
        
        Args:
            corp_id: 企业 ID
            agent_id: 应用 ID
            secret: 应用 Secret
        """
        self.corp_id = corp_id
        self.agent_id = agent_id
        self.secret = secret
        self.access_token = None
    
    def get_access_token(self) -> Optional[str]:
        """获取企业微信访问令牌"""
        if self.access_token:
            return self.access_token
        
        url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
        params = {
            "corpid": self.corp_id,
            "corpsecret": self.secret
        }
        
        try:
            response = requests.get(url, params=params, timeout=10)
            result = response.json()
            
            if result.get('errcode') == 0:
                self.access_token = result.get('access_token')
                return self.access_token
            else:
                print(f"❌ 获取 token 失败：{result.get('errmsg')}")
                return None
        except Exception as e:
            print(f"❌ 请求异常：{e}")
            return None
    
    def upload_file(self, file_path: str, file_type: str = 'file') -> Optional[str]:
        """
        上传文件到企业微信素材库
        
        Args:
            file_path: 文件路径
            file_type: 文件类型 (file/image/voice)
        
        Returns:
            media_id: 素材 ID，失败返回 None
        """
        token = self.get_access_token()
        if not token:
            return None
        
        url = f"https://qyapi.weixin.qq.com/cgi-bin/media/upload?access_token={token}&type={file_type}"
        
        try:
            with open(file_path, 'rb') as f:
                files = {'media': f}
                response = requests.post(url, files=files, timeout=30)
                result = response.json()
            
            if result.get('errcode') == 0:
                media_id = result.get('media_id')
                print(f"✅ 文件上传成功：{media_id}")
                return media_id
            else:
                print(f"❌ 文件上传失败：{result.get('errmsg')}")
                return None
        except Exception as e:
            print(f"❌ 上传异常：{e}")
            return None
    
    def send_file_message(
        self,
        user_id: str,
        file_path: str,
        file_type: str = 'file'
    ) -> bool:
        """
        发送文件消息
        
        Args:
            user_id: 用户 ID
            file_path: 文件路径
            file_type: 文件类型
        
        Returns:
            是否成功
        """
        # 1. 上传文件
        media_id = self.upload_file(file_path, file_type)
        if not media_id:
            return False
        
        # 2. 发送文件消息
        token = self.get_access_token()
        if not token:
            return False
        
        url = f"https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={token}"
        
        payload = {
            "touser": user_id,
            "msgtype": "file",
            "agentid": self.agent_id,
            "file": {
                "media_id": media_id
            },
            "safe": 0
        }
        
        try:
            response = requests.post(url, json=payload, timeout=10)
            result = response.json()
            
            if result.get('errcode') == 0:
                print(f"✅ 文件消息发送成功")
                return True
            else:
                print(f"❌ 文件消息发送失败：{result.get('errmsg')}")
                return False
        except Exception as e:
            print(f"❌ 发送异常：{e}")
            return False
    
    def send_image_message(
        self,
        user_id: str,
        image_path: str
    ) -> bool:
        """
        发送图片消息
        
        Args:
            user_id: 用户 ID
            image_path: 图片路径
        
        Returns:
            是否成功
        """
        return self.send_file_message(user_id, image_path, 'image')


# 便捷函数
def send_file_via_wecom(
    user_id: str,
    file_path: str,
    corp_id: str,
    agent_id: str,
    secret: str
) -> bool:
    """
    通过企业微信发送文件（便捷函数）
    
    Args:
        user_id: 用户 ID
        file_path: 文件路径
        corp_id: 企业 ID
        agent_id: 应用 ID
        secret: 应用 Secret
    
    Returns:
        是否成功
    """
    sender = WeComFileSender(corp_id, agent_id, secret)
    return sender.send_file_message(user_id, file_path)


# CLI 测试
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 6:
        print("用法：python3 wecom_file_sender.py <corp_id> <agent_id> <secret> <user_id> <file_path>")
        print("")
        print("示例:")
        print("  python3 wecom_file_sender.py ww123 1000001 abc123 user123 /tmp/test.pdf")
        sys.exit(1)
    
    corp_id = sys.argv[1]
    agent_id = sys.argv[2]
    secret = sys.argv[3]
    user_id = sys.argv[4]
    file_path = sys.argv[5]
    
    print(f"发送文件：{file_path}")
    print(f"接收用户：{user_id}")
    
    sender = WeComFileSender(corp_id, agent_id, secret)
    success = sender.send_file_message(user_id, file_path)
    
    if success:
        print("✅ 文件发送成功")
    else:
        print("❌ 文件发送失败")
