#!/usr/bin/env python3
"""
企业微信会话管理器
功能：多用户并发会话隔离，任务互不干扰
"""

import json
import os
import hashlib
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Optional, List
import fcntl

class SessionManager:
    """会话管理器"""
    
    def __init__(self):
        self.sessions_dir = Path("/root/.openclaw/extensions/wecom-openclaw-plugin/sessions")
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        
        # 会话配置
        self.session_timeout = timedelta(minutes=30)  # 会话超时时间
        self.max_concurrent_sessions = 100  # 最大并发会话数
        self.lock_file = self.sessions_dir / ".lock"
        
        # 内存缓存
        self.active_sessions: Dict[str, 'Session'] = {}
        self.lock = threading.Lock()
    
    def get_session_id(self, user_id: str, group_id: str) -> str:
        """
        生成会话 ID
        
        规则：session_{user_id_hash}_{group_id_hash}
        同一用户在同一个群聊中始终使用同一个会话
        """
        # 使用哈希缩短长度
        user_hash = hashlib.md5(user_id.encode()).hexdigest()[:8]
        group_hash = hashlib.md5(group_id.encode()).hexdigest()[:8] if group_id else "direct"
        
        return f"session_{user_hash}_{group_hash}"
    
    def get_or_create_session(self, user_id: str, group_id: str = None, message_id: str = None) -> 'Session':
        """
        获取或创建会话
        
        每个用户在每个群聊中有独立会话
        """
        session_id = self.get_session_id(user_id, group_id)
        
        with self.lock:
            # 检查内存缓存
            if session_id in self.active_sessions:
                session = self.active_sessions[session_id]
                
                # 检查是否超时
                if session.is_expired():
                    session.refresh()
                
                return session
            
            # 检查磁盘会话
            session_file = self.sessions_dir / f"{session_id}.json"
            if session_file.exists():
                session = Session.load(session_file)
                self.active_sessions[session_id] = session
                return session
            
            # 创建新会话
            session = Session(
                session_id=session_id,
                user_id=user_id,
                group_id=group_id or "direct",
                created_at=datetime.now()
            )
            
            # 检查并发限制
            if len(self.active_sessions) >= self.max_concurrent_sessions:
                self._cleanup_old_sessions()
            
            self.active_sessions[session_id] = session
            session.save()
            
            return session
    
    def get_session(self, session_id: str) -> Optional['Session']:
        """获取会话"""
        with self.lock:
            return self.active_sessions.get(session_id)
    
    def close_session(self, session_id: str):
        """关闭会话"""
        with self.lock:
            if session_id in self.active_sessions:
                session = self.active_sessions[session_id]
                session.save()
                del self.active_sessions[session_id]
    
    def _cleanup_old_sessions(self):
        """清理过期会话"""
        now = datetime.now()
        expired = []
        
        for session_id, session in self.active_sessions.items():
            if session.is_expired():
                expired.append(session_id)
        
        for session_id in expired:
            session = self.active_sessions[session_id]
            session.save()
            del self.active_sessions[session_id]
    
    def cleanup_all_expired(self):
        """清理所有过期会话（内存 + 磁盘）"""
        with self.lock:
            # 清理内存
            self._cleanup_old_sessions()
            
            # 清理磁盘
            cleaned_count = 0
            for session_file in self.sessions_dir.glob("*.json"):
                try:
                    session = Session.load(session_file)
                    if session.is_expired():
                        session_file.unlink()
                        logger.info(f"清理过期会话：{session.session_id}")
                        cleaned_count += 1
                except Exception as e:
                    logger.error(f"清理会话失败：{e}")
            
            logger.info(f"清理完成，共清理 {cleaned_count} 个过期会话")
            return cleaned_count
    
    def list_active_sessions(self) -> List[Dict]:
        """列出所有活跃会话"""
        with self.lock:
            return [
                {
                    "session_id": session.session_id,
                    "user_id": session.user_id,
                    "group_id": session.group_id,
                    "created_at": session.created_at.isoformat(),
                    "last_activity": session.last_activity.isoformat(),
                    "message_count": session.message_count,
                    "ticket_count": session.ticket_count
                }
                for session in self.active_sessions.values()
            ]
    
    def clear_user_session(self, user_id: str, group_id: str = None):
        """
        清除用户会话（用于强制刷新）
        
        当用户开始新任务时调用，确保不复用旧上下文
        """
        session_id = self.get_session_id(user_id, group_id)
        
        with self.lock:
            if session_id in self.active_sessions:
                session = self.active_sessions[session_id]
                session.clear_context()
                session.active_tickets = []
                session.save()


class Session:
    """会话类"""
    
    def __init__(
        self,
        session_id: str,
        user_id: str,
        group_id: str,
        created_at: datetime
    ):
        self.session_id = session_id
        self.user_id = user_id
        self.group_id = group_id
        self.created_at = created_at
        self.last_activity = created_at
        self.message_count = 0
        self.ticket_count = 0
        self.context: Dict = {}
        self.active_tickets: List[str] = []
        self.lock = threading.Lock()
    
    def is_expired(self) -> bool:
        """检查是否过期"""
        timeout = timedelta(minutes=30)
        return datetime.now() - self.last_activity > timeout
    
    def refresh(self):
        """刷新会话"""
        self.last_activity = datetime.now()
    
    def add_message(self, message: Dict):
        """添加消息到会话"""
        with self.lock:
            self.message_count += 1
            self.refresh()
            
            # 保存到上下文
            if "messages" not in self.context:
                self.context["messages"] = []
            
            self.context["messages"].append({
                "timestamp": datetime.now().isoformat(),
                "content": message
            })
            
            # 保留最近 50 条消息
            if len(self.context["messages"]) > 50:
                self.context["messages"] = self.context["messages"][-50:]
    
    def create_ticket(self, ticket_id: str):
        """创建工单"""
        with self.lock:
            self.active_tickets.append(ticket_id)
            self.ticket_count += 1
            self.refresh()
    
    def complete_ticket(self, ticket_id: str):
        """完成工单"""
        with self.lock:
            if ticket_id in self.active_tickets:
                self.active_tickets.remove(ticket_id)
                self.refresh()
    
    def get_context(self) -> Dict:
        """获取会话上下文"""
        with self.lock:
            return self.context.copy()
    
    def set_context(self, key: str, value):
        """设置上下文"""
        with self.lock:
            self.context[key] = value
            self.refresh()
    
    def get_context_value(self, key: str, default=None):
        """获取上下文值"""
        with self.lock:
            return self.context.get(key, default)
    
    def clear_context(self):
        """清空上下文（用于新任务）"""
        with self.lock:
            # 保留用户信息，清空任务相关上下文
            self.context = {
                "user_id": self.user_id,
                "group_id": self.group_id
            }
            self.active_tickets = []
            self.refresh()
    
    def has_active_ticket(self) -> bool:
        """检查是否有活跃工单"""
        with self.lock:
            return len(self.active_tickets) > 0
    
    def get_last_ticket(self) -> Optional[str]:
        """获取最后一个工单 ID"""
        with self.lock:
            return self.active_tickets[-1] if self.active_tickets else None
    
    def save(self):
        """保存会话到磁盘"""
        session_file = Path(f"/root/.openclaw/extensions/wecom-openclaw-plugin/sessions/{self.session_id}.json")
        
        data = {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "group_id": self.group_id,
            "created_at": self.created_at.isoformat(),
            "last_activity": self.last_activity.isoformat(),
            "message_count": self.message_count,
            "ticket_count": self.ticket_count,
            "context": self.context,
            "active_tickets": self.active_tickets
        }
        
        # 原子写入
        temp_file = session_file.with_suffix('.tmp')
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        temp_file.rename(session_file)
    
    @classmethod
    def load(cls, session_file: Path) -> 'Session':
        """从磁盘加载会话"""
        with open(session_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        session = cls(
            session_id=data["session_id"],
            user_id=data["user_id"],
            group_id=data["group_id"],
            created_at=datetime.fromisoformat(data["created_at"])
        )
        
        session.last_activity = datetime.fromisoformat(data["last_activity"])
        session.message_count = data["message_count"]
        session.ticket_count = data["ticket_count"]
        session.context = data["context"]
        session.active_tickets = data["active_tickets"]
        
        return session


# 全局会话管理器实例
session_manager = SessionManager()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python session_manager.py <command> [args]")
        print("命令:")
        print("  list - 列出活跃会话")
        print("  cleanup - 清理过期会话")
        print("  create <user_id> [group_id] - 创建会话")
        print("  clear <user_id> [group_id] - 清除会话上下文")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "list":
        sessions = session_manager.list_active_sessions()
        print(json.dumps(sessions, ensure_ascii=False, indent=2))
    
    elif command == "cleanup":
        session_manager.cleanup_all_expired()
        print("✅ 已清理过期会话")
    
    elif command == "create":
        if len(sys.argv) < 3:
            print("用法：create <user_id> [group_id]")
            sys.exit(1)
        user_id = sys.argv[2]
        group_id = sys.argv[3] if len(sys.argv) > 3 else None
        session = session_manager.get_or_create_session(user_id, group_id, "manual")
        print(f"✅ 会话已创建：{session.session_id}")
        print(json.dumps({
            "session_id": session.session_id,
            "user_id": session.user_id,
            "group_id": session.group_id,
            "created_at": session.created_at.isoformat()
        }, ensure_ascii=False, indent=2))
    
    elif command == "clear":
        if len(sys.argv) < 3:
            print("用法：clear <user_id> [group_id]")
            sys.exit(1)
        user_id = sys.argv[2]
        group_id = sys.argv[3] if len(sys.argv) > 3 else None
        session_manager.clear_user_session(user_id, group_id)
        print(f"✅ 会话上下文已清除：{user_id}")
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
