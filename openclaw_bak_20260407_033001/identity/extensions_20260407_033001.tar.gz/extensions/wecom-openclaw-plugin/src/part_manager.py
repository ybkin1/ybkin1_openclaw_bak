#!/usr/bin/env python3
"""
分片文件管理器
功能：识别分片文件、跟踪上传状态、合并分片
"""

import json
import re
import shutil
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import hashlib

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/root/.openclaw/logs/wecom-plugin.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('part_manager')

# 分片文件识别模式
PART_PATTERNS = [
    (r'\.part(\d+)(\.|$)', 'part'),           # .part1, .part1.tar.gz
    (r'\.(\d{3})$', 'number'),                # .001, .002
    (r'\.([a-z]{2})$', 'letter'),             # .aa, .ab
    (r'_part(\d+)(\.|$)', 'part'),            # _part1, _part1.tar.gz
    (r'-part(\d+)(\.|$)', 'part'),            # -part1, -part1.tar.gz
]

class PartManager:
    """分片文件管理器"""
    
    def __init__(self):
        self.parts_dir = Path("/root/.openclaw/workspace/files/wecom/parts")
        self.parts_dir.mkdir(parents=True, exist_ok=True)
        self.timeout = timedelta(minutes=10)  # 10 分钟超时
    
    def detect_part_file(self, file_path: Path) -> Optional[Dict]:
        """
        检测是否为分片文件
        
        Args:
            file_path: 文件路径
        
        Returns:
            {
                "is_part": True,
                "base_name": "nvidia-bug-report.tar.gz",
                "part_number": 1,
                "part_suffix": ".part1"
            }
            或 {"is_part": False}
        """
        file_name = file_path.name
        
        for pattern, pattern_type in PART_PATTERNS:
            match = re.search(pattern, file_name, re.IGNORECASE)
            if match:
                part_str = match.group(1)
                part_number = self._parse_part_number(part_str, pattern_type)
                base_name = self._get_base_name(file_name, match.group(0))
                
                logger.info(f"检测到分片文件：{file_name} -> {base_name} part{part_number}")
                
                return {
                    "is_part": True,
                    "base_name": base_name,
                    "part_number": part_number,
                    "part_suffix": match.group(0),
                    "file_path": str(file_path)
                }
        
        return {"is_part": False}
    
    def create_part_task(
        self,
        user_id: str,
        group_id: str,
        base_name: str,
        part_number: int,
        file_path: Path
    ) -> Dict:
        """
        创建分片任务
        
        Args:
            user_id: 用户 ID
            group_id: 群 ID
            base_name: 基础文件名
            part_number: 分片号
            file_path: 文件路径
        
        Returns:
            任务字典
        """
        # 生成任务 ID（使用哈希缩短长度）
        task_hash = hashlib.md5(f"{user_id}-{base_name}".encode()).hexdigest()[:8]
        task_id = f"PART-{task_hash}"
        task_dir = self.parts_dir / task_id
        task_dir.mkdir(parents=True, exist_ok=True)
        
        # 保存分片文件
        part_file = task_dir / f"part_{part_number}"
        shutil.copy(file_path, part_file)
        
        task = {
            "task_id": task_id,
            "user_id": user_id,
            "group_id": group_id,
            "base_name": base_name,
            "status": "waiting_parts",
            "created_at": datetime.now().isoformat(),
            "timeout_at": (datetime.now() + self.timeout).isoformat(),
            "received_parts": [part_number],
            "expected_parts": None,  # 未知，等待用户继续上传
            "parts_dir": str(task_dir),
            "file_size": file_path.stat().st_size
        }
        
        self._save_task(task)
        logger.info(f"创建分片任务：{task_id}, 分片 {part_number}")
        
        return task
    
    def add_part(
        self,
        task_id: str,
        part_number: int,
        file_path: Path
    ) -> Dict:
        """
        添加分片到任务
        
        Args:
            task_id: 任务 ID
            part_number: 分片号
            file_path: 文件路径
        
        Returns:
            {
                "status": "waiting_parts" | "ready_to_process",
                "received_parts": [1, 2, 3, 4],
                "message": "已接收 4/4 个分片，开始处理"
            }
        """
        task = self._load_task(task_id)
        if not task:
            return {"error": "任务不存在", "status": "error"}
        
        # 保存分片文件
        part_file = Path(task["parts_dir"]) / f"part_{part_number}"
        shutil.copy(file_path, part_file)
        
        # 更新分片列表
        if part_number not in task["received_parts"]:
            task["received_parts"].append(part_number)
            task["received_parts"].sort()
        
        # 更新超时时间
        task["timeout_at"] = (datetime.now() + self.timeout).isoformat()
        
        # 检查是否完整（连续分片）
        is_complete = self._check_complete(task["received_parts"])
        
        if is_complete:
            task["status"] = "ready_to_process"
            message = f"✅ 已接收 {len(task['received_parts'])}/{len(task['received_parts'])} 个分片，开始处理"
            logger.info(f"分片任务完成：{task_id}, {len(task['received_parts'])} 个分片")
        else:
            task["status"] = "waiting_parts"
            message = f"✅ 已接收 {len(task['received_parts'])} 个分片，请继续上传剩余分片"
            logger.info(f"分片任务等待：{task_id}, 已接收 {len(task['received_parts'])} 个")
        
        task["updated_at"] = datetime.now().isoformat()
        self._save_task(task)
        
        return {
            "status": task["status"],
            "received_parts": task["received_parts"],
            "total_parts": len(task["received_parts"]),
            "message": message
        }
    
    def merge_parts(self, task: Dict) -> Dict:
        """
        合并分片文件
        
        Args:
            task: 任务字典
        
        Returns:
            {
                "success": True,
                "merged_file": "/path/to/merged_file.tar.gz",
                "message": "分片合并完成"
            }
        """
        parts_dir = Path(task["parts_dir"])
        base_name = task["base_name"]
        merged_file = parts_dir / base_name
        
        try:
            # 按分片号排序
            part_files = []
            for part_num in task["received_parts"]:
                part_file = parts_dir / f"part_{part_num}"
                if part_file.exists():
                    part_files.append(part_file)
                else:
                    logger.error(f"分片文件不存在：{part_file}")
                    return {
                        "success": False,
                        "message": f"分片文件不存在：part_{part_num}"
                    }
            
            # 合并分片
            with open(merged_file, 'wb') as merged:
                for part_file in part_files:
                    with open(part_file, 'rb') as f:
                        merged.write(f.read())
            
            total_size = merged_file.stat().st_size
            logger.info(f"分片合并完成：{merged_file}, {total_size / 1024 / 1024:.1f}MB")
            
            return {
                "success": True,
                "merged_file": str(merged_file),
                "message": f"✅ 分片合并完成：{base_name} ({total_size / 1024 / 1024:.1f}MB)",
                "total_size": total_size
            }
        
        except Exception as e:
            logger.error(f"分片合并失败：{e}")
            return {
                "success": False,
                "message": f"分片合并失败：{str(e)}"
            }
    
    def get_task_status(self, task_id: str) -> Optional[Dict]:
        """获取任务状态"""
        task = self._load_task(task_id)
        if not task:
            return None
        
        return {
            "task_id": task["task_id"],
            "status": task["status"],
            "received_parts": task["received_parts"],
            "expected_parts": task["expected_parts"],
            "timeout_at": task["timeout_at"]
        }
    
    def cleanup_expired_tasks(self) -> int:
        """清理超时任务"""
        now = datetime.now()
        cleaned_count = 0
        
        for task_dir in self.parts_dir.glob("PART-*/"):
            task_file = task_dir / "task.json"
            if task_file.exists():
                try:
                    with open(task_file, 'r', encoding='utf-8') as f:
                        task = json.load(f)
                    
                    timeout_at = datetime.fromisoformat(task["timeout_at"])
                    if now > timeout_at:
                        # 超时，清理
                        shutil.rmtree(task_dir)
                        logger.info(f"清理超时分片任务：{task['task_id']}")
                        cleaned_count += 1
                except Exception as e:
                    logger.error(f"清理任务失败：{e}")
        
        logger.info(f"清理完成，共清理 {cleaned_count} 个超时任务")
        return cleaned_count
    
    def _check_complete(self, received_parts: List[int]) -> bool:
        """
        检查分片是否完整（连续）
        
        例如：[1, 2, 3, 4] 是完整的
             [1, 2, 4] 不完整（缺少 3）
        """
        if not received_parts:
            return False
        
        # 检查是否连续
        for i in range(len(received_parts) - 1):
            if received_parts[i+1] - received_parts[i] != 1:
                return False
        
        return True
    
    def _parse_part_number(self, part_str: str, pattern_type: str) -> int:
        """解析分片号"""
        if part_str.isdigit():
            return int(part_str)
        elif pattern_type == 'letter':
            # .aa, .ab, .ac -> 1, 2, 3
            return ord(part_str[0].lower()) - ord('a') + 1
        else:
            return 1
    
    def _get_base_name(self, file_name: str, suffix: str) -> str:
        """获取基础文件名（不含分片后缀）"""
        # 移除分片后缀
        base_name = file_name.replace(suffix, '')
        return base_name
    
    def _save_task(self, task: Dict):
        """保存任务"""
        task_file = Path(task["parts_dir"]) / "task.json"
        with open(task_file, 'w', encoding='utf-8') as f:
            json.dump(task, f, ensure_ascii=False, indent=2)
    
    def _load_task(self, task_id: str) -> Optional[Dict]:
        """加载任务"""
        task_dir = self.parts_dir / task_id
        task_file = task_dir / "task.json"
        if task_file.exists():
            with open(task_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None


# 全局实例
part_manager = PartManager()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python part_manager.py <command> [args]")
        print("命令:")
        print("  detect <file_path> - 检测分片文件")
        print("  status <task_id> - 查看任务状态")
        print("  cleanup - 清理超时任务")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "detect":
        if len(sys.argv) < 3:
            print("用法：detect <file_path>")
            sys.exit(1)
        file_path = Path(sys.argv[2])
        result = part_manager.detect_part_file(file_path)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "status":
        if len(sys.argv) < 3:
            print("用法：status <task_id>")
            sys.exit(1)
        task_id = sys.argv[2]
        status = part_manager.get_task_status(task_id)
        print(json.dumps(status, ensure_ascii=False, indent=2))
    
    elif command == "cleanup":
        count = part_manager.cleanup_expired_tasks()
        print(f"✅ 清理了 {count} 个超时任务")
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
