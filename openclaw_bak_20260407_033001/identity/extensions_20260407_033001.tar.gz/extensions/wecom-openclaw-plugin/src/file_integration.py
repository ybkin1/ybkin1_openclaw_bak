#!/usr/bin/env python3
"""
企业微信文件发送集成模块

集成到企业微信插件，处理文件发送请求
不修改 openclaw.json 配置
"""

import os
import sys
from typing import Optional, Dict, Any

# 导入文件发送模块
sys.path.insert(0, os.path.dirname(__file__))
from file_sender import WeComFileSender


class WeComFileIntegration:
    """企业微信文件发送集成"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化集成
        
        Args:
            config: 配置字典
                - corp_id: 企业 ID
                - agent_id: 应用 ID
                - secret: 应用 Secret
                - default_user_id: 默认接收用户 ID
        """
        self.corp_id = config.get('corp_id', '')
        self.agent_id = config.get('agent_id', '')
        self.secret = config.get('secret', '')
        self.default_user_id = config.get('default_user_id', '')
        self.sender = None
        
        if self.corp_id and self.agent_id and self.secret:
            self.sender = WeComFileSender(self.corp_id, self.agent_id, self.secret)
    
    def handle_file_request(
        self,
        user_message: str,
        file_path: str,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        处理文件发送请求
        
        Args:
            user_message: 用户消息
            file_path: 文件路径
            user_id: 用户 ID（可选，默认使用 default_user_id）
        
        Returns:
            处理结果
        """
        if not self.sender:
            return {
                'success': False,
                'message': '企业微信配置不完整，缺少 corp_id、agent_id 或 secret'
            }
        
        # 检查文件是否存在
        if not os.path.exists(file_path):
            return {
                'success': False,
                'message': f'文件不存在：{file_path}'
            }
        
        # 确定接收用户
        target_user = user_id or self.default_user_id
        if not target_user:
            return {
                'success': False,
                'message': '未指定接收用户 ID'
            }
        
        # 发送文件
        file_type = self._detect_file_type(file_path)
        success = self.sender.send_file_message(target_user, file_path, file_type)
        
        if success:
            return {
                'success': True,
                'message': f'文件已发送：{os.path.basename(file_path)}',
                'file_name': os.path.basename(file_path),
                'file_size': os.path.getsize(file_path),
                'recipient': target_user
            }
        else:
            return {
                'success': False,
                'message': '文件发送失败，请检查企业微信配置和网络连接'
            }
    
    def _detect_file_type(self, file_path: str) -> str:
        """检测文件类型"""
        ext = os.path.splitext(file_path)[1].lower()
        
        image_exts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']
        voice_exts = ['.amr', '.mp3']
        
        if ext in image_exts:
            return 'image'
        elif ext in voice_exts:
            return 'voice'
        else:
            return 'file'
    
    def get_config_status(self) -> Dict[str, Any]:
        """获取配置状态"""
        return {
            'corp_id': '已配置' if self.corp_id else '❌ 未配置',
            'agent_id': '已配置' if self.agent_id else '❌ 未配置',
            'secret': '已配置' if self.secret else '❌ 未配置',
            'ready': bool(self.corp_id and self.agent_id and self.secret)
        }


# 便捷函数
def send_file_via_wecom_integration(
    file_path: str,
    user_id: str = None,
    config: Dict[str, str] = None
) -> Dict[str, Any]:
    """
    通过企业微信发送文件（集成功能）
    
    Args:
        file_path: 文件路径
        user_id: 用户 ID
        config: 配置字典
    
    Returns:
        发送结果
    """
    if config is None:
        config = {}
    
    integration = WeComFileIntegration(config)
    return integration.handle_file_request('', file_path, user_id)


# CLI 测试
if __name__ == "__main__":
    # 测试配置
    config = {
        'corp_id': 'wwxxxxxxxxxxxxx',  # 替换为企业 ID
        'agent_id': '1000001',  # 替换为应用 ID
        'secret': 'xxxxxxxxxxxxx',  # 替换为 Secret
        'default_user_id': 'user123'  # 替换为用户 ID
    }
    
    print("企业微信文件发送集成 - 测试")
    print("=" * 60)
    
    integration = WeComFileIntegration(config)
    
    # 检查配置状态
    print("\n配置状态:")
    status = integration.get_config_status()
    for key, value in status.items():
        print(f"  {key}: {value}")
    
    if not status['ready']:
        print("\n⚠️  配置不完整，无法发送文件")
        print("\n需要在配置中提供:")
        print("  - corp_id: 企业微信企业 ID")
        print("  - agent_id: 应用 ID")
        print("  - secret: 应用 Secret")
        print("  - default_user_id: 默认接收用户 ID（可选）")
    else:
        print("\n✅ 配置完整，可以发送文件")
    
    print("\n" + "=" * 60)
