#!/usr/bin/env python3
"""
企业微信文件处理器
功能：处理用户上传的文件（包括.tar.gz 压缩包）
"""

import subprocess
import tempfile
import os
import logging
from pathlib import Path
from typing import Dict, Optional, List

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/root/.openclaw/logs/wecom-plugin.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('file_processor')

class WeComFileProcessor:
    """企业微信文件处理器"""
    
    def __init__(self):
        self.upload_dir = Path("/root/.openclaw/workspace/files/wecom")
        try:
            self.upload_dir.mkdir(parents=True, exist_ok=True)
            # 检查权限
            if not os.access(self.upload_dir, os.W_OK):
                logger.error(f"上传目录无写入权限：{self.upload_dir}")
        except Exception as e:
            logger.error(f"创建上传目录失败：{e}")
            raise
    
    def process_uploaded_file(self, file_path: str, user_id: str) -> Dict:
        """
        处理用户上传的文件
        
        Args:
            file_path: 文件路径
            user_id: 用户 ID
        
        Returns:
            处理结果
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            return {
                "success": False,
                "message": f"文件不存在：{file_path}"
            }
        
        # 检测文件类型
        file_type = self._detect_file_type(file_path)
        
        if file_type == "archive":
            # 压缩包：解压并处理
            return self._process_archive(file_path, user_id)
        elif file_type == "log":
            # 日志文件：直接分析
            return self._process_log(file_path, user_id)
        elif file_type == "nvidia_bug_report":
            # NVIDIA 诊断报告：特殊处理
            return self._process_nvidia_bug_report(file_path, user_id)
        else:
            # 其他文件类型
            return {
                "success": True,
                "message": f"文件已接收：{file_path.name}",
                "file_type": file_type,
                "next_step": "请说明需要如何处理该文件"
            }
    
    def _detect_file_type(self, file_path: Path) -> str:
        """检测文件类型"""
        file_name = file_path.name.lower()
        
        # NVIDIA 诊断报告
        if "nvidia-bug-report" in file_name or "nvidia_bug_report" in file_name:
            return "nvidia_bug_report"
        
        # 压缩包
        archive_extensions = ['.tar.gz', '.tgz', '.tar.bz2', '.tar.xz', '.zip', '.gz', '.tar', '.rar', '.7z']
        for ext in archive_extensions:
            if file_name.endswith(ext):
                return "archive"
        
        # 日志文件
        log_extensions = ['.log', '.txt', '.dmesg', '.syslog']
        for ext in log_extensions:
            if file_name.endswith(ext):
                return "log"
        
        return "unknown"
    
    def _process_archive(self, file_path: Path, user_id: str) -> Dict:
        """处理压缩包（带安全限制）"""
        # 安全检查 1: 文件大小限制（最大 500MB）
        max_file_size = 500 * 1024 * 1024  # 500MB
        if file_path.stat().st_size > max_file_size:
            return {
                "success": False,
                "message": f"❌ 文件过大（{file_path.stat().st_size / 1024 / 1024:.1f}MB），最大支持 500MB"
            }
        
        # 创建解压目录
        extract_dir = self.upload_dir / user_id / f"extract_{file_path.stem}"
        extract_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            # 安全检查 2: 路径遍历检查（针对 tar 文件）
            if str(file_path).endswith(('.tar.gz', '.tgz', '.tar.bz2', '.tar.xz', '.tar')):
                import tarfile
                with tarfile.open(file_path, 'r:*') as tar:
                    members = tar.getmembers()
                    
                    # 检查文件数量限制（最大 1000 个）
                    if len(members) > 1000:
                        return {
                            "success": False,
                            "message": f"❌ 文件过多（{len(members)}个），最大支持 1000 个"
                        }
                    
                    # 检查路径遍历
                    for member in members:
                        if '..' in member.path or member.path.startswith('/'):
                            return {
                                "success": False,
                                "message": f"❌ 非法文件路径：{member.path}"
                            }
            
            # 解压
            if str(file_path).endswith('.tar.gz') or str(file_path).endswith('.tgz'):
                cmd = ['tar', '-xzf', str(file_path), '-C', str(extract_dir)]
            elif str(file_path).endswith('.tar.bz2'):
                cmd = ['tar', '-xjf', str(file_path), '-C', str(extract_dir)]
            elif str(file_path).endswith('.tar.xz'):
                cmd = ['tar', '-xJf', str(file_path), '-C', str(extract_dir)]
            elif str(file_path).endswith('.zip'):
                cmd = ['unzip', '-o', str(file_path), '-d', str(extract_dir)]
            elif str(file_path).endswith('.gz'):
                cmd = ['gunzip', '-k', str(file_path)]
            elif str(file_path).endswith('.tar'):
                cmd = ['tar', '-xf', str(file_path), '-C', str(extract_dir)]
            elif str(file_path).endswith('.rar'):
                cmd = ['unrar', 'x', str(file_path), str(extract_dir)]
            elif str(file_path).endswith('.7z'):
                cmd = ['7z', 'x', str(file_path), f'-o{extract_dir}']
            else:
                return {
                    "success": False,
                    "message": f"不支持的压缩格式：{file_path.suffix}"
                }
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            
            if result.returncode != 0:
                return {
                    "success": False,
                    "message": f"解压失败：{result.stderr}"
                }
            
            # 列出生成的文件
            files = list(extract_dir.rglob("*"))
            file_list = [str(f.relative_to(extract_dir)) for f in files if f.is_file()][:20]
            
            # 查找日志文件
            log_files = [f for f in files if f.is_file() and f.suffix in ['.log', '.txt']]
            
            return {
                "success": True,
                "message": f"✅ 压缩包已解压\n\n解压目录：{extract_dir}\n文件数量：{len(files)}\n\n文件列表:\n" + "\n".join(file_list),
                "extract_dir": str(extract_dir),
                "file_count": len(files),
                "log_files": [str(f) for f in log_files[:10]],
                "next_step": "请指定要分析的日志文件，或回复'分析所有日志'"
            }
            
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "message": "解压超时（超过 5 分钟）"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"解压失败：{str(e)}"
            }
    
    def _process_log(self, file_path: Path, user_id: str) -> Dict:
        """处理日志文件"""
        try:
            # 读取日志内容（前 1000 行）
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()[:1000]
            
            # 统计错误和警告
            error_count = sum(1 for line in lines if 'error' in line.lower() or 'fail' in line.lower())
            warning_count = sum(1 for line in lines if 'warning' in line.lower() or 'warn' in line.lower())
            
            # 提取错误信息
            errors = [line.strip() for line in lines if 'error' in line.lower() or 'fail' in line.lower()][:10]
            
            return {
                "success": True,
                "message": f"✅ 日志文件已接收\n\n文件：{file_path.name}\n总行数：{len(lines)}\n错误数：{error_count}\n警告数：{warning_count}\n\n最近的错误:\n" + "\n".join(errors),
                "file_path": str(file_path),
                "total_lines": len(lines),
                "error_count": error_count,
                "warning_count": warning_count,
                "errors": errors,
                "next_step": "请说明需要分析的内容，或回复'分析故障'"
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"读取日志失败：{str(e)}"
            }
    
    def _process_nvidia_bug_report(self, file_path: Path, user_id: str) -> Dict:
        """处理 NVIDIA 诊断报告"""
        # 如果是压缩包，先解压
        if str(file_path).endswith(('.gz', '.tar.gz', '.tgz')):
            archive_result = self._process_archive(file_path, user_id)
            if not archive_result["success"]:
                return archive_result
            
            # 查找解压后的 nvidia-bug-report.log
            extract_dir = Path(archive_result["extract_dir"])
            log_files = list(extract_dir.rglob("nvidia-bug-report*.log"))
            
            if log_files:
                return self._process_log(log_files[0], user_id)
            else:
                return {
                    "success": False,
                    "message": "未在压缩包中找到 nvidia-bug-report.log 文件"
                }
        else:
            # 直接处理日志文件
            return self._process_log(file_path, user_id)


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 3:
        print("用法：python file_processor.py <file_path> <user_id>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    user_id = sys.argv[2]
    
    processor = WeComFileProcessor()
    result = processor.process_uploaded_file(file_path, user_id)
    
    print(json.dumps(result, ensure_ascii=False, indent=2))
