#!/usr/bin/env python3
"""
消息路由器
功能：解析消息、检测意图、任务确认、路由处理、分片文件处理
"""

import json
import logging
from pathlib import Path
from typing import Dict, Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/root/.openclaw/logs/wecom-plugin.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('message_router')

# 导入其他模块
from session_manager import session_manager
from task_confirmation_manager import confirmation_manager
from part_manager import part_manager

class MessageRouter:
    """消息路由器"""
    
    def __init__(self):
        self.session_manager = session_manager
        self.confirmation_manager = confirmation_manager
        self.part_manager = part_manager
        self.upload_dir = Path("/root/.openclaw/workspace/files/wecom")
        self.upload_dir.mkdir(parents=True, exist_ok=True)
    
    def route_message(self, message: Dict) -> Dict:
        """
        路由消息
        
        Args:
            message: 消息字典 {
                "message_id": "...",
                "user_id": "...",
                "group_id": "...",
                "content": "...",
                "has_file": false,
                "file_path": "..."
            }
        
        Returns:
            响应字典
        """
        user_id = message["user_id"]
        group_id = message.get("group_id", "direct")
        content = message.get("content", "")
        has_file = message.get("has_file", False)
        file_path = message.get("file_path")
        
        logger.info(f"收到消息：user={user_id}, has_file={has_file}, content={content[:50]}")
        
        # 获取会话
        session = self.session_manager.get_or_create_session(user_id, group_id, message["message_id"])
        
        # 有文件：优先处理文件
        if has_file and file_path:
            return self._handle_file_upload(session, user_id, group_id, file_path, content)
        
        # 检测任务意图
        task_type = self._detect_task_type(content)
        
        if task_type:
            # 有任务意图
            return self._handle_task_request(session, user_id, group_id, task_type, content)
        else:
            # 无任务意图，普通对话
            return self._handle_normal_chat(session, content)
    
    def _handle_file_upload(self, session, user_id: str, group_id: str, file_path: str, content: str) -> Dict:
        """处理文件上传"""
        file_path_obj = Path(file_path)
        
        # 1. 检测是否为分片文件
        part_info = self.part_manager.detect_part_file(file_path_obj)
        
        if part_info["is_part"]:
            # 是分片文件
            logger.info(f"检测到分片文件：{part_info['base_name']} part{part_info['part_number']}")
            return self._handle_part_file(session, user_id, group_id, part_info, file_path_obj)
        
        # 2. 不是分片文件，正常处理
        return self._process_normal_file(session, user_id, group_id, file_path_obj, content)
    
    def _handle_part_file(self, session, user_id: str, group_id: str, part_info: Dict, file_path: Path) -> Dict:
        """处理分片文件"""
        base_name = part_info["base_name"]
        part_number = part_info["part_number"]
        
        # 创建或更新分片任务
        task_id = f"PART-{user_id[:8]}-{base_name[:20]}"
        task = self.part_manager._load_task(task_id)
        
        if not task:
            # 创建新分片任务
            task = self.part_manager.create_part_task(
                user_id, group_id, base_name, part_number, file_path
            )
            return {
                "session_id": session.session_id,
                "response": f"✅ 已接收分片 {part_number}\n\n请继续上传剩余分片...",
                "status": "waiting_parts",
                "received_parts": [part_number]
            }
        else:
            # 添加到现有任务
            result = self.part_manager.add_part(task_id, part_number, file_path)
            
            if result["status"] == "ready_to_process":
                # 所有分片已接收，合并并处理
                merge_result = self.part_manager.merge_parts(task)
                if merge_result["success"]:
                    # 处理合并后的文件
                    return self._process_normal_file(
                        session, user_id, group_id, Path(merge_result["merged_file"]), ""
                    )
            
            return {
                "session_id": session.session_id,
                "response": result["message"],
                "status": result["status"],
                "received_parts": result["received_parts"]
            }
    
    def _process_normal_file(self, session, user_id: str, group_id: str, file_path: Path, content: str) -> Dict:
        """处理普通文件"""
        # 检测文件类型并处理
        from file_processor import WeComFileProcessor
        processor = WeComFileProcessor()
        file_result = processor.process_uploaded_file(file_path, user_id)
        
        # 创建工单
        from ticket_manager import TicketManager
        ticket_manager = TicketManager()
        ticket = ticket_manager.create_ticket(
            task_type="file_processing",
            user_id=user_id,
            group_id=group_id
        )
        
        return {
            "session_id": session.session_id,
            "response": f"{file_result['message']}\n\n工单已创建：{ticket['ticket_id']}",
            "ticket_id": ticket["ticket_id"]
        }
    
    def _handle_task_request(self, session, user_id: str, group_id: str, task_type: str, content: str) -> Dict:
        """处理任务请求"""
        # 检查是否需要确认（有历史任务且无新数据）
        needs_confirmation = self.confirmation_manager.is_confirmation_needed(
            user_id, group_id, task_type, has_new_data=False
        )
        
        if needs_confirmation:
            # 需要确认
            similar_tasks = self.confirmation_manager.check_similar_tasks(
                user_id, group_id, task_type
            )
            prompt = self.confirmation_manager.generate_confirmation_prompt(
                similar_tasks, task_type
            )
            
            # 保存状态，等待用户选择
            session.set_context("waiting_choice", {
                "task_type": task_type,
                "similar_tasks": similar_tasks
            })
            
            return {
                "session_id": session.session_id,
                "response": prompt,
                "waiting_choice": True
            }
        
        # 检查是否在选择状态
        waiting_choice = session.get_context_value("waiting_choice")
        if waiting_choice:
            # 用户在选择状态
            choice_result = self.confirmation_manager.handle_user_choice(
                user_id, group_id, task_type, content, waiting_choice["similar_tasks"]
            )
            
            if choice_result["action"] == "continue":
                # 继续上一次任务
                ticket_id = choice_result["ticket_id"]
                result = self.confirmation_manager.get_last_ticket_result(ticket_id)
                if result:
                    return {
                        "session_id": session.session_id,
                        "response": f"{choice_result['message']}\n\n上次任务结果:\n{result.get('result', '无结果')}"
                    }
            
            elif choice_result["action"] == "new_task":
                # 开始新任务，清除选择状态
                session.set_context("waiting_choice", None)
                # 继续创建新工单
            else:
                # 无效选择
                return {
                    "session_id": session.session_id,
                    "response": choice_result["message"]
                }
        
        # 创建新工单
        from ticket_manager import TicketManager
        ticket_manager = TicketManager()
        ticket = ticket_manager.create_ticket(
            task_type=task_type,
            user_id=user_id,
            group_id=group_id
        )
        
        # 请求数据
        return {
            "session_id": session.session_id,
            "response": f"📋 **工单已创建**\n\n工单号：{ticket['ticket_id']}\n任务类型：{self._get_task_type_name(task_type)}\n\n请提供数据...",
            "ticket_id": ticket["ticket_id"]
        }
    
    def _detect_task_type(self, content: str) -> Optional[str]:
        """检测任务类型"""
        content_lower = content.lower()
        
        # 故障分析
        if any(kw in content_lower for kw in ["故障", "分析", "diagnos", "analyze"]):
            return "fault_analysis"
        
        # 文件处理
        if any(kw in content_lower for kw in ["文件", "上传", "file", "upload"]):
            return "file_processing"
        
        # 数据查询
        if any(kw in content_lower for kw in ["查询", "数据", "query", "data"]):
            return "data_query"
        
        return None
    
    def _get_task_type_name(self, task_type: str) -> str:
        """获取任务类型名称"""
        return {
            "fault_analysis": "GPU 故障分析",
            "file_processing": "文件处理",
            "data_query": "数据查询"
        }.get(task_type, "任务")
    
    def _handle_normal_chat(self, session, content: str) -> Dict:
        """处理普通对话"""
        # 简单回复
        return {
            "session_id": session.session_id,
            "response": "收到，请问有什么可以帮助您？"
        }


# 全局实例
message_router = MessageRouter()


# CLI 接口
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python message_router.py <command> [args]")
        print("命令:")
        print("  route <message_json> - 路由消息")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "route":
        if len(sys.argv) < 3:
            print("用法：route <message_json>")
            sys.exit(1)
        message = json.loads(sys.argv[2])
        result = message_router.route_message(message)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        print(f"未知命令：{command}")
        sys.exit(1)
