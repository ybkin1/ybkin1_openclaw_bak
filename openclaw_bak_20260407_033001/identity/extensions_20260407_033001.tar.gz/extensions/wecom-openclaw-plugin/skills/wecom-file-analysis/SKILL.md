# wecom-file-analysis - 文件分析与故障诊断

**版本**: v1.0  
**创建时间**: 2026-03-31  
**状态**: ✅ 待实施

---

## 📋 功能

- 检测用户上传的文件
- 自动处理日志文件
- 自动处理压缩包
- 创建故障分析工单
- 调用 server-maintenance Agent 分析

---

## 🎯 触发条件

| 条件 | 说明 |
|------|------|
| **用户上传文件** | 任何文件类型 |
| **消息包含关键词** | "分析"、"故障"、"日志"、"diagnos"、"analyze" |
| **文件类型** | .log, .tar.gz, .gz, .zip, .txt |

---

## 🔧 处理流程

```
用户上传文件 + 消息
    ↓
检测文件类型
    ↓
├── 是分片文件 → 调用 part_manager 等待所有分片
├── 是压缩包 → 调用 file_processor 解压
└── 是日志文件 → 直接分析
    ↓
创建工单 (ticket_manager)
    ↓
调用 server-maintenance Agent
    ↓
返回分析结果
```

---

## 💻 使用方式

### 方式 1: 自动触发

用户上传图片/文件 + "分析故障"
  ↓
自动处理

### 方式 2: MCP tool 调用

```json
{
  "tool": "wecom_mcp",
  "action": "call",
  "params": {
    "method": "file_analysis",
    "args": {
      "file_path": "/path/to/file.log",
      "user_id": "ou_xxx",
      "analysis_type": "fault"
    }
  }
}
```

---

## 📊 响应格式

### 成功响应

```markdown
✅ **文件已接收**

文件名：nvidia-bug-report.log.tar.gz
文件大小：3.2MB
文件类型：压缩包

📋 **工单已创建**
工单号：TKT-xxx
任务类型：GPU 故障分析

正在分析，请稍候...
```

### 分片文件响应

```markdown
✅ **已接收分片 1/4**

文件名：nvidia-bug-report.log.tar.gz.part1
文件大小：15MB

请继续上传剩余分片...
```

---

## 🔍 支持的文件类型

| 类型 | 扩展名 | 处理方式 |
|------|--------|---------|
| **日志文件** | .log, .txt | 直接分析 |
| **NVIDIA 日志** | nvidia-bug-report.log | 专用分析 |
| **压缩包** | .tar.gz, .gz, .zip | 解压后分析 |
| **分片文件** | .part1, .001, .aa | 等待合并 |

---

## ⚠️ 注意事项

1. 文件大小限制：最大 500MB
2. 分片超时：10 分钟
3. 压缩包文件数限制：最大 1000 个
4. 支持格式：.log, .tar.gz, .gz, .zip, .txt

---

**技能版本**: v1.0  
**创建时间**: 2026-03-31  
**状态**: ✅ **待实施**
