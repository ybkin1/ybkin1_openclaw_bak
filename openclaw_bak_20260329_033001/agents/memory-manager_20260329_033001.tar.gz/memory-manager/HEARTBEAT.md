# Memory Manager Agent Heartbeat

## Daily Tasks
- **Memory Classification**: Analyze and classify new memory entries
- **Optimization Check**: Identify memory structures that need optimization
- **Cleanup**: Remove expired temporary memory entries (7-day retention)
- **Coordination**: Sync with other agents for memory consistency

## Monitoring
- **Memory Usage**: Track total memory consumption across all agents
- **Performance Metrics**: Monitor memory access patterns and response times
- **Integrity Check**: Verify memory file integrity and consistency

## Integration Points
- **Master Agent**: Receive memory optimization requests
- **Other Agents**: Provide memory classification and optimization services
- **Backup Agent**: Coordinate memory backup operations

## Error Handling
- **Corrupted Memory**: Quarantine and attempt recovery of corrupted files
- **Access Conflicts**: Implement locking mechanism for concurrent access
- **Storage Limits**: Alert when memory usage exceeds thresholds