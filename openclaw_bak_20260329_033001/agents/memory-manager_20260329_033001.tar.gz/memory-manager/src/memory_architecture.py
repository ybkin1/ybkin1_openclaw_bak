"""
Memory Manager - 记忆架构管理模块

实现三层记忆架构:
- L1: 工作记忆 (Working Memory)
- L2: 语义记忆 (Semantic Memory)
- L3: 事实记忆 (Factual Memory)
"""

import os
import json
import uuid
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta

try:
    from database_manager.src.connection import DatabaseConnection
    from database_manager.src.crud import CRUDOperations
except ImportError:
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'database-manager', 'src'))
    from connection import DatabaseConnection
    from crud import CRUDOperations


class MemoryManager:
    """记忆管理器"""
    
    def __init__(self, db_path: str):
        """
        初始化记忆管理器
        
        Args:
            db_path: 数据库路径
        """
        self.db_conn = DatabaseConnection(db_path)
        self.db_conn.connect()
        self.db = CRUDOperations(self.db_conn)
        
        # 确保表存在
        self._ensure_tables()
    
    def _ensure_tables(self):
        """确保记忆表存在"""
        # 检查工作记忆表
        result = self.db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='memory_working'")
        if not result.fetchone():
            raise RuntimeError("记忆表不存在，请先执行 014_memory_architecture.sql")
    
    # ========== L1: 工作记忆 ==========
    
    def store_working_memory(self, session_id: str, content: str, role: str,
                            user_id: str = None, metadata: Dict = None,
                            ttl_hours: int = 24) -> str:
        """
        存储工作记忆
        
        Args:
            session_id: 会话 ID
            content: 内容
            role: 角色 (user/assistant/system)
            user_id: 用户 ID
            metadata: 元数据
            ttl_hours: 存活时间 (小时)
        
        Returns:
            memory_id
        """
        memory_id = f"wm_{uuid.uuid4().hex[:12]}"
        expires_at = datetime.now() + timedelta(hours=ttl_hours)
        
        self.db.insert('memory_working', {
            'memory_id': memory_id,
            'session_id': session_id,
            'user_id': user_id,
            'content': content,
            'role': role,
            'metadata': json.dumps(metadata or {}),
            'expires_at': expires_at.isoformat()
        })
        
        return memory_id
    
    def get_working_memory(self, session_id: str, limit: int = 10) -> List[Dict]:
        """
        获取工作记忆
        
        Args:
            session_id: 会话 ID
            limit: 限制数量
        
        Returns:
            工作记忆列表
        """
        results = self.db.fetch_all(
            'memory_working',
            where={'session_id': session_id},
            order_by='created_at DESC',
            limit=limit
        )
        
        # 解析 JSON
        for result in results:
            if result.get('metadata'):
                try:
                    result['metadata'] = json.loads(result['metadata'])
                except:
                    pass
        
        return results
    
    def cleanup_working_memory(self) -> int:
        """清理过期工作记忆"""
        # 触发器会自动清理，这里手动清理一次
        self.db.execute("""
            DELETE FROM memory_working 
            WHERE expires_at < CURRENT_TIMESTAMP
        """)
        return 0  # 触发器已处理
    
    # ========== L2: 语义记忆 ==========
    
    def store_semantic_memory(self, content: str, category: str = 'general',
                             confidence: float = 1.0, source_session_id: str = None,
                             source_message_id: str = None, summary: str = None) -> str:
        """
        存储语义记忆
        
        Args:
            content: 内容
            category: 类别 (fact/opinion/preference/context/emotion)
            confidence: 置信度 (0-1)
            source_session_id: 来源会话 ID
            source_message_id: 来源消息 ID
            summary: 摘要
        
        Returns:
            memory_id
        """
        memory_id = f"sm_{uuid.uuid4().hex[:12]}"
        
        self.db.insert('memory_semantic', {
            'memory_id': memory_id,
            'content': content,
            'summary': summary,
            'category': category,
            'confidence': confidence,
            'source_session_id': source_session_id,
            'source_message_id': source_message_id,
            'verified': False
        })
        
        return memory_id
    
    def search_semantic_memory(self, query: str = None, category: str = None,
                              min_confidence: float = 0.8, verified: bool = True,
                              limit: int = 10) -> List[Dict]:
        """
        搜索语义记忆
        
        Args:
            query: 查询文本 (用于简单匹配)
            category: 类别过滤
            min_confidence: 最小置信度
            verified: 是否只返回已验证
            limit: 限制数量
        
        Returns:
            语义记忆列表
        """
        where = {}
        
        if category:
            where['category'] = category
        
        if verified:
            where['verified'] = True
        
        # 查询
        results = self.db.fetch_all(
            'memory_semantic',
            where=where,
            order_by='confidence DESC, access_count DESC',
            limit=limit * 2  # 多取一些用于过滤
        )
        
        # 过滤
        filtered = []
        for result in results:
            # 置信度过滤
            if result.get('confidence', 0) < min_confidence:
                continue
            
            # 查询文本匹配
            if query and query.lower() not in result.get('content', '').lower():
                continue
            
            # 软删除过滤
            if result.get('deleted_at'):
                continue
            
            filtered.append(result)
        
        return filtered[:limit]
    
    def verify_semantic_memory(self, memory_id: str, verified_by: str = 'system') -> bool:
        """
        验证语义记忆
        
        Args:
            memory_id: 记忆 ID
            verified_by: 验证人
        
        Returns:
            bool
        """
        rows = self.db.update(
            'memory_semantic',
            {'verified': True, 'verified_by': verified_by, 'verified_at': datetime.now().isoformat()},
            {'memory_id': memory_id}
        )
        
        return rows > 0
    
    # ========== L3: 事实记忆 ==========
    
    def store_fact(self, subject: str, predicate: str, object: str,
                  category: str = 'general', confidence: float = 1.0,
                  source_memory_id: str = None, valid_until: str = None) -> str:
        """
        存储事实记忆
        
        Args:
            subject: 主体
            predicate: 关系/动作
            object: 客体
            category: 类别 (personal/professional/preference/skill/context)
            confidence: 置信度
            source_memory_id: 来源记忆 ID
            valid_until: 有效期 (ISO 格式，NULL 表示永久)
        
        Returns:
            fact_id
        """
        fact_id = f"fact_{uuid.uuid4().hex[:12]}"
        
        self.db.insert('memory_facts', {
            'fact_id': fact_id,
            'subject': subject,
            'predicate': predicate,
            'object': object,
            'category': category,
            'confidence': confidence,
            'source_memory_id': source_memory_id,
            'verified': True,  # 事实必须验证
            'verified_by': 'system',
            'verified_at': datetime.now().isoformat(),
            'valid_until': valid_until
        })
        
        return fact_id
    
    def search_facts(self, subject: str = None, category: str = None,
                    verified: bool = True, limit: int = 10) -> List[Dict]:
        """
        搜索事实记忆
        
        Args:
            subject: 主体过滤
            category: 类别过滤
            verified: 是否只返回已验证
            limit: 限制数量
        
        Returns:
            事实记忆列表
        """
        where = {}
        
        if subject:
            where['subject'] = subject
        
        if category:
            where['category'] = category
        
        if verified:
            where['verified'] = True
        
        results = self.db.fetch_all(
            'memory_facts',
            where=where,
            order_by='verified_at DESC',
            limit=limit
        )
        
        # 过滤软删除
        return [r for r in results if not r.get('deleted_at')]
    
    def check_fact_conflict(self, subject: str, predicate: str, object: str) -> Tuple[bool, Optional[Dict]]:
        """
        检查事实冲突
        
        Args:
            subject: 主体
            predicate: 关系
            object: 客体
        
        Returns:
            (has_conflict, conflicting_fact)
        """
        # 查找冲突事实
        facts = self.search_facts(subject=subject, verified=True)
        
        for fact in facts:
            if fact['predicate'] == predicate and fact['object'] != object:
                return True, fact
        
        return False, None
    
    # ========== 验证日志 ==========
    
    def log_verification(self, memory_id: str, memory_type: str,
                        verification_type: str, result: str,
                        original_content: str = None, verified_content: str = None,
                        reason: str = None, confidence_before: float = None,
                        confidence_after: float = None, verified_by: str = 'system') -> str:
        """
        记录验证日志
        
        Args:
            memory_id: 记忆 ID
            memory_type: 记忆类型 (semantic/fact)
            verification_type: 验证类型 (user_confirm/auto_verify/conflict_detect/cross_validate)
            result: 结果 (confirmed/corrected/rejected)
            original_content: 原始内容
            verified_content: 验证后内容
            reason: 原因
            confidence_before: 验证前置信度
            confidence_after: 验证后置信度
            verified_by: 验证人
        
        Returns:
            log_id
        """
        log_id = f"log_{uuid.uuid4().hex[:12]}"
        
        self.db.insert('memory_verification_log', {
            'log_id': log_id,
            'memory_id': memory_id,
            'memory_type': memory_type,
            'verification_type': verification_type,
            'original_content': original_content,
            'verified_content': verified_content,
            'result': result,
            'reason': reason,
            'confidence_before': confidence_before,
            'confidence_after': confidence_after,
            'verified_by': verified_by
        })
        
        return log_id
    
    # ========== 统计与清理 ==========
    
    def get_verification_stats(self) -> List[Dict]:
        """获取验证统计"""
        return self.db.fetch_all('v_verification_stats')
    
    def get_active_working_memory_count(self, session_id: str = None) -> int:
        """获取活跃工作记忆数量"""
        where = {}
        if session_id:
            where['session_id'] = session_id
        
        return self.db.count('memory_working', where)
    
    def get_semantic_memory_count(self, verified: bool = True) -> int:
        """获取语义记忆数量"""
        where = {'verified': verified} if verified else {}
        return self.db.count('memory_semantic', where)
    
    def get_fact_count(self, verified: bool = True) -> int:
        """获取事实记忆数量"""
        where = {'verified': verified} if verified else {}
        return self.db.count('memory_facts', where)
    
    def cleanup_old_memories(self, days: int = 30) -> int:
        """
        清理旧记忆
        
        Args:
            days: 多少天无访问的记忆
        
        Returns:
            清理数量
        """
        # 清理 30 天无访问的语义记忆
        self.db.execute("""
            UPDATE memory_semantic 
            SET deleted_at = CURRENT_TIMESTAMP
            WHERE last_accessed_at < datetime('now', ?)
            AND deleted_at IS NULL
        """, (f'-{days} days',))
        
        return 0  # 触发器已处理
    
    def close(self):
        """关闭连接"""
        if self.db_conn:
            self.db_conn.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# 便捷函数
def create_memory_manager(db_path: str) -> MemoryManager:
    """创建记忆管理器实例"""
    return MemoryManager(db_path)
