#!/bin/bash
# Memory Manager - 记忆维护脚本
# 由 Master Agent 的 HEARTBEAT.md 调用，或由 memory-manager Agent 定期执行

set -euo pipefail

WORKSPACE="/root/.openclaw/workspace"
MASTER_MEMORY="$WORKSPACE/agents/master/memory/master"
SHARED_MEMORY="$WORKSPACE/memory"
LOG_FILE="$WORKSPACE/agents/memory-manager/logs/maintenance.log"

mkdir -p "$(dirname "$LOG_FILE")"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"; }

# 短期记忆清理（保留 7 天）
cleanup_short_term() {
    log "清理短期记忆（保留 7 天）..."
    local count=0
    
    if [ -d "$MASTER_MEMORY/short_term" ]; then
        count=$(find "$MASTER_MEMORY/short_term" -type f -mtime +7 | wc -l)
        find "$MASTER_MEMORY/short_term" -type f -mtime +7 -delete
    fi
    
    log "✓ 清理 $count 个过期短期记忆文件"
}

# 已完成任务归档（保留 30 天）
archive_completed_tasks() {
    log "归档已完成任务（保留 30 天）..."
    local count=0
    
    if [ -d "$MASTER_MEMORY/tasks/completed" ]; then
        count=$(find "$MASTER_MEMORY/tasks/completed" -type f -mtime +30 | wc -l)
        find "$MASTER_MEMORY/tasks/completed" -type f -mtime +30 -delete
    fi
    
    log "✓ 清理 $count 个过期已完成任务"
}

# 记忆质量检查
check_memory_quality() {
    log "记忆质量检查..."
    
    local issues=0
    
    # 检查空文件
    local empty_files=$(find "$MASTER_MEMORY" -type f -empty 2>/dev/null | wc -l)
    if [ "$empty_files" -gt 0 ]; then
        log "⚠ 发现 $empty_files 个空记忆文件"
        issues=$((issues + 1))
    fi
    
    # 检查大文件（> 1MB）
    local large_files=$(find "$MASTER_MEMORY" -type f -size +1M 2>/dev/null | wc -l)
    if [ "$large_files" -gt 0 ]; then
        log "⚠ 发现 $large_files 个大记忆文件（> 1MB）"
        issues=$((issues + 1))
    fi
    
    # 检查记忆目录结构
    local required_dirs=(
        "$MASTER_MEMORY/short_term"
        "$MASTER_MEMORY/long_term"
        "$MASTER_MEMORY/tasks/active"
        "$MASTER_MEMORY/tasks/completed"
        "$SHARED_MEMORY"
    )
    
    for dir in "${required_dirs[@]}"; do
        if [ ! -d "$dir" ]; then
            log "⚠ 记忆目录缺失：$dir"
            mkdir -p "$dir"
            issues=$((issues + 1))
        fi
    done
    
    if [ "$issues" -eq 0 ]; then
        log "✓ 记忆质量检查通过"
    else
        log "⚠ 发现 $issues 个记忆质量问题"
    fi
    
    return $issues
}

# 生成记忆统计报告
generate_memory_stats() {
    log "生成记忆统计报告..."
    
    local report_file="$WORKSPACE/agents/memory-manager/logs/memory-stats-$(date +%Y%m%d).txt"
    
    {
        echo "=========================================="
        echo "   记忆系统统计报告"
        echo "   生成时间：$(date '+%Y-%m-%d %H:%M:%S')"
        echo "=========================================="
        echo ""
        
        echo "记忆文件统计:"
        echo "------------------------------------------"
        printf "%-30s %10s %12s\n" "目录" "文件数" "总大小"
        echo "------------------------------------------"
        
        for dir in "$MASTER_MEMORY/short_term" "$MASTER_MEMORY/long_term" "$MASTER_MEMORY/tasks/"* "$SHARED_MEMORY"; do
            if [ -d "$dir" ]; then
                local files=$(find "$dir" -type f 2>/dev/null | wc -l)
                local size=$(du -sh "$dir" 2>/dev/null | cut -f1)
                printf "%-30s %10d %12s\n" "$dir" "$files" "$size"
            fi
        done
        
        echo "------------------------------------------"
        echo ""
        
        echo "记忆增长趋势（最近 7 天）:"
        echo "------------------------------------------"
        for i in {0..6}; do
            local date=$(date -d "-$i days" +%Y-%m-%d)
            local new_files=$(find "$MASTER_MEMORY" -type f -newermt "$date" 2>/dev/null | wc -l)
            echo "  $date: +$new_files 文件"
        done
        
        echo ""
        echo "=========================================="
        
    } > "$report_file"
    
    log "✓ 统计报告已生成：$report_file"
}

# 主函数
main() {
    log "=========================================="
    log "Memory Manager 记忆维护开始"
    log "=========================================="
    
    cleanup_short_term
    archive_completed_tasks
    check_memory_quality || true
    generate_memory_stats
    
    log "=========================================="
    log "Memory Manager 记忆维护完成"
    log "=========================================="
}

# 执行
main "$@"
