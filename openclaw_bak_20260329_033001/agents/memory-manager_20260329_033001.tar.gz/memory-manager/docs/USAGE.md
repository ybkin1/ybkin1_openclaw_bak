# 记忆架构使用指南

**版本**: 1.0  
**创建时间**: 2026-03-27 15:16  
**状态**: 生产就绪

---

## 📋 目录

1. [概述](#概述)
2. [三层记忆架构](#三层记忆架构)
3. [快速开始](#快速开始)
4. [API 参考](#api 参考)
5. [最佳实践](#最佳实践)
6. [防幻觉机制](#防幻觉机制)
7. [示例代码](#示例代码)

---

## 概述

记忆架构是 OpenClaw Agent 系统的核心组件，用于解决 AI 幻觉问题，提供可靠、可验证的记忆存储和检索机制。

### 核心特性

- ✅ **三层架构** - 工作记忆/语义记忆/事实记忆
- ✅ **置信度评分** - 每个记忆都有可信度评分
- ✅ **来源追溯** - 可追溯到具体对话
- ✅ **冲突检测** - 自动检测矛盾信息
- ✅ **自动过期** - 工作记忆 24 小时自动清理
- ✅ **验证日志** - 完整验证历史记录

---

## 三层记忆架构

```
┌─────────────────────────────────────────┐
│     L1: 工作记忆 (Working Memory)        │
│  - 短期缓存 (最近 10 条对话)              │
│  - 高保真、无压缩                        │
│  - 存储：memory_working 表               │
│  - 过期：24 小时自动清理                  │
└─────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│     L2: 语义记忆 (Semantic Memory)       │
│  - 中期记忆 (向量检索 Top-K)             │
│  - 带来源、时间戳、置信度                │
│  - 存储：memory_semantic 表              │
│  - 过期：30 天无访问自动归档              │
└─────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────┐
│     L3: 事实记忆 (Factual Memory)        │
│  - 长期记忆 (已验证事实)                 │
│  - 结构化存储、可验证                    │
│  - 存储：memory_facts 表                 │
│  - 过期：永久保存 (除非手动删除)          │
└─────────────────────────────────────────┘
```

### L1: 工作记忆

**用途**: 临时存储最近对话，保持上下文连贯性

**特点**:
- 存储最近 10 条对话
- 24 小时自动过期
- 100% 准确，无压缩
- 按会话隔离

**示例**:
```python
memory_id = mm.store_working_memory(
    session_id='session_123',
    content='用户询问如何配置数据库',
    role='user',
    ttl_hours=24
)
```

### L2: 语义记忆

**用途**: 存储有意义的信息，支持检索和验证

**特点**:
- 带置信度评分 (0-1)
- 来源追溯 (session_id, message_id)
- 分类存储 (fact/opinion/preference/context/emotion)
- 30 天无访问自动归档

**示例**:
```python
memory_id = mm.store_semantic_memory(
    content='用户喜欢 Python 编程',
    category='preference',
    confidence=0.9,
    source_session_id='session_123',
    summary='用户偏好'
)
```

### L3: 事实记忆

**用途**: 存储已验证的结构化事实

**特点**:
- 主谓宾结构 (subject/predicate/object)
- 必须经过验证
- 永久保存 (除非手动删除)
- 支持冲突检测

**示例**:
```python
fact_id = mm.store_fact(
    subject='用户',
    predicate='职业是',
    object='智算服务器硬件运维经理',
    category='professional',
    confidence=1.0
)
```

---

## 快速开始

### 1. 安装依赖

```bash
# 确保 database-manager 已安装
cd /root/.openclaw/workspace/agents/database-manager
python -m pip install -e .
```

### 2. 执行数据库迁移

```bash
# 执行记忆架构迁移
sqlite3 /root/.openclaw/workspace/agents/master/memory.db < scripts/014_memory_architecture.sql
```

### 3. 初始化记忆管理器

```python
from memory_manager.src.memory_architecture import MemoryManager

# 创建实例
mm = MemoryManager('/path/to/database.db')

# 使用上下文管理器
with MemoryManager('/path/to/database.db') as mm:
    # 使用记忆管理器
    pass
```

---

## API 参考

### 工作记忆 API

#### store_working_memory()

```python
def store_working_memory(
    session_id: str,
    content: str,
    role: str,  # 'user' | 'assistant' | 'system'
    user_id: str = None,
    metadata: Dict = None,
    ttl_hours: int = 24
) -> str
```

**参数**:
- `session_id`: 会话 ID
- `content`: 内容
- `role`: 角色
- `user_id`: 用户 ID (可选)
- `metadata`: 元数据 (可选)
- `ttl_hours`: 存活时间 (小时)

**返回**: memory_id

**示例**:
```python
memory_id = mm.store_working_memory(
    session_id='session_123',
    content='用户说喜欢 Python',
    role='user',
    metadata={'source': 'feishu'}
)
```

#### get_working_memory()

```python
def get_working_memory(
    session_id: str,
    limit: int = 10
) -> List[Dict]
```

**返回**: 工作记忆列表 (按时间倒序)

---

### 语义记忆 API

#### store_semantic_memory()

```python
def store_semantic_memory(
    content: str,
    category: str = 'general',  # 'fact' | 'opinion' | 'preference' | 'context' | 'emotion'
    confidence: float = 1.0,  # 0-1
    source_session_id: str = None,
    source_message_id: str = None,
    summary: str = None
) -> str
```

**返回**: memory_id

#### search_semantic_memory()

```python
def search_semantic_memory(
    query: str = None,
    category: str = None,
    min_confidence: float = 0.8,
    verified: bool = True,
    limit: int = 10
) -> List[Dict]
```

**参数**:
- `query`: 查询文本 (简单匹配)
- `category`: 类别过滤
- `min_confidence`: 最小置信度
- `verified`: 是否只返回已验证
- `limit`: 限制数量

**返回**: 语义记忆列表 (按置信度降序)

#### verify_semantic_memory()

```python
def verify_semantic_memory(
    memory_id: str,
    verified_by: str = 'system'
) -> bool
```

**返回**: 是否成功验证

---

### 事实记忆 API

#### store_fact()

```python
def store_fact(
    subject: str,
    predicate: str,
    object: str,
    category: str = 'general',  # 'personal' | 'professional' | 'preference' | 'skill' | 'context'
    confidence: float = 1.0,
    source_memory_id: str = None,
    valid_until: str = None  # ISO 格式，NULL 表示永久
) -> str
```

**返回**: fact_id

#### search_facts()

```python
def search_facts(
    subject: str = None,
    category: str = None,
    verified: bool = True,
    limit: int = 10
) -> List[Dict]
```

**返回**: 事实记忆列表

#### check_fact_conflict()

```python
def check_fact_conflict(
    subject: str,
    predicate: str,
    object: str
) -> Tuple[bool, Optional[Dict]]
```

**返回**: (是否有冲突，冲突的事实)

---

### 验证日志 API

#### log_verification()

```python
def log_verification(
    memory_id: str,
    memory_type: str,  # 'semantic' | 'fact'
    verification_type: str,  # 'user_confirm' | 'auto_verify' | 'conflict_detect' | 'cross_validate'
    result: str,  # 'confirmed' | 'corrected' | 'rejected'
    original_content: str = None,
    verified_content: str = None,
    reason: str = None,
    confidence_before: float = None,
    confidence_after: float = None,
    verified_by: str = 'system'
) -> str
```

**返回**: log_id

---

## 最佳实践

### 1. 记忆写入流程

```python
# ✅ 推荐流程
# 1. 存储工作记忆 (100% 准确)
wm_id = mm.store_working_memory(session_id, content, role)

# 2. 提取关键信息到语义记忆
sm_id = mm.store_semantic_memory(
    content='提取的信息',
    category='preference',
    confidence=0.8,  # 初始置信度
    source_session_id=session_id
)

# 3. 用户确认后提升置信度
mm.verify_semantic_memory(sm_id, verified_by='user_001')

# 4. 存储为事实记忆
fact_id = mm.store_fact(
    subject='用户',
    predicate='喜欢',
    object='Python',
    category='preference',
    source_memory_id=sm_id
)
```

### 2. 记忆检索流程

```python
# ✅ 推荐流程
# 1. 优先查询事实记忆 (精确匹配)
facts = mm.search_facts(subject='用户', verified=True)

# 2. 向量检索语义记忆 (Top-K + 过滤)
semantic = mm.search_semantic_memory(
    query='用户偏好',
    min_confidence=0.8,
    verified=True
)

# 3. 查询工作记忆 (最近对话)
working = mm.get_working_memory(session_id, limit=10)

# 4. 合并结果 (去重 + 排序)
# 优先级：事实记忆 > 语义记忆 > 工作记忆
```

### 3. 置信度管理

```python
# ✅ 推荐做法
# 初始置信度
confidence = 0.8  # 有来源但未验证

# 用户确认后
confidence = 1.0  # 已验证

# 时间衰减
confidence *= 0.99  # 每天 -1%

# 交叉验证
if multiple_sources:
    confidence *= 1.2  # 多来源提升
```

### 4. 冲突处理

```python
# ✅ 推荐做法
# 存储前检查冲突
has_conflict, conflicting = mm.check_fact_conflict(
    subject='用户',
    predicate='职业是',
    object='新职业'
)

if has_conflict:
    # 记录冲突
    mm.log_verification(
        memory_id=fact_id,
        memory_type='fact',
        verification_type='conflict_detect',
        result='rejected',
        reason=f'与已验证事实冲突：{conflicting}'
    )
    # 不存储冲突事实
else:
    # 存储事实
    mm.store_fact(...)
```

---

## 防幻觉机制

### 1. 置信度评分

```python
置信度 = 来源可信度 × 时间衰减 × 访问频率 × 交叉验证

- 已验证事实：1.0
- 有来源信息：0.8
- 无来源信息：0.5
- 时间衰减：每天 -1%
- 访问频率：>10 次 ×1.1
- 交叉验证：多来源 ×1.2
```

### 2. 事实验证

```python
验证流程:
1. 检查冲突事实
2. 用户确认 (可选)
3. 交叉验证 (多来源)
4. 记录验证日志
```

### 3. 来源追溯

每个记忆包含:
- `source_session_id`: 来源会话
- `source_message_id`: 来源消息
- `verified_by`: 验证人
- `verified_at`: 验证时间

### 4. 幻觉检测

```python
检测项:
1. 主张是否有来源支持
2. 是否与已验证事实冲突
3. 置信度是否 > 阈值
4. 时间是否有效
```

---

## 示例代码

### 完整工作流

```python
from memory_manager.src.memory_architecture import MemoryManager

# 初始化
with MemoryManager('/path/to/database.db') as mm:
    session_id = 'session_123'
    user_id = 'user_001'
    
    # 1. 用户输入
    user_input = '我喜欢 Python 编程，是个运维经理'
    
    # 2. 存储工作记忆
    wm_id = mm.store_working_memory(
        session_id=session_id,
        content=user_input,
        role='user',
        user_id=user_id
    )
    
    # 3. 提取信息到语义记忆
    sm_id_1 = mm.store_semantic_memory(
        content='用户喜欢 Python 编程',
        category='preference',
        confidence=0.8,
        source_session_id=session_id
    )
    
    sm_id_2 = mm.store_semantic_memory(
        content='用户是运维经理',
        category='context',
        confidence=0.8,
        source_session_id=session_id
    )
    
    # 4. 用户确认
    mm.verify_semantic_memory(sm_id_1, verified_by=user_id)
    mm.verify_semantic_memory(sm_id_2, verified_by=user_id)
    
    # 5. 存储为事实
    fact_id_1 = mm.store_fact(
        subject='用户',
        predicate='喜欢',
        object='Python 编程',
        category='preference',
        source_memory_id=sm_id_1
    )
    
    fact_id_2 = mm.store_fact(
        subject='用户',
        predicate='职业是',
        object='运维经理',
        category='professional',
        source_memory_id=sm_id_2
    )
    
    # 6. 记录验证日志
    mm.log_verification(
        memory_id=sm_id_1,
        memory_type='semantic',
        verification_type='user_confirm',
        result='confirmed',
        confidence_before=0.8,
        confidence_after=1.0,
        verified_by=user_id
    )
    
    # 7. 后续查询
    facts = mm.search_facts(subject='用户', verified=True)
    print(facts)  # 输出已验证事实
```

### 防幻觉查询

```python
def query_with_anti_hallucination(mm, query: str, subject: str = None):
    """带防幻觉的查询"""
    
    # 1. 优先查询事实记忆
    if subject:
        facts = mm.search_facts(subject=subject, verified=True)
        if facts:
            return {
                'source': 'facts',
                'data': facts,
                'confidence': 1.0
            }
    
    # 2. 查询语义记忆 (高置信度)
    semantic = mm.search_semantic_memory(
        query=query,
        min_confidence=0.8,
        verified=True
    )
    if semantic:
        return {
            'source': 'semantic',
            'data': semantic,
            'confidence': semantic[0]['confidence']
        }
    
    # 3. 查询工作记忆
    working = mm.get_working_memory(session_id, limit=10)
    if working:
        return {
            'source': 'working',
            'data': working,
            'confidence': 0.5  # 工作记忆置信度较低
        }
    
    # 4. 无结果
    return {
        'source': None,
        'data': [],
        'confidence': 0.0
    }
```

---

## 附录

### A. 数据库表结构

| 表名 | 用途 | 字段数 |
|------|------|--------|
| **memory_working** | 工作记忆 | 8 |
| **memory_semantic** | 语义记忆 | 13 |
| **memory_facts** | 事实记忆 | 12 |
| **memory_verification_log** | 验证日志 | 11 |

### B. 视图

| 视图名 | 用途 |
|--------|------|
| **v_active_working_memory** | 活跃工作记忆 |
| **v_verified_facts** | 已验证事实 |
| **v_high_confidence_semantic** | 高置信度语义记忆 |
| **v_verification_stats** | 验证统计 |

### C. 触发器

| 触发器名 | 用途 |
|----------|------|
| **cleanup_working_memory** | 自动清理过期工作记忆 |
| **update_semantic_access** | 更新访问时间 |
| **detect_fact_conflicts** | 事实冲突检测 |

---

**文档版本**: 1.0  
**创建时间**: 2026-03-27 15:16  
**维护者**: Memory Manager Agent  
**下次审查**: 2026-04-27
