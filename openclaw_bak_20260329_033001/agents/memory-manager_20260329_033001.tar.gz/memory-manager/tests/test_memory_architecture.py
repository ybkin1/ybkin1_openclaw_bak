"""
测试记忆架构模块

测试覆盖:
- 工作记忆 (L1)
- 语义记忆 (L2)
- 事实记忆 (L3)
- 验证日志
- 防幻觉机制
"""

import os
import sys
import unittest
from datetime import datetime, timedelta

# 添加路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))
from memory_architecture import MemoryManager


class TestMemoryArchitecture(unittest.TestCase):
    """记忆架构测试"""
    
    @classmethod
    def setUpClass(cls):
        """设置测试数据库"""
        cls.db_path = ':memory:'
        cls.mm = MemoryManager(cls.db_path)
        
        # 创建表 (使用 SQL 文件)
        sql_file = os.path.join(os.path.dirname(__file__), '..', '..', 'database-manager', 'scripts', '014_memory_architecture.sql')
        if os.path.exists(sql_file):
            with open(sql_file, 'r') as f:
                sql = f.read()
            cls.mm.db.execute(sql)
    
    @classmethod
    def tearDownClass(cls):
        """清理"""
        cls.mm.close()
    
    # ========== L1: 工作记忆测试 ==========
    
    def test_store_working_memory(self):
        """测试存储工作记忆"""
        memory_id = self.mm.store_working_memory(
            session_id='test_session',
            content='用户询问数据库配置',
            role='user',
            user_id='user_001',
            ttl_hours=24
        )
        
        self.assertTrue(memory_id.startswith('wm_'))
    
    def test_get_working_memory(self):
        """测试获取工作记忆"""
        # 存储
        self.mm.store_working_memory(
            session_id='test_session',
            content='消息 1',
            role='user'
        )
        self.mm.store_working_memory(
            session_id='test_session',
            content='消息 2',
            role='assistant'
        )
        
        # 获取
        memories = self.mm.get_working_memory('test_session', limit=10)
        
        self.assertEqual(len(memories), 2)
        self.assertEqual(memories[0]['content'], '消息 2')  # 最新在前
    
    def test_working_memory_metadata(self):
        """测试工作记忆元数据"""
        memory_id = self.mm.store_working_memory(
            session_id='test_session',
            content='测试消息',
            role='user',
            metadata={'source': 'feishu', 'priority': 'high'}
        )
        
        memories = self.mm.get_working_memory('test_session')
        self.assertEqual(memories[0]['metadata']['source'], 'feishu')
    
    # ========== L2: 语义记忆测试 ==========
    
    def test_store_semantic_memory(self):
        """测试存储语义记忆"""
        memory_id = self.mm.store_semantic_memory(
            content='用户喜欢 Python 编程',
            category='preference',
            confidence=0.9,
            source_session_id='test_session',
            summary='用户偏好'
        )
        
        self.assertTrue(memory_id.startswith('sm_'))
    
    def test_search_semantic_memory(self):
        """测试搜索语义记忆"""
        # 存储
        self.mm.store_semantic_memory(
            content='用户喜欢 Python',
            category='preference',
            confidence=0.9
        )
        self.mm.store_semantic_memory(
            content='用户是运维经理',
            category='context',
            confidence=0.95
        )
        
        # 搜索
        results = self.mm.search_semantic_memory(
            category='preference',
            min_confidence=0.8,
            limit=10
        )
        
        self.assertEqual(len(results), 1)
        self.assertIn('Python', results[0]['content'])
    
    def test_verify_semantic_memory(self):
        """测试验证语义记忆"""
        memory_id = self.mm.store_semantic_memory(
            content='待验证信息',
            confidence=0.7
        )
        
        # 验证
        success = self.mm.verify_semantic_memory(memory_id, verified_by='user_confirm')
        
        self.assertTrue(success)
        
        # 检查验证状态
        results = self.mm.search_semantic_memory(verified=True)
        self.assertTrue(any(m['memory_id'] == memory_id for m in results))
    
    # ========== L3: 事实记忆测试 ==========
    
    def test_store_fact(self):
        """测试存储事实记忆"""
        fact_id = self.mm.store_fact(
            subject='用户',
            predicate='职业是',
            object='智算服务器硬件运维经理',
            category='professional',
            confidence=1.0
        )
        
        self.assertTrue(fact_id.startswith('fact_'))
    
    def test_search_facts(self):
        """测试搜索事实记忆"""
        # 存储
        self.mm.store_fact(
            subject='用户',
            predicate='喜欢',
            object='Python',
            category='preference'
        )
        self.mm.store_fact(
            subject='用户',
            predicate='职业是',
            object='运维经理',
            category='professional'
        )
        
        # 搜索
        facts = self.mm.search_facts(subject='用户', category='preference')
        
        self.assertEqual(len(facts), 1)
        self.assertEqual(facts[0]['object'], 'Python')
    
    def test_check_fact_conflict(self):
        """测试事实冲突检测"""
        # 存储事实
        self.mm.store_fact(
            subject='用户',
            predicate='职业是',
            object='运维经理',
            category='professional',
            confidence=1.0
        )
        
        # 检查冲突
        has_conflict, conflicting = self.mm.check_fact_conflict(
            subject='用户',
            predicate='职业是',
            object='软件工程师'  # 冲突
        )
        
        self.assertTrue(has_conflict)
        self.assertEqual(conflicting['object'], '运维经理')
    
    def test_no_fact_conflict(self):
        """测试无冲突情况"""
        # 存储事实
        self.mm.store_fact(
            subject='用户',
            predicate='喜欢',
            object='Python',
            category='preference'
        )
        
        # 检查 (不同 predicate)
        has_conflict, conflicting = self.mm.check_fact_conflict(
            subject='用户',
            predicate='职业是',
            object='运维经理'
        )
        
        self.assertFalse(has_conflict)
        self.assertIsNone(conflicting)
    
    # ========== 验证日志测试 ==========
    
    def test_log_verification(self):
        """测试记录验证日志"""
        memory_id = self.mm.store_semantic_memory(
            content='待验证信息',
            confidence=0.7
        )
        
        # 记录验证
        log_id = self.mm.log_verification(
            memory_id=memory_id,
            memory_type='semantic',
            verification_type='user_confirm',
            result='confirmed',
            confidence_before=0.7,
            confidence_after=0.9,
            reason='用户确认'
        )
        
        self.assertTrue(log_id.startswith('log_'))
    
    def test_verification_stats(self):
        """测试验证统计"""
        # 记录多个验证
        for i in range(3):
            memory_id = self.mm.store_semantic_memory(content=f'测试{i}')
            self.mm.log_verification(
                memory_id=memory_id,
                memory_type='semantic',
                verification_type='user_confirm',
                result='confirmed'
            )
        
        # 获取统计
        stats = self.mm.get_verification_stats()
        
        # 应该有统计记录
        self.assertIsInstance(stats, list)
    
    # ========== 统计测试 ==========
    
    def test_get_counts(self):
        """测试获取记忆数量"""
        # 存储一些记忆
        self.mm.store_working_memory('session', '内容', 'user')
        self.mm.store_semantic_memory('语义记忆', 'general', 0.9)
        self.mm.store_fact('主体', '关系', '客体', 'general')
        
        # 检查数量
        working_count = self.mm.get_active_working_memory_count()
        semantic_count = self.mm.get_semantic_memory_count()
        fact_count = self.mm.get_fact_count()
        
        self.assertGreaterEqual(working_count, 1)
        self.assertGreaterEqual(semantic_count, 1)
        self.assertGreaterEqual(fact_count, 1)
    
    # ========== 防幻觉机制测试 ==========
    
    def test_confidence_filtering(self):
        """测试置信度过滤"""
        # 存储不同置信度的记忆
        self.mm.store_semantic_memory('高置信度', confidence=0.95)
        self.mm.store_semantic_memory('中置信度', confidence=0.7)
        self.mm.store_semantic_memory('低置信度', confidence=0.5)
        
        # 只获取高置信度
        results = self.mm.search_semantic_memory(min_confidence=0.8)
        
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['content'], '高置信度')
    
    def test_verified_only(self):
        """测试只返回已验证记忆"""
        # 存储
        verified_id = self.mm.store_semantic_memory('已验证', confidence=0.9)
        self.mm.verify_semantic_memory(verified_id)
        
        unverified_id = self.mm.store_semantic_memory('未验证', confidence=0.9)
        
        # 只获取已验证
        results = self.mm.search_semantic_memory(verified=True)
        
        self.assertTrue(all(m['verified'] for m in results))
        self.assertFalse(any(m['content'] == '未验证' for m in results))
    
    def test_source_tracing(self):
        """测试来源追溯"""
        # 存储带来源的记忆
        self.mm.store_semantic_memory(
            content='来自特定会话的信息',
            source_session_id='session_123',
            source_message_id='msg_456'
        )
        
        # 搜索
        results = self.mm.search_semantic_memory()
        
        # 检查来源信息
        memory = next(m for m in results if m['content'] == '来自特定会话的信息')
        self.assertEqual(memory['source_session_id'], 'session_123')
        self.assertEqual(memory['source_message_id'], 'msg_456')


class TestMemoryIntegration(unittest.TestCase):
    """记忆集成测试"""
    
    def setUp(self):
        """设置"""
        self.mm = MemoryManager(':memory:')
        
        # 创建表
        sql_file = os.path.join(os.path.dirname(__file__), '..', '..', 'database-manager', 'scripts', '014_memory_architecture.sql')
        if os.path.exists(sql_file):
            with open(sql_file, 'r') as f:
                sql = f.read()
            self.mm.db.execute(sql)
    
    def tearDown(self):
        """清理"""
        self.mm.close()
    
    def test_full_workflow(self):
        """测试完整工作流"""
        # 1. 存储工作记忆
        wm_id = self.mm.store_working_memory(
            session_id='workflow_test',
            content='用户说喜欢 Python',
            role='user'
        )
        
        # 2. 提取语义记忆
        sm_id = self.mm.store_semantic_memory(
            content='用户喜欢 Python 编程',
            category='preference',
            confidence=0.8,
            source_session_id='workflow_test'
        )
        
        # 3. 用户确认
        self.mm.verify_semantic_memory(sm_id, verified_by='user_001')
        
        # 4. 存储为事实
        fact_id = self.mm.store_fact(
            subject='用户',
            predicate='喜欢',
            object='Python 编程',
            category='preference',
            source_memory_id=sm_id
        )
        
        # 5. 记录验证日志
        self.mm.log_verification(
            memory_id=sm_id,
            memory_type='semantic',
            verification_type='user_confirm',
            result='confirmed',
            confidence_before=0.8,
            confidence_after=1.0,
            verified_by='user_001'
        )
        
        # 6. 验证实事存在
        facts = self.mm.search_facts(subject='用户', category='preference')
        self.assertEqual(len(facts), 1)
        self.assertEqual(facts[0]['object'], 'Python 编程')


if __name__ == '__main__':
    unittest.main()
