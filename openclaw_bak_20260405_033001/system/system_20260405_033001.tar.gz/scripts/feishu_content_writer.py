#!/usr/bin/env python3
"""
飞书文档内容写入模块

实现 Markdown 内容到飞书文档的完整写入
"""

import requests
import json
import re
from typing import List, Dict, Any


class FeishuContentWriter:
    """飞书文档内容写入器"""
    
    def __init__(self, app_id: str, app_secret: str, user_id: str):
        self.app_id = app_id
        self.app_secret = app_secret
        self.user_id = user_id
        self.token = None
    
    def get_tenant_token(self) -> str:
        """获取 tenant_access_token"""
        if self.token:
            return self.token
        
        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        payload = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        response = requests.post(url, json=payload)
        result = response.json()
        
        if result.get('code') == 0:
            self.token = result.get('tenant_access_token')
            return self.token
        else:
            raise Exception(f"获取 token 失败：{result}")
    
    def write_markdown_to_doc(self, doc_token: str, markdown_content: str) -> bool:
        """
        将 Markdown 内容写入飞书文档
        
        Args:
            doc_token: 文档 token
            markdown_content: Markdown 内容
        
        Returns:
            是否成功
        """
        if not self.token:
            self.get_tenant_token()
        
        # 飞书文档块操作 API
        base_url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{doc_token}/blocks"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # 解析 Markdown 并转换为飞书块
        blocks = self._parse_markdown(markdown_content)
        
        # 批量创建块
        success_count = 0
        for block in blocks:
            try:
                response = requests.post(f"{base_url}/batch_create", headers=headers, json={
                    "parent_block_id": "",
                    "blocks": [block]
                })
                
                if response.status_code == 200:
                    success_count += 1
            except Exception as e:
                print(f"⚠️ 创建块失败：{e}")
        
        print(f"✅ 成功写入 {success_count}/{len(blocks)} 个块")
        return success_count > 0
    
    def _parse_markdown(self, markdown: str) -> List[Dict[str, Any]]:
        """
        解析 Markdown 并转换为飞书块格式
        
        Args:
            markdown: Markdown 内容
        
        Returns:
            飞书块列表
        """
        blocks = []
        lines = markdown.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            block = self._line_to_block(line)
            if block:
                blocks.append(block)
        
        return blocks
    
    def _line_to_block(self, line: str) -> Dict[str, Any]:
        """将单行 Markdown 转换为飞书块"""
        
        # 标题 H1
        if line.startswith('# '):
            return {
                "block_type": "heading1",
                "heading1": {
                    "elements": [{"text_run": {"text": line[2:]}}]
                }
            }
        
        # 标题 H2
        if line.startswith('## '):
            return {
                "block_type": "heading2",
                "heading2": {
                    "elements": [{"text_run": {"text": line[3:]}}]
                }
            }
        
        # 标题 H3
        if line.startswith('### '):
            return {
                "block_type": "heading3",
                "heading3": {
                    "elements": [{"text_run": {"text": line[4:]}}]
                }
            }
        
        # 列表项
        if line.startswith('- ') or line.startswith('* '):
            return {
                "block_type": "bullet",
                "bullet": {
                    "elements": [{"text_run": {"text": line[2:]}}]
                }
            }
        
        # 代码块（简单处理）
        if line.startswith('```'):
            return {
                "block_type": "code",
                "code": {
                    "elements": [{"text_run": {"text": line[3:]}}]
                }
            }
        
        # 普通段落
        return {
            "block_type": "text",
            "text": {
                "elements": [{"text_run": {"text": line}}]
            }
        }
    
    def write_simple(self, doc_token: str, markdown_content: str) -> bool:
        """
        简化版写入（逐行创建块）
        
        Args:
            doc_token: 文档 token
            markdown_content: Markdown 内容
        
        Returns:
            是否成功
        """
        if not self.token:
            self.get_tenant_token()
        
        # 使用块创建 API
        base_url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{doc_token}/blocks"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # 解析并创建块
        lines = markdown_content.split('\n')
        success_count = 0
        total_lines = 0
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('---'):
                continue
            
            total_lines += 1
            block = self._line_to_block(line)
            
            if block:
                try:
                    payload = {
                        "parent_block_id": "",
                        "blocks": [block]
                    }
                    response = requests.post(f"{base_url}/batch_create", headers=headers, json=payload, timeout=5)
                    
                    if response.status_code in [200, 201]:
                        success_count += 1
                except Exception as e:
                    pass  # 单个块失败不影响整体
        
        if success_count > 0:
            print(f"✅ 内容写入成功：{success_count}/{total_lines} 行")
            return True
        else:
            print(f"⚠️ 内容写入失败：0/{total_lines} 行")
            return False


# 使用示例
if __name__ == "__main__":
    writer = FeishuContentWriter(
        app_id="cli_a9206a37a0f9dcef",
        app_secret="o8EPudtskT8BkNyPyT0UC56hNS7Oyo7X",
        user_id="ou_b46467cc1563871aab03ac1d4f9216f0"
    )
    
    # 测试写入
    test_doc_token = "N7tsdTLrfolMPnxSattcr1i0n5g"  # 替换为实际文档 token
    test_content = "# 测试\n\n这是测试内容。"
    
    success = writer.write_simple(test_doc_token, test_content)
    print(f"写入结果：{'成功' if success else '失败'}")
