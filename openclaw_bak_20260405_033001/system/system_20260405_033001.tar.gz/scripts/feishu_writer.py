#!/usr/bin/env python3
"""
飞书文档内容写入器 - 修正版

使用正确的飞书 API 路径和参数
"""

import requests
import json
from typing import Tuple


def write_content_to_feishu_doc(
    document_id: str,
    markdown_content: str,
    app_id: str = "cli_a9206a37a0f9dcef",
    app_secret: str = "o8EPudtskT8BkNyPyT0UC56hNS7Oyo7X"
) -> Tuple[bool, str]:
    """
    将内容写入飞书文档
    
    Args:
        document_id: 文档 ID
        markdown_content: Markdown 内容
        app_id: 飞书 App ID
        app_secret: 飞书 App Secret
    
    Returns:
        (是否成功，消息)
    """
    # 获取 token
    token_resp = requests.post(
        'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
        json={'app_id': app_id, 'app_secret': app_secret}
    )
    token = token_resp.json().get('tenant_access_token')
    
    if not token:
        return False, "无法获取访问令牌"
    
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    }
    
    # 获取文档的 page block
    blocks_resp = requests.get(
        f"https://open.feishu.cn/open-apis/docx/v1/documents/{document_id}/blocks",
        headers=headers
    )
    
    if blocks_resp.status_code != 200:
        return False, f"获取文档结构失败：{blocks_resp.text}"
    
    blocks_data = blocks_resp.json()
    if blocks_data.get('code') != 0:
        return False, f"API 错误：{blocks_data}"
    
    # 获取 page block ID
    items = blocks_data.get('data', {}).get('items', [])
    if not items:
        return False, "文档为空，无 page block"
    
    page_block_id = items[0].get('block_id')
    print(f"✅ Page Block ID: {page_block_id}")
    
    # 将 Markdown 转换为简单文本块（逐行）
    lines = markdown_content.split('\n')
    success_count = 0
    
    for i, line in enumerate(lines[:100]):  # 限制前 100 行测试
        line = line.strip()
        if not line:
            continue
        
        # 创建文本块
        block_data = {
            "parent_block_id": page_block_id,
            "blocks": [{
                "block_type": "text",
                "text": {
                    "elements": [{"text_run": {"text": line}}]
                }
            }]
        }
        
        try:
            resp = requests.post(
                f"https://open.feishu.cn/open-apis/docx/v1/documents/{document_id}/blocks",
                headers=headers,
                json=block_data,
                timeout=10
            )
            
            if resp.status_code in [200, 201]:
                success_count += 1
            else:
                print(f"⚠️ 行 {i} 失败：{resp.status_code}")
        
        except Exception as e:
            print(f"⚠️ 行 {i} 异常：{e}")
    
    if success_count > 0:
        return True, f"成功写入 {success_count} 行"
    else:
        return False, "未能写入任何内容"


# 测试
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法：python3 feishu_writer.py <document_id> [markdown_file]")
        sys.exit(1)
    
    document_id = sys.argv[1]
    content = "# 测试\n\n这是测试内容。"
    
    if len(sys.argv) >= 3:
        with open(sys.argv[2], 'r') as f:
            content = f.read()
    
    print(f"写入文档：{document_id}")
    print(f"内容大小：{len(content)} 字符")
    
    success, msg = write_content_to_feishu_doc(document_id, content)
    print(f"结果：{'✅ ' if success else '❌ '}{msg}")
