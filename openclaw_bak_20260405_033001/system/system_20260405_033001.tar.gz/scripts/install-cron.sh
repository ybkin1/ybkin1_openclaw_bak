#!/bin/bash
# install-cron.sh - 安装数据调度器 Cron 配置
# P0 优化实施 - 2026-03-31

set -e

CRON_FILE="/etc/cron.d/data-orchestrator"
SCRIPT_DIR="/root/.openclaw/workspace/agents/master/scripts"
LOG_DIR="/root/.openclaw/logs"

echo "=== 安装数据调度器 Cron 配置 ==="
echo "安装时间：$(date '+%Y-%m-%d %H:%M:%S')"

# 确保目录存在
mkdir -p "$LOG_DIR"
mkdir -p "$(dirname "$CRON_FILE")"

# 创建 Cron 配置
cat > "$CRON_FILE" <<'EOF'
# 数据调度器 - Cron 配置
# 安装时间：AUTO_FILLED

SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

# 主调度器 - 每 5 分钟执行一次（增强版）
*/5 * * * * root /root/.openclaw/workspace/agents/master/scripts/task-heartbeat-enhanced.sh >> /root/.openclaw/logs/task-heartbeat.log 2>&1

# 心跳检查 - 每分钟执行一次（备用）
* * * * * root /root/.openclaw/workspace/agents/master/scripts/task-heartbeat.sh >> /root/.openclaw/logs/task-heartbeat-legacy.log 2>&1

# 进度汇报 - 每 10 分钟执行一次（增强版）
*/10 * * * * root /root/.openclaw/workspace/agents/master/scripts/task-progress-reporter-enhanced.sh >> /root/.openclaw/logs/progress-reporter.log 2>&1

# 僵尸检测 - 每 10 分钟执行一次
*/10 * * * * root /root/.openclaw/workspace/agents/master/scripts/zombie-task-detector.sh >> /root/.openclaw/logs/zombie-detector.log 2>&1

# AI 幻觉检测 - 每 30 分钟执行一次
*/30 * * * * root /root/.openclaw/workspace/agents/master/scripts/ai-hallucination-detector.sh >> /root/.openclaw/logs/ai-hallucination.log 2>&1

# 任务执行器 - 每 5 分钟执行一次
*/5 * * * * root /root/.openclaw/workspace/agents/master/scripts/task-executor.sh >> /root/.openclaw/logs/task-executor.log 2>&1

# 跨天暂停 - 每天 23:00 执行
0 23 * * * root /root/.openclaw/workspace/agents/master/scripts/cross-day-scheduler.sh pause >> /root/.openclaw/logs/cross-day.log 2>&1

# 跨天恢复 - 每天 08:30 执行
30 8 * * * root /root/.openclaw/workspace/agents/master/scripts/cross-day-scheduler.sh resume >> /root/.openclaw/logs/cross-day.log 2>&1

# 健康检查 - 每周一 09:00 执行
0 9 * * 1 root /root/.openclaw/workspace/agents/master/scripts/task-health-check.sh >> /root/.openclaw/logs/health-check.log 2>&1
EOF

# 替换时间戳
sed -i "s/AUTO_FILLED/$(date '+%Y-%m-%d %H:%M:%S')/" "$CRON_FILE"

# 设置权限
chmod 644 "$CRON_FILE"

echo "✅ Cron 配置已安装：$CRON_FILE"
echo ""
echo "=== Cron 配置内容 ==="
cat "$CRON_FILE"
echo ""
echo "=== 验证 Cron 语法 ==="
if command -v crontab &> /dev/null; then
    crontab -l 2>/dev/null || echo "（系统 crontab 为空）"
fi
echo ""
echo "=== 安装完成 ==="
echo ""
echo "定时任务列表:"
echo "  - */5  *  *  *  *  心跳检查（增强版）"
echo "  - */10 *  *  *  *  进度汇报（增强版）"
echo "  - */10 *  *  *  *  僵尸检测"
echo "  - */30 *  *  *  *  AI 幻觉检测"
echo "  - */5  *  *  *  *  任务执行器"
echo "  - 0 23 *  *  *  跨天暂停"
echo "  - 30 8 *  *  *  跨天恢复"
echo "  - 0 9  *  * 1  健康检查（周一）"
echo ""
echo "日志文件位置：$LOG_DIR/"
