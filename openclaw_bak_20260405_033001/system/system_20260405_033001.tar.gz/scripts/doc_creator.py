#!/usr/bin/env python3
"""
统一文档创建模块 - 飞书优先

默认使用飞书文档创建，本地.md 作为备份
永久生效配置
"""

import os
import sys
import json
import requests
from datetime import datetime
from typing import Optional, Dict, Any


class DocCreator:
    """统一文档创建器"""
    
    def __init__(self):
        # 飞书配置
        self.app_id = "cli_a9206a37a0f9dcef"
        self.app_secret = "o8EPudtskT8BkNyPyT0UC56hNS7Oyo7X"
        self.user_id = "ou_b46467cc1563871aab03ac1d4f9216f0"
        self.token = None
        
        # 本地配置
        self.workspace = "/root/.openclaw/workspace/agents/master"
        self.docs_dir = f"{self.workspace}/docs"
        self.reports_dir = f"{self.workspace}/reports"
        
        # 确保目录存在
        os.makedirs(self.docs_dir, exist_ok=True)
        os.makedirs(self.reports_dir, exist_ok=True)
    
    def get_tenant_token(self) -> str:
        """获取飞书 tenant_access_token"""
        if self.token:
            return self.token
        
        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        payload = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        try:
            response = requests.post(url, json=payload, timeout=10)
            result = response.json()
            
            if result.get('code') == 0:
                self.token = result.get('tenant_access_token')
                return self.token
            else:
                print(f"⚠️ 飞书 Token 获取失败：{result.get('msg', 'Unknown error')}")
                return None
        except Exception as e:
            print(f"⚠️ 飞书 API 调用失败：{e}")
            return None
    
    def create_feishu_doc(self, title: str, content: str, category: str = "docs") -> Optional[Dict[str, Any]]:
        """
        创建飞书文档
        
        Args:
            title: 文档标题
            content: Markdown 内容
            category: 分类 (docs/reports)
        
        Returns:
            文档信息 {doc_token, doc_url, title, created_at}
        """
        token = self.get_tenant_token()
        if not token:
            return None
        
        url = "https://open.feishu.cn/open-apis/docx/v1/documents"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "title": title,
            "owner_id": self.user_id
        }
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=10)
            result = response.json()
            
            if result.get('code') == 0:
                # 兼容不同 API 响应格式
                doc_data = result.get('data', {})
                if 'document' in doc_data:
                    doc_token = doc_data['document'].get('doc_id') or doc_data['document'].get('document_id')
                else:
                    doc_token = doc_data.get('doc_id') or doc_data.get('document_id')
                
                if not doc_token:
                    raise Exception(f"无法获取 doc_id，响应数据：{result}")
                
                doc_url = f"https://feishu.cn/docx/{doc_token}"
                
                # 写入内容（使用完整的 Markdown 转换器）
                try:
                    import sys
                    sys.path.insert(0, '/root/.openclaw/workspace/agents/master/scripts')
                    from markdown_to_feishu import write_markdown_to_feishu
                    print("📝 正在转换 Markdown 并写入飞书文档...")
                    success, count = write_markdown_to_feishu(doc_token, content, self.app_id, self.app_secret, self.user_id)
                    if success:
                        print(f"✅ 内容写入成功：{count} 个块")
                    else:
                        print(f"⚠️ 内容写入失败，但文档已创建")
                except Exception as e:
                    print(f"⚠️ 内容写入失败：{e}，但文档已创建")
                
                # 设置权限（组织内可读）
                self._set_feishu_permission(doc_token)
                
                return {
                    'doc_token': doc_token,
                    'doc_url': doc_url,
                    'title': title,
                    'platform': 'feishu',
                    'created_at': datetime.now().isoformat()
                }
            else:
                error_msg = result.get('msg', 'Unknown error')
                print(f"⚠️ 飞书文档创建失败：{error_msg}")
                if 'permission' in error_msg.lower() or 'scope' in error_msg.lower():
                    print("💡 解决方案：请在飞书开放平台开通 docx:document 和 docx:document:create 权限")
                    print(f"   链接：https://open.feishu.cn/app/{self.app_id}/auth")
                return None
                
        except Exception as e:
            print(f"⚠️ 飞书文档创建异常：{e}")
            return None
    
    def _set_feishu_permission(self, doc_token: str):
        """设置飞书文档权限（组织内可读）"""
        if not self.token:
            return
        
        url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{doc_token}/memberships"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "member_type": "tenant",
            "permission": "read_only"
        }
        
        try:
            requests.post(url, headers=headers, json=payload, timeout=5)
        except:
            pass  # 权限设置失败不影响文档创建
    
    def create_local_doc(self, filename: str, content: str, category: str = "docs") -> Dict[str, Any]:
        """
        创建本地.md 文档（备份方案）
        
        Args:
            filename: 文件名（不含扩展名）
            content: Markdown 内容
            category: 分类 (docs/reports)
        
        Returns:
            文档信息 {file_path, filename, platform, created_at}
        """
        if category == "reports":
            dir_path = self.reports_dir
        else:
            dir_path = self.docs_dir
        
        file_path = f"{dir_path}/{filename}.md"
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return {
            'file_path': file_path,
            'filename': f"{filename}.md",
            'platform': 'local',
            'created_at': datetime.now().isoformat()
        }
    
    def create_doc(self, title: str, content: str, category: str = "docs", 
                   feishu_first: bool = True) -> Dict[str, Any]:
        """
        创建文档（飞书优先，本地备份）
        
        Args:
            title: 文档标题
            content: Markdown 内容
            category: 分类 (docs/reports)
            feishu_first: 是否优先使用飞书（默认 True）
        
        Returns:
            文档信息
        """
        # 生成安全的文件名
        safe_filename = self._safe_filename(title)
        
        result = {
            'title': title,
            'feishu': None,
            'local': None,
            'primary': None
        }
        
        # 尝试创建飞书文档
        if feishu_first:
            print(f"📄 创建飞书文档：{title}")
            feishu_doc = self.create_feishu_doc(title, content, category)
            
            if feishu_doc:
                result['feishu'] = feishu_doc
                result['primary'] = 'feishu'
                print(f"✅ 飞书文档创建成功：{feishu_doc['doc_url']}")
            else:
                print("⚠️ 飞书文档创建失败，使用本地备份方案")
        
        # 创建本地备份
        print(f"📄 创建本地备份：{safe_filename}.md")
        local_doc = self.create_local_doc(safe_filename, content, category)
        result['local'] = local_doc
        
        if not result['primary']:
            result['primary'] = 'local'
            print(f"✅ 本地文档创建成功：{local_doc['file_path']}")
        
        return result
    
    def _safe_filename(self, title: str) -> str:
        """生成安全的文件名"""
        # 替换非法字符
        safe = title.replace('/', '-').replace('\\', '-')
        safe = safe.replace(':', '-').replace('*', '-').replace('?', '-')
        safe = safe.replace('"', '').replace('<', '').replace('>', '').replace('|', '')
        safe = safe.replace(' ', '_')
        
        # 限制长度
        if len(safe) > 100:
            safe = safe[:100]
        
        # 添加时间戳
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        return f"{safe}_{timestamp}"
    
    def send_notification(self, doc_info: Dict[str, Any]):
        """发送文档创建通知"""
        title = doc_info.get('title', '文档')
        primary = doc_info.get('primary', 'local')
        
        if primary == 'feishu' and doc_info.get('feishu'):
            link = doc_info['feishu']['doc_url']
            print(f"\n📢 文档通知")
            print(f"   标题：{title}")
            print(f"   平台：飞书文档")
            print(f"   链接：{link}")
        else:
            path = doc_info['local']['file_path']
            print(f"\n📢 文档通知")
            print(f"   标题：{title}")
            print(f"   平台：本地文件")
            print(f"   路径：{path}")


# 便捷函数
def create_document(title: str, content: str, category: str = "docs") -> Dict[str, Any]:
    """
    创建文档（快捷方式）
    
    Args:
        title: 文档标题
        content: Markdown 内容
        category: 分类 (docs/reports)
    
    Returns:
        文档信息
    """
    creator = DocCreator()
    result = creator.create_doc(title, content, category)
    creator.send_notification(result)
    return result


# CLI 接口
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法：python3 doc_creator.py <title> <content_file> [category]")
        print("")
        print("参数:")
        print("  title        - 文档标题")
        print("  content_file - 内容文件路径（.md）")
        print("  category     - 分类：docs (默认) 或 reports")
        print("")
        print("示例:")
        print("  python3 doc_creator.py '测试文档' /tmp/content.md docs")
        sys.exit(1)
    
    title = sys.argv[1]
    content_file = sys.argv[2]
    category = sys.argv[3] if len(sys.argv) > 3 else "docs"
    
    # 读取内容
    with open(content_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 创建文档
    result = create_document(title, content, category)
    
    print("\n✅ 文档创建完成!")
    print(f"   主平台：{result['primary']}")
    if result.get('feishu'):
        print(f"   飞书链接：{result['feishu']['doc_url']}")
    if result.get('local'):
        print(f"   本地路径：{result['local']['file_path']}")
