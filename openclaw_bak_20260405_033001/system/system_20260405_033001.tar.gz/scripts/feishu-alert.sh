#!/bin/bash
# 飞书告警集成脚本
# 将系统告警通过飞书机器人发送给用户

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
LOG_FILE="$BASE_DIR/logs/feishu-alert.log"

# 飞书配置
FEISHU_APP_ID="cli_a9206a37a0f9dcef"
FEISHU_APP_SECRET="o8EPudtskT8BkNyPyT0UC56hNS7Oyo7X"
FEISHU_USER_ID="ou_b46467cc1563871aab03ac1d4f9216f0"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 发送飞书消息
send_feishu_alert() {
    local title="$1"
    local content="$2"
    local alert_level="${3:-INFO}"  # INFO/WARN/ERROR/CRITICAL
    
    log_info "发送飞书告警：$title"
    
    # 根据告警级别设置颜色
    local color="#36cfc9"  # INFO - 青色
    case "$alert_level" in
        WARN) color="#faad14" ;;  # 黄色
        ERROR) color="#f5222d" ;;  # 红色
        CRITICAL) color="#722ed1" ;;  # 紫色
    esac
    
    # 使用 Python 发送飞书消息（调用飞书 API）
    python3 <<EOF
import requests
import json
import time

# 飞书 API 配置
app_id = "$FEISHU_APP_ID"
app_secret = "$FEISHU_APP_SECRET"

# 获取 tenant_access_token
def get_tenant_token():
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    payload = {
        "app_id": "${app_id}",
        "app_secret": "${app_secret}"
    }
    response = requests.post(url, json=payload)
    result = response.json()
    if result.get('code') == 0:
        return result.get('tenant_access_token')
    else:
        raise Exception(f"获取 token 失败：{result}")

# 发送消息
def send_message(user_id, title, content, color):
    token = get_tenant_token()
    
    url = "https://open.feishu.cn/open-apis/im/v1/messages"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # 构建富文本消息
    rich_text = [
        {
            "tag": "div",
            "text": {
                "content": f"**{title}**\\n{content}",
                "text_color": color
            }
        },
        {
            "tag": "hr"
        },
        {
            "tag": "note",
            "elements": [
                {
                    "tag": "plain_text",
                    "content": f"发送时间：{time.strftime('%Y-%m-%d %H:%M:%S')}"
                }
            ]
        }
    ]
    
    payload = {
        "receive_id": "$user_id",
        "msg_type": "interactive",
        "content": json.dumps({
            "config": {
                "wide_screen_mode": True
            },
            "elements": rich_text
        })
    }
    
    response = requests.post(url, headers=headers, json=payload)
    result = response.json()
    
    if result.get('code') == 0:
        print(f"✅ 飞书消息发送成功")
        return True
    else:
        print(f"❌ 飞书消息发送失败：{result}")
        return False

# 执行
try:
    success = send_message("$FEISHU_USER_ID", "$title", "$content", "$color")
    exit(0 if success else 1)
except Exception as e:
    print(f"❌ 异常：{e}")
    exit(1)
EOF
    
    return $?
}

# 测试告警
test_alert() {
    log_info "测试飞书告警..."
    
    send_feishu_alert \
        "🧪 飞书告警测试" \
        "这是一条测试告警消息\\n\\n系统：飞书告警集成\\n级别：INFO\\n\\n如果收到此消息，说明告警集成正常工作。" \
        "INFO"
    
    if [ $? -eq 0 ]; then
        log_info "✅ 飞书告警测试成功"
    else
        log_error "❌ 飞书告警测试失败"
    fi
}

# 主程序
case "${1:-}" in
    test)
        test_alert
        ;;
    send)
        send_feishu_alert "$2" "$3" "$4"
        ;;
    *)
        echo "用法：$0 {test|send}"
        echo ""
        echo "test              - 测试飞书告警"
        echo "send <标题> <内容> [级别] - 发送告警"
        echo ""
        echo "告警级别：INFO (默认), WARN, ERROR, CRITICAL"
        exit 1
        ;;
esac
