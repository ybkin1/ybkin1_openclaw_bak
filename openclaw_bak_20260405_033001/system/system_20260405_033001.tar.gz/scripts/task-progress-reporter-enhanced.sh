#!/bin/bash
# task-progress-reporter-enhanced.sh - 任务进度汇报（增强版 - 防 AI 幻觉）
# 汇报前强制验证真实进展
# P0 优化实施 - 2026-03-31

set -euo pipefail

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
REPORTS_DIR="/root/.openclaw/workspace/agents/master/reports/progress"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/progress-reporter.log"

mkdir -p "$REPORTS_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# P0 新增：汇报前强制验证
validate_before_report() {
    local task_file="$1"
    local checkpoint_file="${task_file%.json}.checkpoint"
    local task_id=$(basename "$task_file" .json)
    
    log "🔍 验证任务：$task_id"
    
    # 1. 检查 checkpoint 是否有实际进展
    if [ -f "$checkpoint_file" ]; then
        local total_lines=$(wc -l < "$checkpoint_file")
        local wait_count=$(grep -c '"step": "等待中"' "$checkpoint_file" 2>/dev/null || echo "0")
        
        if [ "$total_lines" -gt 0 ] && [ "$total_lines" -eq "$wait_count" ]; then
            log "❌ 拒绝汇报：checkpoint 全是等待中 (${total_lines}条记录)"
            return 1
        fi
        
        log "✓ checkpoint 验证通过 (${total_lines}条记录，$((total_lines - wait_count))条有进展)"
    else
        log "⚠️ checkpoint 文件不存在"
    fi
    
    # 2. 检查输出文件
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    if [ -n "$output_files" ]; then
        local missing_count=0
        for file in $output_files; do
            if [ ! -f "$file" ]; then
                log "⚠️ 输出文件缺失：$file"
                missing_count=$((missing_count + 1))
            fi
        done
        
        if [ "$missing_count" -gt 0 ]; then
            log "❌ 拒绝汇报：缺失 $missing_count 个输出文件"
            return 1
        fi
        
        log "✓ 输出文件验证通过"
    fi
    
    # 3. 检查 Git 提交（如适用）
    if [ -d "/root/.openclaw/workspace/.git" ]; then
        local commits=$(git -C "/root/.openclaw/workspace" log --oneline --since="24 hours ago" -- "*${task_id}*" 2>/dev/null | wc -l)
        
        if [ "$commits" -eq 0 ]; then
            log "⚠️ 无 Git 提交（过去 24 小时）"
            # 不阻止汇报，但记录警告
        else
            log "✓ Git 提交验证通过 ($commits 个提交)"
        fi
    fi
    
    return 0
}

check_task_progress() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    
    # 读取任务信息
    local started_at=$(jq -r '.started_at // .resumed_at // empty' "$task_file")
    local estimated_duration=$(jq -r '.estimated_duration_minutes // 30' "$task_file")
    local status=$(jq -r '.status // "unknown"' "$task_file")
    local title=$(jq -r '.title // "Unknown Task"' "$task_file")
    local last_report=$(jq -r '.last_report_at // "1970-01-01"' "$task_file")
    
    # 跳过未开始的任务
    if [ -z "$started_at" ] || [ "$status" != "in_progress" ]; then
        return 0
    fi
    
    # 计算已用时间 (分钟)
    local started_ts=$(date -d "$started_at" +%s 2>/dev/null || echo 0)
    local now_ts=$(date +%s)
    local elapsed_minutes=$(( (now_ts - started_ts) / 60 ))
    
    # 计算汇报阈值
    local report_1_3=$((estimated_duration / 3))
    local report_2_3=$((estimated_duration * 2 / 3))
    
    # 检查是否需要汇报
    local need_report=false
    local report_type=""
    
    # 1/3 进度汇报
    if [ $elapsed_minutes -ge $report_1_3 ] && [ "$last_report" = "1970-01-01" ]; then
        need_report=true
        report_type="1/3_progress"
    fi
    
    # 2/3 进度汇报
    if [ $elapsed_minutes -ge $report_2_3 ] && [ "$last_report" != "1/3_progress" ]; then
        need_report=true
        report_type="2/3_progress"
    fi
    
    # 超时告警
    if [ $elapsed_minutes -ge $estimated_duration ] && [ "$status" = "in_progress" ]; then
        need_report=true
        report_type="timeout_alert"
    fi
    
    # 生成汇报（P0 新增：先验证）
    if [ "$need_report" = true ]; then
        log "📊 准备生成汇报：$task_id ($report_type)"
        
        # P0 验证
        if ! validate_before_report "$task_file"; then
            log "❌ 验证失败，拒绝生成汇报：$task_id"
            
            # 生成告警报告而非进度报告
            generate_hallucination_alert "$task_file" "$report_type"
            return 1
        fi
        
        # 验证通过，生成正常汇报
        generate_report "$task_file" "$report_type" "$elapsed_minutes"
        
        # 更新最后汇报时间
        local temp_file=$(mktemp)
        jq --arg report "$report_type" --arg time "$(date -Iseconds)" \
           '.last_report_at = $time | .last_report_type = $report' \
           "$task_file" > "$temp_file" && mv "$temp_file" "$task_file"
    fi
}

generate_report() {
    local task_file="$1"
    local report_type="$2"
    local elapsed_minutes="$3"
    
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title' "$task_file")
    local subagent=$(jq -r '.subagent // "unknown"' "$task_file")
    local estimated=$(jq -r '.estimated_duration_minutes' "$task_file")
    
    local report_file="$REPORTS_DIR/${task_id}_${report_type}_$(date +%H%M).md"
    
    cat > "$report_file" << EOF
# 任务进度汇报

**任务 ID**: $task_id  
**任务标题**: $title  
**汇报类型**: $report_type  
**汇报时间**: $(date '+%Y-%m-%d %H:%M:%S')

---

## 进度信息

| 指标 | 值 |
|------|-----|
| 已用时间 | $elapsed_minutes 分钟 |
| 预计总时间 | $estimated 分钟 |
| 进度百分比 | $((elapsed_minutes * 100 / estimated))% |
| 执行 Agent | $subagent |

---

## 验证清单

- [x] checkpoint 有真实进展
- [x] 输出文件存在
- [ ] Git 提交（如适用）

---

## 当前状态

**状态**: 执行中

**已完成**:
- [待 Subagent 更新]

**进行中**:
- [待 Subagent 更新]

**阻塞项**:
- [无/待更新]

---

## 下一步

[待 Subagent 更新]

---

**自动生成**: task-progress-reporter-enhanced.sh (P0 增强版)
EOF

    log "📊 生成进度汇报：$report_file"
    
    # 如果超时，发送告警
    if [ "$report_type" = "timeout_alert" ]; then
        log "⚠️ 任务超时告警：$task_id (已用${elapsed_minutes}分钟，预计${estimated}分钟)"
    fi
}

generate_hallucination_alert() {
    local task_file="$1"
    local report_type="$2"
    
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title' "$task_file")
    
    local alert_file="$REPORTS_DIR/${task_id}_hallucination_alert_$(date +%H%M).md"
    
    cat > "$alert_file" << EOF
# 🧠 AI 幻觉告警

**任务 ID**: $task_id  
**任务标题**: $title  
**告警类型**: 汇报验证失败  
**告警时间**: $(date '+%Y-%m-%d %H:%M:%S')

---

## 问题描述

任务尝试生成 $report_type 汇报，但验证失败。

## 验证失败原因

- [ ] checkpoint 文件全是"等待中"
- [ ] 输出文件缺失
- [ ] 无 Git 提交（过去 24 小时）

---

## 建议操作

1. 检查任务是否真正在执行
2. 检查 checkpoint 文件内容
3. 检查输出文件是否创建
4. 如确认 AI 幻觉，标记任务为 suspected_zombie

---

**自动生成**: task-progress-reporter-enhanced.sh (AI 幻觉检测)
EOF

    log "🧠 生成 AI 幻觉告警：$alert_file"
}

# 主循环
log "🔍 开始检查任务进度（增强版）..."

report_generated=false

for task_file in "$TASKS_DIR"/*.json; do
    if [ -f "$task_file" ]; then
        check_task_progress "$task_file"
    fi
done

if [ "$report_generated" = false ]; then
    log "📊 无活跃任务或无汇报需要生成"
fi

log "✅ 进度检查完成"
