#!/bin/bash
# task-heartbeat.sh - 任务心跳机制（增强版 - 防 AI 幻觉）
# 每 5 分钟更新一次任务心跳，验证真实进展
# P0 优化实施 - 2026-03-31

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
TASKS_DIR="$BASE_DIR/memory/tasks/active"
CHECKPOINT_DIR="$TASKS_DIR"
LOG_FILE="$BASE_DIR/logs/task-heartbeat.log"

# 配置
HEARTBEAT_INTERVAL=300  # 5 分钟
MAX_WAIT_STEPS=3        # 最大连续"等待中"次数

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保日志目录存在
mkdir -p "$(dirname "$LOG_FILE")"

# P0 新增：检查 checkpoint 是否有真实进展
check_checkpoint_progress() {
    local task_file="$1"
    local checkpoint_file="${task_file%.json}.checkpoint"
    
    if [ ! -f "$checkpoint_file" ]; then
        log_warn "⚠️ checkpoint 文件不存在：$checkpoint_file"
        return 1
    fi
    
    # 读取最近 3 条记录
    local total_lines=$(wc -l < "$checkpoint_file")
    local wait_count=$(grep -c '"step": "等待中"' "$checkpoint_file" 2>/dev/null || echo "0")
    
    # 如果最近 3 条都是"等待中"，标记为疑似卡死
    if [ "$total_lines" -ge 3 ] && [ "$wait_count" -eq "$total_lines" ]; then
        log_warn "⚠️ 任务可能卡死：$(basename "$task_file") (连续${total_lines}次心跳无进展)"
        return 1
    fi
    
    return 0
}

# P0 新增：检查输出文件是否存在
check_output_files() {
    local task_file="$1"
    
    # 读取 output_files 数组
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    
    if [ -z "$output_files" ]; then
        # 无 output_files 要求，跳过检查
        return 0
    fi
    
    local missing_count=0
    for file in $output_files; do
        if [ ! -f "$file" ]; then
            log_warn "⚠️ 输出文件缺失：$file"
            missing_count=$((missing_count + 1))
        fi
    done
    
    if [ "$missing_count" -gt 0 ]; then
        log_warn "⚠️ 共缺失 $missing_count 个输出文件"
        return 1
    fi
    
    return 0
}

# P0 新增：检查 Git 提交（如适用）
check_git_commits() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    
    # 检查是否在 Git 仓库中
    if [ ! -d "$BASE_DIR/.git" ]; then
        return 0  # 非 Git 仓库，跳过
    fi
    
    # 检查过去 24 小时是否有相关提交
    local commits=$(git -C "$BASE_DIR" log --oneline --since="24 hours ago" -- "*${task_id}*" 2>/dev/null | wc -l)
    
    if [ "$commits" -eq 0 ]; then
        # 无提交记录，但不阻止心跳（仅记录警告）
        log_warn "⚠️ 过去 24 小时无 Git 提交：$task_id"
    fi
    
    return 0
}

# 主心跳逻辑
update_heartbeat() {
    local task_file="$1"
    local task_name=$(basename "$task_file")
    local task_id=$(jq -r '.task_id // .title // "unknown"' "$task_file" 2>/dev/null)
    
    log_info "检查任务：$task_name (ID: $task_id)"
    
    # 读取当前状态
    local current_time=$(date -Iseconds)
    local last_activity=$(jq -r '.lastActivity // .last_activity // empty' "$task_file" 2>/dev/null)
    
    # 计算时间差（秒）
    local elapsed=999999
    if [ -n "$last_activity" ] && [ "$last_activity" != "null" ]; then
        local last_activity_ts=$(date -d "$last_activity" +%s 2>/dev/null || echo "0")
        local current_ts=$(date +%s)
        elapsed=$((current_ts - last_activity_ts))
    fi
    
    # 如果超过 5 分钟未更新，强制更新心跳
    if [ $elapsed -gt $HEARTBEAT_INTERVAL ]; then
        log_info "任务 $task_name 超过 5 分钟未更新心跳（已 ${elapsed}s），强制更新"
        
        # P0 新增：验证真实进展
        local has_progress=true
        
        if ! check_checkpoint_progress "$task_file"; then
            log_warn "⚠️ 验证失败：checkpoint 无真实进展"
            has_progress=false
        fi
        
        if ! check_output_files "$task_file"; then
            log_warn "⚠️ 验证失败：输出文件缺失"
            has_progress=false
        fi
        
        # 读取当前进度
        local current_progress=$(jq -r '.progress // 0' "$task_file" 2>/dev/null || echo "0")
        local current_step=$(jq -r '.currentStep // .current_task // "等待中"' "$task_file" 2>/dev/null || echo "等待中")
        
        # 更新心跳（使用临时文件避免并发问题）
        tmp_file="${task_file}.tmp.$$"  # 使用 PID 避免冲突
        jq --arg time "$current_time" \
           '.lastActivity = $time | .last_activity = $time' \
           "$task_file" > "$tmp_file" 2>/dev/null
        
        if [ $? -eq 0 ] && [ -f "$tmp_file" ]; then
            mv "$tmp_file" "$task_file"
            
            # 写入检查点
            local checkpoint_file="${task_file%.json}.checkpoint"
            local progress_status="progress"
            if [ "$has_progress" = false ]; then
                progress_status="no_progress_verified"
            fi
            
            echo "{\"timestamp\": \"$current_time\", \"progress\": $current_progress, \"step\": \"$current_step\", \"type\": \"heartbeat\", \"verified\": $has_progress}" >> "$checkpoint_file"
            
            log_info "✓ 心跳更新成功 (verified: $has_progress)"
        else
            log_error "心跳更新失败：$task_file"
            rm -f "${task_file}.tmp"
        fi
    else
        log_info "任务 $task_name 心跳正常（${elapsed}s 前更新）"
    fi
}

# 主程序
log_info "=== 开始任务心跳检查（增强版）==="

# 检查任务目录是否存在
if [ ! -d "$TASKS_DIR" ]; then
    log_warn "任务目录不存在：$TASKS_DIR"
    exit 0
fi

# 遍历所有活跃任务
task_count=0
updated_count=0
verified_count=0

for task_file in "$TASKS_DIR"/*.json; do
    # 检查是否有匹配的文件
    if [ ! -f "$task_file" ]; then
        continue
    fi
    
    task_count=$((task_count + 1))
    
    # 更新心跳
    update_heartbeat "$task_file"
    
    # 统计验证通过的任务
    if check_checkpoint_progress "$task_file" && check_output_files "$task_file"; then
        verified_count=$((verified_count + 1))
    fi
done

log_info "=== 心跳检查完成 ==="
log_info "总计任务：$task_count, 验证通过：$verified_count"

# 返回统计信息
echo "{\"total_tasks\": $task_count, \"verified\": $verified_count, \"timestamp\": \"$(date -Iseconds)\"}"
