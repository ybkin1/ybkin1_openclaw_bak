#!/bin/bash
# ai-hallucination-detector.sh - AI 幻觉检测器
# 每 30 分钟检测一次，识别虚假任务进度
# P0 优化实施 - 2026-03-31

set -e

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
LOG_FILE="/root/.openclaw/logs/ai-hallucination-detector.log"
ALERT_DIR="/root/.openclaw/workspace/agents/master/reports/alerts"

mkdir -p "$ALERT_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# 检测 AI 幻觉
detect_hallucination() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title // "Unknown"' "$task_file")
    local checkpoint_file="${task_file%.json}.checkpoint"
    
    local hallucination_detected=false
    local reasons=()
    
    # 1. 检查 checkpoint 是否全是"等待中"
    if [ -f "$checkpoint_file" ]; then
        local total_lines=$(wc -l < "$checkpoint_file")
        local wait_count=$(grep -c '"step": "等待中"' "$checkpoint_file" 2>/dev/null || echo "0")
        
        if [ "$total_lines" -ge 5 ] && [ "$total_lines" -eq "$wait_count" ]; then
            hallucination_detected=true
            reasons+=("checkpoint 全是等待中 (${total_lines}条记录)")
        fi
    fi
    
    # 2. 检查输出文件是否存在
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    if [ -n "$output_files" ]; then
        local missing_count=0
        for file in $output_files; do
            if [ ! -f "$file" ]; then
                missing_count=$((missing_count + 1))
            fi
        done
        
        if [ "$missing_count" -gt 0 ]; then
            hallucination_detected=true
            reasons+=("缺失 $missing_count 个输出文件")
        fi
    fi
    
    # 3. 检查进度百分比是否合理
    local progress=$(jq -r '.progress // 0' "$task_file")
    local status=$(jq -r '.status' "$task_file")
    
    if [ "$progress" -gt 90 ] && [ "$status" = "in_progress" ]; then
        hallucination_detected=true
        reasons+=("进度>90% 但未完成")
    fi
    
    # 4. 检查最后活动时间
    local last_activity=$(jq -r '.lastActivity // .last_activity // empty' "$task_file")
    if [ -n "$last_activity" ] && [ "$last_activity" != "null" ]; then
        local last_ts=$(date -d "$last_activity" +%s 2>/dev/null || echo "0")
        local now_ts=$(date +%s)
        local elapsed=$((now_ts - last_ts))
        local elapsed_hours=$((elapsed / 3600))
        
        if [ "$elapsed_hours" -gt 24 ]; then
            hallucination_detected=true
            reasons+=("超过 24 小时无活动")
        fi
    fi
    
    # 生成告警
    if [ "$hallucination_detected" = true ]; then
        log "🧠 检测到 AI 幻觉：$task_id"
        
        local alert_file="$ALERT_DIR/${task_id}_hallucination_$(date +%Y%m%d_%H%M).md"
        
        cat > "$alert_file" << EOF
# 🧠 AI 幻觉告警

**任务 ID**: $task_id  
**任务标题**: $title  
**检测时间**: $(date '+%Y-%m-%d %H:%M:%S')

---

## 告警原因

$(printf '%s\n' "${reasons[@]}")

---

## 建议操作

1. 检查任务是否真正在执行
2. 检查 checkpoint 文件内容
3. 检查输出文件是否创建
4. 如确认 AI 幻觉，标记任务为 suspected_zombie

---

**自动生成**: ai-hallucination-detector.sh
EOF
        
        log "📝 告警文件：$alert_file"
        
        # TODO: 发送飞书告警
        # send_feishu_alert "AI 幻觉检测" "任务 $task_id 检测到 AI 幻觉"
        
        return 1
    fi
    
    return 0
}

# 主循环
log "=== 开始 AI 幻觉检测 ==="

hallucination_count=0
checked_count=0

for task_file in "$TASKS_DIR"/*.json; do
    if [ -f "$task_file" ]; then
        checked_count=$((checked_count + 1))
        
        if ! detect_hallucination "$task_file"; then
            hallucination_count=$((hallucination_count + 1))
        fi
    fi
done

log "=== 检测完成 ==="
log "检查任务数：$checked_count"
log "检测到幻觉：$hallucination_count"
