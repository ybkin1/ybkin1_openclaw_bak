#!/bin/bash
# 自动修复脚本 - 常见问题自愈

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
LOG_FILE="$BASE_DIR/logs/auto-fix.log"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

# 修复 1: 清理临时文件
fix_temp_files() {
    log_info "检查临时文件..."
    
    local count=$(find "$BASE_DIR/memory/tasks/active/" -name "*.tmp*" 2>/dev/null | wc -l)
    
    if [ "$count" -gt 0 ]; then
        log_warn "发现 $count 个临时文件，清理中..."
        find "$BASE_DIR/memory/tasks/active/" -name "*.tmp*" -delete
        log_info "✅ 临时文件清理完成"
    else
        log_info "✅ 无需清理临时文件"
    fi
}

# 修复 2: 归档历史任务
fix_archive_old_tasks() {
    log_info "检查历史任务..."
    
    local active_dir="$BASE_DIR/memory/tasks/active"
    local archived_dir="$BASE_DIR/memory/tasks/archived"
    
    mkdir -p "$archived_dir"
    
    # 归档超过 7 天无活动的任务
    local count=0
    for json_file in "$active_dir"/*.json; do
        [ -f "$json_file" ] || continue
        
        local last_activity=$(jq -r '.lastActivity // .last_activity // empty' "$json_file" 2>/dev/null)
        
        if [ -n "$last_activity" ]; then
            local last_ts=$(date -d "$last_activity" +%s 2>/dev/null || echo "0")
            local now_ts=$(date +%s)
            local days_old=$(( (now_ts - last_ts) / 86400 ))
            
            if [ "$days_old" -gt 7 ]; then
                local filename=$(basename "$json_file")
                log_warn "归档超期任务：$filename (${days_old}天)"
                
                mv "$json_file" "$archived_dir/"
                mv "${json_file%.json}.checkpoint" "$archived_dir/" 2>/dev/null || true
                mv "${json_file%.json}.summary" "$archived_dir/" 2>/dev/null || true
                
                count=$((count + 1))
            fi
        fi
    done
    
    if [ "$count" -gt 0 ]; then
        log_info "✅ 归档 $count 个历史任务"
    else
        log_info "✅ 无需归档历史任务"
    fi
}

# 修复 3: 清理过期日志
fix_cleanup_logs() {
    log_info "清理过期日志..."
    
    local log_dir="$BASE_DIR/../logs"
    
    # 删除超过 30 天的日志
    find "$log_dir" -name "*.log" -mtime +30 -delete 2>/dev/null || true
    
    log_info "✅ 日志清理完成"
}

# 修复 4: 重置冷却期
fix_reset_cooldown() {
    log_info "检查冷却期..."
    
    local state_file="$BASE_DIR/../health-guardian-state.json"
    
    if [ -f "$state_file" ]; then
        local last_fix=$(jq -r '.last_auto_fix // 0' "$state_file" 2>/dev/null || echo "0")
        local now_ts=$(date +%s)
        local hours_since=$(( (now_ts - last_fix) / 3600 ))
        
        if [ "$hours_since" -gt 24 ]; then
            log_warn "冷却期已过 (>24 小时)，重置中..."
            jq '.last_auto_fix = 0 | .auto_fix_count = 0' "$state_file" > "${state_file}.tmp"
            mv "${state_file}.tmp" "$state_file"
            log_info "✅ 冷却期已重置"
        else
            log_info "✅ 冷却期有效 (${hours_since}小时前)"
        fi
    fi
}

# 修复 5: 验证 Cron 配置
fix_verify_cron() {
    log_info "验证 Cron 配置..."
    
    local cron_file="/etc/cron.d/data-orchestrator"
    
    if [ ! -f "$cron_file" ]; then
        log_error "❌ Cron 配置文件丢失"
        return 1
    fi
    
    local task_count=$(grep -E "^[*0-9]" "$cron_file" | wc -l)
    
    if [ "$task_count" -lt 9 ]; then
        log_warn "⚠️ Cron 任务数量不足 (期望 9 个，实际 $task_count 个)"
    else
        log_info "✅ Cron 配置正常 ($task_count 个任务)"
    fi
}

# 主程序
main() {
    log_info "========================================"
    log_info "开始自动修复..."
    log_info "========================================"
    
    fix_temp_files
    fix_archive_old_tasks
    fix_cleanup_logs
    fix_reset_cooldown
    fix_verify_cron
    
    log_info "========================================"
    log_info "自动修复完成"
    log_info "========================================"
}

# 执行
case "${1:-}" in
    temp)
        fix_temp_files
        ;;
    archive)
        fix_archive_old_tasks
        ;;
    logs)
        fix_cleanup_logs
        ;;
    cooldown)
        fix_reset_cooldown
        ;;
    cron)
        fix_verify_cron
        ;;
    all|"")
        main
        ;;
    *)
        echo "用法：$0 {temp|archive|logs|cooldown|cron|all}"
        echo ""
        echo "temp     - 清理临时文件"
        echo "archive  - 归档历史任务"
        echo "logs     - 清理过期日志"
        echo "cooldown - 重置冷却期"
        echo "cron     - 验证 Cron 配置"
        echo "all      - 执行全部修复 (默认)"
        exit 1
        ;;
esac
