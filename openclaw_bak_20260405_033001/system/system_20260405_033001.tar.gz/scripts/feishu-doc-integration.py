#!/usr/bin/env python3
"""
飞书文档集成模块

解决系统文件无法发送给用户的问题
通过飞书 API 创建文档并分享
"""

import requests
import json
import os
from pathlib import Path
from typing import Optional, Dict, Any


class FeishuDocIntegration:
    """飞书文档集成"""
    
    def __init__(self):
        self.app_id = "cli_a9206a37a0f9dcef"
        self.app_secret = "o8EPudtskT8BkNyPyT0UC56hNS7Oyo7X"
        self.user_id = "ou_b46467cc1563871aab03ac1d4f9216f0"
        self.token = None
    
    def get_tenant_token(self) -> str:
        """获取 tenant_access_token"""
        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        payload = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        response = requests.post(url, json=payload)
        result = response.json()
        
        if result.get('code') == 0:
            self.token = result.get('tenant_access_token')
            return self.token
        else:
            raise Exception(f"获取 token 失败：{result}")
    
    def create_doc(self, title: str, content: str = "", folder_token: str = None) -> Dict[str, Any]:
        """
        创建飞书文档
        
        Args:
            title: 文档标题
            content: Markdown 内容
            folder_token: 文件夹 token（可选）
        
        Returns:
            文档信息 {doc_token, doc_url}
        """
        if not self.token:
            self.get_tenant_token()
        
        url = "https://open.feishu.cn/open-apis/docx/v1/documents"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "title": title,
            "owner_id": self.user_id  # 设置用户为所有者
        }
        
        if folder_token:
            payload["folder_token"] = folder_token
        
        response = requests.post(url, headers=headers, json=payload)
        result = response.json()
        
        if result.get('code') == 0:
            doc_token = result['data']['document']['doc_id']
            doc_url = f"https://feishu.cn/docx/{doc_token}"
            
            # 写入内容
            if content:
                self.write_doc(doc_token, content)
            
            # 设置权限
            self.set_permission(doc_token)
            
            return {
                'doc_token': doc_token,
                'doc_url': doc_url,
                'title': title
            }
        else:
            raise Exception(f"创建文档失败：{result}")
    
    def write_doc(self, doc_token: str, content: str):
        """
        写入文档内容
        
        Args:
            doc_token: 文档 token
            content: Markdown 内容
        """
        if not self.token:
            self.get_tenant_token()
        
        # 简单实现：先读取文档结构，然后替换内容
        # 完整实现需要调用飞书块操作 API
        
        url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{doc_token}/raw_content"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # 转换为飞书格式
        payload = {
            "content": content
        }
        
        response = requests.put(url, headers=headers, json=payload)
        result = response.json()
        
        if result.get('code') != 0:
            print(f"⚠️ 写入内容失败：{result}")
    
    def set_permission(self, doc_token: str):
        """
        设置文档权限（组织内可读）
        
        Args:
            doc_token: 文档 token
        """
        if not self.token:
            self.get_tenant_token()
        
        url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{doc_token}/memberships"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        # 添加组织权限
        payload = {
            "member_type": "tenant",  # 组织内所有成员
            "permission": "read_only"
        }
        
        response = requests.post(url, headers=headers, json=payload)
        result = response.json()
        
        if result.get('code') != 0:
            print(f"⚠️ 设置权限失败：{result}")
    
    def upload_file_to_drive(self, file_path: str, folder_token: str = None) -> Dict[str, Any]:
        """
        上传文件到飞书云空间
        
        Args:
            file_path: 本地文件路径
            folder_token: 文件夹 token
        
        Returns:
            文件信息 {file_token, file_url}
        """
        if not self.token:
            self.get_tenant_token()
        
        # 飞书文件上传需要分块上传，这里简化处理
        # 实际使用建议通过飞书文档方式
        
        raise NotImplementedError("文件上传功能待实现，建议使用文档方式")
    
    def send_doc_link(self, doc_info: Dict[str, Any], message: str = ""):
        """
        发送文档链接给用户（通过飞书消息）
        
        Args:
            doc_info: 文档信息
            message: 附加消息
        """
        # 通过 sessions_send 或飞书 API 发送
        doc_url = doc_info.get('doc_url')
        title = doc_info.get('title')
        
        print(f"\n📄 文档已创建：{title}")
        print(f"🔗 链接：{doc_url}")
        print(f"\n请将此链接发送给用户")


# 使用示例
if __name__ == "__main__":
    print("飞书文档集成 - 测试")
    print("=" * 60)
    
    integration = FeishuDocIntegration()
    
    # 测试创建文档
    try:
        doc_info = integration.create_doc(
            title="测试文档",
            content="# 测试\n\n这是一篇测试文档。"
        )
        
        print(f"\n✅ 文档创建成功")
        print(f"   标题：{doc_info['title']}")
        print(f"   Token: {doc_info['doc_token']}")
        print(f"   链接：{doc_info['doc_url']}")
        
        integration.send_doc_link(doc_info)
        
    except Exception as e:
        print(f"\n❌ 创建失败：{e}")
        print("\n可能原因:")
        print("  1. 飞书 API 权限不足")
        print("  2. App Secret 配置错误")
        print("  3. 网络连接问题")
    
    print("\n" + "=" * 60)
