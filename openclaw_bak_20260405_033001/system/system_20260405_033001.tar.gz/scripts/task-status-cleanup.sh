#!/bin/bash
# 任务状态清理脚本 - 修复虚假活跃任务
# 执行时间：2026-03-31 08:46

TASK_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
PAUSED_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/paused"
COMPLETED_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/completed"
LOG_FILE="/root/.openclaw/workspace/agents/master/memory/tasks/task-cleanup-$(date +%Y%m%d_%H%M%S).log"

echo "=== 任务状态清理开始 ===" | tee "$LOG_FILE"
echo "时间：$(date '+%Y-%m-%d %H:%M:%S')" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"

# 计数器
completed_count=0
zombie_count=0
keep_count=0

# 遍历所有活跃任务
for json_file in "$TASK_DIR"/*.json; do
    [ -f "$json_file" ] || continue
    
    filename=$(basename "$json_file")
    task_id=$(jq -r '.task_id // "unknown"' "$json_file" 2>/dev/null)
    title=$(jq -r '.title // "No Title"' "$json_file" 2>/dev/null)
    status=$(jq -r '.status // "unknown"' "$json_file" 2>/dev/null)
    last_activity=$(jq -r '.last_activity // "N/A"' "$json_file" 2>/dev/null)
    completed_at=$(jq -r '.completed_at // "N/A"' "$json_file" 2>/dev/null)
    
    echo "-----------------------------------" | tee -a "$LOG_FILE"
    echo "任务：$title" | tee -a "$LOG_FILE"
    echo "文件：$filename" | tee -a "$LOG_FILE"
    echo "状态：$status" | tee -a "$LOG_FILE"
    echo "最后活动：$last_activity" | tee -a "$LOG_FILE"
    echo "完成时间：$completed_at" | tee -a "$LOG_FILE"
    
    # 检查是否有 completed_at 字段（表示任务已完成）
    if [ "$completed_at" != "null" ] && [ "$completed_at" != "N/A" ] && [ -n "$completed_at" ]; then
        echo "📝 操作：标记为已完成 (completed_at 存在)" | tee -a "$LOG_FILE"
        
        # 更新状态为 completed
        jq '.status = "completed"' "$json_file" > "${json_file}.tmp" && mv "${json_file}.tmp" "$json_file"
        
        # 移动 JSON 到 completed 目录
        mv "$json_file" "$COMPLETED_DIR/" 2>/dev/null
        
        # 移动相关文件
        base_name="${filename%.json}"
        mv "$TASK_DIR/${base_name}.checkpoint" "$COMPLETED_DIR/" 2>/dev/null
        mv "$TASK_DIR/${base_name}.summary" "$COMPLETED_DIR/" 2>/dev/null
        
        ((completed_count++))
        echo "✅ 已移动到 completed 目录" | tee -a "$LOG_FILE"
        
    # 检查最后活动时间（超过 3 天无活动视为僵尸任务）
    elif [ "$last_activity" != "null" ] && [ "$last_activity" != "N/A" ] && [ -n "$last_activity" ]; then
        last_activity_ts=$(date -d "$last_activity" +%s 2>/dev/null || echo "0")
        now_ts=$(date +%s)
        days_old=$(( (now_ts - last_activity_ts) / 86400 ))
        
        if [ $days_old -gt 3 ]; then
            echo "🧟 操作：标记为僵尸任务 (无活动 > 3 天)" | tee -a "$LOG_FILE"
            
            # 更新状态为 zombie
            jq '.status = "zombie"' "$json_file" > "${json_file}.tmp" && mv "${json_file}.tmp" "$json_file"
            
            # 生成僵尸报告
            cat > "$TASK_DIR/${base_name}.zombie-report" <<EOF
# 僵尸任务报告

**任务 ID**: $task_id
**任务名称**: $title
**最后活动**: $last_activity
**无活动天数**: $days_old 天
**标记时间**: $(date '+%Y-%m-%d %H:%M:%S')

## 建议操作
1. 检查任务是否真的需要继续
2. 如不需要，删除相关文件
3. 如需要，手动恢复并更新状态
EOF
            
            # 移动到 paused 目录（等待人工审查）
            mv "$json_file" "$PAUSED_DIR/" 2>/dev/null
            mv "$TASK_DIR/${base_name}.checkpoint" "$PAUSED_DIR/" 2>/dev/null
            mv "$TASK_DIR/${base_name}.summary" "$PAUSED_DIR/" 2>/dev/null
            mv "$TASK_DIR/${base_name}.zombie-report" "$PAUSED_DIR/" 2>/dev/null
            
            ((zombie_count++))
            echo "📋 已生成僵尸报告并移动到 paused 目录" | tee -a "$LOG_FILE"
        else
            echo "⏳ 操作：保持活跃 (最近 $days_old 天内有活动)" | tee -a "$LOG_FILE"
            ((keep_count++))
        fi
    else
        echo "⚠️ 操作：无法判断，保持原状" | tee -a "$LOG_FILE"
        ((keep_count++))
    fi
    
    echo "" | tee -a "$LOG_FILE"
done

echo "===================================" | tee -a "$LOG_FILE"
echo "=== 清理完成 ===" | tee -a "$LOG_FILE"
echo "时间：$(date '+%Y-%m-%d %H:%M:%S')" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"
echo "统计:" | tee -a "$LOG_FILE"
echo "  ✅ 已完成任务：$completed_count" | tee -a "$LOG_FILE"
echo "  🧟 僵尸任务：$zombie_count" | tee -a "$LOG_FILE"
echo "  ⏳ 保持活跃：$keep_count" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"
echo "日志文件：$LOG_FILE" | tee -a "$LOG_FILE"
