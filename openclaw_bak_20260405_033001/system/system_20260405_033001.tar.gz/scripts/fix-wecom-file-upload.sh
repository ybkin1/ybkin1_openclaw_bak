#!/bin/bash
# 企业微信文件上传处理快速修复脚本
# 功能：修复文件上传未被正确处理的问题

set -e

echo "=========================================="
echo "企业微信文件上传处理快速修复"
echo "=========================================="
echo ""

# 1. 备份现有配置
echo "📦 备份现有配置..."
cp /root/.openclaw/openclaw.json /root/.openclaw/openclaw.json.bak.$(date +%Y%m%d_%H%M%S)
echo "✅ 配置已备份"
echo ""

# 2. 检查并修复 AGENT.md
echo "📝 检查 customer-service AGENT.md..."
if ! grep -q "文件上传自动处理" /root/.openclaw/workspace/agents/customer-service/AGENT.md; then
    cat >> /root/.openclaw/workspace/agents/customer-service/AGENT.md << 'EOF'

## 文件上传自动处理（2026-04-01 修复）

**触发条件**:
- 消息包含 MediaPaths 或 MediaTypes
- 文件类型：.log, .tar.gz, .gz, .zip, .txt, .tar

**处理流程**:
1. 检测文件上传（通过 MediaPaths）
2. 自动调用 file-processor Agent 处理文件
3. 如果是故障分析意图，调用 server-maintenance Agent 分析
4. 返回分析结果

**禁止事项**:
- ❌ 禁止 AI 模型直接回复文件上传消息
- ❌ 禁止编造与文件无关的回复（如"资源过期/封禁"）
- ❌ 禁止跳过文件处理流程
- ❌ 禁止基于文件名猜测内容

**文件类型检测**:
```python
# 故障分析相关文件
fault_files = ['.log', '.tar.gz', '.gz', '.txt', '.dmesg', '.syslog']
# 包含关键词
fault_keywords = ['nvidia', 'bug', 'report', 'error', 'fault', 'gpu']
```

**正确回复示例**:
```
✅ 文件已接收，正在处理...

📋 工单已创建：TKT-20260401-001
任务类型：GPU 故障分析

正在调用 server-maintenance Agent 分析日志...
```
EOF
    echo "✅ AGENT.md 已更新"
else
    echo "⚠️  AGENT.md 已包含文件处理规则，跳过"
fi
echo ""

# 3. 检查 file_handler.py 是否存在
echo "🔧 检查 file_handler.py..."
if [ -f /root/.openclaw/workspace/agents/customer-service/src/file_handler.py ]; then
    echo "✅ file_handler.py 存在"
else
    echo "❌ file_handler.py 不存在，需要创建"
fi
echo ""

# 4. 检查 file_processor.py 是否存在
echo "🔧 检查 file_processor.py..."
if [ -f /root/.openclaw/extensions/wecom-openclaw-plugin/src/file_processor.py ]; then
    echo "✅ file_processor.py 存在"
else
    echo "❌ file_processor.py 不存在"
fi
echo ""

# 5. 检查 message_router.py 是否存在
echo "🔧 检查 message_router.py..."
if [ -f /root/.openclaw/extensions/wecom-openclaw-plugin/src/message_router.py ]; then
    echo "✅ message_router.py 存在"
else
    echo "❌ message_router.py 不存在"
fi
echo ""

# 6. 检查 tools.json 配置
echo "🔧 检查 tools.json..."
if grep -q "process_file_upload" /root/.openclaw/extensions/wecom-openclaw-plugin/tools.json; then
    echo "✅ tools.json 包含 process_file_upload 工具"
else
    echo "❌ tools.json 缺少 process_file_upload 工具"
fi
echo ""

# 7. 检查 Gateway 状态
echo "📊 检查 Gateway 状态..."
if systemctl --user is-active openclaw-gateway > /dev/null 2>&1; then
    echo "✅ Gateway 运行中"
else
    echo "⚠️  Gateway 未运行"
fi
echo ""

# 8. 检查日志文件
echo "📋 检查日志文件..."
if [ -f /root/.openclaw/logs/wecom-plugin.log ]; then
    echo "✅ wecom-plugin.log 存在"
    echo "最近 5 条文件相关日志:"
    tail -100 /root/.openclaw/logs/wecom-plugin.log | grep -i "file\|upload" | tail -5 || echo "无文件相关日志"
else
    echo "⚠️  wecom-plugin.log 不存在"
fi
echo ""

# 9. 检查 tickets 目录
echo "📁 检查 tickets 目录..."
if [ -d /root/.openclaw/workspace/agents/customer-service/tickets ]; then
    ticket_count=$(ls /root/.openclaw/workspace/agents/customer-service/tickets/*.json 2>/dev/null | wc -l)
    echo "✅ tickets 目录存在，工单数：$ticket_count"
else
    echo "⚠️  tickets 目录不存在"
fi
echo ""

# 10. 输出修复建议
echo "=========================================="
echo "修复建议"
echo "=========================================="
echo ""
echo "1. 重启 Gateway 使配置生效:"
echo "   systemctl --user restart openclaw-gateway"
echo ""
echo "2. 测试文件上传:"
echo "   上传 nvidia-bug-report.tar.gz 到企业微信"
echo ""
echo "3. 检查回复:"
echo "   期望：文件处理确认 + 工单号"
echo "   避免：资源过期/封禁等无关回复"
echo ""
echo "4. 检查日志:"
echo "   tail -f /root/.openclaw/logs/wecom-plugin.log"
echo ""
echo "=========================================="
echo "修复检查完成！"
echo "=========================================="
