#!/bin/bash
# task-health-check.sh - 任务状态健康检查
# 每周一 09:00 执行，全面审计任务健康度
# P0 优化实施 - 2026-03-31

set -e

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
REPORTS_DIR="/root/.openclaw/workspace/agents/master/reports/health"
LOG_FILE="/root/.openclaw/logs/health-check.log"

mkdir -p "$REPORTS_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# 健康检查项
check_health() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title // "Unknown"' "$task_file")
    
    local issues=()
    local score=100
    
    # 1. Checkpoint 检查
    local checkpoint_file="${task_file%.json}.checkpoint"
    if [ ! -f "$checkpoint_file" ]; then
        issues+=("checkpoint 文件缺失")
        score=$((score - 20))
    else
        local total_lines=$(wc -l < "$checkpoint_file")
        local wait_count=$(grep -c '"step": "等待中"' "$checkpoint_file" 2>/dev/null || echo "0")
        
        if [ "$total_lines" -gt 0 ] && [ "$wait_count" -eq "$total_lines" ]; then
            issues+=("checkpoint 全是等待中")
            score=$((score - 30))
        fi
    fi
    
    # 2. 输出文件检查
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    if [ -n "$output_files" ]; then
        local missing_count=0
        for file in $output_files; do
            if [ ! -f "$file" ]; then
                missing_count=$((missing_count + 1))
            fi
        done
        
        if [ "$missing_count" -gt 0 ]; then
            issues+=("缺失 $missing_count 个输出文件")
            score=$((score - 25))
        fi
    fi
    
    # 3. 最后活动时间检查
    local last_activity=$(jq -r '.lastActivity // .last_activity // empty' "$task_file")
    if [ -n "$last_activity" ] && [ "$last_activity" != "null" ]; then
        local last_ts=$(date -d "$last_activity" +%s 2>/dev/null || echo "0")
        local now_ts=$(date +%s)
        local elapsed=$((now_ts - last_ts))
        local elapsed_hours=$((elapsed / 3600))
        
        if [ "$elapsed_hours" -gt 24 ]; then
            issues+=("超过 24 小时无活动")
            score=$((score - 20))
        elif [ "$elapsed_hours" -gt 12 ]; then
            issues+=("超过 12 小时无活动")
            score=$((score - 10))
        fi
    fi
    
    # 4. 状态一致性检查
    local status=$(jq -r '.status' "$task_file")
    if [ "$status" = "in_progress" ]; then
        local progress=$(jq -r '.progress // 0' "$task_file")
        if [ "$progress" -gt 95 ]; then
            issues+=("进度>95% 但未完成")
            score=$((score - 15))
        fi
    fi
    
    # 生成报告
    local health_status="healthy"
    if [ "$score" -lt 60 ]; then
        health_status="critical"
    elif [ "$score" -lt 80 ]; then
        health_status="warning"
    fi
    
    # 输出结果
    echo "$task_id|$title|$score|$health_status|${issues[*]}"
}

# 主程序
log "=== 开始任务健康检查 ==="
log "检查时间：$(date '+%Y-%m-%d %H:%M:%S')"

report_file="$REPORTS_DIR/health_report_$(date +%Y%m%d_%H%M).md"

cat > "$report_file" << EOF
# 任务健康检查报告

**检查时间**: $(date '+%Y-%m-%d %H:%M:%S')  
**检查范围**: $TASKS_DIR

---

## 概览

| 任务 ID | 任务标题 | 健康分 | 状态 | 问题 |
|---------|---------|--------|------|------|
EOF

total_score=0
task_count=0
healthy_count=0
warning_count=0
critical_count=0

for task_file in "$TASKS_DIR"/*.json; do
    if [ -f "$task_file" ]; then
        result=$(check_health "$task_file")
        
        task_id=$(echo "$result" | cut -d'|' -f1)
        title=$(echo "$result" | cut -d'|' -f2)
        score=$(echo "$result" | cut -d'|' -f3)
        status=$(echo "$result" | cut -d'|' -f4)
        issues=$(echo "$result" | cut -d'|' -f5)
        
        # 更新统计
        total_score=$((total_score + score))
        task_count=$((task_count + 1))
        
        case "$status" in
            healthy) healthy_count=$((healthy_count + 1)) ;;
            warning) warning_count=$((warning_count + 1)) ;;
            critical) critical_count=$((critical_count + 1)) ;;
        esac
        
        # 写入报告
        issues_display="${issues:-无}"
        echo "| $task_id | $title | $score | $status | $issues_display |" >> "$report_file"
        
        log "检查：$task_id - 分数：$score - 状态：$status"
    fi
done

# 计算平均分
if [ "$task_count" -gt 0 ]; then
    avg_score=$((total_score / task_count))
else
    avg_score=0
fi

# 添加总结
cat >> "$report_file" << EOF

## 统计

| 指标 | 值 |
|------|-----|
| 总任务数 | $task_count |
| 健康任务 | $healthy_count |
| 警告任务 | $warning_count |
| 严重任务 | $critical_count |
| 平均健康分 | $avg_score |

---

## 建议操作

EOF

if [ "$critical_count" -gt 0 ]; then
    echo "### 🔴 严重问题（需立即处理）" >> "$report_file"
    echo "" >> "$report_file"
    echo "以下任务健康分<60，建议立即检查：" >> "$report_file"
    echo "" >> "$report_file"
    
    for task_file in "$TASKS_DIR"/*.json; do
        if [ -f "$task_file" ]; then
            result=$(check_health "$task_file")
            score=$(echo "$result" | cut -d'|' -f3)
            
            if [ "$score" -lt 60 ]; then
                task_id=$(echo "$result" | cut -d'|' -f1)
                echo "- $task_id" >> "$report_file"
            fi
        fi
    done
    echo "" >> "$report_file"
fi

if [ "$warning_count" -gt 0 ]; then
    echo "### 🟡 警告（需关注）" >> "$report_file"
    echo "" >> "$report_file"
    echo "以下任务健康分 60-80，建议关注：" >> "$report_file"
    echo "" >> "$report_file"
    
    for task_file in "$TASKS_DIR"/*.json; do
        if [ -f "$task_file" ]; then
            result=$(check_health "$task_file")
            score=$(echo "$result" | cut -d'|' -f3)
            
            if [ "$score" -ge 60 ] && [ "$score" -lt 80 ]; then
                task_id=$(echo "$result" | cut -d'|' -f1)
                echo "- $task_id" >> "$report_file"
            fi
        fi
    done
    echo "" >> "$report_file"
fi

cat >> "$report_file" << EOF
---

**自动生成**: task-health-check.sh  
**下次检查**: $(date -d '+7 days' '+%Y-%m-%d')
EOF

log "=== 健康检查完成 ==="
log "总任务数：$task_count"
log "健康：$healthy_count, 警告：$warning_count, 严重：$critical_count"
log "平均健康分：$avg_score"
log "报告文件：$report_file"
