# MEMORY.md - 长期记忆入口

_最后更新：2026-03-17 | 分层记忆系统已启用 + 多 Agent 架构_

---

## 🧭 导航

**这是长期记忆的入口文件**。完整的分层记忆系统位于 `memory/` 目录。

| 层级 | 用途 | 链接 |
|------|------|------|
| 📁 Projects | 项目跟踪 | [memory/projects/](memory/projects/) |
| 📁 Daily | 日常记录 | [memory/daily/](memory/daily/) |
| 📁 Config | 系统配置 | [memory/config/](memory/config/) |
| 📁 Knowledge | 知识积累 | [memory/knowledge/](memory/knowledge/) |
| 📁 Decisions | 重要决策 | [memory/decisions/](memory/decisions/) |
| 📁 Archive | 归档内容 | [memory/archive/](memory/archive/) |

---

## 🚀 快速参考

### 服务器
- **IP**: 43.166.175.41
- **系统**: OpenCloudOS 9.4
- **服务**: OpenClaw Gateway (18789), Memos (5230), SearXNG (8080)

### 模型
- **主控 Agent**: `qwencode/glm-5-fast` (快速免费模型)
- **助手 Agent**: `qwencode/qwen3-coder-plus` (强推理模型)
- **Fallback**: `qwencode/qwen3.5-plus`
- **可用模型**: glm-5, glm-4.7, qwen3.5-plus, qwen3-max, qwen3-coder-plus, deepseek-v3.2, kimi-k2.5, MiniMax-M2.5

### 配置
- **工作区**: `~/.openclaw/workspace/`
- **Agent 架构**: `agents/{agent_id}/`
- **记忆索引**: [memory/INDEX.md](memory/INDEX.md)

### 任务处理流程
- **规则文档**: [memory/config/task-processing-workflow.md](memory/config/task-processing-workflow.md)
- **防重复规则**: [memory/config/anti-duplication-rules.md](memory/config/anti-duplication-rules.md)

---

## 📋 最近动态

| 日期 | 事件 |
|------|------|
| 2026-03-17 | 多 Agent 架构实施完成，包含 memory-manager, server-maintenance, customer-service, file-processor, database-manager |
| 2026-03-17 | 任务处理流程规则建立，4阶段处理机制 |
| 2026-03-17 | 助手 Agent 超时机制优化，支持长时间任务 |
| 2026-03-12 | 模型配置更新：fallback 从 qwen-portal/coder-model 改为 qwencode/qwen3.5-plus |
| 2026-03-09 | 周一例行检查，补全 daily 记录 (03-05~03-08) |
| 2026-03-08 | 系统初始化完成，Memos/SearXNG 部署完成 |
| 2026-03-05 | 分层记忆系统建立，thinking 模式开启 |
| 2026-03-04 | 系统初始化，Memos/SearXNG 部署 |

---

## 📖 使用说明

### 写入记忆
- **项目相关** → `memory/projects/<name>.md`
- **日常对话** → `memory/daily/YYYY-MM-DD.md`
- **配置变更** → `memory/config/<category>.md`
- **知识学习** → `memory/knowledge/<topic>.md`
- **重要决策** → `memory/decisions/YYYY-MM-DD-topic.md`

### 审查周期
- **daily/**: 每 7 天
- **projects/**: 项目阶段结束
- **knowledge/**: 每月
- **decisions/**: 每季度

---

## 🔗 完整索引

详细索引请查看：[memory/INDEX.md](memory/INDEX.md)
