#!/bin/bash
# Guardian3.0 Package Builder
# Creates installation package for distribution

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GUARDIAN_ROOT="$(dirname "$SCRIPT_DIR")"
VERSION_FILE="$GUARDIAN_ROOT/VERSION.md"
PACKAGE_DIR="/tmp/guardian3.0-package"
OUTPUT_DIR="$GUARDIAN_ROOT/packages"

# Extract version from VERSION.md
VERSION=$(grep "^## Current Version:" "$VERSION_FILE" | awk '{print $4}')
DATE=$(date +%Y%m%d_%H%M%S)
PACKAGE_NAME="guardian3.0-v${VERSION}_${DATE}.tar.gz"

echo "📦 Guardian3.0 Package Builder"
echo "Version: $VERSION"
echo "Package: $PACKAGE_NAME"

# Create output directory
mkdir -p "$OUTPUT_DIR"
mkdir -p "$PACKAGE_DIR"

# Copy guardian3.0 structure
echo "Copying files..."
cp -r "$GUARDIAN_ROOT/bin" "$PACKAGE_DIR/"
cp -r "$GUARDIAN_ROOT/modules" "$PACKAGE_DIR/"
cp -r "$GUARDIAN_ROOT/rules" "$PACKAGE_DIR/"
cp "$GUARDIAN_ROOT/VERSION.md" "$PACKAGE_DIR/"
cp "$GUARDIAN_ROOT/scripts/package.sh" "$PACKAGE_DIR/" 2>/dev/null || true

# Create INSTALL.md
cat > "$PACKAGE_DIR/INSTALL.md" << 'EOF'
# Guardian3.0 Installation Guide

## Quick Install

```bash
# Extract package
tar -xzf guardian3.0-v*.tar.gz -C /target/path/

# Set permissions
chmod +x /target/path/guardian3.0/bin/*.sh
chmod +x /target/path/guardian3.0/modules/*.sh

# Add to crontab
echo "*/30 * * * * /target/path/guardian3.0/bin/guardian-monitor.sh" | crontab -
```

## Requirements
- Bash 4.0+
- jq (for JSON processing)
- Standard Unix tools (grep, find, tar)

## Verification

```bash
# Test monitoring script
/target/path/guardian3.0/bin/guardian-monitor.sh

# Check logs
tail -f /target/path/guardian3.0/logs/cron.log
```

## Uninstall

```bash
# Remove from crontab
crontab -l | grep -v guardian-monitor.sh | crontab -

# Remove files
rm -rf /target/path/guardian3.0
```
EOF

# Create CHANGELOG.md from VERSION.md
echo "# Guardian3.0 Changelog" > "$PACKAGE_DIR/CHANGELOG.md"
grep -A 100 "^##" "$VERSION_FILE" >> "$PACKAGE_DIR/CHANGELOG.md"

# Create package
echo "Creating package..."
cd "$PACKAGE_DIR"
tar -czf "$OUTPUT_DIR/$PACKAGE_NAME" ./*

# Verify package
echo "Verifying package..."
tar -tzf "$OUTPUT_DIR/$PACKAGE_NAME" | head -10

echo ""
echo "✅ Package created: $OUTPUT_DIR/$PACKAGE_NAME"
echo "Size: $(du -h "$OUTPUT_DIR/$PACKAGE_NAME" | cut -f1)"

# Cleanup
rm -rf "$PACKAGE_DIR"

echo ""
echo "📝 Next steps:"
echo "1. Update VERSION.md with new version number"
echo "2. Commit changes to git"
echo "3. Push package to distribution location"