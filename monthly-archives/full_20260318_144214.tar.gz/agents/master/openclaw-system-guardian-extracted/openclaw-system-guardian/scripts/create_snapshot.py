#!/usr/bin/env python3
"""
OpenClaw System Guardian - Snapshot Creation Script

Creates complete or incremental snapshots of OpenClaw system state.
Handles sensitive information filtering and multi-agent architecture.
"""

import os
import json
import hashlib
import tarfile
import shutil
from datetime import datetime
from pathlib import Path

class SnapshotCreator:
    def __init__(self, workspace_path="/root/.openclaw/workspace/main"):
        self.workspace = Path(workspace_path)
        self.snapshot_dir = self.workspace / "backups" / "system_guardian"
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)
        
        # Core files to snapshot
        self.core_files = [
            "SOUL.md", "MEMORY.md", "AGENTS.md", "USER.md", 
            "TOOLS.md", "openclaw.filtered.json", "crontab.txt", 
            ".gitignore", "RECOVERY_CHECKLIST.md"
        ]
        
        # Sensitive patterns to filter
        self.sensitive_patterns = [
            "apiKey", "appSecret", "token", "password", "secret"
        ]
    
    def create_complete_snapshot(self):
        """Create a complete system snapshot"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        snapshot_name = f"complete_snapshot_{timestamp}"
        snapshot_path = self.snapshot_dir / snapshot_name
        
        # Create snapshot directory
        snapshot_path.mkdir(exist_ok=True)
        
        # Copy core files with sensitive data filtering
        self._copy_core_files(snapshot_path)
        
        # Backup memory directory
        self._backup_memory(snapshot_path)
        
        # Backup skills directory (including growth data)
        self._backup_skills(snapshot_path)
        
        # Create checksum file
        self._create_checksum(snapshot_path)
        
        # Create archive
        archive_path = self._create_archive(snapshot_path)
        
        return archive_path
    
    def _copy_core_files(self, snapshot_path):
        """Copy core configuration files with sensitive data filtering"""
        for filename in self.core_files:
            src_file = self.workspace / filename
            if src_file.exists():
                dst_file = snapshot_path / filename
                
                if filename.endswith('.json'):
                    # Filter sensitive data from JSON files
                    self._filter_json_file(src_file, dst_file)
                else:
                    # Copy other files as-is
                    shutil.copy2(src_file, dst_file)
    
    def _filter_json_file(self, src_file, dst_file):
        """Filter sensitive data from JSON files"""
        with open(src_file, 'r') as f:
            data = json.load(f)
        
        # Recursively filter sensitive fields
        filtered_data = self._filter_sensitive_data(data)
        
        with open(dst_file, 'w') as f:
            json.dump(filtered_data, f, indent=2)
    
    def _filter_sensitive_data(self, data):
        """Recursively filter sensitive data from nested structures"""
        if isinstance(data, dict):
            filtered = {}
            for key, value in data.items():
                if any(pattern in key.lower() for pattern in self.sensitive_patterns):
                    # Replace sensitive values with placeholder
                    filtered[key] = f"{{{{{key.upper()}}}}}"
                else:
                    filtered[key] = self._filter_sensitive_data(value)
            return filtered
        elif isinstance(data, list):
            return [self._filter_sensitive_data(item) for item in data]
        else:
            return data
    
    def _backup_memory(self, snapshot_path):
        """Backup complete memory directory"""
        memory_src = self.workspace / "memory"
        memory_dst = snapshot_path / "memory"
        
        if memory_src.exists():
            shutil.copytree(memory_src, memory_dst, dirs_exist_ok=True)
    
    def _backup_skills(self, snapshot_path):
        """Backup complete skills directory including growth data"""
        skills_src = self.workspace / "skills"
        skills_dst = snapshot_path / "skills"
        
        if skills_src.exists():
            shutil.copytree(skills_src, skills_dst, dirs_exist_ok=True)
    
    def _create_checksum(self, snapshot_path):
        """Create checksum file for integrity verification"""
        checksum_file = snapshot_path / "CHECKSUM.sha256"
        checksums = {}
        
        for root, dirs, files in os.walk(snapshot_path):
            for file in files:
                if file == "CHECKSUM.sha256":
                    continue
                
                filepath = Path(root) / file
                relpath = filepath.relative_to(snapshot_path)
                
                with open(filepath, 'rb') as f:
                    file_hash = hashlib.sha256(f.read()).hexdigest()
                    checksums[str(relpath)] = file_hash
        
        with open(checksum_file, 'w') as f:
            json.dump(checksums, f, indent=2)
    
    def _create_archive(self, snapshot_path):
        """Create tar.gz archive of snapshot"""
        archive_name = f"{snapshot_path.name}.tar.gz"
        archive_path = self.snapshot_dir / archive_name
        
        with tarfile.open(archive_path, "w:gz") as tar:
            tar.add(snapshot_path, arcname=snapshot_path.name)
        
        # Clean up temporary directory
        shutil.rmtree(snapshot_path)
        
        return archive_path

if __name__ == "__main__":
    creator = SnapshotCreator()
    archive_path = creator.create_complete_snapshot()
    print(f"Complete snapshot created: {archive_path}")