#!/usr/bin/env python3
"""
OpenClaw System Guardian - Health Check Script

Performs comprehensive health checks on OpenClaw system.
Tests channels, skills, agents functionality and network connectivity.
"""

import os
import json
import subprocess
import requests
from pathlib import Path
from datetime import datetime

class HealthChecker:
    def __init__(self, workspace_path="/root/.openclaw/workspace/main"):
        self.workspace = Path(workspace_path)
        self.config_file = self.workspace / "openclaw.filtered.json"
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "status": "healthy",
            "checks": {}
        }
    
    def run_all_checks(self):
        """Run all health checks"""
        self._check_channels()
        self._check_skills()
        self._check_agents()
        self._check_network()
        self._check_system_services()
        
        # Determine overall status
        failed_checks = [name for name, result in self.results["checks"].items() 
                        if not result.get("success", False)]
        if failed_checks:
            self.results["status"] = "unhealthy"
            self.results["failed_checks"] = failed_checks
        
        return self.results
    
    def _check_channels(self):
        """Check channel functionality"""
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            
            channels_config = config.get("channels", {})
            channel_results = {}
            
            # Check Feishu channel
            if channels_config.get("feishu", {}).get("enabled", False):
                feishu_result = self._test_feishu_channel()
                channel_results["feishu"] = feishu_result
            else:
                channel_results["feishu"] = {"success": False, "error": "Feishu channel not enabled"}
            
            # Check QQBot channel  
            if channels_config.get("qqbot") is not None:
                qqbot_result = self._test_qqbot_channel()
                channel_results["qqbot"] = qqbot_result
            
            self.results["checks"]["channels"] = channel_results
            
        except Exception as e:
            self.results["checks"]["channels"] = {
                "success": False, 
                "error": f"Failed to check channels: {str(e)}"
            }
    
    def _test_feishu_channel(self):
        """Test Feishu channel functionality"""
        try:
            # Test if Feishu configuration exists
            config_exists = (self.workspace / "openclaw.filtered.json").exists()
            if not config_exists:
                return {"success": False, "error": "OpenClaw config file missing"}
            
            # Test basic Feishu API connectivity (without sending actual message)
            # This would be implemented based on Feishu API documentation
            # For now, just verify configuration structure
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            
            feishu_config = config.get("channels", {}).get("feishu", {})
            if not feishu_config.get("accounts", {}).get("default"):
                return {"success": False, "error": "Feishu default account configuration missing"}
            
            return {"success": True, "message": "Feishu channel configuration valid"}
            
        except Exception as e:
            return {"success": False, "error": f"Feishu channel test failed: {str(e)}"}
    
    def _test_qqbot_channel(self):
        """Test QQBot channel functionality"""
        try:
            # Check if QQBot plugin is installed
            plugins_config = {}
            with open(self.config_file, 'r') as f:
                config = json.load(f)
                plugins_config = config.get("plugins", {}).get("entries", {})
            
            if not plugins_config.get("qqbot", {}).get("enabled", False):
                return {"success": False, "error": "QQBot plugin not enabled"}
            
            return {"success": True, "message": "QQBot plugin enabled"}
            
        except Exception as e:
            return {"success": False, "error": f"QQBot channel test failed: {str(e)}"}
    
    def _check_skills(self):
        """Check skills directory and functionality"""
        try:
            skills_dir = self.workspace / "skills"
            if not skills_dir.exists():
                self.results["checks"]["skills"] = {
                    "success": False, 
                    "error": "Skills directory missing"
                }
                return
            
            # Count installed skills
            skill_dirs = [d for d in skills_dir.iterdir() if d.is_dir()]
            skill_count = len(skill_dirs)
            
            # Verify essential skills exist
            essential_skills = ["openclaw-system-guardian", "skill-creator", "github"]
            missing_essential = []
            for skill in essential_skills:
                if not (skills_dir / skill).exists():
                    missing_essential.append(skill)
            
            if missing_essential:
                self.results["checks"]["skills"] = {
                    "success": False,
                    "error": f"Missing essential skills: {missing_essential}",
                    "skill_count": skill_count
                }
            else:
                self.results["checks"]["skills"] = {
                    "success": True,
                    "skill_count": skill_count,
                    "message": f"Found {skill_count} skills"
                }
                
        except Exception as e:
            self.results["checks"]["skills"] = {
                "success": False, 
                "error": f"Skills check failed: {str(e)}"
            }
    
    def _check_agents(self):
        """Check agent configuration and multi-agent architecture"""
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            
            agents_config = config.get("agents", {})
            agents_list = agents_config.get("list", [])
            
            if not agents_list:
                self.results["checks"]["agents"] = {
                    "success": False,
                    "error": "No agents configured"
                }
                return
            
            # Check master agent
            master_agent = next((a for a in agents_list if a.get("id") == "master"), None)
            if not master_agent:
                self.results["checks"]["agents"] = {
                    "success": False,
                    "error": "Master agent not found"
                }
                return
            
            # Check for layered agents (future support)
            layered_agents = [a for a in agents_list if a.get("id") != "master"]
            
            self.results["checks"]["agents"] = {
                "success": True,
                "master_agent": master_agent.get("id"),
                "layered_agents_count": len(layered_agents),
                "total_agents": len(agents_list)
            }
            
        except Exception as e:
            self.results["checks"]["agents"] = {
                "success": False,
                "error": f"Agents check failed: {str(e)}"
            }
    
    def _check_network(self):
        """Check network connectivity and services"""
        network_results = {}
        
        # Check SSH access (localhost)
        try:
            ssh_result = subprocess.run(["ssh", "-o", "ConnectTimeout=5", 
                                       "-o", "BatchMode=yes", "localhost", "echo", "test"], 
                                      capture_output=True, timeout=10)
            network_results["ssh"] = {
                "success": ssh_result.returncode == 0,
                "message": "SSH accessible" if ssh_result.returncode == 0 else "SSH not accessible"
            }
        except Exception as e:
            network_results["ssh"] = {
                "success": False,
                "error": f"SSH check failed: {str(e)}"
            }
        
        # Check OpenClaw Dashboard (assuming it runs on port 18789)
        try:
            response = requests.get("http://localhost:18789", timeout=5)
            network_results["dashboard"] = {
                "success": response.status_code == 200,
                "message": "Dashboard accessible" if response.status_code == 200 else f"Dashboard returned {response.status_code}"
            }
        except Exception as e:
            network_results["dashboard"] = {
                "success": False,
                "error": f"Dashboard check failed: {str(e)}"
            }
        
        self.results["checks"]["network"] = network_results
    
    def _check_system_services(self):
        """Check essential system services"""
        services_results = {}
        
        # Check if OpenClaw gateway is running
        try:
            ps_result = subprocess.run(["ps", "aux"], capture_output=True, text=True)
            gateway_running = "openclaw gateway" in ps_result.stdout
            services_results["openclaw_gateway"] = {
                "success": gateway_running,
                "message": "Gateway running" if gateway_running else "Gateway not running"
            }
        except Exception as e:
            services_results["openclaw_gateway"] = {
                "success": False,
                "error": f"Gateway check failed: {str(e)}"
            }
        
        self.results["checks"]["system_services"] = services_results

if __name__ == "__main__":
    checker = HealthChecker()
    results = checker.run_all_checks()
    print(json.dumps(results, indent=2))