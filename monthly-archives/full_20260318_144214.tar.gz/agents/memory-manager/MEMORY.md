# Memory Manager Agent - Long-term Memory

## Purpose
This file serves as the entry point for the memory manager agent's long-term memory system.

## Memory Structure
- **Shared Knowledge**: Access to system-wide knowledge base
- **Memory Optimization**: Records of memory structure improvements
- **Cross-Agent Coordination**: Coordination logs between different agents' memories
- **Classification Rules**: Rules for intelligent memory classification

## Learning Integration
All memory optimization experiences and cross-agent coordination patterns are recorded here for continuous improvement.

## Access Control
- Read-only access to other agents' memory directories
- Write access only to shared memory areas and own optimization records
- No direct modification of other agents' core memory files

## Maintenance
Regular cleanup and optimization based on the 4-retention backup policy.