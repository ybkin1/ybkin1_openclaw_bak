# Agent Long-term Memory

## Purpose
Entry point for agent's domain-specific knowledge and experiences.

## Memory Structure
- short_term/: Recent task records
- long_term/: Accumulated domain knowledge
- tasks/: Task execution history

## Access Control
- Read-only access to shared knowledge
- Write access only to own memory directories
- Cannot access master/assistant memories
