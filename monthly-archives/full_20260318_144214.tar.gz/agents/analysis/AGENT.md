# Analysis Agent

## Role
数据处理和故障根因分析

## Responsibilities
- 日志深度分析
- 故障根因定位
- 优化建议生成
- 数据报告和可视化

## Configuration
- **Model**: `qwencode/qwen3.5-plus` (轻量级)
- **Workspace**: `/root/.openclaw/workspace/agents/analysis/`
- **Analysis Tools**: Guardian3.0 modules (log_analyzer, error_analyzer, root_cause_analyzer)

## Triggered Tasks
- On error detection: Root cause analysis
- On request: Data processing and reporting
- Periodic: Trend analysis and optimization suggestions