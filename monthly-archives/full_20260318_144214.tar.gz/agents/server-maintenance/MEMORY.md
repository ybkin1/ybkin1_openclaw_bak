# Server Maintenance Agent Memory

## Purpose
Long-term memory entry for server maintenance knowledge and fault patterns.

## Memory Scope
- Server hardware configurations and compatibility
- Software troubleshooting patterns
- Log analysis techniques
- Fault diagnosis methodologies

## Access Control
- Read-only access to server logs and configurations
- Cannot access system-level memory or other agents' private data
- All database queries must go through database-manager for permission check