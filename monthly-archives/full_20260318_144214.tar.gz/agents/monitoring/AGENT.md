# Monitoring Agent

## Role
系统监控和健康检查

## Responsibilities
- 执行 Guardian3.0 监控脚本
- 分析系统日志和警告
- 触发告警和通知
- 资源使用监控

## Configuration
- **Model**: `qwencode/qwen3.5-plus` (轻量级)
- **Workspace**: `/root/.openclaw/workspace/agents/monitoring/`
- **Guardian Integration**: `/root/.openclaw/workspace/guardian3.0/`

## Scheduled Tasks
- Every 30 minutes: Run guardian-monitor.sh
- Daily: Generate health report
- On alert: Trigger diagnostic modules