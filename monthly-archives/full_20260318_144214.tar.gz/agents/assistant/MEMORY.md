# Assistant Agent Memory Entry

## Purpose
This file serves as the memory entry point for the assistant agent.

## Memory Structure
- **short_term/**: Recent task execution records and temporary data
- **long_term/**: Learned patterns, successful strategies, and accumulated knowledge
- **tasks/**: Task execution history with results and lessons learned

## Access Rules
- Master agent can read all assistant memory on demand
- Assistant can only write to its own memory directories
- No access to other agents' private memory spaces

## Retention Policy
- Short-term memory: 7 days
- Long-term memory: Permanent (critical learnings only)
- Task records: Archived after 30 days of completion