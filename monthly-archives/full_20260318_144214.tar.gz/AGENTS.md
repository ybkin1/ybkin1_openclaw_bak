# OpenClaw Agent Architecture

## 🏗️ 分层架构设计

### 主控 Agent (Master)
- **路径**: `/root/.openclaw/workspace/agents/master/`
- **职责**: 系统协调、任务分发、全局监控
- **配置**: `qwencode/glm-5` (主模型), `qwencode/qwen3.5-plus` (备用)

### 功能分支 Agents
- **monitoring**: 系统监控和健康检查
- **backup**: 备份管理和数据保护  
- **analysis**: 日志分析和故障诊断
- **(可扩展)**: 其他专用功能 agents

## 📁 目录结构规范

```
/root/.openclaw/workspace/
├── agents/                    # 所有 Agent 工作区
│   ├── master/               # 主控 Agent (当前激活)
│   ├── monitoring/           # 监控 Agent
│   ├── backup/               # 备份 Agent  
│   └── analysis/             # 分析 Agent
├── backups-unified/          # 统一备份系统 (4 份保留策略)
├── .openclaw/                # 系统级配置
└── openclaw.json             # 全局 Agent 配置
```

## ⚙️ 配置整合

**单一配置源**: 
- 所有 Agent 配置统一在 `/root/.openclaw/workspace/openclaw.json`
- 移除冗余的 `openclaw.filtered.json` 文件
- 主工作区指向 `agents/master/`

## 🔄 迁移状态

- ✅ 架构设计完成
- ✅ 主控 Agent 迁移完成  
- ⏳ 功能分支 Agents 初始化
- ⏳ 配置文件整合
- ⏳ 备份系统适配

## 📋 待办事项

1. **清理冗余文件**: 删除 `/root/.openclaw/workspace/main/` 中的重复内容
2. **更新符号链接**: 确保系统指向新架构
3. **验证功能**: 测试所有 Agent 能正常工作
4. **文档化**: 完成架构文档