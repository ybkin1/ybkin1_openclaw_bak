# HEARTBEAT.md - Master Agent Task Memory System

## Daily Tasks (Execute at 23:50 daily)
1. **Session Summary**: For each active user, summarize today's conversations and update short-term memory
2. **Task Progress Update**: Check all active tasks and update progress status using task metadata schema
3. **Cleanup Check**: Identify completed tasks older than 3 days using completion_date field and prepare deletion inquiries
4. **Memory Consolidation**: Move relevant short-term learnings to long-term memory
5. **Task Completion Verification**: For recently completed tasks, verify completion status with user if not already confirmed
6. **Task Confirmation Check**: Check for tasks with completion_confirmed=false and send confirmation requests
7. **Thinking Principles Review**: Audit all agents' recent task handling for compliance with `memory/config/agent-thinking-principles.md`; flag deviations and suggest corrections
8. **System Backup**: Execute `/root/.openclaw/backups-unified/backup-manager.sh full --push` at 03:30 daily
   - Creates `openclaw_bak_<timestamp>/` bundle with 4-layer structure
   - Pushes to GitHub (`ybkin1/ybkin1_openclaw_bak` via SSH)
   - Auto-deletes older bundles, keeps latest 4
   - Logs to `/root/.openclaw/backups-unified/backup.log`
   - Monitors GitHub sync status and alerts on failure
9. **Memory Architecture Maintenance** (NEW - 2026-03-27):
   - Run memory cleanup: `python /root/.openclaw/workspace/agents/master/src/cleanup_memories.py`
   - Check memory stats: working/semantic/fact counts
   - Review verification logs for conflicts
   - Archive old completed tasks (>7 days)

## Task Progress Monitoring (Execute every 10 minutes during active tasks)
- **1/3 Progress Check**: For any task with estimated duration > 30 minutes, check if 1/3 of time has passed
- **Progress Report**: If 1/3 threshold met, generate progress report and notify user
- **Risk Assessment**: Evaluate if task is on track or needs intervention

## New Session Recovery Workflow
When a new session starts:
1. **User Identification**: Map incoming channel ID to user UUID
2. **Memory Loading**: Load short-term memory (last 10 messages) and active tasks
3. **Context Generation**: Create summary of yesterday's tasks and current status
4. **User Confirmation**: Present context to user: "Yesterday you had X active tasks: [list]. Is my understanding correct?"

## Task Recognition Rules
Automatically identify as tasks any request containing:
- Configuration/setup/setting
- Upgrade/update/install/deploy  
- Backup/restore/archive
- Maintenance/monitoring/troubleshooting
- Any action requiring system changes or persistent tracking

## Learning Integration
- All task completions contribute to long-term memory
- User feedback improves task recognition accuracy
- System continuously evolves based on interaction patterns

## Memory Structure Validation
Ensure the following directory structure exists:
memory/master/
├── users/
├── short_term/  
├── long_term/
└── tasks/
    ├── active/
    ├── completed/
    └── archived/

## Memory Architecture Integration (NEW - 2026-03-27)

### Three-Layer Memory System

**L1: Working Memory** (memory_working table)
- Store: Recent 10 conversations per session
- TTL: 24 hours auto-expiry
- Usage: Context coherence

**L2: Semantic Memory** (memory_semantic table)
- Store: Meaningful information with confidence
- TTL: 30 days no-access archive
- Usage: Retrieval and verification

**L3: Factual Memory** (memory_facts table)
- Store: Verified structured facts (subject-predicate-object)
- TTL: Permanent (unless manually deleted)
- Usage: Anti-hallucination core

### Anti-Hallucination Workflow

```python
# 1. Extract facts from conversation
candidates = extract_facts_from_conversation(text)

# 2. Check conflicts
has_conflict, conflicting = check_fact_conflict(subject, predicate, object)

# 3. Verify and store
if not has_conflict and confidence >= 0.9:
    store_fact(subject, predicate, object, verified=True)

# 4. Query with anti-hallucination
result = query_with_anti_hallucination(query, subject='用户')
# Returns: answer + confidence + evidence + source
```

### Daily Memory Tasks

**At 23:50**:
1. Cleanup expired working memories (auto via trigger)
2. Archive semantic memories with no access > 30 days
3. Review verification logs for conflicts
4. Update memory stats to daily log

**Every hour**:
1. Run memory cleanup script
2. Check memory database health
3. Alert if verification conflicts detected

### Memory Stats to Track

```json
{
  "working_memory_count": 150,
  "semantic_memory_count": 500,
  "fact_count": 100,
  "verification_stats": {
    "confirmed": 95,
    "rejected": 5,
    "conflicts_detected": 2
  }
}
```

### Integration Points

**Master Agent**:
- Use `memory_middleware.py` for automatic memory storage
- Use `memory_integration.py` for fact extraction and verification
- Query with anti-hallucination before responding

**Database Manager**:
- Execute `014_memory_architecture.sql` migration
- Ensure tables and views exist
- Monitor database performance

**Memory Manager Agent**:
- Implement automated cleanup cron jobs
- Monitor memory growth
- Generate weekly memory reports
