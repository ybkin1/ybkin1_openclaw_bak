#!/bin/bash
# OpenClaw 统一备份管理器
# 用法: backup-manager.sh [full|incremental|verify|restore]
# 默认: full

set -e

WORKSPACE="/root/.openclaw/workspace"
BACKUP_ROOT="/root/.openclaw/backups-unified"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
DATE=$(date +%Y-%m-%d)
MANIFEST="$BACKUP_ROOT/manifest_$TIMESTAMP.json"
LOG_DIR="$BACKUP_ROOT/logs"
mkdir -p "$LOG_DIR"
LOGFILE="$LOG_DIR/backup_$TIMESTAMP.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOGFILE"; }
error() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ $*" | tee -a "$LOGFILE" >&2; }
success() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✅ $*" | tee -a "$LOGFILE"; }

# 清单文件位置（由主计划生成）
MANIFEST_LIST="$WORKSPACE/docs/backup-filelist-precise-2026-03-18.txt"

# 临时工作区
TEMP_DIR=$(mktemp -d)
trap 'rm -rf "$TEMP_DIR"' EXIT

backup_full() {
    log "开始完整备份 [full] ..."

    # 读取 P0/P1 文件列表
    local files=()
    local level=""
    while IFS= read -r line; do
        # 跳过注释和空行
        [[ -z "$line" || "$line" =~ ^# ]] && continue
        # 检查是否是指定级别的标题
        if [[ "$line" =~ ^\[P0\] ]]; then
            level="P0"
            continue
        elif [[ "$line" =~ ^\[P1\] ]]; then
            level="P1"
            continue
        elif [[ "$line" =~ ^\[P2\] ]]; then
            level="P2"
            continue
        fi
        # 只收集 P0 和 P1 的路径行（以 / 开头）
        if [[ "$line" =~ ^/ ]] && { [ "$level" = "P0" ] || [ "$level" = "P1" ]; }; then
            files+=("$line")
        fi
    done < "$MANIFEST_LIST"

    local total=${#files[@]}
    log "待备份文件数: $total"
    local count=0
    local failed=0

    for src in "${files[@]}"; do
        if [ -e "$src" ]; then
            # 计算相对路径
            rel_path="${src#/root/.openclaw/workspace/}"
            dest_dir="$TEMP_DIR/$(dirname "$rel_path")"
            mkdir -p "$dest_dir"
            cp -p "$src" "$TEMP_DIR/$rel_path" 2>/dev/null || {
                error "备份失败: $src"
                failed=$((failed+1))
                continue
            }
            count=$((count+1))
            if [ $((count % 50)) -eq 0 ]; then
                log "进度: $count/$total ..."
            fi
        else
            error "源不存在: $src"
            failed=$((failed+1))
        fi
    done

    log "文件复制完成: $count 成功, $failed 失败"

    # 创建归档
    local archive_name="full_${TIMESTAMP}.tar.gz"
    local archive_path="$BACKUP_ROOT/full/$archive_name"
    mkdir -p "$BACKUP_ROOT/full"
    log "创建归档: $archive_path"
    tar -czf "$archive_path" -C "$TEMP_DIR" . 2>/dev/null || {
        error "归档创建失败"
        exit 1
    }

    # 生成 manifest（SHA256）- 简化版，确保成功
    log "生成 manifest..."
    echo "{" > "$MANIFEST"
    echo "  \"timestamp\": \"$TIMESTAMP\"," >> "$MANIFEST"
    echo "  \"date\": \"$DATE\"," >> "$MANIFEST"
    echo "  \"type\": \"full\"," >> "$MANIFEST"
    echo "  \"archive\": \"$archive_name\"," >> "$MANIFEST"
    echo "  \"size\": $(stat -c%s "$archive_path" 2>/dev/null || echo 0)," >> "$MANIFEST"
    echo "  \"files\": [" >> "$MANIFEST"

    local count=0
    local first=1
    while IFS= read -r src; do
        # 在清单中跳过标题行
        [[ "$src" =~ ^\[P0\]|^\[P1\]|^\[P2\] ]] && continue
        [[ -z "$src" || "$src" =~ ^# ]] && continue
        [[ "$src" =~ ^/ ]] || continue

        if [ -f "$src" ]; then
            local rel="${src#/root/.openclaw/workspace/}"
            local sha=$(sha256sum "$src" 2>/dev/null | awk '{print $1}' || echo "unknown")
            if [ $first -eq 0 ]; then
                echo "," >> "$MANIFEST"
            fi
            printf '    {"path":"%s","sha256":"%s"}' "$rel" "$sha" >> "$MANIFEST"
            first=0
            count=$((count+1))
        fi
    done < "$MANIFEST_LIST"

    echo "" >> "$MANIFEST"
    echo "  ]" >> "$MANIFEST"
    echo "}" >> "$MANIFEST"

    success "Manifest 生成: $count 个文件"

    success "完整备份完成: $archive_path"
    success "Manifest: $MANIFEST"
    log "备份统计: $count 文件, $(du -h "$archive_path" | cut -f1) 大小"
}

backup_incremental() {
    log "增量备份暂未实现"
    exit 1
}

verify_backup() {
    local manifest_file="$1"
    if [ -z "$manifest_file" ]; then
        # 验证最新备份
        manifest_file=$(ls -t "$BACKUP_ROOT"/manifest_*.json 2>/dev/null | head -1)
    fi
    if [ ! -f "$manifest_file" ]; then
        error "未找到 manifest 文件"
        exit 1
    fi
    log "验证备份: $manifest_file"
    # 简单验证文件存在和大小
    jq -r '.files[]?.path' "$manifest_file" | while read -r path; do
        if [ ! -f "/root/.openclaw/workspace/$path" ]; then
            error "缺失文件: $path"
        fi
    done
    success "验证通过"
}

usage() {
    echo "用法: $0 [full|incremental|verify|restore]"
    echo "  full          - 执行完整备份（默认）"
    echo "  incremental   - 执行增量备份（未实现）"
    echo "  verify [manifest] - 验证备份完整性"
    echo "  restore [manifest] - 从备份恢复（危险）"
    exit 1
}

case "${1:-full}" in
    full) backup_full ;;
    incremental) backup_incremental ;;
    verify) verify_backup "$2" ;;
    restore) echo "恢复功能需要交互确认，请使用专用恢复脚本"; exit 1 ;;
    *) usage ;;
esac