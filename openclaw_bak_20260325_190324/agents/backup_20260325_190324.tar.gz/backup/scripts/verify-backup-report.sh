#!/bin/bash
# Backup Agent - 备份验证报告脚本
# 每次备份后执行，验证备份完整性并生成报告

set -euo pipefail

BACKUP_ROOT="/root/.openclaw/backups-unified"
REPORT_DIR="/root/.openclaw/workspace/agents/backup/reports"
REPORT_FILE="$REPORT_DIR/backup-verify-$(date +%Y%m%d_%H%M%S).md"

mkdir -p "$REPORT_DIR"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }

# 验证最新备份
verify_latest_backup() {
    log "验证最新备份..."
    
    local latest_bundle=$(ls -td "$BACKUP_ROOT"/openclaw_bak_* 2>/dev/null | head -1)
    
    if [ -z "$latest_bundle" ]; then
        echo "⚠ 未找到任何备份 bundle"
        return 1
    fi
    
    local bundle_name=$(basename "$latest_bundle")
    log "最新备份：$bundle_name"
    
    # 验证 checksums.sha256
    local checksum_file="$latest_bundle/checksums.sha256"
    local checksum_status="✓ 通过"
    
    if [ -f "$checksum_file" ]; then
        cd "$latest_bundle"
        if sha256sum -c checksums.sha256 > /dev/null 2>&1; then
            checksum_status="✓ 通过"
        else
            checksum_status="❌ 失败"
        fi
        cd - > /dev/null
    else
        checksum_status="⚠ 无 checksum 文件"
    fi
    
    echo "### 备份验证结果"
    echo ""
    echo "| 检查项 | 状态 |"
    echo "|--------|------|"
    echo "| 备份名称 | $bundle_name |"
    echo "| 备份时间 | $(stat -c %y "$latest_bundle" | cut -d'.' -f1) |"
    echo "| Checksum 验证 | $checksum_status |"
    echo ""
}

# 分析备份统计
analyze_backup_stats() {
    log "分析备份统计..."
    
    local latest_bundle=$(ls -td "$BACKUP_ROOT"/openclaw_bak_* 2>/dev/null | head -1)
    local stats_file="$latest_bundle/backup-stats.json"
    
    if [ ! -f "$stats_file" ]; then
        echo "### 备份统计\n\n⚠ 统计文件不存在\n"
        return
    fi
    
    # 解析 JSON（需要 jq）
    if command -v jq &> /dev/null; then
        local total_size=$(jq -r '.total_size_human' "$stats_file")
        local file_count=$(jq -r '.file_count' "$stats_file")
        local timestamp=$(jq -r '.timestamp' "$stats_file")
        
        local agents_size=$(jq -r '.breakdown.agents.human' "$stats_file")
        local memory_size=$(jq -r '.breakdown.memory.human' "$stats_file")
        local config_size=$(jq -r '.breakdown.config.human' "$stats_file")
        local system_size=$(jq -r '.breakdown.system.human' "$stats_file")
        local identity_size=$(jq -r '.breakdown.identity.human // "N/A"' "$stats_file")
        
        cat << EOF
### 备份统计

| 指标 | 数值 |
|------|------|
| 备份时间 | $timestamp |
| 总大小 | $total_size |
| 文件总数 | $file_count |

#### 分类详情

| 分类 | 大小 |
|------|------|
| Agents | $agents_size |
| Memory | $memory_size |
| Config | $config_size |
| System | $system_size |
| Identity | $identity_size |

EOF
    else
        echo "### 备份统计\n\n⚠ 需要安装 jq 解析 JSON\n"
        cat "$stats_file"
        echo ""
    fi
}

# 分析备份趋势
analyze_backup_trend() {
    log "分析备份趋势..."
    
    local trend_file="$BACKUP_ROOT/logs/backup-trend-report.txt"
    
    if [ ! -f "$trend_file" ]; then
        echo "### 备份趋势\n\n⚠ 趋势报告不存在\n"
        return
    fi
    
    echo "### 备份趋势"
    echo ""
    echo '```'
    cat "$trend_file"
    echo '```'
    echo ""
}

# 检查保留策略执行
check_retention_policy() {
    log "检查保留策略执行..."
    
    local bundle_count=$(ls -d "$BACKUP_ROOT"/openclaw_bak_* 2>/dev/null | wc -l)
    
    # 统计每日/每周/每月备份数量
    local daily_count=0
    local weekly_count=0
    local monthly_count=0
    
    for bundle in "$BACKUP_ROOT"/openclaw_bak_*; do
        local bundle_name=$(basename "$bundle")
        local date_part=$(echo "$bundle_name" | sed 's/openclaw_bak_//' | cut -d'_' -f1)
        local day=$(echo "$date_part" | cut -c7-8)
        
        # 简单的月度判断（1-7 日）
        if [ "$day" -le 7 ] 2>/dev/null; then
            monthly_count=$((monthly_count + 1))
        else
            daily_count=$((daily_count + 1))
        fi
    done
    
    cat << EOF
### 保留策略执行

| 类型 | 当前数量 | 保留上限 | 状态 |
|------|---------|---------|------|
| 总备份数 | $bundle_count | 23 (7+4+12) | $([ "$bundle_count" -le 23 ] && echo "✓" || echo "⚠") |
| 每日备份 | $daily_count | 7 | $([ "$daily_count" -le 7 ] && echo "✓" || echo "⚠") |
| 每月备份 | $monthly_count | 12 | $([ "$monthly_count" -le 12 ] && echo "✓" || echo "⚠") |

EOF
}

# 检查 GitHub 同步状态
check_github_sync() {
    log "检查 GitHub 同步状态..."
    
    local git_dir="$BACKUP_ROOT/.git"
    
    if [ ! -d "$git_dir" ]; then
        echo "### GitHub 同步\n\n⚠ Git 仓库未初始化\n"
        return
    fi
    
    cd "$BACKUP_ROOT"
    
    local last_commit=$(git log -1 --format="%h %s" 2>/dev/null || echo "无提交记录")
    local local_commits=$(git rev-list --count HEAD 2>/dev/null || echo 0)
    
    # 检查是否需要推送
    local behind=$(git rev-list --count HEAD..origin/main 2>/dev/null || echo 0)
    local ahead=$(git rev-list --count origin/main..HEAD 2>/dev/null || echo 0)
    
    local sync_status="✓ 同步"
    if [ "$ahead" -gt 0 ]; then
        sync_status="⚠ 本地领先 $ahead 个提交（需要推送）"
    elif [ "$behind" -gt 0 ]; then
        sync_status="⚠ 本地落后 $behind 个提交（需要拉取）"
    fi
    
    cd - > /dev/null
    
    cat << EOF
### GitHub 同步

| 指标 | 数值 |
|------|------|
| 最后提交 | $last_commit |
| 本地提交数 | $local_commits |
| 同步状态 | $sync_status |

EOF
}

# 恢复演练检查
check_restore_drill() {
    log "检查恢复演练..."
    
    local restore_log="$BACKUP_ROOT/RESTORE.md"
    
    if [ ! -f "$restore_log" ]; then
        echo "### 恢复演练\n\n⚠ 恢复文档不存在\n"
        return
    fi
    
    local last_drill=$(grep -oP '\d{4}-\d{2}-\d{2}' "$restore_log" | head -1 || echo "无记录")
    
    cat << EOF
### 恢复演练

| 指标 | 数值 |
|------|------|
| 上次演练 | $last_drill |
| 演练频率 | 每月一次 |
| 下次演练 | $(date -d "+1 month" +%Y-%m-%d) |

EOF
}

# 生成完整报告
generate_report() {
    log "生成验证报告..."
    
    {
        echo "# OpenClaw 备份验证报告"
        echo ""
        echo "**生成时间**: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "**验证对象**: 最新备份 bundle"
        echo ""
        echo "---"
        echo ""
        
        verify_latest_backup
        analyze_backup_stats
        analyze_backup_trend
        check_retention_policy
        check_github_sync
        check_restore_drill
        
        echo "---"
        echo ""
        echo "## 建议操作"
        echo ""
        echo "1. 查看备份详情：\`ls -la $BACKUP_ROOT/openclaw_bak_*/\`"
        echo "2. 验证完整性：\`cd $BACKUP_ROOT && sha256sum -c openclaw_bak_*/checksums.sha256\`"
        echo "3. 推送至 GitHub：\`cd $BACKUP_ROOT && git push\`"
        echo "4. 执行恢复演练：参考 \`$BACKUP_ROOT/RESTORE.md\`"
        echo ""
        echo "---"
        echo "*报告由 Backup Agent 自动生成*"
        
    } > "$REPORT_FILE"
    
    log "✓ 验证报告已生成：$REPORT_FILE"
}

# 主函数
main() {
    log "=========================================="
    log "Backup Agent 备份验证开始"
    log "=========================================="
    
    generate_report
    
    log "=========================================="
    log "Backup Agent 备份验证完成"
    log "=========================================="
}

# 执行
main "$@"
