#!/bin/bash
# 将最新完整备份同步到 GitHub 仓库
# 用法: ./sync-backup-to-github.sh [repo] [branch]

set -e

BACKUP_ROOT="/root/.openclaw/backups-unified"
GIT_REPO_DIR="/root/.openclaw/backups-repo"
REPO="${1:-ybkin1/openclaw_backups}"
BRANCH="${2:-main}"
LATEST_MANIFEST=$(ls -t "$BACKUP_ROOT"/manifest_*.json 2>/dev/null | head -1)

if [ -z "$LATEST_MANIFEST" ]; then
    echo "❌ 未找到 manifest 文件"
    exit 1
fi

TIMESTAMP=$(basename "$LATEST_MANIFEST" .json | sed 's/manifest_//')
ARCHIVE=$(jq -r '.archive' "$LATEST_MANIFEST" 2>/dev/null)
ARCHIVE_PATH="$BACKUP_ROOT/full/$ARCHIVE"

if [ ! -f "$ARCHIVE_PATH" ]; then
    echo "❌ 归档文件不存在: $ARCHIVE_PATH"
    exit 1
fi

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }
success() { echo "✅ $*"; }
error() { echo "❌ $*" >&2; }

log "开始 GitHub 同步..."
log "Manifest: $LATEST_MANIFEST"
log "Archive: $ARCHIVE ($(du -h "$ARCHIVE_PATH" | cut -f1))"

# 准备 git 仓库
mkdir -p "$GIT_REPO_DIR"
cd "$GIT_REPO_DIR"

if [ ! -d .git ]; then
    git init
    git remote add origin "git@github.com:$REPO.git" || true
else
    # 确保使用 SSH 而非 HTTPS
    git remote set-url origin "git@github.com:$REPO.git" || true
fi

# 创建目录结构
mkdir -p monthly-archives restore-scripts

# 复制归档和 manifest
cp -n "$ARCHIVE_PATH" "monthly-archives/" 2>/dev/null || true
cp -n "$LATEST_MANIFEST" "monthly-archives/manifest.json" 2>/dev/null || true

# 生成恢复脚本（如果不存在）
if [ ! -f restore-scripts/restore-latest.sh ]; then
    cat > restore-scripts/restore-latest.sh << 'RESTORE_EOF'
#!/bin/bash
set -e
MANIFEST="./monthly-archives/manifest.json"
ARCHIVE=$(jq -r '.archive' "$MANIFEST")
echo "恢复最新备份: $ARCHIVE"
tar -xzf "./monthly-archives/$ARCHIVE" -C /tmp/restore-$$ && \
    /root/.openclaw/workspace/agents/backup/scripts/restore-from-backup.js /tmp/restore-$$ || {
    echo "恢复失败"; exit 1;
}
echo "恢复完成"
RESTORE_EOF
    chmod +x restore-scripts/restore-latest.sh
fi

# 创建 README
cat > README.md << README_EOF
# OpenClaw 系统备份仓库

## 内容
- `monthly-archives/` - 月度全量备份（永久保留）
- `restore-scripts/` - 恢复工具
- `manifest.json` - 最新备份清单（指向最新归档）

## 最新备份
- 时间戳: $(jq -r '.timestamp' "$LATEST_MANIFEST" 2>/dev/null || echo "unknown")
- 归档: $(jq -r '.archive' "$LATEST_MANIFEST" 2>/dev/null || echo "unknown")
- 文件数: $(jq -r '.files | length' "$LATEST_MANIFEST" 2>/dev/null || echo "unknown")
- 大小: $(du -h "$ARCHIVE_PATH" | cut -f1)

## 恢复系统
\`\`\`bash
./restore-scripts/restore-latest.sh
\`\`\`

---
自动生成于 $(date)
README_EOF

# Git 提交
git add -A
git commit -m "backup: $TIMESTAMP" || echo "无变更"
git push origin "$BRANCH" || {
    error "Git push 失败 - 请检查 SSH 密钥配置"
    exit 1
}

success "GitHub 同步完成"
log "仓库: $REPO ($BRANCH)"
log "推送: git@github.com:$REPO"