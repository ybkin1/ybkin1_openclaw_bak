#!/bin/bash
# Backup Agent 恢复演练脚本 - 简化版
set -euo pipefail

# 配置
BACKUP_ROOT="/root/.openclaw/backups-unified"
DRILL_DIR="/tmp/backup-restore-drill"
REPORT_DIR="/root/.openclaw/workspace/agents/backup/reports"
LOG_FILE="$REPORT_DIR/restore-drill.log"

# 创建目录
mkdir -p "$REPORT_DIR" "$DRILL_DIR"

# 日志函数
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"; }

# 清理函数
cleanup() {
    log "清理临时目录..."
    rm -rf "$DRILL_DIR"
}

# 主函数
main() {
    log "=========================================="
    log "Backup Agent 恢复演练开始"
    log "=========================================="
    
    trap cleanup EXIT
    
    # 找到最新的备份
    local latest_bundle=$(find "$BACKUP_ROOT" -maxdepth 1 -name "openclaw_bak_*" -type d | sort -r | head -n1)
    if [ -z "$latest_bundle" ]; then
        log "❌ 未找到备份文件"
        exit 1
    fi
    
    log "使用备份: $(basename "$latest_bundle")"
    
    # 测试1: 解压配置文件
    log "测试1: 配置文件恢复..."
    if tar -xzf "$latest_bundle/config/config_$(basename "$latest_bundle" | cut -d'_' -f3-4).tar.gz" -C "$DRILL_DIR" 2>/dev/null; then
        log "✓ 配置文件恢复成功"
        test1_success=1
    else
        log "❌ 配置文件恢复失败"
        test1_success=0
    fi
    
    # 测试2: 解压记忆文件
    log "测试2: 记忆文件恢复..."
    if tar -xzf "$latest_bundle/memory/memory_main_$(basename "$latest_bundle" | cut -d'_' -f3-4).tar.gz" -C "$DRILL_DIR" 2>/dev/null; then
        log "✓ 记忆文件恢复成功"
        test2_success=1
    else
        log "❌ 记忆文件恢复失败"
        test2_success=0
    fi
    
    # 生成报告
    local total_tests=2
    local success_count=$((test1_success + test2_success))
    local success_rate=$((success_count * 100 / total_tests))
    
    local report_file="$REPORT_DIR/restore-drill-$(date +%Y%m%d_%H%M%S).md"
    {
        echo "# 备份恢复演练报告"
        echo ""
        echo "**日期**: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "**备份**: $(basename "$latest_bundle")"
        echo ""
        echo "## 测试结果"
        echo ""
        echo "| 测试项 | 结果 |"
        echo "|--------|------|"
        echo "| 配置文件恢复 | $([ $test1_success -eq 1 ] && echo "✓ 通过" || echo "❌ 失败") |"
        echo "| 记忆文件恢复 | $([ $test2_success -eq 1 ] && echo "✓ 通过" || echo "❌ 失败") |"
        echo ""
        echo "## 成功率"
        echo ""
        echo "**$success_count/$total_tests** (${success_rate}%)"
        echo ""
        echo "## 下次演练"
        echo ""
        echo "**日期**: $(date -d "+1 month" +%Y-%m-%d)"
        echo ""
        echo "---"
        echo "*演练由 Backup Agent 自动执行*"
    } > "$report_file"
    
    log "✓ 演练报告已生成：$report_file"
    
    log "=========================================="
    log "Backup Agent 恢复演练完成"
    log "成功率：$success_count/$total_tests"
    log "=========================================="
    
    if [ $success_count -eq $total_tests ]; then
        log "✅ 所有测试通过"
    else
        log "⚠ 部分测试失败"
    fi
}

# 执行主函数
main "$@"