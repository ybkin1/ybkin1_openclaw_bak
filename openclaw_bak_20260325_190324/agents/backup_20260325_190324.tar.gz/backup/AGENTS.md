# backup Agent

## 职责

[待定义]

---

## 📚 共享配置引用

本 agent 遵循以下共享配置：

- `memory/config/gstack-design-patterns.md` - 工作流程和设计模式
- `memory/config/agent-thinking-principles.md` - 思考原则
- `memory/config/task-processing-workflow.md` - 任务处理流程

### 工作流程（强制遵循）

```
Think → Plan → Build → Review → Test → Ship → Reflect
```
