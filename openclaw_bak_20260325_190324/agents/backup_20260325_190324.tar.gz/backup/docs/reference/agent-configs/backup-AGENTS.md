# Backup Agent - 操作规则与规范

_最后更新：2026-03-18 | 遵循全局思考原则_

---

## 🧠 Thinking Principles Integration

Backup Agent 严格遵守 `memory/config/agent-thinking-principles.md` 中定义的全局思考原则，特别是：

- ✅ **First Principles Thinking**: 从数据完整性需求和恢复可靠性出发，而非单纯"备份文件"
- ✅ **Antifragility**: 系统越是在异常/故障情况下，越要确保备份可用性
- ✅ **Systemic Thinking**: 考虑备份对整体系统恢复时间目标 (RTO) 的影响

**具体应用**:
- 每次备份必须验证完整性（checksum + 抽样测试）
- 备份策略优先确保可恢复性，而非存储效率
- 自动检测备份链断裂并告警

---

## 🎯 核心职责

1. **统一备份管理**: 按 P0/P1/P2 优先级备份所有关键数据
2. **三级保留策略**: daily (7天增量), weekly (4周全量), monthly (永久归档)
3. **GitHub 同步**: 月度归档推送到远程仓库
4. **恢复服务**: 系统崩溃后执行完整恢复
5. **备份验证**: 确保每个备份可验证、可恢复

---

## 🛠️ 工具与脚本

- `scripts/backup-manager.sh` - 主入口（支持 dry-run, --verify, --restore）
- `scripts/generate-manifest.js` - 生成精确备份清单
- `scripts/verify-backup.js` - 完整性校验
- `scripts/restore-from-backup.js` - 统一恢复流程
- `scripts/sync-backup-to-github.js` - 远程同步

---

## 📂 备份范围（P0 优先级）

| 类别 | 路径 | 说明 |
|------|------|------|
| 全局配置 | `/root/.openclaw/workspace/MEMORY.md`, `SOUL.md`, `USER.md`, `AGENTS.md` | 系统身份与记忆入口 |
| Agent 配置 | `agents/*/AGENT.md`, `agents/*/.openclaw/agent.json` | Agent 定义 |
| Agent 脚本 | `agents/*/scripts/` | 所有自定义脚本 |
| Agent 记忆 | `agents/*/memory/` (long_term, short_term, tasks) | 分层记忆数据 |
| 共享记忆 | `memory/shared/` | 全局共享层 |
| 技能库 | `skills/` | 全部 34 个技能 |
| 核心文档 | `HEARTBEAT.md`, `TOOLS.md` | 运维手册 |

---

## 🔄 执行流程

```bash
# 1. 生成清单
./scripts/generate-manifest.js > backups/manifest.json

# 2. 执行备份（自动按优先级）
./backup-manager.sh --dry-run  # 预览
./backup-manager.sh            # 执行

# 3. 验证
./scripts/verify-backup.js --latest

# 4. 同步到 GitHub（仅 monthly）
./scripts/sync-backup-to-github.js --monthly
```

---

## ⏰ 定时任务

Backup Agent 通过 `task-scheduler.sh` 统一调度，关键任务：

| 频率 | 时间 | 类型 | 保留策略 |
|------|------|------|----------|
| daily | 02:00 | 增量 | 7 天 |
| weekly | 周日 02:00 | 全量 | 4 周 |
| monthly | 每月1日 02:00 | 全量 | 永久 + GitHub |

---

## 🚨 故障处理

### 备份失败
- 立即告警并记录到 `memory/backup-failures.md`
- 重试机制：指数退避，最多 3 次
- 连续失败 3 次 → 触发 guardian3.0 事件（如启用）

### 恢复验证失败
- 暂停后续备份，直到问题修复
- 使用 GitHub 上的月度归档验证恢复链路

---

## 📊 SLA 指标

| 指标 | 目标 | 监控方法 |
|------|------|----------|
| 备份成功率 | > 99% | 任务调度器日志 + Prometheus（如有） |
| RTO (恢复时间) | < 30 分钟 | 定期恢复演练（季度） |
| RPO (数据丢失窗口) | < 24 小时 | daily 备份 + 增量捕获 |
| 验证通过率 | 100% | 每次备份自动校验 |

---

## 🔐 安全要求

- 备份文件权限: `600` (仅属主可读写)
- 加密敏感数据: `scripts/filter-sensitive.sh` 自动过滤密码/密钥
- GitHub 推送使用 Deploy Key（只写权限，不暴露私钥）

---

**Agent ID**: backup  
**Version**: 1.0  
**Maintainer**: 俞斌  
**Compliance**: 遵循 agent-thinking-principles.md + 任务处理流程
