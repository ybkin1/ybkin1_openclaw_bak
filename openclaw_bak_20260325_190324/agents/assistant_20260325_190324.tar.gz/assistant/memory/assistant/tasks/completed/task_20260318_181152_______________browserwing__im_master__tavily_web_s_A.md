# 任务 - [协作] 这是一个复杂任务：需要安装 browserwing, im-master, tavily web search, vectormemory, feishu-tools, excel-magic, report-gen-ppt, code-assistent, git-auto-pr, bug-fix-suggest, multi-source-research, research-verify, awesome-openclaw 共13个第三方skill。要求：1) 调研可用性 2) 安装 3) 验证 4) 维护 skill registry 清单 5) 生成报告。任务需要 deep reasoning 和多步骤规划，请按协作模式处理。 (Assistant部分)

**创建时间**: 2026-03-18 18:11:52  
**任务ID**: task_20260318_181152_______________browserwing__im_master__tavily_web_s_A  
**来源**: master agent (智能路由)  
**独有标识**: 074207ee-91cd-402f-96c6-eb520f04d874

## 原始任务

**标题**: [协作] 这是一个复杂任务：需要安装 browserwing, im-master, tavily web search, vectormemory, feishu-tools, excel-magic, report-gen-ppt, code-assistent, git-auto-pr, bug-fix-suggest, multi-source-research, research-verify, awesome-openclaw 共13个第三方skill。要求：1) 调研可用性 2) 安装 3) 验证 4) 维护 skill registry 清单 5) 生成报告。任务需要 deep reasoning 和多步骤规划，请按协作模式处理。 (Assistant部分)  
**描述**: 协作任务 - Assistant 子任务\n\n**父任务**: 这是一个复杂任务：需要安装 browserwing, im-master, tavily web search, vectormemory, feishu-tools, excel-magic, report-gen-ppt, code-assistent, git-auto-pr, bug-fix-suggest, multi-source-research, research-verify, awesome-openclaw 共13个第三方skill。要求：1) 调研可用性 2) 安装 3) 验证 4) 维护 skill registry 清单 5) 生成报告。任务需要 deep reasoning 和多步骤规划，请按协作模式处理。\n\n**你的职责**:\n- 处理核心复杂逻辑\n\n**完整父任务描述**: 协作测试 - 批量安装技能

## 元数据
无附加元数据

## 协作信息\n- 类型: assistant_subtask\n- 父任务ID: task_20260318_181152_______________browserwing__im_master__tavily_web_s\n- 协作伙伴: master\n- 期望输出: 深度分析/核心产出
