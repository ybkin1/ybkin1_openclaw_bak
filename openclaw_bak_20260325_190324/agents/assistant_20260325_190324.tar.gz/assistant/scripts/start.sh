#!/bin/bash

# Assistant Agent Service Startup Script
# 启动助手 Agent 的任务监听和处理服务

# 配置
TASK_LISTENER="/root/.openclaw/workspace/agents/assistant/scripts/task-listener.sh"
HEARTBEAT_LOG="/root/.openclaw/workspace/agents/assistant/logs/service.log"
PID_FILE="/tmp/assistant-agent.pid"

# 确保日志目录存在
mkdir -p "$(dirname "$HEARTBEAT_LOG")"

# 日志函数
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$HEARTBEAT_LOG"
    echo "$1"
}

log_info() { log "INFO: $1"; }
log_error() { log "ERROR: $1"; }

# 检查是否已运行
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if ps -p "$OLD_PID" > /dev/null 2>&1; then
        log_info "Assistant Agent 已在运行 (PID: $OLD_PID)"
        exit 0
    else
        log_info "清理僵尸 PID 文件"
        rm -f "$PID_FILE"
    fi
fi

# 启动任务监听器（后台）
log_info "启动 Assistant Agent 任务监听器..."

# 执行监听器脚本（目前是单次扫描模式，可以扩展为守护进程）
bash "$TASK_LISTENER" &

# 记录 PID
LISTENER_PID=$!
echo "$LISTENER_PID" > "$PID_FILE"

log_info "Assistant Agent 已启动 (PID: $LISTENER_PID)"
log_info "监听器: $TASK_LISTENER"
log_info "任务目录: /root/.openclaw/workspace/agents/assistant/memory/assistant/tasks"

# 等待一下确保进程启动成功
sleep 1

if ps -p "$LISTENER_PID" > /dev/null 2>&1; then
    log_info "服务状态: 运行中"
    exit 0
else
    log_error "服务启动失败"
    rm -f "$PID_FILE"
    exit 1
fi