#!/bin/bash

# Assistant Agent Task Listener (Daemon Mode)
# 持续监听和处理来自 master agent 的复杂任务

# 配置
TASKS_DIR="/root/.openclaw/workspace/agents/assistant/memory/assistant/tasks"
PROCESSING_DIR="/root/.openclaw/workspace/agents/assistant/memory/assistant/tasks/processing"
COMPLETED_DIR="/root/.openclaw/workspace/agents/assistant/memory/assistant/tasks/completed"
FAILED_DIR="/root/.openclaw/workspace/agents/assistant/memory/assistant/tasks/failed"
HEARTBEAT_LOG="/root/.openclaw/workspace/agents/assistant/logs/task-listener.log"
CHECK_INTERVAL=30  # 检查间隔（秒）

# 确保目录存在
mkdir -p "$PROCESSING_DIR" "$COMPLETED_DIR" "$FAILED_DIR" "$(dirname "$HEARTBEAT_LOG")"

# 日志函数
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$HEARTBEAT_LOG"
    echo "$1"
}

log_info() { log "INFO: $1"; }
log_warn() { log "WARN: $1"; }
log_error() { log "ERROR: $1"; }

# 检查任务来源
validate_task_source() {
    local task_file="$1"
    # 检查任务文件是否来自 master agent
    if grep -q "来源.*master" "$task_file" 2>/dev/null; then
        return 0  # 有效来源
    else
        log_warn "任务来源验证失败: $task_file (非 master agent 创建)"
        return 1
    fi
}

# 处理单个任务
process_task() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .md)
    local processing_file="$PROCESSING_DIR/$task_id.md"

    log_info "开始处理任务: $task_id"

    # 1. 移动任务到处理中状态
    if ! mv "$task_file" "$processing_file" 2>/dev/null; then
        log_error "无法移动任务到处理状态: $task_file"
        return 1
    fi

    # 2. 提取任务信息
    local task_title=$(grep -E '^\*\*标题\*\*:' "$processing_file" 2>/dev/null | sed 's/^\*\*标题\*\*:\s*//' | head -1)
    local task_desc=$(grep -E '^\*\*描述\*\*:' "$processing_file" 2>/dev/null | sed 's/^\*\*描述\*\*:\s*//' | head -1)

    if [ -z "$task_title" ] || [ -z "$task_desc" ]; then
        log_error "任务格式不完整: $task_id"
        mv "$processing_file" "$FAILED_DIR/" 2>/dev/null
        return 1
    fi

    log_info "任务详情 - 标题: $task_title, 描述: $task_desc"

    # 3. 执行任务（根据任务内容选择处理方式）
    # 这里可以扩展：基于任务标题/描述的关键词路由到不同的处理函数

    local execution_result=0
    local result_summary="任务执行完成"

    # 示例：根据任务类型处理
    case "$task_title" in
        *"备份"*)
            log_info "识别为备份相关任务"
            # TODO: 调用备份处理逻辑
            result_summary="备份操作已执行（需要实现具体逻辑）"
            ;;
        *"分析"*)
            log_info "识别为分析相关任务"
            # TODO: 调用分析处理逻辑
            result_summary="分析任务已完成（需要实现具体逻辑）"
            ;;
        *"开发"*|*"工具"*)
            log_info "识别为开发相关任务"
            # TODO: 调用开发处理逻辑
            result_summary="开发任务已处理（需要实现具体逻辑）"
            ;;
        *)
            log_info "通用任务处理"
            result_summary="任务已按通用流程处理"
            ;;
    esac

    if [ $execution_result -eq 0 ]; then
        # 4. 创建结果报告
        local result_file="$COMPLETED_DIR/${task_id}_result.md"
        cat > "$result_file" <<EOF
# 任务执行结果

**任务ID**: $task_id  
**完成时间**: $(date '+%Y-%m-%d %H:%M:%S')  
**执行状态**: 成功

## 任务摘要
- 标题: $task_title
- 描述: $task_desc

## 执行摘要
$result_summary

## 系统信息
- 执行环境: Assistant Agent
- 处理时间: $(date '+%Y-%m-%d %H:%M:%S')
- 处理节点: $(hostname)

---
*此结果由 Assistant Agent 自动生成*
EOF

        # 5. 将结果返回给 master agent
        local results_queue="/tmp/agent_results.json"
        local temp_queue=$(mktemp)

        # 确保结果队列存在且格式正确
        if [ ! -f "$results_queue" ] || ! grep -q '"results"' "$results_queue" 2>/dev/null; then
            echo '{"results":[]}' > "$results_queue"
        fi

        # 添加新结果到队列
        local result_json=$(jq -n \
            --arg task_id "$task_id" \
            --arg title "$task_title" \
            --arg description "$task_desc" \
            --arg summary "$result_summary" \
            --arg timestamp "$(date -Iseconds)" \
            '{
                task_id: $task_id,
                title: $title,
                description: $description,
                summary: $summary,
                completed_at: $timestamp,
                status: "success"
            }')

        # 使用 jq 安全地更新队列
        if command -v jq &>/dev/null; then
            if jq ".results += [$result_json]" "$results_queue" > "$temp_queue" 2>/dev/null; then
                mv "$temp_queue" "$results_queue"
                log_info "结果已返回给 master agent (队列: $results_queue)"
            else
                log_error "jq 更新失败，结果队列可能损坏"
                cat "$temp_queue" > "$results_queue" 2>/dev/null || true
            fi
        else
            log_warn "jq 不可用，无法更新结果队列"
        fi

        log_info "任务完成: $task_id"
        mv "$processing_file" "$COMPLETED_DIR/" 2>/dev/null
    else
        log_error "任务执行失败: $task_id"
        mv "$processing_file" "$FAILED_DIR/" 2>/dev/null
    fi
}

# 信号处理
trap 'log_info "收到终止信号，退出监听"; exit 0' TERM INT

log_info "任务监听器启动，监控目录: $TASKS_DIR"
log_info "检查间隔: ${CHECK_INTERVAL}秒"

# 主循环
while true; do
    # 扫描任务目录中的新任务（仅处理 task_*.md 文件）
    while IFS= read -r task_file; do
        # 跳过非文件
        [ -f "$task_file" ] || continue

        # 验证任务来源
        if ! validate_task_source "$task_file"; then
            log_warn "跳过非法任务: $task_file"
            # 移动非法任务到失败目录
            mv "$task_file" "$FAILED_DIR/" 2>/dev/null
            continue
        fi

        # 处理任务（串行处理，避免资源争用）
        process_task "$task_file"
    done < <(find "$TASKS_DIR" -maxdepth 1 -name "task_*.md" -type f 2>/dev/null | sort)

    # 等待下一次检查
    sleep $CHECK_INTERVAL
done