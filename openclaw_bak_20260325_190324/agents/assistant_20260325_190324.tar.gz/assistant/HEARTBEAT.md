# Assistant Agent Heartbeat

## Task Monitoring
- Monitor long-running tasks (>30 minutes)
- Report progress every 10 minutes for active tasks
- Check resource usage (CPU/Memory) and alert if >80%

## Status Reporting
- Generate daily summary of completed complex tasks
- Report any failed task executions with error details
- Track model usage statistics for optimization

## Cleanup Tasks
- Remove temporary files older than 24 hours
- Clean up completed task results after 7 days
- Archive successful task patterns to long-term memory