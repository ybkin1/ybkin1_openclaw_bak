# Backup Agent - 完整能力定义

**版本**: 2.0 (开发备份能力增强版)  
**生效日期**: 2026-03-26  
**适用范围**: 系统备份 + 代码版本管理 + 状态持久化

---

## 🎯 核心能力矩阵

| 能力域 | 能力项 | 状态 | 说明 |
|--------|--------|------|------|
| **系统备份** | 完整备份 | ✅ 已有 | backup-manager.sh |
| | GitHub 同步 | ✅ 已有 | 自动推送 |
| | 恢复验证 | ✅ 已有 | 恢复演练 |
| **代码版本管理** | Git 高频提交 | 🆕 新增 | 每 30 分钟提交 |
| | 分支管理 | 🆕 新增 | feature/main 分支 |
| | 标签管理 | 🆕 新增 | Milestone 标签 |
| **状态持久化** | 任务状态备份 | 🆕 新增 | 每 Task 完成备份 |
| | 会话检查点备份 | 🆕 新增 | 每 Task 完成备份 |
| | 配置版本控制 | 🆕 新增 | openclaw.json 版本追踪 |

---

## 🔧 新增能力详细说明

### 能力 4: 代码版本管理 (Code Version Control)

#### Git 高频提交

**提交频率**:
- 时间维度：每 30 分钟提交
- 代码维度：每 100 行提交
- 功能维度：每完成 1 个测试提交

**提交模板**:
```bash
git commit -m "feat: [task_id] 功能简述

- 实现：具体实现内容
- 测试：添加 X 个测试用例
- 审查：待 Spec Review + Quality Review

Co-Authored-By: {agent_type} Agent"
```

**分支策略**:
```
main (保护分支)
    ↑
develop (开发分支)
    ↑
feature/{milestone}/{task} (功能分支)
```

#### 标签管理

**标签命名**:
```
milestone-{N}           # Milestone 完成标签
milestone-{N}-slice-{M} # Slice 完成标签
```

**打标签时机**:
- Milestone 完成并通过验收
- 所有测试通过
- 代码审查通过

---

### 能力 5: 状态持久化 (State Persistence)

#### 任务状态备份

**备份内容**:
```
/root/.openclaw/workspace/agents/master/memory/tasks/active/
├── task_{task_id}.json
├── current_milestone.md
├── current_slice.md
├── current_task.md
└── session_checkpoint.json
```

**备份频率**: 每 Task 完成

**备份位置**:
```
/root/.openclaw/backups-unified/
└── dev-state/
    └── YYYY-MM-DD/
        └── task_state_{timestamp}.tar.gz
```

#### 会话检查点备份

**检查点内容**:
```json
{
  "session_id": "session_123",
  "timestamp": "ISO8601",
  "context_summary": "正在执行 Task X.Y.Z - 任务简述",
  "files_modified": ["file1.py", "file2.py"],
  "tests_written": ["test_1", "test_2"],
  "next_step": "继续实现函数 foo()"
}
```

**恢复流程**:
```python
def restore_session(checkpoint_file):
    """
    恢复会话
    """
    # 1. 读取检查点
    checkpoint = load_checkpoint(checkpoint_file)
    
    # 2. 恢复文件状态
    for file_path in checkpoint['files_modified']:
        restore_file_from_backup(file_path)
    
    # 3. 恢复会话上下文
    context = checkpoint['context_summary']
    
    return {
        'status': 'restored',
        'next_action': checkpoint['next_step']
    }
```

---

### 能力 6: 配置版本控制 (Configuration Version Control)

#### 配置追踪

**追踪内容**:
| 配置文件 | 变更频率 | 版本策略 |
|---------|---------|---------|
| openclaw.json | 低 | 每次变更打标签 |
| agent.json | 中 | 每次变更提交 |
| AGENT_RULES.md | 低 | 每次变更提交 |

**版本标签**:
```
config-{config_name}-v{version}
示例：config-openclaw-v1.2
```

#### 配置回滚

**回滚命令**:
```bash
# 回滚 openclaw.json 到指定版本
git checkout <commit_hash> -- openclaw.json

# 验证配置
openclaw doctor

# 重启 Gateway
systemctl --user restart openclaw-gateway
```

---

## 🛠️ 工具接口

### Git 提交工具

```python
def auto_commit_changes(task_id, changes_summary, agent_type):
    """
    自动提交代码变更
    
    Args:
        task_id: 任务 ID
        changes_summary: 变更摘要
        agent_type: Agent 类型
    
    Returns:
        commit_hash: Git 提交哈希
    """
    # 1. 添加文件
    run_command("git add -A")
    
    # 2. 生成提交信息
    commit_message = f"feat: [{task_id}] {changes_summary['brief']}\n\n"
    commit_message += f"- 实现：{changes_summary['details']}\n"
    commit_message += f"- 测试：{changes_summary['tests']}\n"
    commit_message += f"- 审查：待 Spec Review + Quality Review\n"
    commit_message += f"\nCo-Authored-By: {agent_type} Agent"
    
    # 3. 提交
    run_command(f"git commit -m '{commit_message}'")
    
    # 4. 获取提交哈希
    commit_hash = run_command("git rev-parse HEAD").strip()
    
    return commit_hash
```

### 状态备份工具

```python
def backup_task_state():
    """
    备份任务状态
    """
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # 1. 创建备份目录
    backup_dir = f"/root/.openclaw/backups-unified/dev-state/{datetime.now().strftime('%Y-%m-%d')}"
    os.makedirs(backup_dir, exist_ok=True)
    
    # 2. 打包状态文件
    state_files = [
        "/root/.openclaw/workspace/agents/master/memory/tasks/active/"
    ]
    
    tarball = f"{backup_dir}/task_state_{timestamp}.tar.gz"
    run_command(f"tar -czf {tarball} {' '.join(state_files)}")
    
    # 3. 清理旧备份 (保留 7 天)
    cleanup_old_backups(backup_dir, keep_days=7)
    
    return tarball
```

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 新增能力定义完成
