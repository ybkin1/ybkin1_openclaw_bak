# Backup Agent - 行为规范

**版本**: 1.0  
**生效日期**: 2026-03-26  
**适用范围**: 开发备份与版本管理

---

## 🔧 开发备份规范

### Git 提交规则

```
提交频率:
- 时间：每 30 分钟提交一次
- 代码：每 100 行提交一次
- 功能：每完成 1 个测试提交一次

提交信息格式:
feat: [task_id] 功能简述

- 实现：具体实现内容
- 测试：添加 X 个测试用例
- 审查：待 Spec Review + Quality Review

Co-Authored-By: {agent_type} Agent
```

### 分支管理规则

```
分支策略:
- main: 保护分支，仅接受 merge request
- develop: 开发分支，日常开发基于此分支
- feature/{milestone}/{task}: 功能分支，每个 Task 一个分支

合并规则:
- feature → develop: Task 完成后合并
- develop → main: Milestone 完成后合并
```

### 标签管理规则

```
标签命名:
- milestone-{N}: Milestone 完成标签
- milestone-{N}-slice-{M}: Slice 完成标签
- config-{config_name}-v{version}: 配置版本标签

打标签时机:
- Milestone 完成并通过验收
- 所有测试通过
- 代码审查通过
```

---

## 🔧 状态持久化规范

### 备份频率

```
持久化频率:
- 任务状态：每 Task 完成
- 会话检查点：每 Task 完成
- 配置变更：每次变更后

持久化位置:
- /root/.openclaw/backups-unified/dev-state/YYYY-MM-DD/
```

### 备份验证

```
验证频率:
- 每日：验证当日备份完整性
- 每周：验证恢复流程

验证方法:
- checksum 验证
- 恢复演练 (每周一次)
```

---

## 🔧 配置版本控制规范

### 配置追踪

```
追踪内容:
- openclaw.json: 每次变更打标签
- agent.json: 每次变更提交
- AGENT_RULES.md: 每次变更提交

版本标签:
- config-{config_name}-v{version}
```

### 配置回滚

```
回滚流程:
1. git checkout <commit_hash> -- <config_file>
2. openclaw doctor (验证配置)
3. systemctl --user restart openclaw-gateway

回滚审批:
- 配置回滚需 Master Agent 审批
```

---

## 📊 备份报告模板

```markdown
# 备份报告

**备份时间**: {timestamp}  
**备份类型**: {full|incremental|dev-state}  
**备份大小**: {size}

## 备份内容
- [ ] 代码提交
- [ ] 任务状态
- [ ] 会话检查点
- [ ] 配置文件

## 验证结果
- [ ] checksum 验证通过
- [ ] 恢复演练通过

## 下次备份
- 时间：{next_backup_time}
- 类型：{next_backup_type}
```

---

**最后更新**: 2026-03-26  
**维护者**: Master Agent  
**状态**: ✅ 新增规范定义完成
