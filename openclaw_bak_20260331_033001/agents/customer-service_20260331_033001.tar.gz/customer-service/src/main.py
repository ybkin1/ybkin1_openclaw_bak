"""
Customer Service Agent 主程序

集成权限管理器，实现安全权限隔离
"""

import sys
import os
sys.path.insert(0, '/root/.openclaw/workspace/agents/master')

from src.security.permission_manager import PermissionManager, User
from src.security.rbac import Permission, Role
from src.security.trust_level import TrustLevel, get_trust_level_from_wecom_user_type
from src.security.audit_logger import audit_logger
from typing import Dict, Any, Optional
import json


class CustomerServiceAgent:
    """智能客服 Agent"""
    
    def __init__(self):
        self.permission_manager = PermissionManager()
        self.user_sessions: Dict[str, Dict] = {}  # 用户会话管理
    
    def handle_user_request(
        self,
        user_id: str,
        request: Dict[str, Any],
        user_type: str = 'employee'  # admin/manager/employee/guest
    ) -> Dict[str, Any]:
        """
        处理企业微信用户请求
        
        流程:
        1. 识别用户信任等级
        2. 检查用户权限
        3. 执行请求或申请临时权限
        4. 记录审计日志
        """
        
        # 1. 识别用户信任等级
        trust_level = get_trust_level_from_wecom_user_type(user_type)
        user = User(id=user_id, wecom_user_type=user_type, trust_level=trust_level)
        
        # 记录用户会话 (按等级隔离)
        self._init_user_session(user_id, trust_level)
        
        # 2. 解析请求
        action = request.get('action')
        required_permission = self._get_required_permission(action)
        
        # 记录审计日志
        audit_logger.log_wecom_message(
            user_id=user_id,
            message_type='request',
            content_length=len(json.dumps(request)),
            trust_level=trust_level.value
        )
        
        # 3. 检查权限
        permission_result = self.permission_manager.check_permission(
            user=user,
            permission=required_permission
        )
        
        # 记录权限检查日志
        audit_logger.log_permission_check(
            user_id=user_id,
            permission=required_permission.value,
            allowed=permission_result.allowed,
            reason=permission_result.reason
        )
        
        if permission_result.allowed:
            # 4a. 权限充足，执行请求
            result = await self._execute_request(user, action, request)
            return {
                'success': True,
                'data': result,
                'message': '请求执行成功'
            }
        
        elif permission_result.requires_approval:
            # 4b. 需要申请临时权限
            temp_result = self.permission_manager.grant_temporary_permission(
                user=user,
                permission=required_permission,
                duration_seconds=3600,  # 默认 1 小时
                granted_by='auto_approved'  # L2+ 自动审批
            )
            
            if temp_result.allowed:
                # 临时权限已授予，执行请求
                result = await self._execute_request(user, action, request)
                return {
                    'success': True,
                    'data': result,
                    'message': f'临时权限已授予，有效期 1 小时',
                    'temporary': True
                }
            else:
                # 临时权限申请失败
                return {
                    'success': False,
                    'error': '权限申请失败',
                    'message': temp_result.reason
                }
        
        else:
            # 4c. 权限不足，拒绝请求
            return {
                'success': False,
                'error': 'permission_denied',
                'message': permission_result.reason
            }
    
    def _init_user_session(self, user_id: str, trust_level: TrustLevel):
        """初始化用户会话 (按等级隔离)"""
        if user_id not in self.user_sessions:
            self.user_sessions[user_id] = {
                'user_id': user_id,
                'trust_level': trust_level.value,
                'created_at': self._get_timestamp(),
                'requests': [],
                'memory_path': f'/root/.openclaw/workspace/agents/customer-service/memory/sessions/{trust_level.value}/{user_id}.json'
            }
    
    def _get_required_permission(self, action: str) -> Permission:
        """根据动作获取所需权限"""
        action_permission_map = {
            'create_ticket': Permission.TICKET_CREATE,
            'view_ticket': Permission.TICKET_VIEW,
            'close_ticket': Permission.TICKET_CLOSE,
            'view_report': Permission.REPORT_VIEW,
            'call_assistant': Permission.AGENT_CALL_ASSISTANT,
            'call_analysis': Permission.AGENT_CALL_ANALYSIS,
            'call_file': Permission.AGENT_CALL_FILE,
            'call_database': Permission.AGENT_CALL_DATABASE,
            'process_file': Permission.FILE_PROCESS,
            'query_data': Permission.DATA_QUERY,
            'send_message': Permission.WECOM_MESSAGE,
        }
        return action_permission_map.get(action, Permission.TICKET_VIEW)
    
    async def _execute_request(
        self,
        user: User,
        action: str,
        request: Dict[str, Any]
    ) -> Any:
        """执行用户请求"""
        
        # 记录请求到会话
        self.user_sessions[user.id]['requests'].append({
            'action': action,
            'timestamp': self._get_timestamp(),
            'request': request
        })
        
        # 根据动作执行不同逻辑
        if action == 'create_ticket':
            return await self._create_ticket(user, request)
        elif action == 'view_ticket':
            return await self._view_ticket(user, request)
        elif action == 'call_analysis':
            return await self._call_analysis_agent(user, request)
        elif action == 'call_file':
            return await self._call_file_agent(user, request)
        elif action == 'call_database':
            return await self._call_database_agent(user, request)
        elif action == 'query_data':
            return await self._query_data(user, request)
        else:
            return {'message': f'动作 {action} 已执行'}
    
    async def _create_ticket(self, user: User, request: Dict) -> Dict:
        """创建工单"""
        ticket = {
            'ticket_id': self._generate_ticket_id(),
            'user_id': user.id,
            'status': 'open',
            'created_at': self._get_timestamp(),
            'content': request.get('content', '')
        }
        
        # 记录审计日志
        audit_logger.log(
            event_type='ticket_create',
            user_id=user.id,
            action='create_ticket',
            result='success',
            details=ticket
        )
        
        return ticket
    
    async def _view_ticket(self, user: User, request: Dict) -> Dict:
        """查看工单"""
        ticket_id = request.get('ticket_id')
        return {
            'ticket_id': ticket_id,
            'status': 'open',
            'content': '工单内容示例'
        }
    
    async def _call_analysis_agent(self, user: User, request: Dict) -> Dict:
        """调用故障分析 Agent"""
        # 记录 Agent 调用日志
        audit_logger.log_agent_call(
            caller_id='customer-service',
            callee_id='analysis',
            user_id=user.id,
            task_type='fault_analysis',
            success=True,
            duration_ms=1500
        )
        
        return {
            'agent': 'analysis',
            'result': '故障分析结果示例',
            'suggestions': ['建议检查网络连接', '建议重启服务器']
        }
    
    async def _call_file_agent(self, user: User, request: Dict) -> Dict:
        """调用文件处理 Agent"""
        audit_logger.log_agent_call(
            caller_id='customer-service',
            callee_id='file-processor',
            user_id=user.id,
            task_type='file_process',
            success=True,
            duration_ms=800
        )
        
        return {
            'agent': 'file-processor',
            'result': '文件处理完成',
            'file_path': '/tmp/processed_file.txt'
        }
    
    async def _call_database_agent(self, user: User, request: Dict) -> Dict:
        """调用数据库 Agent"""
        audit_logger.log_agent_call(
            caller_id='customer-service',
            callee_id='database-manager',
            user_id=user.id,
            task_type='data_query',
            success=True,
            duration_ms=500
        )
        
        return {
            'agent': 'database-manager',
            'result': '查询结果',
            'data': [{'id': 1, 'name': '示例数据'}]
        }
    
    async def _query_data(self, user: User, request: Dict) -> Dict:
        """查询数据"""
        # 记录数据访问日志
        audit_logger.log_data_access(
            user_id=user.id,
            data_type='query_result',
            sensitivity_level='P1',
            action='query',
            desensitized=False
        )
        
        return {
            'data': [{'id': 1, 'name': '示例数据'}],
            'count': 1
        }
    
    def _generate_ticket_id(self) -> str:
        """生成工单 ID"""
        import datetime
        return f"TKT-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    def _get_timestamp(self) -> str:
        """获取时间戳"""
        import datetime
        return datetime.datetime.now().isoformat()
    
    def save_user_session(self, user_id: str):
        """保存用户会话"""
        if user_id in self.user_sessions:
            session = self.user_sessions[user_id]
            os.makedirs(os.path.dirname(session['memory_path']), exist_ok=True)
            with open(session['memory_path'], 'w', encoding='utf-8') as f:
                json.dump(session, f, ensure_ascii=False, indent=2)


# 全局 Customer Service Agent 实例
customer_service_agent = CustomerServiceAgent()


# 测试入口
if __name__ == '__main__':
    import asyncio
    
    async def test():
        agent = CustomerServiceAgent()
        
        # 测试 1: 内部员工创建工单
        result = await agent.handle_user_request(
            user_id='user123',
            user_type='employee',
            request={
                'action': 'create_ticket',
                'content': '服务器故障报告'
            }
        )
        print("测试 1 - 创建工单:", json.dumps(result, ensure_ascii=False, indent=2))
        
        # 测试 2: 内部员工查询数据
        result = await agent.handle_user_request(
            user_id='user123',
            user_type='employee',
            request={
                'action': 'query_data',
                'query': 'SELECT * FROM tickets'
            }
        )
        print("测试 2 - 查询数据:", json.dumps(result, ensure_ascii=False, indent=2))
        
        # 测试 3: 内部员工调用故障分析
        result = await agent.handle_user_request(
            user_id='user123',
            user_type='employee',
            request={
                'action': 'call_analysis',
                'server_id': 'server-001',
                'error': 'GPU 故障'
            }
        )
        print("测试 3 - 调用故障分析:", json.dumps(result, ensure_ascii=False, indent=2))
        
        # 保存会话
        agent.save_user_session('user123')
        print("\n✅ 所有测试完成！")
    
    asyncio.run(test())
