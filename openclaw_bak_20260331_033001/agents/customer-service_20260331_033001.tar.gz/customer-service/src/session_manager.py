"""
用户会话记忆管理

按信任等级隔离用户会话记忆
"""

import sys
sys.path.insert(0, '/root/.openclaw/workspace/agents/master')

import os
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path

from security.trust_level import TrustLevel


class UserSessionManager:
    """用户会话管理器"""
    
    def __init__(self, base_dir: Optional[str] = None):
        if base_dir is None:
            base_dir = '/root/.openclaw/workspace/agents/customer-service/memory/sessions'
        
        self.base_dir = Path(base_dir)
        # 按信任等级分目录
        self.sessions_dirs = {
            TrustLevel.L0: self.base_dir / 'l0_untrusted',
            TrustLevel.L1: self.base_dir / 'l1_low',
            TrustLevel.L2: self.base_dir / 'l2_medium',
            TrustLevel.L3: self.base_dir / 'l3_high',
            TrustLevel.L4: self.base_dir / 'l4_full'
        }
        
        # 创建目录
        for dir_path in self.sessions_dirs.values():
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # 内存缓存
        self.sessions: Dict[str, Dict] = {}
    
    def create_session(
        self,
        user_id: str,
        trust_level: TrustLevel,
        user_info: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """创建用户会话"""
        
        session = {
            'user_id': user_id,
            'trust_level': trust_level.value,
            'created_at': self._get_timestamp(),
            'updated_at': self._get_timestamp(),
            'user_info': user_info or {},
            'requests': [],
            'permissions_used': [],
            'temporary_permissions': [],
            'metadata': {
                'total_requests': 0,
                'last_active': self._get_timestamp()
            }
        }
        
        # 保存到内存
        self.sessions[user_id] = session
        
        # 保存到文件
        self._save_session(session, trust_level)
        
        return session
    
    def get_session(self, user_id: str) -> Optional[Dict[str, Any]]:
        """获取用户会话"""
        
        # 先查内存
        if user_id in self.sessions:
            return self.sessions[user_id]
        
        # 再查文件 (遍历所有等级目录)
        for trust_level, dir_path in self.sessions_dirs.items():
            session_file = dir_path / f"{user_id}.json"
            if session_file.exists():
                with open(session_file, 'r', encoding='utf-8') as f:
                    session = json.load(f)
                    self.sessions[user_id] = session
                    return session
        
        return None
    
    def add_request(
        self,
        user_id: str,
        request_data: Dict[str, Any]
    ) -> bool:
        """添加请求记录"""
        
        session = self.get_session(user_id)
        if not session:
            return False
        
        # 添加请求
        request_record = {
            'timestamp': self._get_timestamp(),
            'action': request_data.get('action'),
            'permission': request_data.get('permission'),
            'result': request_data.get('result'),
            'duration_ms': request_data.get('duration_ms')
        }
        
        session['requests'].append(request_record)
        session['updated_at'] = self._get_timestamp()
        session['metadata']['total_requests'] += 1
        session['metadata']['last_active'] = self._get_timestamp()
        
        # 保存
        trust_level = TrustLevel(session['trust_level'])
        self._save_session(session, trust_level)
        
        return True
    
    def add_permission_usage(
        self,
        user_id: str,
        permission: str,
        granted_by: str = 'rbac'
    ) -> bool:
        """记录权限使用"""
        
        session = self.get_session(user_id)
        if not session:
            return False
        
        usage_record = {
            'permission': permission,
            'granted_by': granted_by,
            'timestamp': self._get_timestamp()
        }
        
        session['permissions_used'].append(usage_record)
        self._save_session(session, TrustLevel(session['trust_level']))
        
        return True
    
    def add_temporary_permission(
        self,
        user_id: str,
        permission: str,
        duration_seconds: int,
        granted_by: str,
        expires_at: str
    ) -> bool:
        """记录临时权限"""
        
        session = self.get_session(user_id)
        if not session:
            return False
        
        temp_perm_record = {
            'permission': permission,
            'duration_seconds': duration_seconds,
            'granted_by': granted_by,
            'granted_at': self._get_timestamp(),
            'expires_at': expires_at,
            'status': 'active'
        }
        
        session['temporary_permissions'].append(temp_perm_record)
        self._save_session(session, TrustLevel(session['trust_level']))
        
        return True
    
    def get_user_history(
        self,
        user_id: str,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """获取用户历史请求"""
        
        session = self.get_session(user_id)
        if not session:
            return []
        
        requests = session.get('requests', [])
        return requests[-limit:]
    
    def cleanup_old_sessions(self, days: int = 30):
        """清理旧会话"""
        
        from datetime import timedelta
        
        cutoff = datetime.now() - timedelta(days=days)
        
        for trust_level, dir_path in self.sessions_dirs.items():
            for session_file in dir_path.glob('*.json'):
                try:
                    with open(session_file, 'r', encoding='utf-8') as f:
                        session = json.load(f)
                    
                    created_at = datetime.fromisoformat(session['created_at'])
                    if created_at < cutoff:
                        # 归档而不是删除
                        archive_dir = self.base_dir / 'archived'
                        archive_dir.mkdir(exist_ok=True)
                        
                        # 移动到归档
                        session['archived_at'] = self._get_timestamp()
                        session['archive_reason'] = f'超过{days}天未活动'
                        
                        archive_file = archive_dir / session_file.name
                        with open(archive_file, 'w', encoding='utf-8') as f:
                            json.dump(session, f, ensure_ascii=False, indent=2)
                        
                        session_file.unlink()
                
                except Exception as e:
                    print(f"清理会话失败 {session_file}: {e}")
    
    def _save_session(self, session: Dict[str, Any], trust_level: TrustLevel):
        """保存会话到文件"""
        
        dir_path = self.sessions_dirs[trust_level]
        session_file = dir_path / f"{session['user_id']}.json"
        
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session, f, ensure_ascii=False, indent=2)
    
    def _get_timestamp(self) -> str:
        """获取时间戳"""
        return datetime.now().isoformat()


# 全局用户会话管理器实例
user_session_manager = UserSessionManager()


# 测试入口
if __name__ == '__main__':
    manager = UserSessionManager()
    
    # 测试 1: 创建会话 (L2 用户)
    session = manager.create_session(
        user_id='user123',
        trust_level=TrustLevel.L2,
        user_info={'name': '张三', 'department': '运维部'}
    )
    print("测试 1 - 创建会话:", json.dumps(session, ensure_ascii=False, indent=2))
    
    # 测试 2: 添加请求记录
    manager.add_request(
        user_id='user123',
        request_data={
            'action': 'create_ticket',
            'permission': 'ticket:create',
            'result': 'success',
            'duration_ms': 150
        }
    )
    print("\n✅ 测试 2 - 添加请求记录完成")
    
    # 测试 3: 记录权限使用
    manager.add_permission_usage(
        user_id='user123',
        permission='ticket:create',
        granted_by='rbac'
    )
    print("✅ 测试 3 - 记录权限使用完成")
    
    # 测试 4: 记录临时权限
    from datetime import timedelta
    expires_at = (datetime.now() + timedelta(hours=1)).isoformat()
    manager.add_temporary_permission(
        user_id='user123',
        permission='data:export',
        duration_seconds=3600,
        granted_by='manager456',
        expires_at=expires_at
    )
    print("✅ 测试 4 - 记录临时权限完成")
    
    # 测试 5: 获取用户历史
    history = manager.get_user_history('user123', limit=10)
    print("\n测试 5 - 用户历史:", json.dumps(history, ensure_ascii=False, indent=2))
    
    print("\n✅ 所有测试完成！")
