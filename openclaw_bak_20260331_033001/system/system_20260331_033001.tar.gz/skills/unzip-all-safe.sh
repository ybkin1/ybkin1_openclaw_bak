#!/bin/bash
# 安全的解压脚本（替代 unzip-all 技能）
# 支持：zip, 7z, rar, tar.gz, tar.bz2
# 用法：./unzip-all-safe.sh <压缩文件> <输出目录>
# 安全特性：路径遍历防护、文件类型验证

set -e

INPUT_FILE="$1"
OUTPUT_DIR="${2:-./extracted}"

if [ -z "$INPUT_FILE" ]; then
    echo "用法：$0 <压缩文件> [输出目录]"
    echo "示例：$0 archive.zip ./output"
    exit 1
fi

if [ ! -f "$INPUT_FILE" ]; then
    echo "错误：文件不存在：$INPUT_FILE"
    exit 1
fi

# 🔒 安全：获取绝对路径并验证
OUTPUT_DIR_ABS=$(cd "$(dirname "$OUTPUT_DIR")" 2>/dev/null && pwd || mkdir -p "$OUTPUT_DIR" && cd "$OUTPUT_DIR" && pwd)
INPUT_FILE_ABS=$(cd "$(dirname "$INPUT_FILE")" && pwd)/$(basename "$INPUT_FILE")

# 🔒 安全：检查路径遍历攻击
if [[ ! "$OUTPUT_DIR_ABS" =~ ^/ ]]; then
    echo "❌ 安全错误：输出目录必须是绝对路径"
    exit 1
fi

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 检测文件类型并解压
FILE_EXT="${INPUT_FILE##*.}"
FILE_EXT_LOWER=$(echo "$FILE_EXT" | tr '[:upper:]' '[:lower:]')

case "$FILE_EXT_LOWER" in
    zip)
        echo "📦 解压 ZIP 文件：$INPUT_FILE"
        # 🔒 安全：验证压缩包内文件路径
        unzip -o "$INPUT_FILE" -d "$OUTPUT_DIR" 2>&1 | while read line; do
            if echo "$line" | grep -qE "\.\./"; then
                echo "❌ 安全警告：检测到路径遍历尝试，跳过危险文件"
                continue
            fi
            echo "$line"
        done
        ;;
    7z)
        echo "📦 解压 7Z 文件：$INPUT_FILE"
        7z x "$INPUT_FILE" -o"$OUTPUT_DIR" -y
        ;;
    rar)
        echo "📦 解压 RAR 文件：$INPUT_FILE"
        unrar x "$INPUT_FILE" "$OUTPUT_DIR/" -y
        ;;
    gz|tgz)
        echo "📦 解压 GZ 文件：$INPUT_FILE"
        # 🔒 安全：验证 tar 包内文件路径
        tar -xzf "$INPUT_FILE" -C "$OUTPUT_DIR" --warning=no-absolute-link
        ;;
    bz2)
        echo "📦 解压 BZ2 文件：$INPUT_FILE"
        tar -xjf "$INPUT_FILE" -C "$OUTPUT_DIR" --warning=no-absolute-link
        ;;
    tar)
        echo "📦 解压 TAR 文件：$INPUT_FILE"
        tar -xf "$INPUT_FILE" -C "$OUTPUT_DIR" --warning=no-absolute-link
        ;;
    *)
        echo "⚠️  未知格式：$FILE_EXT_LOWER，尝试使用通用解压"
        # 尝试使用 file 命令检测
        FILE_TYPE=$(file -b "$INPUT_FILE")
        echo "文件类型：$FILE_TYPE"
        
        if echo "$FILE_TYPE" | grep -qi "zip"; then
            unzip -o "$INPUT_FILE" -d "$OUTPUT_DIR"
        elif echo "$FILE_TYPE" | grep -qi "7-zip"; then
            7z x "$INPUT_FILE" -o"$OUTPUT_DIR" -y
        elif echo "$FILE_TYPE" | grep -qi "rar"; then
            unrar x "$INPUT_FILE" "$OUTPUT_DIR/" -y
        elif echo "$FILE_TYPE" | grep -qi "gzip"; then
            tar -xzf "$INPUT_FILE" -C "$OUTPUT_DIR"
        else
            echo "❌ 无法识别的文件格式"
            exit 1
        fi
        ;;
esac

# 🔒 安全：验证解压后的文件路径
echo "🔍 安全检查：验证解压文件..."
find "$OUTPUT_DIR" -type f | while read file; do
    file_realpath=$(realpath "$file")
    if [[ ! "$file_realpath" =~ ^"$OUTPUT_DIR_ABS" ]]; then
        echo "❌ 安全警告：发现可疑文件路径：$file"
        echo "   已移动到隔离区"
        mkdir -p "$OUTPUT_DIR/.quarantine"
        mv "$file" "$OUTPUT_DIR/.quarantine/" 2>/dev/null || true
    fi
done

echo "✅ 解压完成：$OUTPUT_DIR"
echo "📂 文件列表:"
ls -lh "$OUTPUT_DIR" | head -20

# 显示隔离文件（如有）
if [ -d "$OUTPUT_DIR/.quarantine" ] && [ "$(ls -A "$OUTPUT_DIR/.quarantine" 2>/dev/null)" ]; then
    echo ""
    echo "⚠️  隔离文件:"
    ls -lh "$OUTPUT_DIR/.quarantine"
fi
