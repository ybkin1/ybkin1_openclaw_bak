#!/usr/bin/env python3
"""
OpenClaw System Guardian - Skill Integrity Check

Performs robust integrity verification of skills without full functional testing.
Validates skill structure, essential files, and growth data preservation.
"""

import os
import json
import yaml
from pathlib import Path
from datetime import datetime

class SkillIntegrityChecker:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.skills_dir = self.workspace / "skills"
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "skills_checked": 0,
            "skills_valid": 0,
            "skills_invalid": 0,
            "details": {}
        }
    
    def check_all_skills(self):
        """Check integrity of all installed skills"""
        if not self.skills_dir.exists():
            self.results["error"] = "Skills directory not found"
            return self.results
        
        skill_dirs = [d for d in self.skills_dir.iterdir() if d.is_dir()]
        self.results["skills_checked"] = len(skill_dirs)
        
        for skill_dir in skill_dirs:
            skill_name = skill_dir.name
            skill_result = self._check_single_skill(skill_dir)
            self.results["details"][skill_name] = skill_result
            
            if skill_result["valid"]:
                self.results["skills_valid"] += 1
            else:
                self.results["skills_invalid"] += 1
        
        return self.results
    
    def _check_single_skill(self, skill_dir):
        """Check integrity of a single skill"""
        result = {
            "valid": False,
            "errors": [],
            "warnings": [],
            "structure": {},
            "growth_data": {}
        }
        
        # Check SKILL.md exists and is valid
        skill_md = skill_dir / "SKILL.md"
        if not skill_md.exists():
            result["errors"].append("SKILL.md missing")
            return result
        
        # Validate SKILL.md structure
        skill_md_content = skill_md.read_text()
        frontmatter, body = self._parse_skill_md(skill_md_content)
        
        if not frontmatter:
            result["errors"].append("SKILL.md frontmatter invalid")
        else:
            # Check required frontmatter fields
            if "name" not in frontmatter:
                result["errors"].append("SKILL.md missing 'name' field")
            if "description" not in frontmatter:
                result["errors"].append("SKILL.md missing 'description' field")
            
            result["structure"]["name"] = frontmatter.get("name", "unknown")
            result["structure"]["description_length"] = len(frontmatter.get("description", ""))
        
        # Check bundled resources structure
        self._check_bundled_resources(skill_dir, result)
        
        # Check for growth data (learning records, user customizations)
        self._check_growth_data(skill_dir, result)
        
        # Determine overall validity
        result["valid"] = len(result["errors"]) == 0
        
        return result
    
    def _parse_skill_md(self, content):
        """Parse SKILL.md frontmatter and body"""
        if not content.startswith("---"):
            return None, content
        
        try:
            parts = content.split("---", 2)
            if len(parts) < 3:
                return None, content
            
            frontmatter_yaml = parts[1]
            body = parts[2]
            
            frontmatter = yaml.safe_load(frontmatter_yaml)
            return frontmatter, body
            
        except Exception as e:
            return None, content
    
    def _check_bundled_resources(self, skill_dir, result):
        """Check bundled resources structure"""
        expected_dirs = ["scripts", "references", "assets"]
        found_dirs = []
        
        for expected_dir in expected_dirs:
            dir_path = skill_dir / expected_dir
            if dir_path.exists():
                found_dirs.append(expected_dir)
                # Count files in each directory
                file_count = len([f for f in dir_path.rglob("*") if f.is_file()])
                result["structure"][f"{expected_dir}_files"] = file_count
        
        result["structure"]["bundled_dirs"] = found_dirs
    
    def _check_growth_data(self, skill_dir, result):
        """Check for skill growth data and learning records"""
        growth_indicators = []
        
        # Look for common growth data patterns
        # 1. Memory files related to this skill
        memory_files = list(self.workspace.glob(f"memory/knowledge/{skill_dir.name}*.md"))
        if memory_files:
            growth_indicators.append(f"knowledge_memory_files: {len(memory_files)}")
        
        # 2. Custom configuration files
        config_files = list(skill_dir.glob("*.config.*"))
        if config_files:
            growth_indicators.append(f"custom_config_files: {len(config_files)}")
        
        # 3. User-modified files (check modification time vs creation)
        skill_files = list(skill_dir.rglob("*"))
        modified_files = []
        for file_path in skill_files:
            if file_path.is_file():
                stat = file_path.stat()
                # If modified significantly after creation, likely user-modified
                if stat.st_mtime - stat.st_ctime > 3600:  # 1 hour difference
                    modified_files.append(str(file_path.relative_to(skill_dir)))
        
        if modified_files:
            growth_indicators.append(f"user_modified_files: {len(modified_files)}")
        
        result["growth_data"]["indicators"] = growth_indicators
        result["growth_data"]["preserved"] = len(growth_indicators) > 0

if __name__ == "__main__":
    checker = SkillIntegrityChecker()
    results = checker.check_all_skills()
    print(json.dumps(results, indent=2))