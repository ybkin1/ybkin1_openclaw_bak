#!/usr/bin/env python3
"""
OpenClaw System Guardian - Automated Monitoring (Fixed Version)

Monitors OpenClaw logs and configuration every 30 minutes.
Sends notifications via Feishu only when issues are detected.
"""

import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timedelta

# Add the scripts directory to Python path
scripts_dir = Path(__file__).parent
sys.path.insert(0, str(scripts_dir))

# Import with error handling
try:
    from log_analyzer import LogAnalyzer
    from checksum_validator import ConfigValidator
    from issue_analyzer import IssueAnalyzer
    from notification_scheduler import NotificationScheduler
except ImportError as e:
    print(f"Import error (will retry): {e}")
    sys.exit(1)

class AutomatedMonitor:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.monitor_dir = self.workspace / "backups" / "system_guardian" / "monitor"
        self.monitor_dir.mkdir(parents=True, exist_ok=True)
        
    def run_monitoring_cycle(self):
        """Run a complete monitoring cycle"""
        results = {
            "timestamp": datetime.now().isoformat(),
            "checks": {},
            "issues_found": [],
            "notifications_sent": []
        }
        
        try:
            # Analyze logs
            log_analyzer = LogAnalyzer()
            log_results = log_analyzer.analyze_recent_logs()
            results["checks"]["logs"] = log_results
            
            # Validate configuration
            validator = ConfigValidator()
            validation_results = validator.validate_checksums()
            results["checks"]["config_validation"] = validation_results
            
            # Check service health
            service_health = self._check_service_health()
            results["checks"]["service_health"] = service_health
            
            # Collect all issues
            issues = []
            if log_results.get("issues"):
                issues.extend(log_results["issues"])
                
            if validation_results.get("status") == "invalid":
                for change in validation_results.get("changes", []):
                    file_path = change.get("file", change.get("directory", "unknown"))
                    issues.append({
                        "source": "config_validation",
                        "type": change.get("type", "config_changed"),
                        "severity": "medium",
                        "message": f"Configuration changed: {file_path}"
                    })
                    
            if not service_health.get("gateway_running", True):
                issues.append({
                    "source": "service_health",
                    "type": "gateway_down",
                    "severity": "critical",
                    "message": "Gateway service is not running"
                })
                
            if not service_health.get("feishu_connected", True):
                issues.append({
                    "source": "service_health",
                    "type": "feishu_disconnected",
                    "severity": "high",
                    "message": "Feishu connection lost"
                })
                
            results["issues_found"] = issues
            
            # Only send notifications if issues are found
            if issues:
                # Analyze issues with detailed remediation steps
                analyzer = IssueAnalyzer()
                detailed_analysis = []
                for issue in issues:
                    analysis = analyzer.analyze_issue(issue)
                    detailed_analysis.append(analysis)
                
                # Use notification scheduler to limit Feishu API calls
                scheduler = NotificationScheduler()
                notification_result = scheduler.schedule_notification(
                    issues=detailed_analysis,
                    timestamp=results["timestamp"]
                )
                results["notifications_sent"] = [notification_result]
            else:
                # No issues found, no notification needed
                results["notifications_sent"] = []
                
        except Exception as e:
            results["error"] = str(e)
            print(f"Monitoring cycle error: {e}")
        
        # Log results
        self._log_results(results)
        
        return results
    
    def _check_service_health(self):
        """Check Gateway and Feishu service health"""
        try:
            # Check if Gateway process is running
            result = subprocess.run(["pgrep", "-f", "openclaw.*gateway"], 
                                  capture_output=True, text=True)
            gateway_running = len(result.stdout.strip()) > 0
            
            # Check Feishu connection (simplified check)
            feishu_connected = gateway_running
            
            return {
                "gateway_running": gateway_running,
                "feishu_connected": feishu_connected
            }
        except Exception as e:
            return {
                "gateway_running": False,
                "feishu_connected": False,
                "error": str(e)
            }
    
    def _log_results(self, results):
        """Log monitoring results to file"""
        log_file = self.monitor_dir / "monitoring_history.jsonl"
        with open(log_file, "a", encoding='utf-8') as f:
            f.write(json.dumps(results, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    monitor = AutomatedMonitor()
    results = monitor.run_monitoring_cycle()
    print(json.dumps(results, indent=2, ensure_ascii=False))
