#!/usr/bin/env python3
"""
OpenClaw System Guardian - Qwen Portal Configuration Cleanup

Removes all qwen-portal/coder-model references from configuration files.
Ensures skills don't attempt to restore qwen-portal configurations.
"""

import json
from pathlib import Path

def cleanup_openclaw_config():
    """Remove qwen-portal references from openclaw.filtered.json"""
    config_file = Path("/root/.openclaw/workspace/agents/master/openclaw.filtered.json")
    
    if not config_file.exists():
        print("❌ openclaw.filtered.json not found")
        return False
    
    with open(config_file, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    changes_made = False
    
    # Remove qwen-portal auth profiles
    if "auth" in config and "profiles" in config["auth"]:
        profiles_to_remove = [k for k in config["auth"]["profiles"].keys() if "qwen-portal" in k]
        for profile in profiles_to_remove:
            del config["auth"]["profiles"][profile]
            print(f"✅ Removed auth profile: {profile}")
            changes_made = True
    
    # Remove qwen-portal from plugins allow list
    if "plugins" in config and "allow" in config["plugins"]:
        plugins_to_remove = [p for p in config["plugins"]["allow"] if "qwen-portal" in p]
        for plugin in plugins_to_remove:
            config["plugins"]["allow"].remove(plugin)
            print(f"✅ Removed plugin from allow list: {plugin}")
            changes_made = True
    
    # Remove qwen-portal plugin entries
    if "plugins" in config and "entries" in config["plugins"]:
        entries_to_remove = [k for k in config["plugins"]["entries"].keys() if "qwen-portal" in k]
        for entry in entries_to_remove:
            del config["plugins"]["entries"][entry]
            print(f"✅ Removed plugin entry: {entry}")
            changes_made = True
    
    # Remove qwen-portal models from agent configurations
    if "agents" in config and "list" in config["agents"]:
        for agent in config["agents"]["list"]:
            if "model" in agent and "fallbacks" in agent["model"]:
                fallbacks_to_remove = [f for f in agent["model"]["fallbacks"] if "qwen-portal" in f]
                for fallback in fallbacks_to_remove:
                    agent["model"]["fallbacks"].remove(fallback)
                    print(f"✅ Removed qwen-portal fallback from agent {agent['id']}: {fallback}")
                    changes_made = True
    
    # Save updated config
    if changes_made:
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        print(f"✅ Configuration cleanup complete")
        return True
    else:
        print(f"ℹ️ No qwen-portal references found")
        return False

def update_skills_to_skip_qwen_portal():
    """Update skills to skip qwen-portal restoration"""
    skills_dir = Path("/root/.openclaw/workspace/agents/master/skills/openclaw-system-guardian/scripts")
    
    # Update intelligent_recovery.py
    recovery_script = skills_dir / "intelligent_recovery.py"
    if recovery_script.exists():
        with open(recovery_script, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Add qwen-portal to skip list
        if "qwen-portal" not in content:
            content = content.replace(
                'incompatible_names = [skill["name"] for skill in self.incompatible_skills]',
                'incompatible_names = [skill["name"] for skill in self.incompatible_skills] + ["qwen-portal", "qwen-portal-auth"]'
            )
            
            with open(recovery_script, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Updated intelligent_recovery.py to skip qwen-portal")
    
    # Update error_analyzer.py
    error_script = skills_dir / "error_analyzer.py"
    if error_script.exists():
        with open(error_script, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Modify to not suggest qwen-portal installation
        if 'install the qwen-portal extension' in content:
            content = content.replace(
                'self.results["solution"] = "Install the qwen-portal extension using: openclaw plugins install qwen-portal-auth"',
                'self.results["solution"] = "Qwen portal is deprecated. Use alternative models (glm-5, qwen3.5-plus, deepseek)"'
            )
            
            with open(error_script, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"✅ Updated error_analyzer.py to not suggest qwen-portal")

if __name__ == "__main__":
    print("🧹 Starting qwen-portal configuration cleanup...")
    print("=" * 60)
    
    # Cleanup main config
    cleanup_openclaw_config()
    
    # Update skills
    update_skills_to_skip_qwen_portal()
    
    print("=" * 60)
    print("✅ Cleanup complete!")
