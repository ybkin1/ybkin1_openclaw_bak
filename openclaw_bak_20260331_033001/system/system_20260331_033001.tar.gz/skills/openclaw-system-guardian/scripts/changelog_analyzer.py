#!/usr/bin/env python3
"""
OpenClaw System Guardian - Changelog Analyzer

Analyzes OpenClaw changelog to detect configuration changes and provide adaptive recommendations.
"""

import re
import json
import requests
from pathlib import Path
from datetime import datetime

class ChangelogAnalyzer:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.config_file = self.workspace / "openclaw.filtered.json"
        self.changelog_url = "https://raw.githubusercontent.com/openclaw/openclaw/main/CHANGELOG.md"
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "current_version": None,
            "new_version": None,
            "config_changes": [],
            "adaptive_recommendations": [],
            "incompatible_skills": []
        }
    
    def analyze_changelog(self, target_version=None):
        """Analyze changelog for configuration changes"""
        try:
            # Get current version
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            self.results["current_version"] = config.get("meta", {}).get("lastTouchedVersion")
            
            # Fetch changelog
            response = requests.get(self.changelog_url, timeout=10)
            changelog_content = response.text
            
            # Extract target version if not provided
            if target_version is None:
                target_version = self._extract_latest_version(changelog_content)
            self.results["new_version"] = target_version
            
            # Analyze configuration changes
            self._analyze_config_changes(changelog_content, target_version)
            self._generate_adaptive_recommendations()
            
            return self.results
            
        except Exception as e:
            self.results["error"] = f"Changelog analysis failed: {str(e)}"
            return self.results
    
    def _extract_latest_version(self, changelog_content):
        """Extract the latest version from changelog"""
        version_pattern = r"## (\d+\.\d+\.\d+)"
        versions = re.findall(version_pattern, changelog_content)
        return versions[0] if versions else None
    
    def _analyze_config_changes(self, changelog_content, target_version):
        """Analyze changelog for configuration-related changes"""
        # Split changelog into version sections
        version_sections = self._split_changelog_by_version(changelog_content)
        
        # Find changes for target version
        target_section = version_sections.get(target_version, "")
        if not target_section:
            return
        
        # Look for configuration-related keywords
        config_keywords = [
            "config", "configuration", "channel", "agent", "auth", "authentication",
            "skill", "plugin", "model", "gateway", "websocket", "api", "token"
        ]
        
        lines = target_section.split('\n')
        for line in lines:
            line_lower = line.lower()
            if any(keyword in line_lower for keyword in config_keywords):
                # Check if it's a breaking change or just an addition
                if self._is_breaking_change(line):
                    self.results["config_changes"].append({
                        "type": "breaking",
                        "description": line.strip(),
                        "component": self._identify_component(line)
                    })
                elif self._is_config_change(line):
                    self.results["config_changes"].append({
                        "type": "config_update",
                        "description": line.strip(),
                        "component": self._identify_component(line)
                    })
    
    def _split_changelog_by_version(self, changelog_content):
        """Split changelog into version sections"""
        version_pattern = r"## (\d+\.\d+\.\d+)"
        sections = {}
        current_version = None
        current_content = []
        
        for line in changelog_content.split('\n'):
            version_match = re.match(version_pattern, line)
            if version_match:
                if current_version:
                    sections[current_version] = '\n'.join(current_content)
                current_version = version_match.group(1)
                current_content = []
            else:
                current_content.append(line)
        
        if current_version:
            sections[current_version] = '\n'.join(current_content)
        
        return sections
    
    def _is_breaking_change(self, line):
        """Check if a line describes a breaking change"""
        breaking_indicators = ["breaking", "removed", "deprecated", "changed", "renamed", "replaced"]
        return any(indicator in line.lower() for indicator in breaking_indicators)
    
    def _is_config_change(self, line):
        """Check if a line describes a configuration change"""
        config_indicators = ["config", "configuration", "channel", "agent", "auth", "skill", "plugin"]
        return any(indicator in line.lower() for indicator in config_indicators)
    
    def _identify_component(self, line):
        """Identify the component affected by the change"""
        line_lower = line.lower()
        if "channel" in line_lower:
            return "channel"
        elif "agent" in line_lower:
            return "agent"
        elif "auth" in line_lower or "authentication" in line_lower:
            return "auth"
        elif "skill" in line_lower or "plugin" in line_lower:
            return "skill"
        elif "gateway" in line_lower or "websocket" in line_lower:
            return "gateway"
        else:
            return "general"
    
    def _generate_adaptive_recommendations(self):
        """Generate adaptive recommendations based on config changes"""
        for change in self.results["config_changes"]:
            if change["type"] == "breaking":
                recommendation = self._create_breaking_change_recommendation(change)
            else:
                recommendation = self._create_config_update_recommendation(change)
            
            if recommendation:
                self.results["adaptive_recommendations"].append(recommendation)
    
    def _create_breaking_change_recommendation(self, change):
        """Create recommendation for breaking changes"""
        component = change["component"]
        description = change["description"]
        
        if component == "channel":
            return {
                "action": "update_channel_config",
                "description": f"Update channel configuration due to breaking change: {description}",
                "priority": "high",
                "steps": [
                    "Backup current channel configuration",
                    "Review new channel configuration format in documentation",
                    "Update openclaw.filtered.json with new format",
                    "Test channel connectivity"
                ]
            }
        elif component == "agent":
            return {
                "action": "update_agent_config",
                "description": f"Update agent configuration due to breaking change: {description}",
                "priority": "high",
                "steps": [
                    "Backup current agent configuration", 
                    "Review new agent configuration format",
                    "Update openclaw.filtered.json with new format",
                    "Verify agent functionality"
                ]
            }
        elif component == "auth":
            return {
                "action": "update_auth_config",
                "description": f"Update authentication configuration due to breaking change: {description}",
                "priority": "critical",
                "steps": [
                    "Backup current auth configuration",
                    "Review new authentication requirements",
                    "Update tokens/API keys as needed",
                    "Test authentication flow"
                ]
            }
        else:
            return {
                "action": "manual_review",
                "description": f"Manual review required for breaking change: {description}",
                "priority": "medium",
                "steps": [
                    "Review changelog entry in detail",
                    "Check OpenClaw documentation for migration guide",
                    "Plan manual configuration update"
                ]
            }
    
    def _create_config_update_recommendation(self, change):
        """Create recommendation for configuration updates"""
        component = change["component"]
        description = change["description"]
        
        return {
            "action": f"review_{component}_config",
            "description": f"Review {component} configuration for potential updates: {description}",
            "priority": "low",
            "steps": [
                f"Check if current {component} configuration needs updates",
                "Apply updates if necessary",
                "Test functionality"
            ]
        }

if __name__ == "__main__":
    analyzer = ChangelogAnalyzer()
    results = analyzer.analyze_changelog()
    print(json.dumps(results, indent=2))