#!/usr/bin/env python3
"""
OpenClaw System Guardian - Issue Analyzer

Provides comprehensive remediation strategies, risk assessments, and mitigation measures for all detected issues.
"""

import json
from datetime import datetime

class IssueAnalyzer:
    """Analyzes issues and provides detailed remediation guidance"""
    
    REMEDIATION_DATABASE = {
        "gateway_down": {
            "title": "Gateway 服务宕机",
            "repair_steps": [
                "1. 检查 Gateway 服务状态：`systemctl --user status openclaw-gateway`",
                "2. 启动 Gateway 服务：`systemctl --user start openclaw-gateway`",
                "3. 查看详细日志：`journalctl --user -u openclaw-gateway -n 50 --no-pager`",
                "4. 如果是 Node.js 版本问题：`openclaw doctor --repair`",
                "5. 重启 Gateway：`systemctl --user restart openclaw-gateway`"
            ],
            "risks": [
                "🔴 所有 Channel 功能失效（飞书、Telegram 等无法通信）",
                "🔴 定时任务无法执行（cron jobs 停止）",
                "🔴 会话数据可能丢失（未保存的对话内容）",
                "🟠 监控和告警系统中断"
            ],
            "mitigation": [
                "✅ 配置系统服务自动重启：`systemctl --user enable openclaw-gateway`",
                "✅ 设置看门狗监控（systemd watchdog）",
                "✅ 配置备用通信渠道（如 Telegram 作为飞书的备份）",
                "✅ 定期备份会话数据和配置文件"
            ],
            "estimated_time": "5-10 分钟",
            "impact": "高 - 系统核心功能完全中断",
            "priority": "P0 - 最高优先级"
        },
        
        "feishu_disconnected": {
            "title": "飞书连接断开",
            "repair_steps": [
                "1. 检查飞书应用配置：`openclaw channels list`",
                "2. 验证 App ID 和 App Secret 是否有效",
                "3. 检查飞书应用权限是否被修改",
                "4. 重新认证飞书应用：`openclaw channels login --channel feishu`",
                "5. 重启 Gateway 服务以重建连接",
                "6. 检查网络连通性和防火墙规则"
            ],
            "risks": [
                "🔴 无法接收用户消息和命令",
                "🔴 无法发送通知和告警",
                "🔴 用户交互功能完全中断",
                "🟠 重要业务通知可能丢失"
            ],
            "mitigation": [
                "✅ 配置多个通信渠道作为备份（Telegram/Discord）",
                "✅ 使用飞书开放平台的事件订阅功能检测断连",
                "✅ 实施心跳检测机制（每 5 分钟验证连接）",
                "✅ 配置 Webhook 作为紧急通知渠道"
            ],
            "estimated_time": "3-5 分钟",
            "impact": "高 - 主要通信渠道中断",
            "priority": "P1 - 高优先级"
        },
        
        "model_failure": {
            "title": "模型调用失败",
            "repair_steps": [
                "1. 检查模型提供商 API 状态（访问 provider status page）",
                "2. 验证 API Key 是否有效：`openclaw models list`",
                "3. 检查 API Key 是否过期或额度用尽",
                "4. 切换到备用模型：修改 openclaw.json 中的 fallback 配置",
                "5. 检查网络连接和代理设置",
                "6. 验证模型配额和速率限制"
            ],
            "risks": [
                "🔴 AI 功能完全不可用",
                "🔴 所有依赖模型的任务失败",
                "🟠 用户体验严重下降",
                "🟠 自动化流程中断"
            ],
            "mitigation": [
                "✅ 配置多个模型提供商（glm-5 + qwen3.5-plus + deepseek）",
                "✅ 实施智能降级策略（大模型→小模型→本地模型）",
                "✅ 设置请求重试和超时机制",
                "✅ 监控 API 使用量和配额"
            ],
            "estimated_time": "2-5 分钟",
            "impact": "高 - AI 核心能力丧失",
            "priority": "P1 - 高优先级"
        },
        
        "config_changed": {
            "title": "配置文件变更",
            "repair_steps": [
                "1. 对比变更内容：`diff current_config backup_config`",
                "2. 确认变更是否为授权操作",
                "3. 如果是意外变更，从快照恢复：`python3 checksum_validator.py restore`",
                "4. 如果是合法变更，更新校验文件：`python3 checksum_validator.py generate`",
                "5. 记录变更原因和责任人",
                "6. 验证变更后系统功能正常"
            ],
            "risks": [
                "🟠 配置错误可能导致功能异常",
                "🟠 安全设置可能被意外修改",
                "🟡 系统稳定性可能受影响",
                "🟡 可能引入安全漏洞"
            ],
            "mitigation": [
                "✅ 实施配置变更审批流程",
                "✅ 所有变更前自动创建快照",
                "✅ 使用 Git 进行配置版本控制",
                "✅ 定期审计配置变更历史"
            ],
            "estimated_time": "5-15 分钟",
            "impact": "中 - 取决于变更内容",
            "priority": "P2 - 中优先级"
        },
        
        "skills_directory_changed": {
            "title": "Skills 目录结构变更",
            "repair_steps": [
                "1. 检查 Skills 目录变化：`ls -la skills/`",
                "2. 验证新增/删除的 Skills 是否合法",
                "3. 如果是意外删除，从快照恢复 Skills",
                "4. 重新验证所有 Skills 的完整性",
                "5. 检查 Skills 依赖关系是否完整",
                "6. 重启 Gateway 以加载变更"
            ],
            "risks": [
                "🟠 关键 Skills 可能丢失",
                "🟠 功能模块不完整",
                "🟡 系统依赖关系破坏",
                "🟡 可能导致连锁故障"
            ],
            "mitigation": [
                "✅ 定期备份完整的 Skills 目录",
                "✅ 实施 Skills 安装/卸载审计",
                "✅ 维护 Skills 依赖关系图",
                "✅ 使用 Git 管理 Skills 版本"
            ],
            "estimated_time": "10-20 分钟",
            "impact": "中 - 功能完整性受影响",
            "priority": "P2 - 中优先级"
        }
    }
    
    def analyze_issue(self, issue):
        """Analyze a single issue and return comprehensive remediation info"""
        issue_type = issue.get("type", "unknown")
        severity = issue.get("severity", "low")
        
        # Get remediation info from database
        remediation = self.REMEDIATION_DATABASE.get(issue_type, {
            "title": "未知问题",
            "repair_steps": [
                "1. 手动检查相关组件状态",
                "2. 查看系统日志获取更多信息",
                "3. 查阅 OpenClaw 文档",
                "4. 联系系统管理员"
            ],
            "risks": ["未知风险 - 需要进一步诊断"],
            "mitigation": ["实施全面监控和告警"],
            "estimated_time": "未知",
            "impact": "未知",
            "priority": "P3 - 需要诊断"
        })
        
        return {
            "issue": issue,
            "title": remediation["title"],
            "repair_steps": remediation["repair_steps"],
            "risks": remediation["risks"],
            "mitigation": remediation["mitigation"],
            "estimated_time": remediation["estimated_time"],
            "impact": remediation["impact"],
            "priority": remediation["priority"]
        }
    
    def generate_comprehensive_report(self, issues_found):
        """Generate a comprehensive report for all issues"""
        report = {
            "timestamp": datetime.now().isoformat(),
            "issues_count": len(issues_found),
            "detailed_analysis": []
        }
        
        for issue in issues_found:
            analysis = self.analyze_issue(issue)
            report["detailed_analysis"].append(analysis)
        
        # Calculate overall priority
        priorities = [a["priority"] for a in report["detailed_analysis"]]
        if "P0" in priorities:
            report["overall_priority"] = "P0 - 紧急"
        elif "P1" in priorities:
            report["overall_priority"] = "P1 - 高"
        elif "P2" in priorities:
            report["overall_priority"] = "P2 - 中"
        else:
            report["overall_priority"] = "P3 - 低"
        
        return report

if __name__ == "__main__":
    # Test with sample issues
    test_issues = [
        {"type": "gateway_down", "severity": "critical"},
        {"type": "feishu_disconnected", "severity": "high"},
        {"type": "model_failure", "severity": "high"}
    ]
    
    analyzer = IssueAnalyzer()
    report = analyzer.generate_comprehensive_report(test_issues)
    print(json.dumps(report, indent=2, ensure_ascii=False))