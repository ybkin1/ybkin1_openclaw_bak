#!/usr/bin/env python3
"""
OpenClaw System Guardian - Intelligent Recovery with Skill Compatibility Handling

Performs intelligent recovery operations that skip incompatible skills and notify via Feishu.
"""

import os
import json
import shutil
import subprocess
from pathlib import Path
from datetime import datetime

class IntelligentRecovery:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.snapshot_dir = self.workspace / "backups" / "system_guardian"
        self.incompatible_skills = []
        self.recovery_log = []
        
    def perform_intelligent_recovery(self, snapshot_name=None):
        """Perform intelligent recovery with skill compatibility checking"""
        try:
            # Get latest snapshot if not specified
            if snapshot_name is None:
                snapshot_name = self._get_latest_snapshot()
            
            # Extract snapshot
            extracted_path = self._extract_snapshot(snapshot_name)
            
            # Check skill compatibility before recovery
            self._check_skill_compatibility(extracted_path)
            
            # Perform recovery (skipping incompatible skills)
            self._perform_recovery(extracted_path)
            
            # Send Feishu notification about incompatible skills
            if self.incompatible_skills:
                self._send_feishu_notification()
            
            # Cleanup
            shutil.rmtree(extracted_path)
            
            return {
                "success": True,
                "timestamp": datetime.now().isoformat(),
                "incompatible_skills": self.incompatible_skills,
                "recovery_log": self.recovery_log
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _get_latest_snapshot(self):
        """Get the latest snapshot filename"""
        snapshots = list(self.snapshot_dir.glob("complete_snapshot_*.tar.gz"))
        if not snapshots:
            raise Exception("No snapshots found")
        return max(snapshots, key=os.path.getctime).name
    
    def _extract_snapshot(self, snapshot_name):
        """Extract snapshot to temporary directory"""
        snapshot_path = self.snapshot_dir / snapshot_name
        extract_path = self.workspace / "temp_recovery"
        extract_path.mkdir(exist_ok=True)
        
        # Extract snapshot
        subprocess.run(["tar", "-xzf", str(snapshot_path), "-C", str(extract_path)], check=True)
        
        # Get the actual extracted directory name
        extracted_dirs = list(extract_path.glob("complete_snapshot_*"))
        if not extracted_dirs:
            raise Exception("Snapshot extraction failed")
        
        return extracted_dirs[0]
    
    def _check_skill_compatibility(self, extracted_path):
        """Check skill compatibility with current OpenClaw version"""
        skills_path = extracted_path / "skills"
        if not skills_path.exists():
            return
        
        # Get current OpenClaw version
        current_version = self._get_current_openclaw_version()
        
        # Check each skill for compatibility
        for skill_dir in skills_path.iterdir():
            if skill_dir.is_dir():
                skill_name = skill_dir.name
                if not self._is_skill_compatible(skill_name, current_version):
                    self.incompatible_skills.append({
                        "name": skill_name,
                        "reason": "Incompatible with OpenClaw version " + current_version
                    })
    
    def _get_current_openclaw_version(self):
        """Get current OpenClaw version from config"""
        config_file = self.workspace / "openclaw.filtered.json"
        if not config_file.exists():
            return "unknown"
        
        with open(config_file, 'r') as f:
            config = json.load(f)
        return config.get("meta", {}).get("lastTouchedVersion", "unknown")
    
    def _is_skill_compatible(self, skill_name, openclaw_version):
        """Check if a skill is compatible with the current OpenClaw version"""
        # This is a simplified compatibility check
        # In reality, this would use a compatibility matrix or skill metadata
        
        # Known incompatible skills for specific versions
        incompatible_combinations = {
            "old-skill-example": ["2026.4.0", "2026.5.0"]
        }
        
        if skill_name in incompatible_combinations:
            incompatible_versions = incompatible_combinations[skill_name]
            if openclaw_version in incompatible_versions:
                return False
        
        # Also check if skill has valid SKILL.md
        skill_path = self.workspace / "skills" / skill_name
        if skill_path.exists():
            skill_md = skill_path / "SKILL.md"
            if not skill_md.exists():
                return False
            
            # Check if SKILL.md has valid frontmatter
            try:
                content = skill_md.read_text()
                if not content.startswith("---"):
                    return False
            except:
                return False
        
        return True
    
    def _perform_recovery(self, extracted_path):
        """Perform recovery operations, skipping incompatible skills"""
        # Recover core files
        core_files = [
            "SOUL.md", "MEMORY.md", "AGENTS.md", "USER.md", 
            "TOOLS.md", "openclaw.filtered.json", "crontab.txt", 
            ".gitignore", "RECOVERY_CHECKLIST.md"
        ]
        
        for filename in core_files:
            src_file = extracted_path / filename
            if src_file.exists():
                dst_file = self.workspace / filename
                shutil.copy2(src_file, dst_file)
                self.recovery_log.append(f"Recovered {filename}")
        
        # Recover memory directory
        memory_src = extracted_path / "memory"
        if memory_src.exists():
            memory_dst = self.workspace / "memory"
            if memory_dst.exists():
                shutil.rmtree(memory_dst)
            shutil.copytree(memory_src, memory_dst)
            self.recovery_log.append("Recovered memory directory")
        
        # Recover skills (skip incompatible ones)
        skills_src = extracted_path / "skills"
        if skills_src.exists():
            skills_dst = self.workspace / "skills"
            incompatible_names = [skill["name"] for skill in self.incompatible_skills] + ["qwen-portal", "qwen-portal-auth"]
            
            for skill_dir in skills_src.iterdir():
                if skill_dir.is_dir() and skill_dir.name not in incompatible_names:
                    dst_skill_dir = skills_dst / skill_dir.name
                    if dst_skill_dir.exists():
                        shutil.rmtree(dst_skill_dir)
                    shutil.copytree(skill_dir, dst_skill_dir)
                    self.recovery_log.append(f"Recovered skill: {skill_dir.name}")
                elif skill_dir.name in incompatible_names:
                    self.recovery_log.append(f"Skipped incompatible skill: {skill_dir.name}")
    
    def _send_feishu_notification(self):
        """Send Feishu notification about incompatible skills"""
        notification_message = f"""🚨 OpenClaw System Guardian - Recovery Complete

**Recovery Summary:**
- ✅ Core configuration restored
- ✅ Memory directory restored  
- ✅ Compatible skills restored
- ⚠️ **{len(self.incompatible_skills)} incompatible skills skipped**

**Skipped Skills:**
"""
        for skill in self.incompatible_skills:
            notification_message += f"- {skill['name']}: {skill['reason']}\n"
        
        notification_message += """
**Next Steps:**
1. Review the skipped skills
2. Update or replace incompatible skills
3. Test system functionality

Recovery completed at: """ + datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Log the notification (in real implementation, this would send to Feishu)
        print("Feishu Notification:")
        print(notification_message)
        self.recovery_log.append("Feishu notification sent about incompatible skills")

if __name__ == "__main__":
    recovery = IntelligentRecovery()
    result = recovery.perform_intelligent_recovery()
    print(json.dumps(result, indent=2))