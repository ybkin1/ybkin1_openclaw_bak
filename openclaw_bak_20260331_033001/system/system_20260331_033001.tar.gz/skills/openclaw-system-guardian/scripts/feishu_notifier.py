#!/usr/bin/env python3
"""
OpenClaw System Guardian - Feishu Notifier (Fixed)

Sends notifications via Feishu using the correct OpenClaw message API.
Implements retry logic, error handling, and self-healing.
"""

import json
import subprocess
import os
from pathlib import Path
from datetime import datetime

class FeishuNotifier:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.monitor_dir = self.workspace / "backups" / "system_guardian" / "monitor"
        self.monitor_dir.mkdir(parents=True, exist_ok=True)
        self.notification_log = self.monitor_dir / "notification_log.jsonl"
        self.pending_file = self.monitor_dir / "pending_notifications.jsonl"
        
    def send_message(self, message, retry_count=3):
        """Send message via Feishu with retry logic and self-healing"""
        result = {
            "timestamp": datetime.now().isoformat(),
            "message_length": len(message),
            "attempts": [],
            "success": False,
            "self_healing_actions": []
        }
        
        for attempt in range(1, retry_count + 1):
            try:
                # Method: Use OpenClaw message send command
                # This is the correct way to send messages via Feishu
                cmd = [
                    "openclaw", "message", "send",
                    "--channel", "feishu",
                    "--target", "ou_b46467cc1563871aab03ac1d4f9216f0",  # Your user ID
                    "--message", message
                ]
                
                # Set NVM environment for Node.js v22
                env = os.environ.copy()
                env["NVM_DIR"] = "/root/.nvm"
                
                process = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=60,
                    env=env,
                    shell=False
                )
                
                attempt_result = {
                    "attempt": attempt,
                    "method": "openclaw_message_send",
                    "command": " ".join(cmd[:6]) + " ...",
                    "returncode": process.returncode,
                    "stdout": process.stdout[:500] if process.stdout else "",
                    "stderr": process.stderr[:500] if process.stderr else ""
                }
                
                result["attempts"].append(attempt_result)
                
                if process.returncode == 0:
                    result["success"] = True
                    print(f"✅ Attempt {attempt}: Message sent successfully")
                    break
                else:
                    # Analyze the error for self-healing
                    error_analysis = self._analyze_send_error(process.stderr)
                    attempt_result["error_analysis"] = error_analysis
                    
                    # Try self-healing actions
                    if error_analysis["action"] == "check_feishu_connection":
                        healing_result = self._check_feishu_connection()
                        result["self_healing_actions"].append(healing_result)
                        if healing_result["success"]:
                            print(f"🔧 Self-healing: Feishu connection restored")
                            continue  # Retry after healing
                    
                    print(f"❌ Attempt {attempt} failed: {process.stderr[:200]}")
                    
            except subprocess.TimeoutExpired:
                attempt_result = {
                    "attempt": attempt,
                    "method": "openclaw_message_send",
                    "error": "Timeout after 60 seconds"
                }
                result["attempts"].append(attempt_result)
                print(f"⏱️ Attempt {attempt} timed out")
                
            except FileNotFoundError as e:
                # OpenClaw command not found
                attempt_result = {
                    "attempt": attempt,
                    "method": "openclaw_message_send",
                    "error": f"OpenClaw command not found: {str(e)}",
                    "fallback": "Message saved to pending queue"
                }
                result["attempts"].append(attempt_result)
                self._save_pending_message(message)
                break
                
            except Exception as e:
                attempt_result = {
                    "attempt": attempt,
                    "method": "openclaw_message_send",
                    "error": str(e)
                }
                result["attempts"].append(attempt_result)
                print(f"❌ Attempt {attempt} error: {e}")
        
        # Log the result
        self._log_notification(result)
        
        return result
    
    def _analyze_send_error(self, error_message):
        """Analyze send error and suggest self-healing action"""
        error_lower = error_message.lower()
        
        if "feishu" in error_lower and ("not connected" in error_lower or "disconnected" in error_lower):
            return {
                "type": "feishu_disconnected",
                "action": "check_feishu_connection",
                "description": "Feishu channel is not connected"
            }
        elif "timeout" in error_lower:
            return {
                "type": "timeout",
                "action": "retry_with_longer_timeout",
                "description": "Request timed out"
            }
        elif "authentication" in error_lower or "auth" in error_lower:
            return {
                "type": "auth_failure",
                "action": "check_feishu_credentials",
                "description": "Authentication failed"
            }
        else:
            return {
                "type": "unknown",
                "action": "save_to_pending",
                "description": "Unknown error"
            }
    
    def _check_feishu_connection(self):
        """Check and attempt to restore Feishu connection"""
        try:
            # Check if Feishu channel is configured
            result = subprocess.run(
                ["openclaw", "channels", "list"],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if "feishu" in result.stdout.lower():
                return {
                    "success": True,
                    "action": "feishu_channel_found",
                    "message": "Feishu channel is configured"
                }
            else:
                return {
                    "success": False,
                    "action": "feishu_channel_not_found",
                    "message": "Feishu channel not found in configuration"
                }
                
        except Exception as e:
            return {
                "success": False,
                "action": "check_failed",
                "error": str(e)
            }
    
    def _save_pending_message(self, message):
        """Save message to pending queue when sending fails"""
        with open(self.pending_file, "a") as f:
            notification = {
                "timestamp": datetime.now().isoformat(),
                "message": message,
                "status": "pending",
                "reason": "send_failed"
            }
            f.write(json.dumps(notification, ensure_ascii=False) + "\n")
    
    def _log_notification(self, result):
        """Log notification attempt"""
        with open(self.notification_log, "a") as f:
            f.write(json.dumps(result, ensure_ascii=False) + "\n")
    
    def process_pending_notifications(self):
        """Process any pending notifications that failed to send"""
        if not self.pending_file.exists():
            return {"processed": 0, "message": "No pending notifications"}
        
        with open(self.pending_file, "r") as f:
            lines = f.readlines()
        
        if not lines:
            return {"processed": 0, "message": "Pending queue is empty"}
        
        # Create backup
        backup_file = self.monitor_dir / "pending_notifications_backup.jsonl"
        with open(backup_file, "w") as f:
            f.writelines(lines)
        
        processed = 0
        failed = 0
        remaining = []
        
        for line in lines:
            try:
                notification = json.loads(line)
                message = notification.get("message", "")
                
                result = self.send_message(message, retry_count=1)
                
                if result["success"]:
                    processed += 1
                else:
                    failed += 1
                    remaining.append(line)
                    
            except Exception as e:
                failed += 1
                remaining.append(line)
                print(f"Failed to process notification: {e}")
        
        # Update pending file
        with open(self.pending_file, "w") as f:
            f.writelines(remaining)
        
        return {
            "processed": processed,
            "failed": failed,
            "remaining": len(remaining)
        }

if __name__ == "__main__":
    import sys
    
    notifier = FeishuNotifier()
    
    if len(sys.argv) > 1:
        message = " ".join(sys.argv[1:])
        result = notifier.send_message(message)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        result = notifier.process_pending_notifications()
        print(json.dumps(result, indent=2, ensure_ascii=False))
