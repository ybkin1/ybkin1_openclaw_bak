#!/usr/bin/env python3
"""
OpenClaw System Guardian - Notification Scheduler

Manages notification frequency to optimize Feishu API usage:
- No notifications when system is healthy
- Issues are batched and sent every 30 minutes
- Feishu API calls limited to once every 30 minutes
"""

import json
from pathlib import Path
from datetime import datetime, timedelta

class NotificationScheduler:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.monitor_dir = self.workspace / "backups" / "system_guardian" / "monitor"
        self.pending_issues_file = self.monitor_dir / "pending_issues.jsonl"
        self.last_notification_file = self.monitor_dir / "last_notification.txt"
        self.monitor_dir.mkdir(parents=True, exist_ok=True)
        
    def should_send_notification(self):
        """Check if we should send a notification (max once every 30 minutes)"""
        if not self.last_notification_file.exists():
            return True, 0
            
        with open(self.last_notification_file, 'r') as f:
            last_time_str = f.read().strip()
            
        try:
            last_time = datetime.fromisoformat(last_time_str)
            time_since_last = datetime.now() - last_time
            minutes_remaining = 30 - time_since_last.total_seconds() / 60
            
            if time_since_last >= timedelta(minutes=30):
                return True, 0
            else:
                return False, int(minutes_remaining)
        except:
            return True, 0
    
    def add_pending_issue(self, issue):
        """Add an issue to the pending queue"""
        issue_with_timestamp = {
            "timestamp": datetime.now().isoformat(),
            "issue": issue
        }
        
        with open(self.pending_issues_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(issue_with_timestamp, ensure_ascii=False) + '\n')
    
    def get_pending_issues(self):
        """Get all pending issues"""
        if not self.pending_issues_file.exists():
            return []
            
        pending_issues = []
        with open(self.pending_issues_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    try:
                        issue_record = json.loads(line)
                        pending_issues.append(issue_record)
                    except:
                        continue
                        
        return pending_issues
    
    def clear_pending_issues(self):
        """Clear all pending issues after sending notification"""
        if self.pending_issues_file.exists():
            self.pending_issues_file.unlink()
    
    def record_notification_sent(self):
        """Record that a notification was sent"""
        with open(self.last_notification_file, 'w') as f:
            f.write(datetime.now().isoformat())
    
    def schedule_notification(self, issues, timestamp):
        """
        Schedule notification based on issues and timing.
        Returns notification result.
        """
        should_send, minutes_remaining = self.should_send_notification()
        
        if not issues:
            # No issues, no notification needed
            return {
                "type": "no_issues",
                "sent": False,
                "reason": "No issues detected"
            }
        
        if should_send:
            # Send notification now
            self.record_notification_sent()
            return {
                "type": "issues_alert",
                "sent": True,
                "reason": "Issues detected and notification sent",
                "issues_count": len(issues)
            }
        else:
            # Queue issues for next notification cycle
            for issue in issues:
                self.add_pending_issue(issue)
            return {
                "type": "issues_queued",
                "sent": False,
                "reason": f"Waiting for next notification cycle in {minutes_remaining} minutes",
                "pending_issues_count": len(self.get_pending_issues())
            }

if __name__ == "__main__":
    scheduler = NotificationScheduler()
    can_send, wait_time = scheduler.should_send_notification()
    print(f"Can send notification: {can_send}, Wait time: {wait_time} minutes")
