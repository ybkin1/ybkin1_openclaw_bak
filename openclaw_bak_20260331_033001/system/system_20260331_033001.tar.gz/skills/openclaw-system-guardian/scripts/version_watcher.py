#!/usr/bin/env python3
"""
OpenClaw System Guardian - Version Watcher

Monitors OpenClaw releases and provides proactive upgrade notifications with compatibility analysis.
"""

import json
import requests
from pathlib import Path
from datetime import datetime

class VersionWatcher:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.config_file = self.workspace / "openclaw.filtered.json"
        self.github_api_url = "https://api.github.com/repos/openclaw/openclaw/releases/latest"
        self.changelog_url = "https://raw.githubusercontent.com/openclaw/openclaw/main/CHANGELOG.md"
        
    def check_for_new_version(self):
        """Check if a new OpenClaw version is available"""
        try:
            # Get current version
            current_version = self._get_current_version()
            
            # Get latest release from GitHub
            response = requests.get(self.github_api_url, timeout=10)
            latest_release = response.json()
            latest_version = latest_release['tag_name'].lstrip('v')
            
            # Check if new version is available
            if self._is_version_newer(latest_version, current_version):
                return {
                    "new_version_available": True,
                    "current_version": current_version,
                    "latest_version": latest_version,
                    "release_notes": latest_release['body'],
                    "download_url": latest_release['html_url']
                }
            else:
                return {
                    "new_version_available": False,
                    "current_version": current_version,
                    "latest_version": latest_version
                }
                
        except Exception as e:
            return {
                "error": f"Version check failed: {str(e)}"
            }
    
    def analyze_upgrade_impact(self, target_version):
        """Analyze the impact of upgrading to the target version"""
        try:
            # Fetch changelog
            changelog_response = requests.get(self.changelog_url, timeout=10)
            changelog_content = changelog_response.text
            
            # Analyze changelog (reuse changelog analyzer logic)
            from changelog_analyzer import ChangelogAnalyzer
            analyzer = ChangelogAnalyzer(str(self.workspace))
            analysis_result = analyzer.analyze_changelog(target_version)
            
            # Check skill compatibility
            incompatible_skills = self._check_skill_compatibility_for_version(target_version)
            
            return {
                "target_version": target_version,
                "config_changes": analysis_result.get("config_changes", []),
                "adaptive_recommendations": analysis_result.get("adaptive_recommendations", []),
                "incompatible_skills": incompatible_skills,
                "upgrade_risk": self._assess_upgrade_risk(analysis_result, incompatible_skills)
            }
            
        except Exception as e:
            return {
                "error": f"Upgrade impact analysis failed: {str(e)}"
            }
    
    def _get_current_version(self):
        """Get current OpenClaw version from config"""
        if not self.config_file.exists():
            return "unknown"
        
        with open(self.config_file, 'r') as f:
            config = json.load(f)
        return config.get("meta", {}).get("lastTouchedVersion", "unknown")
    
    def _is_version_newer(self, version1, version2):
        """Compare versions to see if version1 is newer than version2"""
        try:
            v1_parts = [int(x) for x in version1.split('.')]
            v2_parts = [int(x) for x in version2.split('.')]
            return v1_parts > v2_parts
        except:
            return False
    
    def _check_skill_compatibility_for_version(self, target_version):
        """Check which skills are incompatible with the target version"""
        # This would use a compatibility matrix or skill metadata
        # For now, return empty list as placeholder
        return []
    
    def _assess_upgrade_risk(self, analysis_result, incompatible_skills):
        """Assess the risk level of the upgrade"""
        config_changes = analysis_result.get("config_changes", [])
        breaking_changes = [change for change in config_changes if change.get("type") == "breaking"]
        
        if len(breaking_changes) > 0 or len(incompatible_skills) > 0:
            return "high"
        elif len(config_changes) > 5:
            return "medium"
        else:
            return "low"

if __name__ == "__main__":
    watcher = VersionWatcher()
    
    # Check for new version
    version_check = watcher.check_for_new_version()
    print("Version Check:")
    print(json.dumps(version_check, indent=2))
    
    if version_check.get("new_version_available"):
        # Analyze upgrade impact
        impact_analysis = watcher.analyze_upgrade_impact(version_check["latest_version"])
        print("\nUpgrade Impact Analysis:")
        print(json.dumps(impact_analysis, indent=2))