#!/usr/bin/env python3
"""
OpenClaw System Guardian - Log Analyzer

Analyzes OpenClaw logs to detect issues and provide automated fixes.
"""

import json
import subprocess
from pathlib import Path
from datetime import datetime

class LogAnalyzer:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "issues": [],
            "fixes_applied": [],
            "recommendations": []
        }
    
    def analyze_recent_logs(self, lines=200):
        """Analyze recent OpenClaw logs"""
        try:
            # Get recent logs
            result = subprocess.run(
                ["openclaw", "logs", "--limit", str(lines), "--json"],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode != 0:
                self.results["error"] = f"Failed to get logs: {result.stderr}"
                return self.results
            
            # Parse JSON logs
            logs = []
            for line in result.stdout.strip().split('\n'):
                if line.strip():
                    try:
                        log_entry = json.loads(line)
                        logs.append(log_entry)
                    except json.JSONDecodeError:
                        continue
            
            # Analyze patterns
            self._analyze_error_patterns(logs)
            self._analyze_warning_patterns(logs)
            self._analyze_service_health(logs)
            
            return self.results
            
        except Exception as e:
            self.results["error"] = f"Log analysis failed: {str(e)}"
            return self.results
    
    def _analyze_error_patterns(self, logs):
        """Analyze error patterns in logs"""
        error_keywords = [
            "OAuth token refresh failed",
            "All models failed",
            "Service config issue",
            "failed",
            "error"
        ]
        
        for log in logs:
            message = log.get("message", "").lower()
            level = log.get("level", "").lower()
            
            if level == "error" or any(keyword in message for keyword in error_keywords):
                # OAuth token issue
                if "oauth token refresh failed" in message and "qwen-portal" in message:
                    self.results["issues"].append({
                        "type": "oauth_failure",
                        "provider": "qwen-portal",
                        "severity": "critical",
                        "message": log.get("message"),
                        "auto_fix": "install_qwen_portal_plugin"
                    })
                
                # Model failure
                elif "all models failed" in message:
                    self.results["issues"].append({
                        "type": "model_failure",
                        "severity": "high",
                        "message": log.get("message"),
                        "auto_fix": "check_model_config"
                    })
                
                # Service config issue
                elif "service config issue" in message:
                    self.results["issues"].append({
                        "type": "service_config",
                        "severity": "medium",
                        "message": log.get("message"),
                        "auto_fix": "run_doctor_repair"
                    })
    
    def _analyze_warning_patterns(self, logs):
        """Analyze warning patterns in logs"""
        for log in logs:
            level = log.get("level", "").lower()
            message = log.get("message", "").lower()
            
            if level == "warn":
                # Tools configuration warning
                if "tools.profile" in message and "unknown entries" in message:
                    self.results["issues"].append({
                        "type": "tools_config",
                        "severity": "low",
                        "message": log.get("message"),
                        "auto_fix": "review_tools_config"
                    })
    
    def _analyze_service_health(self, logs):
        """Analyze service health indicators"""
        gateway_started = False
        feishu_connected = False
        
        for log in logs:
            message = log.get("message", "").lower()
            
            if "websocket client started" in message and "feishu" in message:
                feishu_connected = True
            
            if "gateway" in message and "started" in message:
                gateway_started = True
        
        self.results["service_health"] = {
            "gateway_running": gateway_started,
            "feishu_connected": feishu_connected
        }
    
    def apply_auto_fixes(self):
        """Apply automatic fixes for detected issues"""
        for issue in self.results["issues"]:
            auto_fix = issue.get("auto_fix")
            
            if auto_fix == "install_qwen_portal_plugin":
                try:
                    result = subprocess.run(
                        ["openclaw", "plugins", "install", "qwen-portal-auth"],
                        capture_output=True,
                        text=True,
                        timeout=60
                    )
                    if result.returncode == 0:
                        self.results["fixes_applied"].append({
                            "issue": issue["type"],
                            "fix": "Installed qwen-portal-auth plugin",
                            "success": True
                        })
                    else:
                        self.results["fixes_applied"].append({
                            "issue": issue["type"],
                            "fix": "Failed to install qwen-portal-auth plugin",
                            "success": False,
                            "error": result.stderr
                        })
                except Exception as e:
                    self.results["fixes_applied"].append({
                        "issue": issue["type"],
                        "fix": "Failed to install qwen-portal-auth plugin",
                        "success": False,
                        "error": str(e)
                    })
            
            elif auto_fix == "run_doctor_repair":
                self.results["recommendations"].append({
                    "priority": "high",
                    "action": "Run 'openclaw doctor --repair' to fix service configuration issues",
                    "reason": issue["message"]
                })

if __name__ == "__main__":
    analyzer = LogAnalyzer()
    results = analyzer.analyze_recent_logs()
    analyzer.apply_auto_fixes()
    print(json.dumps(results, indent=2))