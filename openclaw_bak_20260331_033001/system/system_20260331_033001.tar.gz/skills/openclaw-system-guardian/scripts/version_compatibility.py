#!/usr/bin/env python3
"""
OpenClaw System Guardian - Version Compatibility Checker

Checks OpenClaw version compatibility and provides migration guidance.
Detects deprecated features and incompatible configurations.
"""

import json
import re
from pathlib import Path
from datetime import datetime

class VersionCompatibilityChecker:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.config_file = self.workspace / "openclaw.filtered.json"
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "current_version": None,
            "compatibility_status": "unknown",
            "issues": [],
            "recommendations": []
        }
    
    def check_compatibility(self):
        """Check version compatibility"""
        if not self.config_file.exists():
            self.results["error"] = "OpenClaw config file not found"
            return self.results
        
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
            
            # Get current OpenClaw version
            meta = config.get("meta", {})
            self.results["current_version"] = meta.get("lastTouchedVersion")
            
            # Check for known compatibility issues
            self._check_deprecated_features(config)
            self._check_skill_compatibility(config)
            self._check_channel_compatibility(config)
            
            # Determine overall status
            if self.results["issues"]:
                self.results["compatibility_status"] = "incompatible"
            else:
                self.results["compatibility_status"] = "compatible"
                
        except Exception as e:
            self.results["error"] = f"Compatibility check failed: {str(e)}"
        
        return self.results
    
    def _check_deprecated_features(self, config):
        """Check for deprecated features in current configuration"""
        # Example: Check for old-style agent configuration
        agents_config = config.get("agents", {})
        if "default" in agents_config and "list" not in agents_config:
            self.results["issues"].append({
                "type": "deprecated_feature",
                "feature": "old_agent_config",
                "description": "Old-style agent configuration detected",
                "impact": "May cause agent initialization failures in newer versions"
            })
            self.results["recommendations"].append({
                "action": "migrate_agent_config",
                "description": "Migrate to new agent list format",
                "priority": "high"
            })
    
    def _check_skill_compatibility(self, config):
        """Check skill compatibility with current OpenClaw version"""
        # This would be populated with actual compatibility rules
        # based on OpenClaw version changelogs and skill requirements
        
        # Example placeholder logic
        current_version = self.results["current_version"]
        if current_version and self._is_version_older(current_version, "2026.4.0"):
            # Skills that require newer OpenClaw versions
            incompatible_skills = self._get_incompatible_skills(current_version)
            if incompatible_skills:
                self.results["issues"].append({
                    "type": "skill_incompatibility",
                    "skills": incompatible_skills,
                    "description": f"Skills incompatible with OpenClaw {current_version}",
                    "impact": "These skills may not function correctly"
                })
                self.results["recommendations"].append({
                    "action": "upgrade_openclaw",
                    "description": "Upgrade OpenClaw to latest version",
                    "priority": "medium"
                })
    
    def _check_channel_compatibility(self, config):
        """Check channel compatibility with current OpenClaw version"""
        channels_config = config.get("channels", {})
        
        # Example: Check Feishu channel configuration format
        feishu_config = channels_config.get("feishu", {})
        if feishu_config and "accounts" not in feishu_config:
            self.results["issues"].append({
                "type": "channel_incompatibility",
                "channel": "feishu",
                "description": "Old Feishu channel configuration format",
                "impact": "Feishu integration may fail"
            })
            self.results["recommendations"].append({
                "action": "update_feishu_config",
                "description": "Update Feishu configuration to new format",
                "priority": "high"
            })
    
    def _is_version_older(self, version1, version2):
        """Compare OpenClaw versions"""
        try:
            v1_parts = [int(x) for x in re.findall(r'\d+', version1)]
            v2_parts = [int(x) for x in re.findall(r'\d+', version2)]
            return v1_parts < v2_parts
        except:
            return False
    
    def _get_incompatible_skills(self, current_version):
        """Get list of skills incompatible with current version"""
        # This would be populated from a compatibility matrix
        # For now, return empty list as placeholder
        return []

if __name__ == "__main__":
    checker = VersionCompatibilityChecker()
    results = checker.check_compatibility()
    print(json.dumps(results, indent=2))