#!/usr/bin/env python3
"""
OpenClaw System Guardian - Root Cause Analyzer

Analyzes system state to identify root causes and provide temporary workarounds + optimized solutions.
"""

import json
import subprocess
import os
from pathlib import Path
from datetime import datetime

class RootCauseAnalyzer:
    """Advanced root cause analysis with temporary and permanent solutions"""
    
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.issue_analyzer = None  # Will be initialized when needed
        
    def analyze_system_state(self, health_check_results):
        """Analyze comprehensive system state for root cause identification"""
        issues = []
        
        # Analyze each component
        if not health_check_results.get("checks", {}).get("channels", {}).get("success"):
            issues.extend(self._analyze_channel_issues(health_check_results))
            
        if not health_check_results.get("checks", {}).get("skills", {}).get("success"):
            issues.extend(self._analyze_skill_issues(health_check_results))
            
        if not health_check_results.get("checks", {}).get("agents", {}).get("success"):
            issues.extend(self._analyze_agent_issues(health_check_results))
            
        if not health_check_results.get("checks", {}).get("system_services", {}).get("success"):
            issues.extend(self._analyze_system_service_issues(health_check_results))
            
        # Resource-based analysis
        resource_issues = self._analyze_resource_constraints(health_check_results)
        issues.extend(resource_issues)
        
        return issues
    
    def _analyze_channel_issues(self, results):
        """Analyze channel-specific issues"""
        issues = []
        channels_result = results.get("checks", {}).get("channels", {})
        
        if "feishu" in channels_result.get("failed_channels", []):
            issues.append({
                "type": "feishu_disconnected",
                "severity": "high",
                "component": "channels",
                "details": "飞书连接断开或配置错误"
            })
            
        return issues
    
    def _analyze_skill_issues(self, results):
        """Analyze skill-related issues"""
        issues = []
        skills_result = results.get("checks", {}).get("skills", {})
        
        if not skills_result.get("success"):
            issues.append({
                "type": "skills_directory_changed",
                "severity": "medium",
                "component": "skills",
                "details": "Skills目录结构异常或完整性校验失败"
            })
            
        return issues
    
    def _analyze_agent_issues(self, results):
        """Analyze agent-related issues"""
        issues = []
        agents_result = results.get("checks", {}).get("agents", {})
        
        if not agents_result.get("success"):
            issues.append({
                "type": "agent_failure",
                "severity": "high",
                "component": "agents",
                "details": "Agent配置或运行异常"
            })
            
        return issues
    
    def _analyze_system_service_issues(self, results):
        """Analyze system service issues"""
        issues = []
        services_result = results.get("checks", {}).get("system_services", {})
        
        if not services_result.get("gateway_running"):
            issues.append({
                "type": "gateway_down",
                "severity": "critical",
                "component": "system_services",
                "details": "OpenClaw Gateway服务未运行"
            })
            
        return issues
    
    def _analyze_resource_constraints(self, results):
        """Analyze resource-related constraints"""
        issues = []
        
        # Check memory usage
        try:
            mem_info = self._get_memory_info()
            if mem_info["available_percent"] < 20:
                issues.append({
                    "type": "memory_low",
                    "severity": "medium",
                    "component": "system_resources",
                    "details": f"可用内存不足 ({mem_info['available_percent']}%)"
                })
        except Exception as e:
            issues.append({
                "type": "resource_monitoring_failed",
                "severity": "low",
                "component": "system_resources",
                "details": f"资源监控失败: {str(e)}"
            })
            
        return issues
    
    def _get_memory_info(self):
        """Get memory usage information"""
        result = subprocess.run(["free", "-b"], capture_output=True, text=True)
        lines = result.stdout.strip().split('\n')
        mem_line = lines[1].split()
        total = int(mem_line[1])
        available = int(mem_line[6])
        available_percent = (available / total) * 100
        
        return {
            "total": total,
            "available": available,
            "available_percent": round(available_percent, 1)
        }
    
    def generate_solutions(self, issues):
        """Generate temporary workarounds and optimized solutions"""
        solutions = []
        
        # Initialize issue analyzer if not already done
        if self.issue_analyzer is None:
            from issue_analyzer import IssueAnalyzer
            self.issue_analyzer = IssueAnalyzer()
        
        for issue in issues:
            # Get standard remediation from issue analyzer
            remediation = self.issue_analyzer.analyze_issue(issue)
            
            # Add temporary workaround and optimized solution
            temp_workaround = self._get_temporary_workaround(issue)
            optimized_solution = self._get_optimized_solution(issue)
            
            solutions.append({
                "issue": remediation,
                "temporary_workaround": temp_workaround,
                "optimized_solution": optimized_solution,
                "implementation_priority": self._calculate_priority(issue)
            })
            
        return solutions
    
    def _get_temporary_workaround(self, issue):
        """Get temporary workaround for specific issue types"""
        workarounds = {
            "gateway_down": [
                "立即重启Gateway服务: systemctl --user restart openclaw-gateway",
                "临时使用本地模型避免API依赖"
            ],
            "feishu_disconnected": [
                "切换到备用通信渠道（如Telegram）",
                "手动检查飞书配置并重新认证"
            ],
            "model_failure": [
                "切换到fallback模型配置",
                "降低请求频率避免速率限制"
            ],
            "memory_low": [
                "终止非关键后台进程",
                "清理系统缓存: echo 3 > /proc/sys/vm/drop_caches"
            ]
        }
        
        return workarounds.get(issue["type"], ["手动诊断和临时修复"])
    
    def _get_optimized_solution(self, issue):
        """Get long-term optimized solution for specific issue types"""
        solutions = {
            "gateway_down": [
                "配置systemd自动重启和看门狗监控",
                "实施多节点冗余部署",
                "添加健康检查和自动恢复机制"
            ],
            "feishu_disconnected": [
                "实施多渠道通信冗余",
                "添加连接状态监控和自动重连",
                "优化API调用频率和错误处理"
            ],
            "model_failure": [
                "配置多模型提供商负载均衡",
                "实施智能降级和缓存策略",
                "添加配额监控和预警"
            ],
            "memory_low": [
                "优化应用内存使用",
                "添加资源使用监控和告警",
                "考虑升级系统内存或优化工作负载"
            ]
        }
        
        return solutions.get(issue["type"], ["实施全面的系统优化和监控"])
    
    def _calculate_priority(self, issue):
        """Calculate implementation priority based on issue severity"""
        priority_map = {
            "critical": "P0 - 立即执行",
            "high": "P1 - 24小时内",
            "medium": "P2 - 本周内",
            "low": "P3 - 计划中"
        }
        return priority_map.get(issue.get("severity", "low"), "P3 - 计划中")
    
    def generate_comprehensive_report(self, health_check_results):
        """Generate complete root cause analysis report"""
        issues = self.analyze_system_state(health_check_results)
        solutions = self.generate_solutions(issues)
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "analysis_type": "Root Cause Analysis with Solutions",
            "issues_found": len(issues),
            "solutions_provided": len(solutions),
            "detailed_analysis": solutions,
            "summary": self._generate_summary(solutions)
        }
        
        return report
    
    def _generate_summary(self, solutions):
        """Generate executive summary"""
        if not solutions:
            return "系统状态正常，无需干预"
            
        p0_count = sum(1 for s in solutions if "P0" in s["implementation_priority"])
        p1_count = sum(1 for s in solutions if "P1" in s["implementation_priority"])
        
        summary = f"发现 {len(solutions)} 个问题需要处理"
        if p0_count > 0:
            summary += f"，其中 {p0_count} 个为紧急问题(P0)"
        if p1_count > 0:
            summary += f"，{p1_count} 个为高优先级问题(P1)"
            
        return summary

if __name__ == "__main__":
    # Test functionality
    test_results = {
        "checks": {
            "channels": {"success": False, "failed_channels": ["feishu"]},
            "skills": {"success": True},
            "agents": {"success": True},
            "system_services": {"success": False, "gateway_running": False}
        }
    }
    
    analyzer = RootCauseAnalyzer()
    report = analyzer.generate_comprehensive_report(test_results)
    print(json.dumps(report, indent=2, ensure_ascii=False))