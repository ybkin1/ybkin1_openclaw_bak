#!/usr/bin/env python3
"""
OpenClaw System Guardian - Error Analyzer

Analyzes OpenClaw error messages and provides root cause analysis with actionable solutions.
"""

import re
import json
from pathlib import Path
from datetime import datetime

class ErrorAnalyzer:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.config_file = self.workspace / "openclaw.filtered.json"
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "error_type": None,
            "root_cause": None,
            "solution": None,
            "severity": "high"
        }
    
    def analyze_error(self, error_message):
        """Analyze an error message and provide root cause analysis"""
        # OAuth token refresh failure
        if "OAuth token refresh failed" in error_message and "qwen-portal" in error_message:
            return self._analyze_qwen_oauth_error(error_message)
        
        # LLM request timeout
        elif "LLM request timed out" in error_message:
            return self._analyze_timeout_error(error_message)
        
        # Model authentication failure
        elif "auth" in error_message.lower() and "failed" in error_message.lower():
            return self._analyze_auth_error(error_message)
        
        # Generic error analysis
        else:
            return self._analyze_generic_error(error_message)
    
    def _analyze_qwen_oauth_error(self, error_message):
        """Analyze Qwen portal OAuth token refresh failure"""
        # Check if qwen-portal extension is installed
        extensions_path = Path("/root/.openclaw/extensions")
        qwen_extension = extensions_path / "qwen-portal"
        
        if not qwen_extension.exists():
            self.results["error_type"] = "missing_extension"
            self.results["root_cause"] = "Qwen portal extension is not installed"
            self.results["solution"] = "Install the qwen-portal extension using: openclaw plugins install qwen-portal-auth"
            self.results["severity"] = "critical"
        else:
            # Check if credentials exist
            credentials_path = Path("/root/.openclaw/credentials")
            qwen_credentials = list(credentials_path.glob("*qwen*"))
            
            if not qwen_credentials:
                self.results["error_type"] = "missing_credentials"
                self.results["root_cause"] = "Qwen portal OAuth credentials are missing or expired"
                self.results["solution"] = "Re-authenticate with Qwen portal: openclaw models auth login --provider qwen-portal (requires interactive TTY)"
                self.results["severity"] = "high"
            else:
                self.results["error_type"] = "expired_token"
                self.results["root_cause"] = "Qwen portal OAuth refresh token has expired"
                self.results["solution"] = "Re-authenticate with Qwen portal to refresh the OAuth token"
                self.results["severity"] = "high"
        
        return self.results
    
    def _analyze_timeout_error(self, error_message):
        """Analyze LLM request timeout errors"""
        self.results["error_type"] = "timeout"
        self.results["root_cause"] = "LLM request timed out, possibly due to network issues or model unavailability"
        self.results["solution"] = "Check network connectivity and verify the model provider is available. Consider using fallback models."
        self.results["severity"] = "medium"
        return self.results
    
    def _analyze_auth_error(self, error_message):
        """Analyze general authentication errors"""
        self.results["error_type"] = "auth_failure"
        self.results["root_cause"] = "Authentication failed for the specified model provider"
        self.results["solution"] = "Verify your authentication credentials and re-authenticate if necessary"
        self.results["severity"] = "high"
        return self.results
    
    def _analyze_generic_error(self, error_message):
        """Analyze generic errors"""
        self.results["error_type"] = "unknown"
        self.results["root_cause"] = "Unknown error occurred"
        self.results["solution"] = "Check OpenClaw logs for more details: openclaw logs --follow"
        self.results["severity"] = "medium"
        return self.results

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) != 2:
        print("Usage: python3 error_analyzer.py \"error message\"")
        sys.exit(1)
    
    error_message = sys.argv[1]
    analyzer = ErrorAnalyzer()
    results = analyzer.analyze_error(error_message)
    print(json.dumps(results, indent=2))