#!/usr/bin/env python3
"""
OpenClaw System Guardian - Configuration Checksum Validator

Generates and validates checksums for critical OpenClaw configuration files.
Detects unauthorized or accidental configuration changes.
"""

import os
import json
import hashlib
from pathlib import Path
from datetime import datetime

class ConfigValidator:
    def __init__(self, workspace_path="/root/.openclaw/workspace/agents/master"):
        self.workspace = Path(workspace_path)
        self.checksum_dir = self.workspace / "backups" / "system_guardian" / "checksums"
        self.checksum_file = self.checksum_dir / "config_checksums.json"
        self.checksum_dir.mkdir(parents=True, exist_ok=True)
        
        # Critical configuration files to monitor
        self.critical_files = [
            "SOUL.md",
            "MEMORY.md",
            "AGENTS.md",
            "USER.md",
            "TOOLS.md",
            "openclaw.filtered.json",
            "crontab.txt",
            ".gitignore",
            "RECOVERY_CHECKLIST.md"
        ]
        
        # Critical directories to monitor
        self.critical_dirs = [
            "memory",
            "skills"
        ]
        
        # OpenClaw system configuration files (outside workspace)
        self.system_files = [
            "/root/.openclaw/openclaw.json",
            "/root/.openclaw/openclaw.filtered.json"
        ]
    
    def generate_checksums(self):
        """Generate checksums for all critical files and directories"""
        checksums = {
            "timestamp": datetime.now().isoformat(),
            "files": {},
            "directories": {},
            "system_files": {}
        }
        
        # Checksum workspace files
        for filename in self.critical_files:
            filepath = self.workspace / filename
            if filepath.exists():
                checksum = self._calculate_file_checksum(filepath)
                checksums["files"][filename] = {
                    "checksum": checksum,
                    "size": filepath.stat().st_size,
                    "modified": datetime.fromtimestamp(filepath.stat().st_mtime).isoformat()
                }
        
        # Checksum critical directories (structure + file list)
        for dirname in self.critical_dirs:
            dirpath = self.workspace / dirname
            if dirpath.exists():
                dir_checksum = self._calculate_directory_checksum(dirpath)
                checksums["directories"][dirname] = dir_checksum
        
        # Checksum system configuration files
        for filepath in self.system_files:
            filepath = Path(filepath)
            if filepath.exists():
                checksum = self._calculate_file_checksum(filepath)
                checksums["system_files"][str(filepath)] = {
                    "checksum": checksum,
                    "size": filepath.stat().st_size,
                    "modified": datetime.fromtimestamp(filepath.stat().st_mtime).isoformat()
                }
        
        # Save checksums
        with open(self.checksum_file, 'w') as f:
            json.dump(checksums, f, indent=2)
        
        return checksums
    
    def validate_checksums(self):
        """Validate current configuration against stored checksums"""
        if not self.checksum_file.exists():
            return {
                "status": "no_baseline",
                "message": "No baseline checksums found. Run generate_checksums() first."
            }
        
        # Load stored checksums
        with open(self.checksum_file, 'r') as f:
            stored_checksums = json.load(f)
        
        # Generate current checksums
        current_checksums = self.generate_checksums()
        
        # Compare checksums
        validation_results = {
            "timestamp": datetime.now().isoformat(),
            "baseline_timestamp": stored_checksums["timestamp"],
            "status": "valid",
            "changes": [],
            "missing_files": [],
            "new_files": [],
            "size_changes": []
        }
        
        # Check workspace files
        for filename, stored_data in stored_checksums["files"].items():
            if filename not in current_checksums["files"]:
                validation_results["missing_files"].append({
                    "file": filename,
                    "type": "workspace_file"
                })
                validation_results["status"] = "invalid"
            elif current_checksums["files"][filename]["checksum"] != stored_data["checksum"]:
                validation_results["changes"].append({
                    "file": filename,
                    "type": "content_changed",
                    "old_checksum": stored_data["checksum"],
                    "new_checksum": current_checksums["files"][filename]["checksum"],
                    "size_diff": current_checksums["files"][filename]["size"] - stored_data["size"]
                })
                validation_results["status"] = "invalid"
        
        # Check for new files
        for filename in current_checksums["files"]:
            if filename not in stored_checksums["files"]:
                validation_results["new_files"].append({
                    "file": filename,
                    "type": "workspace_file"
                })
        
        # Check system files
        for filepath, stored_data in stored_checksums["system_files"].items():
            if filepath not in current_checksums["system_files"]:
                validation_results["missing_files"].append({
                    "file": filepath,
                    "type": "system_file"
                })
                validation_results["status"] = "invalid"
            elif current_checksums["system_files"][filepath]["checksum"] != stored_data["checksum"]:
                validation_results["changes"].append({
                    "file": filepath,
                    "type": "system_config_changed",
                    "old_checksum": stored_data["checksum"],
                    "new_checksum": current_checksums["system_files"][filepath]["checksum"]
                })
                validation_results["status"] = "invalid"
        
        # Check directories
        for dirname, stored_checksum in stored_checksums["directories"].items():
            if dirname not in current_checksums["directories"]:
                validation_results["missing_files"].append({
                    "file": dirname,
                    "type": "directory"
                })
                validation_results["status"] = "invalid"
            elif current_checksums["directories"][dirname] != stored_checksum:
                validation_results["changes"].append({
                    "directory": dirname,
                    "type": "directory_structure_changed"
                })
                validation_results["status"] = "invalid"
        
        return validation_results
    
    def _calculate_file_checksum(self, filepath):
        """Calculate SHA256 checksum of a file"""
        sha256_hash = hashlib.sha256()
        with open(filepath, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()
    
    def _calculate_directory_checksum(self, dirpath):
        """Calculate checksum of directory structure and file list"""
        file_list = []
        for root, dirs, files in os.walk(dirpath):
            for file in sorted(files):
                filepath = Path(root) / file
                relpath = filepath.relative_to(dirpath)
                file_checksum = self._calculate_file_checksum(filepath)
                file_list.append(f"{relpath}:{file_checksum}")
        
        combined = "\n".join(sorted(file_list))
        return hashlib.sha256(combined.encode()).hexdigest()

if __name__ == "__main__":
    import sys
    
    validator = ConfigValidator()
    
    if len(sys.argv) > 1 and sys.argv[1] == "validate":
        results = validator.validate_checksums()
    else:
        results = validator.generate_checksums()
    
    print(json.dumps(results, indent=2))