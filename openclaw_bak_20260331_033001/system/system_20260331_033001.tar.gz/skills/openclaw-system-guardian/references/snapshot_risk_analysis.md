# 快照策略风险分析与规避方案

## 📊 当前快照策略

### **备份范围**
- ✅ **备份**: workspace内的所有文件（SOUL.md, MEMORY.md, AGENTS.md, USER.md, TOOLS.md等）
- ✅ **备份**: memory/目录（完整分层记忆系统）
- ✅ **备份**: skills/目录（所有技能配置和成长数据）
- ❌ **不备份**: /root/.openclaw/openclaw.json（系统级配置）
- ❌ **不备份**: /root/.openclaw/openclaw.filtered.json（系统级配置）

---

## ⚠️ **潜在风险分析**

### **风险 1：openclaw.json被破坏或丢失**
**风险等级**: 🔴 高

**可能场景**:
1. 系统崩溃导致文件损坏
2. OpenClaw升级过程中配置被覆盖
3. 误操作删除或修改关键配置
4. 磁盘故障导致文件丢失

**影响**:
- 所有Channel配置丢失（飞书、Telegram等）
- 模型配置丢失（API keys、fallback配置）
- Agent配置丢失（routing、workspace设置）
- 插件配置丢失

**规避方案**:
```bash
# 方案1: 在workspace中保留openclaw.json的符号链接或副本
ln -s /root/.openclaw/openclaw.json /root/.openclaw/workspace/main/openclaw.json.backup

# 方案2: 每小时同步openclaw.json到workspace
0 * * * * cp /root/.openclaw/openclaw.json /root/.openclaw/workspace/main/backups/system_guardian/openclaw.json.hourly

# 方案3: 使用Git版本控制openclaw.json
cd /root/.openclaw && git add openclaw.json && git commit -m "Backup openclaw.json"
```

---

### **风险 2：OpenClaw升级覆盖配置**
**风险等级**: 🟠 中高

**可能场景**:
1. `openclaw update`命令覆盖用户自定义配置
2. 新版本配置格式不兼容旧版本
3. 升级过程中断导致配置损坏

**影响**:
- Channel配置需要重新配置
- 模型API keys需要重新输入
- 自定义Agent设置丢失

**规避方案**:
```bash
# 方案1: 升级前自动备份
openclaw update --pre-backup  # 假设有此选项

# 方案2: 手动备份后升级
cp /root/.openclaw/openclaw.json /root/.openclaw/workspace/main/backups/system_guardian/openclaw.pre-upgrade.json
openclaw update
# 如果升级后有问题，恢复备份

# 方案3: 使用配置管理工具
# 将openclaw.json纳入版本控制，升级后对比差异
```

---

### **风险 3：敏感信息泄露**
**风险等级**: 🟡 中

**可能场景**:
1. 快照文件包含明文API keys
2. GitHub仓库公开导致配置泄露
3. 备份文件权限设置不当

**影响**:
- API keys被盗用
- 云服务配额被滥用
- 安全风险

**规避方案**:
```bash
# 方案1: 使用占位符机制
# 快照中使用{{FEISHU_APP_ID}}代替实际值
# 实际值存储在安全位置（如~/.openclaw/credentials/）

# 方案2: 加密敏感配置
# 使用gpg或age加密openclaw.json中的敏感字段

# 方案3: 分离敏感配置
# 将敏感信息移到独立文件，设置严格权限
chmod 600 /root/.openclaw/credentials/*
```

---

### **风险 4：skills目录过大**
**风险等级**: 🟢 低

**可能场景**:
1. skills目录包含大量成长数据
2. 快照文件过大导致备份缓慢
3. GitHub仓库超出免费配额

**影响**:
- 备份时间过长
- 存储空间不足
- GitHub推送失败

**规避方案**:
```bash
# 方案1: 增量备份
# 只备份变化的文件，使用rsync或git

# 方案2: 压缩快照
tar -czf snapshot.tar.gz skills/

# 方案3: 定期清理旧快照
# 只保留最近7天的快照
find /root/.openclaw/workspace/main/backups -name "*.tar.gz" -mtime +7 -delete
```

---

## ✅ **推荐的快照优化策略**

### **策略 1：分层备份**
```
Level 1 (每小时): openclaw.json → workspace/backups/
Level 2 (每天): 完整workspace快照 → GitHub
Level 3 (每周): 完整系统备份 → 外部存储
```

### **策略 2：敏感信息分离**
```
敏感配置：/root/.openclaw/credentials/ (不备份到GitHub)
普通配置：/root/.openclaw/workspace/main/ (备份到GitHub)
```

### **策略 3：升级前自动备份**
```bash
# 在openclaw update前自动执行
cp /root/.openclaw/openclaw.json /root/.openclaw/workspace/main/backups/system_guardian/openclaw.pre-$(date +%Y%m%d_%H%M%S).json
```

---

## 📋 **实施建议**

1. **立即实施**: 
   - 每小时同步openclaw.json到workspace
   - 升级前手动备份openclaw.json

2. **短期实施** (1周内):
   - 实现敏感信息占位符机制
   - 配置Git版本控制openclaw.json

3. **长期实施** (1个月内):
   - 实现增量备份机制
   - 配置外部存储备份

---

## 🔍 **结论**

**不备份openclaw.json的风险是可控的**，前提是：
1. ✅ 实施每小时同步机制
2. ✅ 升级前手动备份
3. ✅ 使用Git版本控制
4. ✅ 分离敏感信息存储

**建议**: 保留当前策略（不备份openclaw.json到快照），但增加每小时同步机制作为补偿。
