# 🎬 视频专家分析报告

## 📋 基本信息

| 项目 | 内容 |
|------|------|
| **视频 ID** | {video_id} |
| **来源 URL** | {url} |
| **分析时间** | {analysis_date} |
| **视频大小** | {video_size_mb} MB |
| **场景数量** | {scene_count} 个 |
| **转录语言** | {transcription_language} |
| **字幕段数** | {transcription_segments} 段 |

---

## 🎯 分析方法论

本报告基于 **Walter Murch 剪辑六法则** 和 **动态权重评分系统**：

### 核心哲学
> **情感 > 故事 > 节奏 > 视线追踪 > 2D平面 > 3D空间**
> 
> 一个情感真挚但画面略抖的镜头，优于一个画面完美但内容空洞的镜头。

### 五维评分体系 (1-10分制)

| 维度 | 权重 | 评估要点 |
|------|------|---------|
| **美感 (Aesthetic)** | 20% | 构图(三分法)、光影质感、色彩和谐度 |
| **可信度 (Credibility)** | 20% | 表演自然度、物理逻辑、无出戏感 |
| **冲击力 (Impact)** | 20% | 视觉显著性(Saliency)、动态张力 |
| **记忆度 (Memorability)** | 20% | 独特视觉符号(Von Restorff效应)、金句、趣味性 |
| **趣味度 (Fun/Interest)** | 20% | 参与感、娱乐价值、社交货币潜力 |

### 场景类型与权重适配

- **TYPE-A Hook/高能型**: IMPACT 40% + MEMORABILITY 30% + SYNC 20%
- **TYPE-B 叙事/情感型**: CREDIBILITY 40% + MEMORABILITY 30% + AESTHETICS 20%
- **TYPE-C 氛围/空镜型**: AESTHETICS 50% + SYNC 30% + IMPACT 20%
- **TYPE-D 商业/展示型**: CREDIBILITY 40% + MEMORABILITY 40% + AESTHETICS 20%

### 筛选决策规则

| 等级 | 标准 | 用途 |
|------|------|------|
| 🌟 **MUST KEEP** | 加权总分 > 8.5 或 任意单项 = 10 | 核心素材，极致长板 |
| 📁 **USABLE** | 7.0 <= 加权总分 < 8.5 | 过渡素材，辅助叙事 |
| 🗑️ **DISCARD** | 加权总分 < 7.0 或存在致命瑕疵 | 建议舍弃 |

---

## 📝 视频内容概述

### 转录文本

```
{transcript_text}
```

### 内容主题分析

*(请在完成场景评分后，由分析师填写)*

- **视频类型**: TODO (广告/剧情/Vlog/教程/其他)
- **核心主题**: TODO 
- **目标受众**: TODO
- **情感基调**: TODO (励志/搞笑/温馨/悬疑/其他)
- **商业意图**: TODO (如有)

---

## 🎞️ 场景详细分析

### 场景列表概览

| 场景编号 | 类型 | 加权得分 | 筛选建议 | 片段路径 |
|---------|------|---------|---------|---------|
{scene_list_table}

### 各场景详细评估

*(以下部分需要基于帧图片进行专业分析后填写)*

{detailed_scene_evaluations}

---

## ⭐ 精选片段推荐

### 入选精选文件夹的片段

*(完成评分后，得分 >= {best_threshold} 的片段将自动入选)*

**入选标准**: 加权总分 >= {best_threshold} 或 单项得分 = 10 (极致长板)

**精选片段位置**: `scenes/best_shots/`

{best_shots_table}

### 最佳 Hook 候选
> TODO: 基于 IMPACT 和 MEMORABILITY 得分，推荐最适合作为开场 Hook 的场景

### 最佳情感片段
> TODO: 基于 CREDIBILITY 得分，推荐最能建立共情的场景

### 最佳视觉片段  
> TODO: 基于 AESTHETICS 得分，推荐视觉最精美的场景

---

## 📊 整体影片评价

### 综合评分

| 评价维度 | 得分 (1-10) | 评价说明 |
|---------|------------|---------|
| 整体美感 | TODO | TODO |
| 叙事连贯性 | TODO | TODO |
| 情感共鸣度 | TODO | TODO |
| 商业转化力 | TODO | TODO (如适用) |
| 病毒传播潜力 | TODO | TODO |
| **综合得分** | **TODO** | - |

### 优势分析
> TODO: 总结视频的核心优势和亮点

### 改进建议
> TODO: 基于 Walter Murch 法则提出具体的改进建议

### 最终 verdict
| 评价项 | 结论 |
|-------|------|
| **是否值得保留** | TODO |
| **推荐使用场景** | TODO |
| **二次创作建议** | TODO |

---

## 📁 文件结构

```
{video_output_dir_name}/
├── {video_id}.mp4                    # 完整视频
├── {video_id}.m4a                    # 音频文件
├── {video_id}.srt                    # 字幕文件
├── {video_id}_transcript.txt         # 转录文本
├── scene_scores.json                      # 评分模板
├── {video_id}_analysis_report.md     # 基础报告
├── {video_id}_detailed_analysis.md   # 本详细报告
├── scenes/                                # 场景片段
│   ├── {video_id}-Scene-001.mp4
│   ├── {video_id}-Scene-002.mp4
│   ├── ...
│   └── best_shots/                        # ⭐ 精选片段
│       ├── (评分后自动复制入选片段)
├── frames/                                # 场景预览帧
│   ├── {video_id}-Scene-001.jpg
│   └── ...
```

---

## 📝 后续步骤

1. **查看帧图片**: 打开 `frames/` 目录查看每个场景的预览
2. **完成评分**: 编辑 `scene_scores.json`，为每个场景填写评分和评价
3. **计算排名**: 运行 `python3 scripts/scoring_helper_enhanced.py scene_scores.json calculate`
4. **生成精选**: 运行 `python3 scripts/scoring_helper_enhanced.py scene_scores.json best`
5. **完善报告**: 根据评分结果，完善本报告的 TODO 部分

---

*本报告由 Video Expert Analyzer 自动生成*
*基于 Walter Murch 剪辑六法则 和 动态权重评分系统*
