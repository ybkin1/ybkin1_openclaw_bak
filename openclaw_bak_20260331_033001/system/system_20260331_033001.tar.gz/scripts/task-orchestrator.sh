#!/bin/bash
# task-orchestrator.sh - 任务编排器
# 每日 08:00 自动运行，创建当日任务并发送通知

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
TASKS_DIR="$BASE_DIR/tasks"
TASKS_ACTIVE_DIR="$TASKS_DIR/active"
PLAN_FILE="$BASE_DIR/memory/config/task-execution-plan-p0-to-p3.md"
LOG_FILE="$BASE_DIR/logs/task-orchestrator.log"
STATE_FILE="$BASE_DIR/memory/master/orchestrator-state.json"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保目录存在
mkdir -p "$TASKS_ACTIVE_DIR"
mkdir -p "$BASE_DIR/logs"
mkdir -p "$BASE_DIR/memory/master"
mkdir -p "$BASE_DIR/reports/daily"

# 发送通知函数
send_notification() {
    local title="$1"
    local content="$2"
    
    log_info "发送通知：$title - $content"
    # TODO: 集成飞书通知 API
    # 当前仅记录日志
}

# 读取编排器状态
read_state() {
    if [ -f "$STATE_FILE" ]; then
        cat "$STATE_FILE"
    else
        echo '{"lastRun": null, "lastTask": null, "totalTasks": 0}'
    fi
}

# 保存编排器状态
save_state() {
    local state="$1"
    echo "$state" > "$STATE_FILE"
}

# 解析今日任务
parse_today_tasks() {
    local current_date=$(date +%s)
    local week1_end=$(date -d "2026-03-31" +%s)
    local week2_end=$(date -d "2026-04-07" +%s)
    local week3_end=$(date -d "2026-04-14" +%s)
    
    if [ $current_date -le $week1_end ]; then
        echo "W1"  # M1 已完成
    elif [ $current_date -le $week2_end ]; then
        echo "W2"  # M2: P1 任务
    elif [ $current_date -le $week3_end ]; then
        echo "W3"  # M3: P2 任务
    else
        echo "W4"  # M4: P3 任务
    fi
}

# 创建任务状态文件
create_task_state() {
    local task_id="$1"
    local task_name="$2"
    local milestone="$3"
    local expected_duration="$4"  # 秒
    local current_step="$5"
    
    local state_file="$TASKS_ACTIVE_DIR/${task_id}.json"
    local timestamp=$(date -Iseconds)
    
    log_info "创建任务状态文件：$task_id"
    
    cat > "$state_file" << EOF
{
  "taskId": "$task_id",
  "taskName": "$task_name",
  "milestone": "$milestone",
  "status": "pending",
  "progress": 0,
  "createdAt": "$timestamp",
  "startedAt": null,
  "lastActivity": "$timestamp",
  "expectedDuration": $expected_duration,
  "currentStep": "$current_step",
  "nextStep": "等待启动",
  "checkpoints": [],
  "context": {
    "summary": "",
    "dependencies": [],
    "blockers": []
  },
  "antiHallucination": {
    "dataSupport": null,
    "comparisonAnalysis": null,
    "testCaseCount": 0,
    "userConfirmed": false
  },
  "cost": {
    "inputTokens": 0,
    "outputTokens": 0,
    "totalTokens": 0,
    "estimatedCost": 0
  }
}
EOF
    
    log_info "✓ 任务状态文件已创建：$state_file"
}

# 主程序
main() {
    log_info "=========================================="
    log_info "开始任务编排"
    log_info "=========================================="
    
    # 读取状态
    local state=$(read_state)
    local last_run=$(echo "$state" | jq -r '.lastRun')
    
    # 检查是否已运行（避免重复）
    local today=$(date +%Y-%m-%d)
    if [ "$last_run" = "$today" ]; then
        log_info "今日已运行，跳过"
        exit 0
    fi
    
    # 解析本周任务
    local week=$(parse_today_tasks)
    log_info "当前周次：$week"
    
    local task_count=0
    
    # 根据日期创建任务（连续执行，不等待）
    case "$week" in
        "W1")
            # P0 已完成，立即开始 P1
            log_info "P0 已完成，开始创建 P1 任务"
            
            # P1-1: SOP 具象化（明天就开始）
            if [ ! -f "$TASKS_ACTIVE_DIR/P1-1-sop-enforcement.json" ]; then
                create_task_state \
                    "P1-1-sop-enforcement" \
                    "SOP 具象化" \
                    "M1" \
                    259200  # 3 天 = 259200 秒
                    "设计 SOP 状态机"
                task_count=$((task_count + 1))
                log_info "✓ 创建任务：P1-1 SOP 具象化（预计完成：$(date -d "+3 days" +%Y-%m-%d)）"
            fi
            ;;
        "W2")
            # M2: P1 任务（如果还有未完成）
            log_info "检查 P1 任务完成情况"
            
            # P1-1: SOP 具象化
            if [ ! -f "$TASKS_ACTIVE_DIR/P1-1-sop-enforcement.json" ] && \
               [ ! -f "$TASKS_DIR/completed/P1-1-sop-enforcement.json" ]; then
                create_task_state \
                    "P1-1-sop-enforcement" \
                    "SOP 具象化" \
                    "M2" \
                    259200 \
                    "设计 SOP 状态机"
                task_count=$((task_count + 1))
            fi
            
            # P1-2: 成本追踪
            if [ -f "$TASKS_DIR/completed/P1-1-sop-enforcement.json" ] && \
               [ ! -f "$TASKS_ACTIVE_DIR/P1-2-cost-tracking.json" ] && \
               [ ! -f "$TASKS_DIR/completed/P1-2-cost-tracking.json" ]; then
                create_task_state \
                    "P1-2-cost-tracking" \
                    "成本追踪" \
                    "M2" \
                    259200 \
                    "调研 OpenClaw 原生支持"
                task_count=$((task_count + 1))
                log_info "✓ 创建任务：P1-2 成本追踪（预计完成：$(date -d "+3 days" +%Y-%m-%d)）"
            fi
            ;;
        "W3")
            # M3: P2 任务
            log_info "创建 M3 任务（P2 任务）"
            
            # P2-1: 记忆清理
            if [ ! -f "$TASKS_ACTIVE_DIR/P2-1-memory-cleanup.json" ]; then
                create_task_state \
                    "P2-1-memory-cleanup" \
                    "记忆清理策略" \
                    "M3" \
                    604800  # 7 天
                    "设计清理策略"
                task_count=$((task_count + 1))
            fi
            
            # P2-2: 日志轮转
            if [ ! -f "$TASKS_ACTIVE_DIR/P2-2-log-rotation.json" ]; then
                create_task_state \
                    "P2-2-log-rotation" \
                    "日志轮转" \
                    "M3" \
                    259200  # 3 天
                    "配置 logrotate"
                task_count=$((task_count + 1))
            fi
            
            # P2-3: 反馈闭环
            if [ ! -f "$TASKS_ACTIVE_DIR/P2-3-feedback-loop.json" ]; then
                create_task_state \
                    "P2-3-feedback-loop" \
                    "用户反馈闭环" \
                    "M3" \
                    259200 \
                    "设计反馈模板"
                task_count=$((task_count + 1))
            fi
            ;;
        "W4")
            # M4: P3 任务
            log_info "创建 M4 任务（P3 任务）"
            
            # P3-1: 自适应重规划
            if [ ! -f "$TASKS_ACTIVE_DIR/P3-1-adaptive-replan.json" ]; then
                create_task_state \
                    "P3-1-adaptive-replan" \
                    "自适应重规划" \
                    "M4" \
                    259200 \
                    "设计重规划算法"
                task_count=$((task_count + 1))
            fi
            
            # P3-2: 技能加载
            if [ ! -f "$TASKS_ACTIVE_DIR/P3-2-skill-loading.json" ]; then
                create_task_state \
                    "P3-2-skill-loading" \
                    "技能按需加载" \
                    "M4" \
                    345600  # 4 天
                    "技能需求分析"
                task_count=$((task_count + 1))
            fi
            
            # P3-3: 磁盘监控
            if [ ! -f "$TASKS_ACTIVE_DIR/P3-3-disk-monitor.json" ]; then
                create_task_state \
                    "P3-3-disk-monitor" \
                    "磁盘空间监控" \
                    "M4" \
                    259200 \
                    "设计监控方案"
                task_count=$((task_count + 1))
            fi
            ;;
        *)
            log_warn "未知周次：$week"
            ;;
    esac
    
    # 更新状态
    local new_state=$(echo "$state" | jq --arg today "$today" \
                                         --argjson count "$task_count" \
                                         '.lastRun = $today | .totalTasks = (.totalTasks + $count)')
    save_state "$new_state"
    
    # 发送通知
    if [ $task_count -gt 0 ]; then
        send_notification "任务编排完成" "今日创建 $task_count 个新任务"
        log_info "✓ 任务编排完成：创建 $task_count 个新任务"
    else
        log_info "✓ 任务编排完成：无新任务"
    fi
    
    log_info "=========================================="
}

# 运行主程序
main "$@"
