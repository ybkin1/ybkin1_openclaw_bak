#!/bin/bash
# Task Scheduler - 安全增强版
set -euo pipefail

# ==================== 配置 ====================
WORKSPACE="/root/.openclaw/workspace"
MASTER_MEMORY="$WORKSPACE/agents/master/memory/master"
ACTIVE_TASKS="$MASTER_MEMORY/tasks/active"
PROCESSING_TASKS="$MASTER_MEMORY/tasks/processing"
COMPLETED_TASKS="$MASTER_MEMORY/tasks/completed"
FAILED_TASKS="$MASTER_MEMORY/tasks/failed"
LOGFILE="$WORKSPACE/agents/master/logs/task-scheduler.log"
PIDFILE="/tmp/task-scheduler.pid"
MAX_CONCURRENT=10
SCAN_INTERVAL=30

# ==================== 安全限制 ====================
ulimit -n 1024
ulimit -u 1000

mkdir -p "$PROCESSING_TASKS" "$COMPLETED_TASKS" "$FAILED_TASKS" "$(dirname "$LOGFILE")" 2>/dev/null || true

# 日志函数
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOGFILE"; }
error() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ $*" | tee -a "$LOGFILE" >&2; }
info() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] ℹ️  $*" | tee -a "$LOGFILE"; }
success() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✅ $*" | tee -a "$LOGFILE"; }

# ==================== 工具函数 ====================
check_single_instance() {
    if [ -f "$PIDFILE" ]; then
        local old_pid=$(cat "$PIDFILE" 2>/dev/null || echo "")
        if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
            error "调度器已在运行 (PID: $old_pid)"
            return 1
        else
            info "清理僵PID文件: $PIDFILE"
            rm -f "$PIDFILE"
        fi
    fi
    return 0
}

classify_task() {
    local task_file="$1"
    local file_size=$(stat -c%s "$task_file" 2>/dev/null || echo 0)
    if [ "$file_size" -gt 1048576 ]; then
        error "任务文件过大: $task_file ($file_size bytes)"
        return 1
    fi
    
    local task_text=$(head -c 65536 "$task_file" 2>/dev/null || echo "")
    if echo "$task_text" | grep -Ei 'complex|multiple steps|break down|分解|助手|assistant|cognitive' >/dev/null; then
        echo "COMPLEX"
    elif echo "$task_text" | grep -Ei 'simple|quick|single|direct|immediate|单步|直接|立即' >/dev/null; then
        echo "SIMPLE"
    else
        echo "COMPLEX"
    fi
}

process_task() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json | sed 's/task_//;s/\.json$//')
    [ -z "$task_id" ] && task_id="unknown_$(date +%s)"
    
    local processing_count=$(find "$PROCESSING_TASKS" -type f 2>/dev/null | wc -l)
    if [ "$processing_count" -ge "$MAX_CONCURRENT" ]; then
        info "并发数已达到上限($MAX_CONCURRENT)，跳过任务: $task_id"
        return 0
    fi

    local task_type=$(classify_task "$task_file") || {
        error "任务分类失败: $task_id"
        mv "$task_file" "$FAILED_TASKS/" 2>/dev/null || true
        return 1
    }

    info "处理任务: $task_id (类型: $task_type)"

    local processing_file="$PROCESSING_TASKS/$(basename "$task_file")"
    if ! mv "$task_file" "$processing_file" 2>/dev/null; then
        error "无法移动任务文件: $task_file"
        return 1
    fi

    if [ "$task_type" = "COMPLEX" ]; then
        local title="$task_id"
        local description=""
        if command -v jq &>/dev/null; then
            title=$(jq -r '.title // .task_id' "$processing_file" 2>/dev/null || echo "$task_id")
            description=$(jq -r '.description // (.requirements[0] // "Task $task_id")' "$processing_file" 2>/dev/null || echo "Task $task_id")
        fi
        [ -z "$description" ] && description="Task $task_id"

        info "调用路由器: $title"

        local router_output
        router_output=$("/root/.openclaw/workspace/agents/master/scripts/task-router.sh" "$description" "$title" 2>&1) || true
        local router_exit=$?
        local routed_to=$(echo "$router_output" | grep '^ROUTED_TO=' | head -1 | cut -d= -f2)

        if [ "$routed_to" = "assistant" ]; then
            success "任务已路由给 Assistant: $task_id"
            echo "{\"status\":\"routed\",\"agent\":\"assistant\",\"timestamp\":\"$(date -Iseconds)\"}" > "$processing_file.status"
        elif [ "$routed_to" = "master" ] || [ $router_exit -eq 1 ]; then
            info "任务标记为 Master 处理: $task_id"
            echo "{\"status\":\"pending_master_execution\",\"agent\":\"master\",\"timestamp\":\"$(date -Iseconds)\"}" > "$processing_file.status"
        else
            error "路由异常: $task_id (exit=$router_exit, output=$router_output)"
            mv "$processing_file" "$FAILED_TASKS/" 2>/dev/null || error "移动失败任务出错"
        fi
    else
        info "标记为需要 Master 处理（待实现执行器）: $task_id"
        echo "{\"status\":\"pending_master_execution\",\"agent\":\"master\",\"timestamp\":\"$(date -Iseconds)\"}" > "$processing_file.status"
    fi
}

main() {
    check_single_instance || return 1
    echo $$ > "$PIDFILE"
    log "=== 任务调度器启动 (PID: $$) ==="
    mkdir -p "$ACTIVE_TASKS"
    
    local start_time=$(date +%s)
    local task_count=0
    
    trap 'log "收到终止信号，正在退出..."; rm -f "$PIDFILE"; exit 0' INT TERM EXIT
    
    while true; do
        local now=$(date +%s)
        local elapsed=$((now - start_time))
        if [ $((elapsed / 3600)) -ge 24 ]; then
            log "运行超过24小时，计划重启..."
            break
        fi
        
        shopt -s nullglob
        local processing_count=0
        processing_count=$(find "$PROCESSING_TASKS" -type f 2>/dev/null | wc -l)
        for task in "$ACTIVE_TASKS"/*.json; do
            [ -e "$task" ] || continue
            process_task "$task" || error "任务处理异常: $task"
            task_count=$((task_count + 1))
        done
        shopt -u nullglob
        
        if [ $((task_count % 120)) -eq 0 ] && [ $task_count -gt 0 ]; then
            info "健康检查: 已处理 $task_count 个任务，并发 $processing_count"
        fi
        
        sleep "$SCAN_INTERVAL"
    done
    
    rm -f "$PIDFILE"
    log "=== 任务调度器正常退出 ==="
}

daemonize() {
    if [ -t 0 ]; then
        nohup "$0" "$@" > /dev/null 2>&1 &
        local daemon_pid=$!
        echo $daemon_pid > "$PIDFILE"
        echo "调度器已后台启动 (PID: $daemon_pid)"
        exit 0
    else
        main "$@"
    fi
}

case "${1:-}" in
    start|daemon)
        shift
        daemonize "$@"
        ;;
    stop)
        if [ -f "$PIDFILE" ]; then
            kill "$(cat "$PIDFILE")" 2>/dev/null && rm -f "$PIDFILE"
            echo "调度器已停止"
        else
            echo "调度器未运行"
        fi
        exit 0
        ;;
    status)
        if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
            echo "调度器运行中 (PID: $(cat "$PIDFILE"))"
            exit 0
        else
            echo "调度器未运行"
            exit 3
        fi
        ;;
    *)
        main "$@"
        ;;
esac
