#!/usr/bin/env python3
"""
Memory Cron Job - 记忆定时清理任务

每小时执行一次，清理过期记忆并生成报告
"""

import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path

# 添加路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from cleanup_memories import cleanup_memories, check_memory_health, export_memory_stats

# 配置日志
LOG_DIR = '/root/.openclaw/logs'
LOG_FILE = os.path.join(LOG_DIR, 'memory-cron.log')

os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger('memory-cron')


def run_memory_cleanup():
    """执行记忆清理"""
    logger.info("=" * 60)
    logger.info("开始执行记忆清理任务")
    logger.info(f"时间：{datetime.now().isoformat()}")
    logger.info("=" * 60)
    
    try:
        # 1. 清理过期记忆
        logger.info("步骤 1: 清理过期记忆...")
        cleanup_result = cleanup_memories(
            db_path='/root/.openclaw/workspace/agents/master/memory.db',
            dry_run=False
        )
        logger.info(f"清理完成：{cleanup_result['status']}")
        
        # 2. 健康检查
        logger.info("步骤 2: 健康检查...")
        health_result = check_memory_health(
            db_path='/root/.openclaw/workspace/agents/master/memory.db'
        )
        logger.info(f"健康状态：{health_result.get('status', 'unknown')}")
        
        # 3. 导出统计
        logger.info("步骤 3: 导出统计...")
        stats_result = export_memory_stats(
            db_path='/root/.openclaw/workspace/agents/master/memory.db',
            output_file='/root/.openclaw/workspace/agents/master/memory/cron-stats.json'
        )
        logger.info(f"统计导出：{stats_result.get('timestamp', 'unknown')}")
        
        # 4. 生成报告
        logger.info("步骤 4: 生成报告...")
        report = generate_report(cleanup_result, health_result, stats_result)
        save_report(report)
        
        logger.info("=" * 60)
        logger.info("记忆清理任务完成")
        logger.info("=" * 60)
        
        return {
            'status': 'success',
            'timestamp': datetime.now().isoformat(),
            'report': report
        }
    
    except Exception as e:
        logger.error(f"任务执行失败：{e}", exc_info=True)
        return {
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }


def generate_report(cleanup_result, health_result, stats_result):
    """生成清理报告"""
    report = {
        'timestamp': datetime.now().isoformat(),
        'cleanup': {
            'status': cleanup_result.get('status', 'unknown'),
            'working_memory_before': cleanup_result.get('stats_before', {}).get('working_memory_count', 0),
            'working_memory_after': cleanup_result.get('stats_after', {}).get('working_memory_count', 0),
            'semantic_memory_before': cleanup_result.get('stats_before', {}).get('semantic_memory_count', 0),
            'semantic_memory_after': cleanup_result.get('stats_after', {}).get('semantic_memory_count', 0),
            'fact_count': cleanup_result.get('stats_after', {}).get('fact_count', 0),
        },
        'health': {
            'status': health_result.get('status', 'unknown'),
            'conflicts': health_result.get('conflicts', 0),
        },
        'stats': stats_result.get('stats', {})
    }
    
    return report


def save_report(report):
    """保存报告"""
    report_dir = '/root/.openclaw/workspace/agents/master/memory/reports'
    os.makedirs(report_dir, exist_ok=True)
    
    # 按日期保存
    date_str = datetime.now().strftime('%Y-%m-%d')
    report_file = os.path.join(report_dir, f'cron-report-{date_str}.json')
    
    # 追加到文件
    reports = []
    if os.path.exists(report_file):
        try:
            with open(report_file, 'r') as f:
                reports = json.load(f)
        except:
            reports = []
    
    reports.append(report)
    
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(reports, f, indent=2, ensure_ascii=False)
    
    logger.info(f"报告已保存：{report_file}")


def main():
    """主函数"""
    result = run_memory_cleanup()
    
    # 退出码
    if result['status'] == 'success':
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == '__main__':
    main()
