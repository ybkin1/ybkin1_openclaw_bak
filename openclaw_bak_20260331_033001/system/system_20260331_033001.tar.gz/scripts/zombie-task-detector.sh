#!/bin/bash
# zombie-task-detector.sh - 僵尸任务检测
# 每 10 分钟检查一次，超过 30 分钟无心跳的任务标记为僵尸

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
TASKS_ACTIVE_DIR="$BASE_DIR/memory/tasks/active"
TASKS_PAUSED_DIR="$BASE_DIR/memory/tasks/paused"
LOG_FILE="$BASE_DIR/logs/zombie-task-detector.log"

# 配置
IDLE_TIMEOUT=1800  # 30 分钟（秒）
ALERT_COOLDOWN=3600  # 告警冷却时间 1 小时（秒）
STALE_THRESHOLD=604800  # 7 天（秒）- 超期任务阈值

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保目录存在
mkdir -p "$TASKS_PAUSED_DIR"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "/tmp/task-alerts"  # 告警冷却文件目录

# 发送通知函数
send_notification() {
    local title="$1"
    local content="$2"
    
    log_info "发送通知：$title - $content"
    # TODO: 集成飞书通知 API
}

# 检测僵尸任务
check_zombie_tasks() {
    log_info "=== 开始僵尸任务检测 ==="
    
    if [ ! -d "$TASKS_ACTIVE_DIR" ]; then
        log_warn "活跃任务目录不存在：$TASKS_ACTIVE_DIR"
        return 0
    fi
    
    # 检测超期任务（超过 7 天）
    check_stale_tasks
    
    current_ts=$(date +%s)
    zombie_count=0
    alerted_count=0
    
    for task_file in "$TASKS_ACTIVE_DIR"/*.json; do
        if [ ! -f "$task_file" ]; then
            continue
        fi
        
        task_name=$(basename "$task_file")
        task_id=$(jq -r '.taskId' "$task_file" 2>/dev/null || echo "unknown")
        last_activity=$(jq -r '.lastActivity' "$task_file" 2>/dev/null || echo "")
        
        # 跳过无最后活动时间的任务（刚创建）
        if [ -z "$last_activity" ] || [ "$last_activity" = "null" ]; then
            log_info "跳过无心跳任务：$task_name（刚创建）"
            continue
        fi
        
        # 计算时间差
        last_activity_ts=$(date -d "$last_activity" +%s 2>/dev/null || echo "0")
        elapsed=$((current_ts - last_activity_ts))
        
        log_info "检查任务：$task_name (ID: $task_id, 无活动：${elapsed}s)"
        
        # 超过阈值，标记为僵尸
        if [ $elapsed -gt $IDLE_TIMEOUT ]; then
            log_warn "发现僵尸任务：$task_name (无活动 ${elapsed}s)"
            
            # 检查是否已发送过告警（冷却机制）
            alert_file="/tmp/task-alerts/alerted_${task_name}"
            if [ -f "$alert_file" ]; then
                alert_ts=$(cat "$alert_file")
                alert_elapsed=$((current_ts - alert_ts))
                
                if [ $alert_elapsed -lt $ALERT_COOLDOWN ]; then
                    log_info "告警冷却中，跳过：$task_name (${alert_elapsed}s < ${ALERT_COOLDOWN}s)"
                    continue
                fi
            fi
            
            # 更新状态为 paused
            current_time=$(date -Iseconds)
            jq --arg time "$current_time" --arg reason "zombie_detected" --arg elapsed "$elapsed" \
               '.status = "paused" | .pauseReason = $reason | .zombieElapsed = ($elapsed|tonumber) | .pausedAt = $time' \
               "$task_file" > "${task_file}.tmp"
            
            if [ $? -eq 0 ]; then
                # 移动到 paused 目录
                mv "${task_file}.tmp" "$TASKS_PAUSED_DIR/$task_name"
                
                # 创建僵尸任务报告
                report_file="$TASKS_PAUSED_DIR/${task_name%.json}.zombie-report"
                cat > "$report_file" << EOF
# 僵尸任务报告

**任务 ID**: $task_id
**文件名称**: $task_name
**检测时间**: $current_time
**无活动时长**: ${elapsed}秒 ($(echo "scale=2; $elapsed/60" | bc) 分钟)
**最后活动时间**: $last_activity

## 可能原因
- 任务执行卡死
- Agent 崩溃
- 系统资源不足
- 网络中断

## 建议操作
1. 检查任务日志
2. 确认是否需要继续执行
3. 如需继续，手动恢复任务状态
4. 如不需要，删除任务文件

## 自动操作记录
- [x] 检测到僵尸任务
- [x] 标记为 paused 状态
- [x] 移动到 paused 目录
- [ ] 发送告警通知
EOF
                
                zombie_count=$((zombie_count + 1))
                log_warn "✓ 僵尸任务已标记：$task_name"
                
                # 发送告警
                send_notification "僵尸任务告警" "检测到僵尸任务 $task_id，已无活动 ${elapsed}秒，请检查处理"
                
                # 记录告警时间（冷却机制）
                echo "$current_ts" > "$alert_file"
                alerted_count=$((alerted_count + 1))
            else
                log_error "标记失败：$task_name"
                rm -f "${task_file}.tmp"
            fi
        fi
    done
    
    log_info "=== 检测完成 ==="
    log_info "检测任务数：$(ls -1 "$TASKS_ACTIVE_DIR"/*.json 2>/dev/null | wc -l)"
    log_info "僵尸任务数：$zombie_count"
    log_info "发送告警数：$alerted_count"
}

# 清理过期的告警冷却文件
cleanup_alert_files() {
    log_info "清理过期告警文件..."
    find /tmp/task-alerts -name "alerted_*" -mmin +60 -delete 2>/dev/null || true
}

# 检测超期任务（超过 7 天无进展）
check_stale_tasks() {
    log_info "检测超期任务（阈值：7 天）..."
    
    local stale_count=0
    local current_ts=$(date +%s)
    
    for task_file in "$TASKS_ACTIVE_DIR"/*.json; do
        [ -f "$task_file" ] || continue
        
        # 跳过 FILE-AGENT-DEV（有独立状态文件）
        [[ "$(basename "$task_file")" == *"FILE-AGENT"* ]] && continue
        
        # 获取创建时间
        created_at=$(jq -r '.created_at // empty' "$task_file" 2>/dev/null)
        [ -z "$created_at" ] && continue
        
        # 转换为时间戳
        created_ts=$(date -d "$created_at" +%s 2>/dev/null || echo 0)
        [ "$created_ts" -eq 0 ] && continue
        
        # 计算任务年龄
        age=$((current_ts - created_ts))
        age_days=$((age / 86400))
        
        # 检查是否超期
        if [ $age -gt $STALE_THRESHOLD ]; then
            task_id=$(jq -r '.task_id // "unknown"' "$task_file")
            title=$(jq -r '.title // "无标题"' "$task_file")
            progress=$(jq -r '.progress // 0' "$task_file")
            
            log_warn "⚠️  超期任务：$task_id (创建：${age_days}天前，进度：$progress)"
            log_warn "   标题：$title"
            
            stale_count=$((stale_count + 1))
        fi
    done
    
    if [ $stale_count -gt 0 ]; then
        log_warn "发现 $stale_count 个超期任务，建议清理或归档"
        # TODO: 发送超期任务告警
    fi
}

# 主程序
log_info "========================================"
check_stale_tasks
check_zombie_tasks
cleanup_alert_files
log_info "========================================"
