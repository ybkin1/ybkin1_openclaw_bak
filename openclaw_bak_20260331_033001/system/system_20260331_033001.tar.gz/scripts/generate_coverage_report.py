#!/usr/bin/env python3
"""
测试覆盖率报告生成脚本

用途：生成覆盖率报告，检查是否达标，发送通知
"""

import json
import sys
from pathlib import Path
from typing import Dict, Any
from datetime import datetime


# 覆盖率目标
COVERAGE_TARGETS = {
    'overall': 85,        # 总体覆盖率目标
    'critical': 90,       # 核心模块覆盖率目标
}

# 核心模块列表
CRITICAL_MODULES = [
    'nvlink_error_detector',
    'pcie_error_detector',
    'memory_error_detector',
    'dcgm_log_parser',
    'prometheus_metrics_parser',
    'comprehensive_fault_detector',
]


def parse_coverage_xml(xml_path: str) -> Dict[str, Any]:
    """解析覆盖率 XML 报告"""
    import xml.etree.ElementTree as ET
    
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    packages = {}
    
    for package in root.findall('.//package'):
        package_name = package.get('name')
        classes = []
        
        for cls in package.findall('class'):
            classes.append({
                'name': cls.get('name'),
                'line-rate': float(cls.get('line-rate', 0)),
                'branches-covered': int(cls.get('branches-covered', 0)),
            })
        
        packages[package_name] = {
            'line-rate': float(package.get('line-rate', 0)),
            'classes': classes
        }
    
    return packages


def check_coverage(packages: Dict[str, Any]) -> Dict[str, Any]:
    """检查覆盖率是否达标"""
    results = {
        'overall': 0,
        'critical': 0,
        'modules': {},
        'passed': True,
        'warnings': [],
        'failures': []
    }
    
    # 计算总体覆盖率
    total_lines = 0
    covered_lines = 0
    
    for package_name, package_data in packages.items():
        module_name = package_name.split('.')[-1]
        line_rate = package_data['line-rate'] * 100
        
        results['modules'][module_name] = line_rate
        
        # 检查核心模块
        if module_name in CRITICAL_MODULES:
            if line_rate < COVERAGE_TARGETS['critical']:
                results['failures'].append(
                    f"❌ {module_name}: {line_rate:.1f}% "
                    f"(目标：{COVERAGE_TARGETS['critical']}%)"
                )
                results['passed'] = False
            else:
                results['critical'] += 1
        
        # 统计总体
        for cls in package_data['classes']:
            # 简化计算
            covered_lines += int(cls['line-rate'] * 100)
            total_lines += 100
    
    results['overall'] = (covered_lines / total_lines * 100) if total_lines > 0 else 0
    
    if results['overall'] < COVERAGE_TARGETS['overall']:
        results['failures'].append(
            f"❌ 总体覆盖率：{results['overall']:.1f}% "
            f"(目标：{COVERAGE_TARGETS['overall']}%)"
        )
        results['passed'] = False
    else:
        results['warnings'].append(
            f"✅ 总体覆盖率：{results['overall']:.1f}% "
            f"(目标：{COVERAGE_TARGETS['overall']}%)"
        )
    
    return results


def generate_report(results: Dict[str, Any], output_path: str = None) -> str:
    """生成覆盖率报告"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    report_lines = [
        "=" * 60,
        "测试覆盖率报告",
        f"生成时间：{timestamp}",
        "=" * 60,
        ""
    ]
    
    # 总体统计
    report_lines.append("总体统计:")
    report_lines.append(f"  覆盖率：{results['overall']:.1f}%")
    report_lines.append(f"  核心模块达标：{results['critical']}/{len(CRITICAL_MODULES)}")
    report_lines.append("")
    
    # 模块详情
    report_lines.append("模块详情:")
    report_lines.append("-" * 60)
    
    for module_name, coverage in sorted(results['modules'].items()):
        status = "✅" if coverage >= COVERAGE_TARGETS['overall'] else "⚠️"
        report_lines.append(f"  {status} {module_name}: {coverage:.1f}%")
    
    report_lines.append("")
    
    # 警告和失败
    if results['warnings']:
        report_lines.append("通过项:")
        for warning in results['warnings']:
            report_lines.append(f"  {warning}")
        report_lines.append("")
    
    if results['failures']:
        report_lines.append("失败项:")
        for failure in results['failures']:
            report_lines.append(f"  {failure}")
        report_lines.append("")
    
    # 总结
    report_lines.append("=" * 60)
    if results['passed']:
        report_lines.append("✅ 覆盖率检查通过")
    else:
        report_lines.append("❌ 覆盖率检查失败")
    report_lines.append("=" * 60)
    
    report = "\n".join(report_lines)
    
    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report)
    
    return report


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='覆盖率报告生成')
    parser.add_argument('coverage_xml', help='覆盖率 XML 报告路径')
    parser.add_argument('--output', '-o', help='输出报告路径')
    
    args = parser.parse_args()
    
    # 解析覆盖率报告
    packages = parse_coverage_xml(args.coverage_xml)
    
    # 检查覆盖率
    results = check_coverage(packages)
    
    # 生成报告
    report = generate_report(results, args.output)
    print(report)
    
    # 如果失败，返回错误码
    sys.exit(0 if results['passed'] else 1)


if __name__ == '__main__':
    main()
