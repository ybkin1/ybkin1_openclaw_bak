#!/bin/bash
# Subagent Concurrency Control - Subagent 并发控制
# 限制同时运行的 Subagent 数量，防止资源耗尽
# Task: 1.2.2

set -euo pipefail

PID_DIR="/tmp/subagent_pids"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/subagent-concurrency.log"
MAX_CONCURRENT=4

mkdir -p "$PID_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Concurrency: $1" | tee -a "$LOG_FILE"
}

# Task 1.2.2: 获取当前运行的 Subagent 数量
get_running_count() {
    local count=0
    
    for pid_file in "$PID_DIR"/*.pid; do
        if [ -f "$pid_file" ]; then
            local pid=$(cat "$pid_file")
            if ps -p "$pid" > /dev/null 2>&1; then
                count=$((count + 1))
            else
                # PID 已停止，清理文件
                rm -f "$pid_file"
            fi
        fi
    done
    
    echo "$count"
}

# Task 1.2.2: 检查是否可以启动新的 Subagent
can_launch() {
    local running=$(get_running_count)
    
    if [ "$running" -lt "$MAX_CONCURRENT" ]; then
        log "✅ 可以启动：当前运行 $running/$MAX_CONCURRENT"
        return 0
    else
        log "⏸️ 已达上限：当前运行 $running/$MAX_CONCURRENT"
        return 1
    fi
}

# Task 1.2.2: 等待有空闲槽位
wait_for_slot() {
    local timeout=${1:-300}  # 默认 5 分钟超时
    local start_time=$(date +%s)
    
    log "⏳ 等待空闲槽位..."
    
    while true; do
        local running=$(get_running_count)
        
        if [ "$running" -lt "$MAX_CONCURRENT" ]; then
            log "✅ 有空闲槽位：当前运行 $running/$MAX_CONCURRENT"
            return 0
        fi
        
        # 检查超时
        local current_time=$(date +%s)
        local elapsed=$((current_time - start_time))
        
        if [ "$elapsed" -gt "$timeout" ]; then
            log "❌ 等待超时：${timeout}秒"
            return 1
        fi
        
        # 等待 5 秒后重试
        sleep 5
    done
}

# Task 1.2.2: 监控所有 Subagent 状态
monitor_all() {
    log "📊 Subagent 状态监控"
    
    local running=0
    local stopped=0
    
    for pid_file in "$PID_DIR"/*.pid; do
        if [ -f "$pid_file" ]; then
            local pid=$(cat "$pid_file")
            local task_id=$(basename "$pid_file" .pid | sed 's/subagent_//')
            
            if ps -p "$pid" > /dev/null 2>&1; then
                log "✅ 运行中：$task_id (PID: $pid)"
                running=$((running + 1))
            else
                log "⏹️ 已停止：$task_id (PID: $pid)"
                stopped=$((stopped + 1))
                
                # 清理 PID 文件
                rm -f "$pid_file"
            fi
        fi
    done
    
    log "📊 汇总：运行中 $running, 已停止 $stopped"
}

# Task 1.2.2: 启动 Subagent (带并发控制)
launch_with_control() {
    local task_file="$1"
    local agent_type=$(jq -r '.subagent // "assistant"' "$task_file")
    local task_id=$(basename "$task_file" .json)
    
    log "🚀 请求启动：$task_id ($agent_type)"
    
    # 检查是否可以启动
    if ! can_launch; then
        # 等待空闲槽位
        if ! wait_for_slot 300; then
            log "❌ 无法启动：$task_id (等待超时)"
            return 1
        fi
    fi
    
    # 启动 Subagent
    python3 /root/.openclaw/workspace/agents/master/scripts/subagent-launcher.py "$task_file" "$agent_type"
    
    if [ $? -eq 0 ]; then
        log "✅ 启动成功：$task_id"
        return 0
    else
        log "❌ 启动失败：$task_id"
        return 1
    fi
}

# 主函数：根据参数执行不同操作
case "${1:-monitor}" in
    monitor)
        monitor_all
        ;;
    can_launch)
        can_launch
        ;;
    wait)
        wait_for_slot "${2:-300}"
        ;;
    launch)
        if [ -z "${2:-}" ]; then
            log "❌ 用法：subagent-concurrency-control.sh launch <task_file>"
            exit 1
        fi
        launch_with_control "$2"
        ;;
    *)
        echo "用法：subagent-concurrency-control.sh {monitor|can_launch|wait|launch} [args]"
        echo ""
        echo "命令:"
        echo "  monitor     - 监控所有 Subagent 状态"
        echo "  can_launch  - 检查是否可以启动新的 Subagent"
        echo "  wait        - 等待有空闲槽位"
        echo "  launch      - 启动 Subagent (带并发控制)"
        exit 1
        ;;
esac
