#!/usr/bin/env python3
"""
性能回归检查脚本

用途：对比当前性能基准与历史基线，检测性能回归
"""

import json
import sys
from pathlib import Path
from typing import Dict, Any, List


# 性能基线配置 (毫秒)
PERFORMANCE_BASELINES = {
    'test_small_log_parsing': 100,      # 1MB 日志解析 < 100ms
    'test_medium_log_parsing': 500,     # 10MB 日志解析 < 500ms
    'test_large_log_parsing': 3000,     # 100MB 日志解析 < 3000ms
    'test_parallel_processing': 1000,   # 并行处理 < 1000ms
    'test_streaming_processing': 2000,  # 流式处理 < 2000ms
}

# 性能回归阈值 (超过基线的百分比)
REGRESSION_THRESHOLD = 0.20  # 20%


def load_benchmark_results(filepath: str) -> Dict[str, Any]:
    """加载基准测试结果"""
    with open(filepath, 'r') as f:
        return json.load(f)


def check_regression(
    current: Dict[str, Any],
    baseline: Dict[str, float],
    threshold: float
) -> List[str]:
    """检查性能回归"""
    regressions = []
    
    for benchmark in current.get('benchmarks', []):
        name = benchmark['name']
        mean_time = benchmark['stats']['mean'] * 1000  # 转换为毫秒
        
        if name in baseline:
            baseline_time = baseline[name]
            increase = (mean_time - baseline_time) / baseline_time
            
            if increase > threshold:
                regressions.append(
                    f"❌ {name}: {mean_time:.2f}ms (基线：{baseline_time:.2f}ms, "
                    f"回归：{increase*100:.1f}%)"
                )
            elif increase > 0:
                regressions.append(
                    f"⚠️ {name}: {mean_time:.2f}ms (基线：{baseline_time:.2f}ms, "
                    f"增加：{increase*100:.1f}%)"
                )
            else:
                regressions.append(
                    f"✅ {name}: {mean_time:.2f}ms (基线：{baseline_time:.2f}ms, "
                    f"优化：{abs(increase)*100:.1f}%)"
                )
    
    return regressions


def generate_report(regressions: List[str], output_path: str = None) -> str:
    """生成性能报告"""
    report_lines = [
        "=" * 60,
        "性能回归检查报告",
        "=" * 60,
        ""
    ]
    
    passed = sum(1 for r in regressions if r.startswith("✅"))
    warning = sum(1 for r in regressions if r.startswith("⚠️"))
    failed = sum(1 for r in regressions if r.startswith("❌"))
    
    report_lines.append(f"总计：{len(regressions)} 个测试")
    report_lines.append(f"✅ 通过：{passed}")
    report_lines.append(f"⚠️ 警告：{warning}")
    report_lines.append(f"❌ 回归：{failed}")
    report_lines.append("")
    report_lines.append("详细结果:")
    report_lines.append("-" * 60)
    
    for regression in regressions:
        report_lines.append(regression)
    
    report_lines.append("")
    report_lines.append("=" * 60)
    
    if failed > 0:
        report_lines.append("❌ 检测到性能回归！")
    elif warning > 0:
        report_lines.append("⚠️ 存在性能下降趋势")
    else:
        report_lines.append("✅ 性能表现良好")
    
    report = "\n".join(report_lines)
    
    if output_path:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report)
    
    return report


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='性能回归检查')
    parser.add_argument('benchmark_file', help='基准测试结果文件')
    parser.add_argument('--output', '-o', help='输出报告路径')
    parser.add_argument('--threshold', '-t', type=float, default=REGRESSION_THRESHOLD,
                       help='回归阈值 (默认：0.20)')
    
    args = parser.parse_args()
    
    # 加载结果
    results = load_benchmark_results(args.benchmark_file)
    
    # 检查回归
    regressions = check_regression(results, PERFORMANCE_BASELINES, args.threshold)
    
    # 生成报告
    report = generate_report(regressions, args.output)
    print(report)
    
    # 如果有回归，返回错误码
    failed = sum(1 for r in regressions if r.startswith("❌"))
    sys.exit(1 if failed > 0 else 0)


if __name__ == '__main__':
    main()
