#!/bin/bash
# 任务超时监督脚本 - 阶段 1 快速修复
# 每 5 分钟检查一次，防止任务挂死
# 优化：支持任务类型识别、进度更新检测、动态阈值

set -euo pipefail

TASKS_DIR="/root/.openclaw/workspace/agents/assistant/memory/tasks"
SUPERVISOR_LOG="/root/.openclaw/workspace/agents/master/logs/task-timeout.log"
ALERT_FILE="/tmp/task-timeout-alerts.json"
LAST_CHECK_DIR="/tmp/task_last_check"

mkdir -p "$(dirname "$SUPERVISOR_LOG")"
mkdir -p "$LAST_CHECK_DIR"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$SUPERVISOR_LOG"
}

# 阶段 1 修复：根据任务类型返回动态阈值
get_timeout_thresholds() {
    local task_title="$1"
    
    # 从任务标题识别类型
    if echo "$task_title" | grep -qiE "批量 | 备份 | 导出|全量|同步"; then
        # 批量处理任务：3 小时 HARD timeout
        echo "1800 3600 10800"
    elif echo "$task_title" | grep -qiE "分析 | 报告 | 总结 | 审计 | 评估"; then
        # 复杂分析任务：1.5 小时 HARD timeout
        echo "900 1800 5400"
    elif echo "$task_title" | grep -qiE "协作 | 多.*任务 | 联合"; then
        # 多 Agent 协作任务：1.5 小时 HARD timeout
        echo "900 1800 5400"
    elif echo "$task_title" | grep -qiE "安装 | 配置 | 部署 | 升级"; then
        # 中等任务：30 分钟 HARD timeout
        echo "600 1200 1800"
    else
        # 默认/简单任务：15 分钟 HARD timeout
        echo "300 600 900"
    fi
}

# 阶段 1 修复：检查任务是否有进展（文件修改时间）
check_task_progress() {
    local task_file="$1"
    local task_name="$2"
    
    local file_mtime=$(stat -c %Y "$task_file" 2>/dev/null || echo "0")
    local now=$(date +%s)
    local age_seconds=$((now - file_mtime))
    local age_minutes=$((age_seconds / 60))
    
    # 如果文件在最近 5 分钟内有更新，认为任务有进展
    if [ $age_minutes -lt 5 ]; then
        log "📝 任务 $task_name 最近有更新 (${age_minutes}分钟前)，跳过超时检查"
        return 0  # 有进展，跳过超时
    fi
    
    return 1  # 无进展，继续超时检查
}

# 阶段 1 修复：检查任务是否豁免超时
is_timeout_exempt() {
    local task_file="$1"
    
    # 检查是否标记豁免
    if grep -q "timeout_exempt: true" "$task_file" 2>/dev/null; then
        return 0  # 豁免
    fi
    
    return 1  # 不豁免
}

check_task_timeout() {
    local alerts=()
    local skipped=0
    local checked=0
    
    for task_file in "$TASKS_DIR"/processing/*.md; do
        [ -f "$task_file" ] || continue
        
        local task_name=$(basename "$task_file")
        local task_title=$(grep -oP "标题：\K.*" "$task_file" 2>/dev/null | head -1 || echo "未知任务")
        
        checked=$((checked + 1))
        
        # 阶段 1 修复：检查是否豁免超时
        if is_timeout_exempt "$task_file"; then
            log "⏭️  任务 $task_name 标记为超时豁免，跳过检查"
            skipped=$((skipped + 1))
            continue
        fi
        
        # 阶段 1 修复：检查任务是否有进展
        if check_task_progress "$task_file" "$task_name"; then
            skipped=$((skipped + 1))
            continue
        fi
        
        # 阶段 1 修复：获取动态阈值
        local thresholds=$(get_timeout_thresholds "$task_title")
        local SOFT_TIMEOUT=$(echo "$thresholds" | cut -d' ' -f1)
        local IDLE_TIMEOUT=$(echo "$thresholds" | cut -d' ' -f2)
        local HARD_TIMEOUT=$(echo "$thresholds" | cut -d' ' -f3)
        
        # 计算任务年龄（使用文件修改时间）
        local file_mtime=$(stat -c %Y "$task_file")
        local now=$(date +%s)
        local file_age=$((now - file_mtime))
        local age_minutes=$((file_age / 60))
        
        if [ $file_age -gt $HARD_TIMEOUT ]; then
            local age_hours=$((file_age / 3600))
            local age_mins=$(( (file_age % 3600) / 60 ))
            log "❌ HARD TIMEOUT: $task_name - $task_title (${age_hours}h${age_mins}m > $((HARD_TIMEOUT/60))m)"
            # 移动到 failed 目录
            mv "$task_file" "$TASKS_DIR/failed/" 2>/dev/null || true
            alerts+=("{\"type\":\"hard_timeout\",\"task\":\"$task_name\",\"age_seconds\":$file_age,\"threshold_seconds\":$HARD_TIMEOUT}")
            
        elif [ $file_age -gt $IDLE_TIMEOUT ]; then
            log "⚠️  IDLE TIMEOUT: $task_name - $task_title (${age_minutes}m > $((IDLE_TIMEOUT/60))m)"
            alerts+=("{\"type\":\"idle_timeout\",\"task\":\"$task_name\",\"age_seconds\":$file_age,\"threshold_seconds\":$IDLE_TIMEOUT}")
            
        elif [ $file_age -gt $SOFT_TIMEOUT ]; then
            log "📝 SOFT TIMEOUT: $task_name - $task_title (${age_minutes}m > $((SOFT_TIMEOUT/60))m)"
            # 仅记录日志
        fi
    done
    
    # 写入告警文件（供 Master Agent 读取）
    if [ ${#alerts[@]} -gt 0 ]; then
        local alerts_json=$(printf '%s\n' "${alerts[@]}" | jq -s '.')
        echo "{\"timestamp\":\"$(date -Iseconds)\",\"checked\":$checked,\"skipped\":$skipped,\"alerts\":$alerts_json}" > "$ALERT_FILE"
        log "📊 检查 $checked 个任务，跳过 $skipped 个，生成 ${#alerts[@]} 条超时告警"
    else
        echo "{\"timestamp\":\"$(date -Iseconds)\",\"checked\":$checked,\"skipped\":$skipped,\"alerts\":[]}" > "$ALERT_FILE"
        log "📊 检查 $checked 个任务，跳过 $skipped 个，无超时告警"
    fi
}

# 主函数
main() {
    log "=========================================="
    log "任务超时监督开始 (阶段 1 优化版)"
    log "=========================================="
    
    check_task_timeout
    
    log "=========================================="
    log "任务超时监督完成"
    log "=========================================="
}

# 执行
main "$@"
