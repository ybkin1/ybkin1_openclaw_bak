#!/usr/bin/env python3
"""
飞书告警集成

发送系统告警到飞书群聊
"""

import os
import json
import requests
from datetime import datetime
from typing import List, Dict, Any


class FeishuAlert:
    """飞书告警"""
    
    def __init__(self, webhook_url: str = None):
        """初始化飞书告警
        
        Args:
            webhook_url: 飞书机器人 webhook URL
        """
        self.webhook_url = webhook_url or os.environ.get('FEISHU_WEBHOOK_URL', '')
        self.secret = os.environ.get('FEISHU_SECRET', '')
    
    def send_text(self, content: str, mention_all: bool = False) -> bool:
        """发送文本消息
        
        Args:
            content: 消息内容
            mention_all: 是否@所有人
        
        Returns:
            是否成功
        """
        if not self.webhook_url:
            print("⚠️  飞书 webhook URL 未配置")
            return False
        
        payload = {
            "msg_type": "text",
            "content": {
                "text": content
            }
        }
        
        if mention_all:
            payload["content"]["text"] = "<at user_id=\"all\">所有人</at>\n" + content
        
        return self._send(payload)
    
    def send_post(self, title: str, content: List[List[Dict[str, Any]]]) -> bool:
        """发送富文本消息
        
        Args:
            title: 标题
            content: 内容 (二维数组)
        
        Returns:
            是否成功
        """
        if not self.webhook_url:
            print("⚠️  飞书 webhook URL 未配置")
            return False
        
        payload = {
            "msg_type": "post",
            "content": {
                "post": {
                    "zh_cn": {
                        "title": title,
                        "content": content
                    }
                }
            }
        }
        
        return self._send(payload)
    
    def send_card(self, card: Dict[str, Any]) -> bool:
        """发送交互式卡片
        
        Args:
            card: 卡片配置
        
        Returns:
            是否成功
        """
        if not self.webhook_url:
            print("⚠️  飞书 webhook URL 未配置")
            return False
        
        payload = {
            "msg_type": "interactive",
            "card": card
        }
        
        return self._send(payload)
    
    def _send(self, payload: Dict[str, Any]) -> bool:
        """发送消息
        
        Args:
            payload: 消息载荷
        
        Returns:
            是否成功
        """
        try:
            # 添加签名 (如果配置了 secret)
            if self.secret:
                import time
                import hmac
                import hashlib
                
                timestamp = str(int(time.time()))
                sign_str = timestamp + "\n" + self.secret
                signature = hmac.new(
                    sign_str.encode('utf-8'),
                    digestmod=hashlib.sha256
                ).digest()
                signature = base64.b64encode(signature).decode('utf-8')
                
                payload["timestamp"] = timestamp
                payload["sign"] = signature
            
            response = requests.post(
                self.webhook_url,
                json=payload,
                timeout=10
            )
            
            result = response.json()
            if result.get('StatusCode') == 0 or result.get('code') == 0:
                print("✅ 飞书消息发送成功")
                return True
            else:
                print(f"❌ 飞书消息发送失败：{result}")
                return False
                
        except Exception as e:
            print(f"❌ 飞书消息发送异常：{e}")
            return False
    
    def send_backup_alert(self, status: str, details: Dict[str, Any]) -> bool:
        """发送备份告警
        
        Args:
            status: 状态 (success/failure)
            details: 详细信息
        
        Returns:
            是否成功
        """
        emoji = "✅" if status == "success" else "❌"
        title = f"{emoji} 备份告警"
        
        content = [
            [
                {"tag": "text", "text": f"状态：{status}\n"},
                {"tag": "text", "text": f"时间：{details.get('time', 'N/A')}\n"},
                {"tag": "text", "text": f"类型：{details.get('type', 'N/A')}\n"},
            ]
        ]
        
        if 'size' in details:
            content[0].append({"tag": "text", "text": f"大小：{details['size']}\n"})
        
        if 'message' in details:
            content.append([{"tag": "text", "text": f"详情：{details['message']}\n"}])
        
        return self.send_post(title, content)
    
    def send_sla_alert(self, task_id: str, sla_timeout: int, elapsed: int) -> bool:
        """发送 SLA 违规告警
        
        Args:
            task_id: 任务 ID
            sla_timeout: SLA 时限 (秒)
            elapsed: 已用时间 (秒)
        
        Returns:
            是否成功
        """
        title = "🚨 SLA 违规告警"
        
        content = [
            [
                {"tag": "text", "text": f"任务 ID: {task_id}\n"},
                {"tag": "text", "text": f"SLA 时限：{sla_timeout}秒\n"},
                {"tag": "text", "text": f"已用时间：{elapsed}秒\n"},
                {"tag": "text", "text": f"违规程度：{elapsed/sla_timeout*100:.1f}%\n"},
            ]
        ]
        
        return self.send_post(title, content)
    
    def send_system_alert(self, alert_type: str, message: str, details: Dict[str, Any] = None) -> bool:
        """发送系统告警
        
        Args:
            alert_type: 告警类型
            message: 告警消息
            details: 详细信息
        
        Returns:
            是否成功
        """
        emojis = {
            'error': '❌',
            'warning': '⚠️',
            'info': 'ℹ️',
            'success': '✅',
        }
        
        emoji = emojis.get(alert_type, '📢')
        title = f"{emoji} 系统告警"
        
        content = [
            [
                {"tag": "text", "text": f"类型：{alert_type}\n"},
                {"tag": "text", "text": f"消息：{message}\n"},
            ]
        ]
        
        if details:
            detail_text = "\n".join([f"{k}: {v}" for k, v in details.items()])
            content.append([{"tag": "text", "text": f"详情：\n{detail_text}\n"}])
        
        return self.send_post(title, content)


def test_feishu_alert():
    """测试飞书告警"""
    alert = FeishuAlert()
    
    print("=" * 60)
    print("📢 飞书告警测试")
    print("=" * 60)
    
    # 测试文本消息
    print("\n1️⃣  测试文本消息...")
    result = alert.send_text("【测试】这是一条测试消息")
    print(f"   结果：{'✅ 成功' if result else '❌ 失败'}")
    
    # 测试富文本消息
    print("\n2️⃣  测试富文本消息...")
    content = [
        [
            {"tag": "text", "text": "项目：智能运维团队架构改造\n"},
            {"tag": "text", "text": "日期：2026-03-30\n"},
            {"tag": "text", "text": "状态：✅ 圆满完成\n"},
        ]
    ]
    result = alert.send_post("📊 项目总结", content)
    print(f"   结果：{'✅ 成功' if result else '❌ 失败'}")
    
    # 测试备份告警
    print("\n3️⃣  测试备份告警...")
    result = alert.send_backup_alert('success', {
        'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'type': 'P0 核心配置',
        'size': '16KB',
    })
    print(f"   结果：{'✅ 成功' if result else '❌ 失败'}")
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)


if __name__ == '__main__':
    import base64  # 需要在 send 方法中使用
    test_feishu_alert()
