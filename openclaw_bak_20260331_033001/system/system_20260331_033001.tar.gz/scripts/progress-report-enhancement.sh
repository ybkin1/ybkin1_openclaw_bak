#!/bin/bash
# Progress Report Enhancement - 进度汇报完善
# 实现汇报前强制验证，防止 AI 幻觉虚假汇报
# Task: 2.1.1

set -euo pipefail

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
REPORTS_DIR="/root/.openclaw/workspace/agents/master/reports/progress"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/progress-enhancement.log"

mkdir -p "$REPORTS_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Enhancement: $1" | tee -a "$LOG_FILE"
}

# Task 2.1.1: 汇报前强制验证
validate_before_report() {
    local task_file="$1"
    local validation_errors=0
    local task_id=$(basename "$task_file" .json)
    
    log "🔍 验证任务：$task_id"
    
    # 验证 1: 代码文件是否实际存在
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    for file in $output_files; do
        if [ ! -f "$file" ]; then
            log "❌ 验证失败：输出文件不存在 $file"
            validation_errors=$((validation_errors + 1))
        fi
    done
    
    # 验证 2: Git 提交是否实际存在 (仅已完成任务)
    local status=$(jq -r '.status' "$task_file")
    if [ "$status" = "completed" ]; then
        local commit_hash=$(jq -r '.commit_hash // empty' "$task_file")
        if [ -n "$commit_hash" ] && [ "$commit_hash" != "null" ] && [ "$commit_hash" != "pending" ]; then
            cd /root/.openclaw/workspace
            if ! git rev-parse "$commit_hash" > /dev/null 2>&1; then
                log "❌ 验证失败：Git 提交不存在 $commit_hash"
                validation_errors=$((validation_errors + 1))
            fi
        else
            log "⚠️ 警告：任务已完成但无 Git 提交"
            # 不阻止汇报，但记录警告
        fi
    fi
    
    # 验证 3: PID 是否实际运行 (仅进行中任务)
    if [ "$status" = "in_progress" ]; then
        local pid_file="/tmp/subagent_${task_id}.pid"
        if [ -f "$pid_file" ]; then
            local pid=$(cat "$pid_file")
            if ! ps -p "$pid" > /dev/null 2>&1; then
                log "⚠️ 警告：PID 已停止 $pid"
                # 不阻止汇报，但标记为异常
            fi
        fi
    fi
    
    # 返回验证结果
    if [ $validation_errors -gt 0 ]; then
        log "🚫 验证失败：$validation_errors 个错误"
        return 1
    fi
    
    log "✅ 验证通过"
    return 0
}

# Task 2.1.2: 生成带验证清单的汇报
generate_report_with_checklist() {
    local task_file="$1"
    local report_type="$2"
    local elapsed_minutes="$3"
    
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title' "$task_file")
    local status=$(jq -r '.status' "$task_file")
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    
    local report_file="$REPORTS_DIR/${task_id}_${report_type}_$(date +%H%M).md"
    
    # 执行验证
    local validation_passed=true
    if ! validate_before_report "$task_file"; then
        validation_passed=false
    fi
    
    # 生成汇报 (带验证清单)
    cat > "$report_file" << EOF
# 任务进度汇报

**任务 ID**: $task_id  
**任务标题**: $title  
**汇报类型**: $report_type  
**汇报时间**: $(date '+%Y-%m-%d %H:%M:%S')

---

## 验证清单

- [$( [ -n "$output_files" ] && echo "x" || echo " " )] 代码文件已验证存在
- [$( [ "$status" = "completed" ] && echo "x" || echo " " )] Git 提交已验证存在
- [$( [ "$status" = "in_progress" ] && [ -f "/tmp/subagent_${task_id}.pid" ] && echo "x" || echo " " )] PID 已验证运行中
- [$( [ "$validation_passed" = true ] && echo "x" || echo " " )] 汇报前验证通过

---

## 进度信息

| 指标 | 值 |
|------|-----|
| 已用时间 | $elapsed_minutes 分钟 |
| 状态 | $status |

---

## 验证结果

$( [ "$validation_passed" = true ] && echo "✅ 所有验证通过" || echo "⚠️ 部分验证失败，请检查日志" )

---

**自动生成**: task-progress-reporter.sh (带验证)
EOF

    log "📊 生成汇报：$report_file"
}

# 主函数
log "🔍 开始验证并生成汇报..."

for task_file in "$TASKS_DIR"/*.json; do
    if [ -f "$task_file" ]; then
        status=$(jq -r '.status' "$task_file")
        
        if [ "$status" = "in_progress" ]; then
            # 计算已用时间
            started_at=$(jq -r '.started_at' "$task_file")
            started_ts=$(date -d "$started_at" +%s 2>/dev/null || echo 0)
            now_ts=$(date +%s)
            elapsed_minutes=$(( (now_ts - started_ts) / 60 ))
            
            # 生成带验证的汇报
            generate_report_with_checklist "$task_file" "progress" "$elapsed_minutes"
        fi
    fi
done

log "✅ 汇报完善执行完成"
