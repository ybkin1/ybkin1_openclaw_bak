#!/bin/bash
# restore-task-persistence.sh - 恢复跨天任务持久化机制
# 当检测到机制失效时，运行此脚本恢复

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
LOG_FILE="$BASE_DIR/logs/restore-task-persistence.log"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保日志目录存在
mkdir -p "$BASE_DIR/logs"

log_info "=========================================="
log_info "开始恢复跨天任务持久化机制"
log_info "=========================================="

# 1. 检查并恢复脚本文件
log_info "检查脚本文件..."
scripts=("task-heartbeat.sh" "cross-day-scheduler.sh" "zombie-task-detector.sh")
for script in "${scripts[@]}"; do
    if [ ! -f "$SCRIPT_DIR/$script" ]; then
        log_error "脚本文件丢失：$script"
        log_error "请从备份恢复或重新创建"
        exit 1
    else
        log_info "✓ 脚本存在：$script"
    fi
done

# 2. 设置执行权限
log_info "设置执行权限..."
chmod +x "$SCRIPT_DIR"/*.sh
log_info "✓ 执行权限已设置"

# 3. 检查并恢复 Cron 配置
log_info "检查 Cron 配置..."

# 检查是否已存在配置
if crontab -l 2>/dev/null | grep -q "task-heartbeat.sh"; then
    log_info "✓ Cron 配置已存在"
else
    log_warn "Cron 配置丢失，正在恢复..."
    
    # 备份当前配置
    crontab -l > /tmp/crontab.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
    
    # 添加配置
    cat >> /tmp/crontab.new << 'EOF'

# ==================== 跨天任务持久化机制 ====================
# 每 5 分钟 - 任务心跳更新
*/5 * * * * /root/.openclaw/workspace/agents/master/scripts/task-heartbeat.sh >> /root/.openclaw/workspace/agents/master/logs/task-heartbeat.log 2>&1

# 每天 23:00 - 跨天任务暂停
0 23 * * * /root/.openclaw/workspace/agents/master/scripts/cross-day-scheduler.sh pause >> /root/.openclaw/workspace/agents/master/logs/cross-day-scheduler.log 2>&1

# 每天 08:30 - 跨天任务恢复
30 8 * * * /root/.openclaw/workspace/agents/master/scripts/cross-day-scheduler.sh resume >> /root/.openclaw/workspace/agents/master/logs/cross-day-scheduler.log 2>&1

# 每 10 分钟 - 僵尸任务检测
*/10 * * * * /root/.openclaw/workspace/agents/master/scripts/zombie-task-detector.sh >> /root/.openclaw/workspace/agents/master/logs/zombie-task-detector.log 2>&1
EOF
    
    # 合并配置
    cat /tmp/crontab.backup.* 2>/dev/null /tmp/crontab.new | crontab -
    
    log_info "✓ Cron 配置已恢复"
fi

# 4. 验证配置
log_info "验证 Cron 配置..."
if crontab -l 2>/dev/null | grep -q "task-heartbeat.sh"; then
    log_info "✓ Cron 配置验证通过"
else
    log_error "Cron 配置验证失败"
    exit 1
fi

# 5. 检查设计文档
log_info "检查设计文档..."
if [ -f "$BASE_DIR/memory/config/cross-session-task-persistence.md" ]; then
    log_info "✓ 设计文档存在"
else
    log_warn "设计文档丢失，建议从备份恢复"
fi

# 6. 检查系统记录
log_info "检查系统记录..."
if grep -q "跨天任务持久化机制" "$BASE_DIR/MEMORY.md" 2>/dev/null; then
    log_info "✓ MEMORY.md 记录存在"
else
    log_warn "MEMORY.md 记录丢失"
fi

if grep -q "跨天任务持久化机制" "$BASE_DIR/AGENTS.md" 2>/dev/null; then
    log_info "✓ AGENTS.md 记录存在"
else
    log_warn "AGENTS.md 记录丢失"
fi

# 7. 测试脚本
log_info "测试脚本执行..."
if bash -n "$SCRIPT_DIR/task-heartbeat.sh" && \
   bash -n "$SCRIPT_DIR/cross-day-scheduler.sh" && \
   bash -n "$SCRIPT_DIR/zombie-task-detector.sh"; then
    log_info "✓ 脚本语法检查通过"
else
    log_error "脚本语法检查失败"
    exit 1
fi

# 8. 启动 Cron 服务（如果停止）
log_info "检查 Cron 服务..."
if ! pgrep -x "cron" > /dev/null; then
    log_warn "Cron 服务未运行，尝试启动..."
    systemctl restart cron || service cron restart || {
        log_error "无法启动 Cron 服务，请手动处理"
        exit 1
    }
    log_info "✓ Cron 服务已启动"
else
    log_info "✓ Cron 服务运行中"
fi

log_info "=========================================="
log_info "恢复完成！"
log_info "=========================================="
log_info ""
log_info "下次执行时间:"
log_info "- 心跳更新：5 分钟内"
log_info "- 僵尸检测：10 分钟内"
log_info "- 跨天暂停：今天 23:00"
log_info "- 跨天恢复：明天 08:30"
log_info ""
log_info "验证命令:"
log_info "  crontab -l | grep -E 'task-heartbeat|cross-day|zombie-task'"
log_info "  tail -f $BASE_DIR/logs/task-heartbeat.log"
