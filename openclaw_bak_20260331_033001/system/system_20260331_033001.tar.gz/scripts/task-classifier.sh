#!/bin/bash

# 任务复杂度分类器
# 用于判断任务是否应该交给 assistant agent 处理

# 输入参数
TASK_DESC="$1"
TASK_TITLE="${2:-}"

# 复杂任务关键词（需要 assistant 处理）
COMPLEX_KEYWORDS=(
    "架构优化"
    "系统升级"
    "代码开发"
    "复杂调试"
    "数据迁移"
    "重构"
    "refactor"
    "upgrade"
    "migration"
    "debugging"
    "开发新工具"
    "创建脚本"
    "tool creation"
    "script writing"
    "开发工具"
    "编写脚本"
    "多步骤推理"
    "root cause"
    "根本原因"
    "深入分析"
    "深入调查"
    "long-running"
    "耗时"
    "30分钟"
    "1小时"
    "2小时"
    "复杂分析"
    "复杂任务"
    "heavy computation"
    "处理大量数据"
    "批量处理"
    "性能优化"
    "performance"
    "资源密集型"
    "开发"
    "创建"
    "编写"
    "实现"
    "implement"
    "create"
    "build"
    "construct"
    # 新增：第三方集成、多技能管理
    "第三方"
    "third-party"
    "多个工具"
    "多个skill"
    "技能清单"
    "skill registry"
    "技能管理"
    "安装.*skill"
    "安装.*技能"
    "批量安装"
    "批量部署"
    "集成多个"
    "统一管理"
    "清单维护"
    "自动维护"
    "集成测试"
)

# 中等任务关键词（master 可处理，但需要规划）
MEDIUM_KEYWORDS=(
    "备份恢复"
    "监控检查"
    "日志分析"
    "配置更新"
    "文档更新"
    "文件整理"
    "数据导出"
    "简单查询"
    "命令执行"
    "状态检查"
)

# 分类函数
classify_task() {
    local desc_lower=$(echo "$TASK_DESC $TASK_TITLE" | tr '[:upper:]' '[:lower:]')
    local complex_count=0
    local medium_count=0

    # 检查复杂关键词
    for keyword in "${COMPLEX_KEYWORDS[@]}"; do
        if echo "$desc_lower" | grep -q "$(echo "$keyword" | tr '[:upper:]' '[:lower:]')"; then
            ((complex_count++))
        fi
    done

    # 检查中等关键词
    for keyword in "${MEDIUM_KEYWORDS[@]}"; do
        if echo "$desc_lower" | grep -q "$(echo "$keyword" | tr '[:upper:]' '[:lower:]')"; then
            ((medium_count++))
        fi
    done

    # 判断时间关键词
    local time_indicator=0
    if echo "$desc_lower" | grep -qE "(30分|1小时|2小时|3小时|4小时|耗时.*长)"; then
        ((time_indicator++))
    fi

    # 综合判断
    if [ $complex_count -gt 0 ] || [ $time_indicator -gt 0 ]; then
        echo "COMPLEX"
    elif [ $medium_count -gt 0 ]; then
        echo "MEDIUM"
    else
        echo "SIMPLE"
    fi
}

# 获取建议的处理 agent
get_recommended_agent() {
    local complexity=$(classify_task)
    case $complexity in
        "COMPLEX")
            echo "assistant"
            ;;
        "MEDIUM")
            echo "master"
            ;;
        "SIMPLE")
            echo "master"
            ;;
        *)
            echo "master"
            ;;
    esac
}

# 主程序
if [ -z "$TASK_DESC" ]; then
    echo "Usage: $0 <task_description> [task_title]"
    exit 1
fi

complexity=$(classify_task)
recommended=$(get_recommended_agent)

# 输出 JSON 格式结果
cat <<EOF
{
  "complexity": "$complexity",
  "recommended_agent": "$recommended",
  "reason": "基于关键词分析和时间预估",
  "task_description": "$TASK_DESC"
}
EOF