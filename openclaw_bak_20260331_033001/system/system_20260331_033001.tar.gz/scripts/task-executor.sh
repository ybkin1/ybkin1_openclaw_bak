#!/bin/bash
# Task Executor - 任务执行器
# 每 5 分钟检查活跃任务，启动 Subagent 执行
# Task: 1.1.1, 1.1.2, 1.1.3

set -euo pipefail

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/task-executor.log"
PID_DIR="/tmp/subagent_pids"

mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$PID_DIR"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Task 1.1.1: 任务检查逻辑
check_active_tasks() {
    log "🔍 开始检查活跃任务..."
    
    local active_count=0
    local need_execute_count=0
    
    for task_file in "$TASKS_DIR"/*.json; do
        if [ ! -f "$task_file" ]; then
            continue
        fi
        
        local task_id=$(basename "$task_file" .json)
        local status=$(jq -r '.status // "unknown"' "$task_file")
        
        # 仅处理 in_progress 状态的任务
        if [ "$status" != "in_progress" ]; then
            continue
        fi
        
        active_count=$((active_count + 1))
        
        # 检查 Subagent 是否已启动 (通过 PID 文件)
        local pid_file="$PID_DIR/${task_id}.pid"
        
        if [ ! -f "$pid_file" ]; then
            # Subagent 未启动，需要执行
            need_execute_count=$((need_execute_count + 1))
            log "📋 发现待执行任务：$task_id"
            
            # 启动 Subagent
            launch_subagent "$task_file"
        else
            # Subagent 已在运行
            local pid=$(cat "$pid_file")
            if ps -p "$pid" > /dev/null 2>&1; then
                log "✅ Subagent 运行中：$task_id (PID: $pid)"
            else
                # Subagent 已停止，清理 PID 文件
                rm -f "$pid_file"
                log "⚠️ Subagent 已停止：$task_id (清理 PID 文件)"
                
                # 更新任务状态为完成
                update_task_status "$task_file" "completed"
            fi
        fi
    done
    
    log "✅ 检查完成：活跃任务 $active_count 个，需要执行 $need_execute_count 个"
}

# Task 1.1.2: Subagent 启动逻辑 (使用 subagent-launcher.py)
launch_subagent() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    local subagent=$(jq -r '.subagent // "assistant"' "$task_file")
    
    log "🚀 启动 Subagent: $subagent for $task_id"
    
    # 调用 subagent-launcher.py
    python3 /root/.openclaw/workspace/agents/master/scripts/subagent-launcher.py \
        "$task_file" "$subagent"
    
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        log "✅ Subagent 启动成功：$task_id"
    else
        log "❌ Subagent 启动失败：$task_id (exit code: $exit_code)"
    fi
    
    return $exit_code
}

# Task 1.1.2: 生成 Subagent Prompt
generate_prompt() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title // "Unknown Task"' "$task_file")
    local description=$(jq -r '.description // ""' "$task_file")
    local acceptance=$(jq -r '.acceptance_criteria[]' "$task_file" 2>/dev/null | head -5)
    
    cat << EOF
任务：$title

描述：$description

验收标准：
$acceptance

约束：
- 实现 Bash/Python 脚本
- 添加详细注释
- 错误处理完整

开始执行。
EOF
}

# Task 1.1.2: 实际任务执行
execute_task() {
    local task_file="$1"
    local prompt_file="$2"
    local task_id=$(basename "$task_file" .json)
    
    # 读取任务信息
    local subagent=$(jq -r '.subagent' "$task_file")
    
    # 根据任务类型执行不同逻辑
    case "$task_id" in
        *task_20260326_144500*)
            # Task 1.1.1: 实现任务检查逻辑
            log "📝 执行 Task 1.1.1: 任务检查逻辑"
            
            # 任务执行逻辑已在此脚本中实现
            # 这里是递归调用，实际应该由 assistant Agent 执行
            
            # 标记任务完成
            update_task_status "$task_file" "completed"
            ;;
        *)
            log "⚠️ 未知任务类型：$task_id"
            ;;
    esac
}

# Task 1.1.3: 执行状态更新
update_task_status() {
    local task_file="$1"
    local new_status="$2"
    
    local task_id=$(basename "$task_file" .json)
    local temp_file=$(mktemp)
    
    # 更新状态
    jq --arg status "$new_status" --arg time "$(date -Iseconds)" \
       '.status = $status | .last_activity = $time | 
        if $status == "completed" then .completed_at = $time else . end' \
       "$task_file" > "$temp_file" && mv "$temp_file" "$task_file"
    
    log "✅ 任务状态更新：$task_id -> $new_status"
    
    # 清理 PID 文件
    rm -f "$PID_DIR/${task_id}.pid"
}

# 主循环
check_active_tasks

log "✅ Task Executor 执行完成"
