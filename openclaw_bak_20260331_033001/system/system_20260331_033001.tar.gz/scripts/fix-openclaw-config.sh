#!/bin/bash
# OpenClaw 配置修复脚本
# 用途：修复 channels.feishu 配置错误

set -e

CONFIG_FILE="/root/.openclaw/openclaw.json"
BACKUP_FILE="$CONFIG_FILE.bak.$(date +%Y%m%d_%H%M%S)"

echo "========================================"
echo "🔧 OpenClaw 配置修复脚本"
echo "========================================"
echo ""

# 1. 备份原配置
echo "1️⃣  备份原配置..."
cp "$CONFIG_FILE" "$BACKUP_FILE"
echo "   ✅ 备份完成：$BACKUP_FILE"
echo ""

# 2. 使用 Python 修复配置
echo "2️⃣  修复 channels.feishu 配置..."

python3 << 'PYTHON_SCRIPT'
import json
import sys

config_file = "/root/.openclaw/openclaw.json"

# 读取配置
with open(config_file, 'r', encoding='utf-8') as f:
    config = json.load(f)

# 修复 channels.feishu.accounts.default
if 'channels' in config and 'feishu' in config['channels']:
    feishu_config = config['channels']['feishu']
    
    # 修复 accounts.default
    if 'accounts' in feishu_config and 'default' in feishu_config['accounts']:
        default_account = feishu_config['accounts']['default']
        
        # 删除不支持的配置项
        removed = []
        if 'debounceMs' in default_account:
            del default_account['debounceMs']
            removed.append('debounceMs')
        
        if 'messageQueue' in default_account:
            del default_account['messageQueue']
            removed.append('messageQueue')
        
        if removed:
            print(f"   ✅ 已删除不支持的配置项：{', '.join(removed)}")
        else:
            print("   ✅ 配置无需修改")
    
    # 修复 plugins 重复配置
    if 'plugins' in config:
        plugins = config['plugins']
        
        # 如果 plugins.allow 包含 feishu，则删除 plugins.entries.feishu
        if 'allow' in plugins and 'feishu' in plugins['allow']:
            if 'entries' in plugins and 'feishu' in plugins['entries']:
                del plugins['entries']['feishu']
                print("   ✅ 已删除重复的 plugins.entries.feishu 配置")

# 保存修复后的配置
with open(config_file, 'w', encoding='utf-8') as f:
    json.dump(config, f, indent=2, ensure_ascii=False)

print("   ✅ 配置修复完成")
PYTHON_SCRIPT

echo ""

# 3. 验证配置
echo "3️⃣  验证配置..."
if openclaw doctor 2>&1 | grep -q "Config invalid"; then
    echo "   ⚠️  配置仍有问题，请检查错误信息"
    openclaw doctor 2>&1 | grep "Invalid config" | head -5
else
    echo "   ✅ 配置验证通过"
fi
echo ""

# 4. 显示修复建议
echo "========================================"
echo "📋 其他修复建议"
echo "========================================"
echo ""

echo "【可选】清理多个 state 目录:"
echo "  # 检查 /home/admin/.openclaw 是否在使用"
echo "  ls -la /home/admin/.openclaw"
echo "  # 如不使用，可以删除"
echo "  rm -rf /home/admin/.openclaw"
echo ""

echo "【可选】禁用多余的 Guardian 服务:"
echo "  systemctl --user disable --now openclaw-archguardian.service"
echo "  systemctl --user disable --now openclaw-config-guardian.service"
echo "  # 只保留 health-guardian"
echo ""

echo "【建议】Gateway 安全配置:"
echo "  # 如需远程访问，建议使用 SSH 隧道:"
echo "  ssh -N -L 15527:127.0.0.1:15527 user@gateway-host"
echo "  # 或将 bind 改为 loopback"
echo ""

echo "【建议】设置性能优化环境变量:"
echo "  export NODE_COMPILE_CACHE=/var/tmp/openclaw-compile-cache"
echo "  mkdir -p /var/tmp/openclaw-compile-cache"
echo "  export OPENCLAW_NO_RESPAWN=1"
echo ""

echo "========================================"
echo "✅ 配置修复完成"
echo "========================================"
echo ""
echo "📄 备份文件：$BACKUP_FILE"
echo "🔧 验证命令：openclaw doctor"
echo "🚀 重启 Gateway: systemctl --user restart openclaw-gateway.service"
echo ""
