#!/usr/bin/env python3
"""
File Agent 监控和告警脚本

功能:
- 监控系统资源
- 检查服务健康
- 性能指标收集
- 告警通知
"""

import os
import sys
import json
import time
import smtplib
import requests
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


# ===========================================
# 配置
# ===========================================
CONFIG = {
    'log_file': '/var/log/file-agent-monitor.log',
    'metrics_file': '/var/log/file-agent-metrics.json',
    'check_interval': 60,  # 秒
    
    # 告警阈值
    'thresholds': {
        'cpu_percent': 80,
        'memory_percent': 85,
        'disk_percent': 90,
        'error_rate': 0.05,  # 5%
        'response_time_ms': 5000,
    },
    
    # 通知配置
    'notifications': {
        'email': {
            'enabled': False,
            'smtp_server': 'smtp.example.com',
            'smtp_port': 587,
            'username': '',
            'password': '',
            'from_addr': '',
            'to_addrs': [],
        },
        'webhook': {
            'enabled': False,
            'url': '',
        },
    }
}


# ===========================================
# 监控函数
# ===========================================
def get_system_metrics() -> Dict[str, Any]:
    """获取系统指标"""
    import resource
    
    try:
        # CPU 使用率 (简化)
        cpu_percent = 0  # 需要 psutil
        
        # 内存使用
        usage = resource.getrusage(resource.RUSAGE_SELF)
        memory_mb = usage.ru_maxrss / 1024
        
        # 磁盘使用
        import shutil
        total, used, free = shutil.disk_usage('/')
        disk_percent = (used / total) * 100
        
        return {
            'timestamp': datetime.now().isoformat(),
            'cpu_percent': cpu_percent,
            'memory_mb': memory_mb,
            'disk_percent': disk_percent,
            'disk_free_gb': free / (1024**3),
        }
    except Exception as e:
        return {
            'timestamp': datetime.now().isoformat(),
            'error': str(e),
        }


def check_service_health() -> Dict[str, Any]:
    """检查服务健康"""
    health = {
        'cli_available': False,
        'modules_loaded': False,
        'tests_passing': False,
    }
    
    try:
        # 检查 CLI
        import subprocess
        result = subprocess.run(
            ['python3', 'src/cli.py', '--version'],
            capture_output=True,
            timeout=5
        )
        health['cli_available'] = (result.returncode == 0)
        
        # 检查核心模块
        try:
            from src import nvlink_error_detector
            from src import pcie_error_detector
            from src import comprehensive_fault_detector
            health['modules_loaded'] = True
        except ImportError:
            health['modules_loaded'] = False
        
        # 运行快速测试
        result = subprocess.run(
            ['python3', '-m', 'pytest', 'tests/', '-k', 'test_empty', '-q'],
            capture_output=True,
            timeout=30
        )
        health['tests_passing'] = (result.returncode == 0)
        
    except Exception as e:
        health['error'] = str(e)
    
    return health


def check_error_logs() -> Dict[str, Any]:
    """检查错误日志"""
    log_dir = Path('/root/.openclaw/logs')
    error_count = 0
    total_lines = 0
    
    if log_dir.exists():
        for log_file in log_dir.glob('*.log'):
            try:
                with open(log_file, 'r') as f:
                    for line in f:
                        total_lines += 1
                        if 'ERROR' in line or 'CRITICAL' in line:
                            error_count += 1
            except:
                pass
    
    error_rate = error_count / total_lines if total_lines > 0 else 0
    
    return {
        'error_count': error_count,
        'total_lines': total_lines,
        'error_rate': error_rate,
    }


# ===========================================
# 告警函数
# ===========================================
def check_thresholds(metrics: Dict[str, Any]) -> list:
    """检查阈值"""
    alerts = []
    thresholds = CONFIG['thresholds']
    
    if metrics.get('cpu_percent', 0) > thresholds['cpu_percent']:
        alerts.append(f"CPU 使用率过高：{metrics['cpu_percent']:.1f}%")
    
    if metrics.get('disk_percent', 0) > thresholds['disk_percent']:
        alerts.append(f"磁盘使用率过高：{metrics['disk_percent']:.1f}%")
    
    return alerts


def send_email_alert(subject: str, message: str):
    """发送邮件告警"""
    config = CONFIG['notifications']['email']
    
    if not config['enabled']:
        return
    
    msg = MIMEMultipart()
    msg['From'] = config['from_addr']
    msg['To'] = ', '.join(config['to_addrs'])
    msg['Subject'] = f"[File Agent 告警] {subject}"
    
    body = f"""
File Agent 监控告警

时间：{datetime.now().isoformat()}

{message}

---
此邮件由 File Agent 监控系统自动发送
    """
    
    msg.attach(MIMEText(body, 'plain'))
    
    try:
        server = smtplib.SMTP(config['smtp_server'], config['smtp_port'])
        server.starttls()
        server.login(config['username'], config['password'])
        server.send_message(msg)
        server.quit()
    except Exception as e:
        log(f"邮件发送失败：{e}")


def send_webhook_alert(message: str):
    """发送 Webhook 告警"""
    config = CONFIG['notifications']['webhook']
    
    if not config['enabled']:
        return
    
    try:
        payload = {
            'text': f"🚨 File Agent 告警\n\n{message}",
            'timestamp': datetime.now().isoformat(),
        }
        
        response = requests.post(config['url'], json=payload, timeout=10)
        response.raise_for_status()
    except Exception as e:
        log(f"Webhook 发送失败：{e}")


def send_alert(alert_type: str, message: str):
    """发送告警"""
    log(f"🚨 告警 [{alert_type}]: {message}")
    
    send_email_alert(alert_type, message)
    send_webhook_alert(message)


# ===========================================
# 日志函数
# ===========================================
def log(message: str):
    """记录日志"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_line = f"{timestamp} {message}\n"
    
    print(log_line, end='')
    
    try:
        with open(CONFIG['log_file'], 'a') as f:
            f.write(log_line)
    except:
        pass


def save_metrics(metrics: Dict[str, Any]):
    """保存指标"""
    try:
        # 读取历史指标
        history = []
        if Path(CONFIG['metrics_file']).exists():
            with open(CONFIG['metrics_file'], 'r') as f:
                history = json.load(f)
        
        # 添加新指标
        history.append(metrics)
        
        # 保留最近 1000 条
        history = history[-1000:]
        
        # 保存
        with open(CONFIG['metrics_file'], 'w') as f:
            json.dump(history, f, indent=2)
    except Exception as e:
        log(f"保存指标失败：{e}")


# ===========================================
# 主循环
# ===========================================
def monitor_loop():
    """监控主循环"""
    log("🚀 启动 File Agent 监控系统...")
    
    while True:
        try:
            # 收集指标
            system_metrics = get_system_metrics()
            health_status = check_service_health()
            error_status = check_error_logs()
            
            # 合并指标
            all_metrics = {
                **system_metrics,
                'health': health_status,
                'errors': error_status,
            }
            
            # 保存指标
            save_metrics(all_metrics)
            
            # 检查阈值
            alerts = check_thresholds(system_metrics)
            
            # 检查健康
            if not all(health_status.values()):
                alerts.append(f"服务健康检查失败：{health_status}")
            
            # 发送告警
            for alert in alerts:
                send_alert('监控告警', alert)
            
            # 等待下一次检查
            time.sleep(CONFIG['check_interval'])
            
        except KeyboardInterrupt:
            log("⛔ 监控停止")
            break
        except Exception as e:
            log(f"❌ 监控错误：{e}")
            time.sleep(CONFIG['check_interval'])


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='File Agent 监控')
    parser.add_argument('command', nargs='?', choices=['start', 'check', 'metrics'],
                       default='start', help='命令')
    
    args = parser.parse_args()
    
    if args.command == 'start':
        monitor_loop()
    elif args.command == 'check':
        metrics = get_system_metrics()
        health = check_service_health()
        print(json.dumps({**metrics, 'health': health}, indent=2))
    elif args.command == 'metrics':
        metrics_file = Path(CONFIG['metrics_file'])
        if metrics_file.exists():
            with open(metrics_file, 'r') as f:
                metrics = json.load(f)
                print(json.dumps(metrics[-10:], indent=2))  # 最近 10 条
        else:
            print("暂无指标数据")


if __name__ == '__main__':
    main()
