#!/bin/bash
# sop-validator.sh - SOP 状态机验证器
# 修复版本：添加状态到目录的映射关系

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
TASKS_DIR="$BASE_DIR/tasks"
LOG_FILE="$BASE_DIR/logs/sop-validator.log"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保日志目录存在
mkdir -p "$BASE_DIR/logs"

# 定义合法的状态转换
VALID_TRANSITIONS=(
    "pending:in_progress"
    "in_progress:reviewing"
    "in_progress:paused"
    "in_progress:failed"
    "reviewing:completed"
    "reviewing:in_progress"
    "reviewing:failed"
    "paused:in_progress"
    "paused:failed"
    "failed:pending"
    "completed:pending"
)

# 状态到目录的映射
declare -A STATE_TO_DIR=(
    ["pending"]="active"
    ["in_progress"]="active"
    ["reviewing"]="reviewing"
    ["paused"]="paused"
    ["failed"]="failed"
    ["completed"]="completed"
)

# 检查状态转换是否合法
is_valid_transition() {
    local current="$1"
    local next="$2"
    
    local transition="$current:$next"
    
    for valid in "${VALID_TRANSITIONS[@]}"; do
        if [ "$valid" = "$transition" ]; then
            return 0
        fi
    done
    
    return 1
}

# 检查检查点是否完成
check_checkpoints() {
    local task_file="$1"
    local next_status="$2"
    
    local checkpoint_file="${task_file%.json}.checkpoint"
    
    if [ ! -f "$checkpoint_file" ]; then
        return 0
    fi
    
    local last_checkpoint=$(tail -1 "$checkpoint_file" 2>/dev/null)
    local last_progress=$(echo "$last_checkpoint" | jq -r '.progress // 0' 2>/dev/null || echo "0")
    
    case "$next_status" in
        "reviewing")
            if [ "$last_progress" -lt 90 ]; then
                log_error "SOP 违规：进度 $last_progress% < 90%，不能进入 reviewing"
                return 1
            fi
            ;;
        "completed")
            if [ "$last_progress" -lt 100 ]; then
                log_error "SOP 违规：进度 $last_progress% < 100%，不能进入 completed"
                return 1
            fi
            ;;
    esac
    
    return 0
}

# 验证状态转换
validate_transition() {
    local task_id="$1"
    local current_status="$2"
    local next_status="$3"
    
    log_info "验证状态转换：$task_id ($current_status → $next_status)"
    
    if ! is_valid_transition "$current_status" "$next_status"; then
        log_error "❌ SOP 违规：$current_status → $next_status 不是合法的状态转换"
        return 1
    fi
    
    local task_file="$TASKS_DIR/active/${task_id}.json"
    if [ -f "$task_file" ]; then
        if ! check_checkpoints "$task_file" "$next_status"; then
            return 1
        fi
    fi
    
    log_info "✓ 状态转换验证通过：$current_status → $next_status"
    return 0
}

# 执行状态转换（带验证）
apply_transition() {
    local task_id="$1"
    local next_status="$2"
    
    local task_file=""
    local current_status=""
    
    for dir in active reviewing completed paused failed; do
        local test_file="$TASKS_DIR/$dir/${task_id}.json"
        if [ -f "$test_file" ]; then
            task_file="$test_file"
            current_status=$(jq -r '.status' "$test_file" 2>/dev/null || echo "unknown")
            break
        fi
    done
    
    if [ -z "$task_file" ]; then
        log_error "任务文件不存在：$task_id"
        return 1
    fi
    
    log_info "当前状态：$current_status"
    
    if ! validate_transition "$task_id" "$current_status" "$next_status"; then
        log_error "❌ 状态转换被拦截"
        return 1
    fi
    
    local timestamp=$(date -Iseconds)
    local target_dir="${STATE_TO_DIR[$next_status]:-active}"
    
    jq --arg status "$next_status" --arg time "$timestamp" \
       '.status = $status | .lastActivity = $time' \
       "$task_file" > "${task_file}.tmp"
    
    if [ $? -ne 0 ]; then
        log_error "状态更新失败"
        rm -f "${task_file}.tmp"
        return 1
    fi
    
    mv "${task_file}.tmp" "$TASKS_DIR/$target_dir/${task_id}.json"
    
    local checkpoint_file="$TASKS_DIR/$target_dir/${task_id}.checkpoint"
    echo "{\"timestamp\": \"$timestamp\", \"progress\": null, \"step\": \"状态转换：$current_status → $next_status\"}" >> "$checkpoint_file"
    
    log_info "✓ 状态转换成功：$current_status → $next_status"
    return 0
}

# 检查所有任务合规性
check_all_tasks() {
    log_info "检查所有任务 SOP 合规性..."
    
    local violations=0
    
    for dir in active reviewing paused completed failed; do
        for task_file in "$TASKS_DIR/$dir"/*.json; do
            if [ ! -f "$task_file" ]; then
                continue
            fi
            
            local task_id=$(jq -r '.taskId' "$task_file" 2>/dev/null || echo "unknown")
            local status=$(jq -r '.status' "$task_file" 2>/dev/null || echo "unknown")
            local progress=$(jq -r '.progress' "$task_file" 2>/dev/null || echo "0")
            
            # 检查状态一致性（使用映射表）
            local expected_dir="${STATE_TO_DIR[$status]}"
            if [ "$dir" != "$expected_dir" ]; then
                log_warn "SOP 违规：$task_id 状态不一致 (文件在 $dir, 状态为 $status, 应该在 $expected_dir)"
                violations=$((violations + 1))
            fi
            
            # 检查进度异常
            if [ "$progress" -lt 0 ] || [ "$progress" -gt 100 ]; then
                log_warn "SOP 违规：$task_id 进度异常 ($progress%)"
                violations=$((violations + 1))
            fi
        done
    done
    
    log_info "检查完成：发现 $violations 个 SOP 违规"
    
    if [ $violations -gt 0 ]; then
        return 1
    fi
    return 0
}

# 主程序
main() {
    local action="${1:-help}"
    
    case "$action" in
        "validate")
            local task_id="$2"
            local current="$3"
            local next="$4"
            
            if [ -z "$task_id" ] || [ -z "$current" ] || [ -z "$next" ]; then
                echo "用法：$0 validate <task_id> <current_status> <next_status>"
                exit 1
            fi
            
            validate_transition "$task_id" "$current" "$next"
            ;;
        
        "apply")
            local task_id="$2"
            local next="$3"
            
            if [ -z "$task_id" ] || [ -z "$next" ]; then
                echo "用法：$0 apply <task_id> <next_status>"
                exit 1
            fi
            
            apply_transition "$task_id" "$next"
            ;;
        
        "check")
            check_all_tasks
            ;;
        
        *)
            echo "SOP 验证器 - 状态机验证工具（修复版）"
            echo ""
            echo "用法:"
            echo "  $0 validate <task_id> <current_status> <next_status>"
            echo "  $0 apply <task_id> <next_status>"
            echo "  $0 check"
            echo ""
            echo "合法状态转换:"
            for trans in "${VALID_TRANSITIONS[@]}"; do
                echo "  - $trans"
            done
            ;;
    esac
}

main "$@"
