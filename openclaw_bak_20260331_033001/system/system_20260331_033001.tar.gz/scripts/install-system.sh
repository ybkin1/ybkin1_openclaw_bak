#!/bin/bash
# 运维自动化安装脚本
# 用途：一键安装 PostgreSQL 并配置环境变量

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE="/root/.openclaw/workspace/agents/master"
BACKUP_ROOT="/root/.openclaw/backups-unified"

echo "========================================"
echo "🔧 智能运维系统 - 运维自动化安装"
echo "========================================"
echo ""

# 检测操作系统
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        echo "$ID $VERSION_ID"
    else
        echo "unknown"
    fi
}

OS=$(detect_os)
echo "📋 检测到操作系统：$OS"
echo ""

# 1. 安装 PostgreSQL
echo "1️⃣  安装 PostgreSQL..."

case "$OS" in
    *"opencloudos"*|*"rocky"*|*"almalinux"*|*"rhel"*)
        echo "   使用 yum 安装..."
        yum install -y postgresql15 postgresql15-server postgresql15-contrib || {
            echo "   ⚠️  PostgreSQL 安装失败，请手动安装"
            echo "   命令：yum install -y postgresql15 postgresql15-server"
            exit 1
        }
        ;;
    *"ubuntu"*|*"debian"*)
        echo "   使用 apt 安装..."
        apt-get update
        apt-get install -y postgresql postgresql-contrib || {
            echo "   ⚠️  PostgreSQL 安装失败，请手动安装"
            echo "   命令：apt-get install -y postgresql postgresql-contrib"
            exit 1
        }
        ;;
    *)
        echo "   ⚠️  不支持的操作系统：$OS"
        echo "   请手动安装 PostgreSQL"
        exit 1
        ;;
esac

echo "   ✅ PostgreSQL 安装完成"
echo ""

# 2. 初始化数据库
echo "2️⃣  初始化数据库..."

# 检查是否是首次初始化
if [ ! -f /var/lib/pgsql/15/data/PG_VERSION ] && [ ! -f /var/lib/postgresql/data/PG_VERSION ]; then
    # OpenCloudOS/RHEL
    if [ -d /var/lib/pgsql/15 ]; then
        postgresql-setup --initdb || {
            echo "   ⚠️  数据库初始化失败"
            exit 1
        }
    # Ubuntu/Debian
    elif [ -d /var/lib/postgresql ]; then
        pg_createcluster 15 main --start || {
            echo "   ⚠️  数据库初始化失败"
            exit 1
        }
    fi
    echo "   ✅ 数据库初始化完成"
else
    echo "   ✅ 数据库已初始化"
fi
echo ""

# 3. 启动 PostgreSQL
echo "3️⃣  启动 PostgreSQL 服务..."

systemctl enable postgresql
systemctl start postgresql

if systemctl is-active --quiet postgresql; then
    echo "   ✅ PostgreSQL 服务已启动"
else
    echo "   ⚠️  PostgreSQL 服务启动失败"
    exit 1
fi
echo ""

# 4. 创建数据库和用户
echo "4️⃣  创建数据库和用户..."

DB_PASSWORD=$(python3 -c "import secrets; print(secrets.token_urlsafe(16))")

sudo -u postgres psql << EOF || {
    echo "   ⚠️  数据库配置失败，请手动配置"
    exit 1
}
-- 创建数据库
CREATE DATABASE fault_analysis;

-- 创建用户
CREATE USER app_user WITH PASSWORD '$DB_PASSWORD';

-- 授权
GRANT ALL PRIVILEGES ON DATABASE fault_analysis TO app_user;

-- 设置默认权限
\\c fault_analysis
GRANT ALL ON SCHEMA public TO app_user;
EOF

echo "   ✅ 数据库和用户创建完成"
echo "   📝 数据库密码：$DB_PASSWORD"
echo "   ⚠️  请保存此密码！"
echo ""

# 5. 配置环境变量
echo "5️⃣  配置环境变量..."

ENV_FILE="$WORKSPACE/.env"

# 生成密钥
ENCRYPTION_KEY=$(python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
JWT_SECRET=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")

cat > "$ENV_FILE" << EOF
# 智能运维系统环境变量
# 生成时间：$(date '+%Y-%m-%d %H:%M:%S')

# 加密配置
ENCRYPTION_KEY=$ENCRYPTION_KEY

# 数据库配置
DB_HOST=localhost
DB_PORT=5432
DB_NAME=fault_analysis
DB_USER=app_user
DB_PASSWORD=$DB_PASSWORD

# JWT 配置
JWT_SECRET=$JWT_SECRET

# 飞书告警 (可选)
FEISHU_WEBHOOK_URL=
FEISHU_SECRET=
EOF

chmod 600 "$ENV_FILE"
echo "   ✅ 环境变量已配置：$ENV_FILE"
echo ""

# 6. 配置 PostgreSQL 访问
echo "6️⃣  配置 PostgreSQL 访问..."

# 找到 pg_hba.conf 位置
PG_HBA=$(find /etc/postgresql -name pg_hba.conf 2>/dev/null | head -1)
if [ -z "$PG_HBA" ]; then
    PG_HBA="/var/lib/pgsql/15/data/pg_hba.conf"
fi

if [ -f "$PG_HBA" ]; then
    # 备份原配置
    cp "$PG_HBA" "$PG_HBA.bak.$(date +%Y%m%d_%H%M%S)"
    
    # 添加本地信任配置
    echo "host    fault_analysis  app_user  127.0.0.1/32    md5" >> "$PG_HBA"
    echo "host    fault_analysis  app_user  ::1/128         md5" >> "$PG_HBA"
    
    # 重载配置
    systemctl reload postgresql
    echo "   ✅ PostgreSQL 访问配置完成"
else
    echo "   ⚠️  未找到 pg_hba.conf，请手动配置"
fi
echo ""

# 7. 运行系统验证
echo "7️⃣  运行系统验证..."

# 测试数据库连接
export PGPASSWORD="$DB_PASSWORD"
if psql -h localhost -U app_user -d fault_analysis -c "SELECT 1" > /dev/null 2>&1; then
    echo "   ✅ 数据库连接测试通过"
else
    echo "   ⚠️  数据库连接测试失败"
fi

# 运行部署脚本
if [ -f "$WORKSPACE/scripts/deploy.sh" ]; then
    echo "   运行一键部署..."
    "$WORKSPACE/scripts/deploy.sh" || {
        echo "   ⚠️  部署脚本执行失败，请检查日志"
    }
fi
echo ""

# 8. 生成安装报告
echo "8️⃣  生成安装报告..."

INSTALL_REPORT="$WORKSPACE/docs/INSTALL-REPORT-$(date +%Y%m%d_%H%M%S).md"

cat > "$INSTALL_REPORT" << EOF
# 🔧 安装报告

**日期**: $(date '+%Y-%m-%d %H:%M:%S')
**主机**: $(hostname)
**操作系统**: $OS

## 安装内容

- [x] PostgreSQL 安装
- [x] 数据库初始化
- [x] 数据库用户创建
- [x] 环境变量配置
- [x] PostgreSQL 访问配置
- [x] 系统验证

## 数据库信息

- **主机**: localhost
- **端口**: 5432
- **数据库**: fault_analysis
- **用户**: app_user
- **密码**: $DB_PASSWORD (请妥善保存)

## 配置文件

- 环境变量：$ENV_FILE
- PostgreSQL: $PG_HBA

## 验证命令

\`\`\`bash
# 检查数据库连接
psql -h localhost -U app_user -d fault_analysis

# 检查系统状态
python3 $WORKSPACE/scripts/dashboard.py

# 运行测试
python3 $WORKSPACE/tests/integration/test_all_modules.py
\`\`\`

## 安全提醒

1. 请修改默认密码
2. 配置防火墙规则
3. 定期备份数据库
4. 监控日志文件

---
**安装状态**: ✅ 完成
EOF

echo "   ✅ 安装报告已生成：$INSTALL_REPORT"
echo ""

# 9. 显示总结
echo "========================================"
echo "✅ 安装完成"
echo "========================================"
echo ""
echo "📋 重要信息:"
echo "   数据库密码：$DB_PASSWORD"
echo "   配置文件：$ENV_FILE"
echo "   安装报告：$INSTALL_REPORT"
echo ""
echo "⚠️  安全提醒:"
echo "   1. 请修改默认密码"
echo "   2. 配置防火墙规则"
echo "   3. 定期备份数据库"
echo ""
echo "🚀 下一步:"
echo "   1. 运行系统验证：python3 $WORKSPACE/scripts/dashboard.py"
echo "   2. 执行集成测试：python3 $WORKSPACE/tests/integration/test_all_modules.py"
echo "   3. 配置飞书告警 (可选)"
echo ""
echo "========================================"
