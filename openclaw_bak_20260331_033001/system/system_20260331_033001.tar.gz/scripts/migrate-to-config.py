#!/usr/bin/env python3
"""
配置迁移脚本

将各模块迁移到使用统一的 config.py 和 logging_config.py
"""

import os
import re
from pathlib import Path

SRC_DIR = Path(__file__).parent.parent / 'src'

# 需要迁移的模块
MODULES_TO_MIGRATE = [
    'pattern_matcher.py',
    'timeline_builder.py',
    'event_summarizer.py',
    'chunk_processor.py',  # 已部分迁移
    'encoding_detector.py',
    'timestamp_extractor.py',
    'table_format_detector.py',
    'nvidia_monitor_parser.py',
    'event_extractor.py',
    'evidence_validator.py',
    'extraction_logger.py',
    'evidence_mapper.py',
    'report_generator.py',
]

def migrate_module(filepath: Path):
    """迁移单个模块"""
    print(f"处理：{filepath.name}")
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    
    # 1. 添加 logging 导入
    if 'import logging' not in content and 'get_logger' not in content:
        # 在第一个 import 块后添加
        import_match = re.search(r'^(import .+?\n)+', content, re.MULTILINE)
        if import_match:
            insert_pos = import_match.end()
            content = content[:insert_pos] + '\nlogger = None  # 稍后初始化\n' + content[insert_pos:]
    
    # 2. 替换硬编码配置为配置模块引用
    # 示例：max_lines_per_chunk = 10000 → from config import get_config
    if 'max_lines_per_chunk' in content and 'get_config' not in content:
        print(f"  - 发现硬编码配置：max_lines_per_chunk")
    
    # 3. 添加日志使用示例
    if 'print(' in content and 'logger' not in content:
        print(f"  - 发现 print 语句，建议替换为 logger.info()")
    
    # 保存修改
    if content != original_content:
        with open(filepath, 'w', encoding='utf-8') as f:
            content = f.write(content)
        print(f"  ✅ 已更新")
    else:
        print(f"  ℹ️ 无需修改")


def main():
    """主函数"""
    print("=== 配置迁移脚本 ===\n")
    
    for module in MODULES_TO_MIGRATE:
        filepath = SRC_DIR / module
        if filepath.exists():
            migrate_module(filepath)
        else:
            print(f"❌ 文件不存在：{filepath}")
    
    print("\n=== 迁移完成 ===")
    print("\n后续工作:")
    print("1. 手动检查每个模块的日志使用")
    print("2. 替换 print 为 logger.info/debug")
    print("3. 添加 get_config() 调用")
    print("4. 运行测试确保无回归")


if __name__ == '__main__':
    main()
