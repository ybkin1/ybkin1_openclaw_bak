#!/bin/bash
# Auto Review Trigger - 自动审查触发
# 任务完成后自动触发 Analysis Agent 审查
# Task: 2.2.1 + 2.2.2

set -euo pipefail

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
REVIEW_TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/review"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/auto-review-trigger.log"

mkdir -p "$REVIEW_TASKS_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Review: $1" | tee -a "$LOG_FILE"
}

# Task 2.2.1: 检测已完成但未审查的任务
detect_completed_tasks() {
    log "🔍 检测已完成但未审查的任务..."
    
    local detected=0
    
    for task_file in "$TASKS_DIR"/*.json; do
        if [ ! -f "$task_file" ]; then
            continue
        fi
        
        local task_id=$(basename "$task_file" .json)
        local status=$(jq -r '.status' "$task_file")
        local review_status=$(jq -r '.review_status // "pending"' "$task_file")
        
        # 检测已完成但未审查的任务
        if [ "$status" = "completed" ] && [ "$review_status" = "pending_analysis_review" ]; then
            log "📋 发现待审查任务：$task_id"
            detected=$((detected + 1))
            
            # 触发审查
            trigger_review "$task_file"
        fi
    done
    
    log "✅ 检测完成：发现 $detected 个待审查任务"
}

# Task 2.2.2: 触发审查
trigger_review() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title' "$task_file")
    local description=$(jq -r '.description' "$task_file")
    local output_files=$(jq -r '.output_files[]' "$task_file" 2>/dev/null)
    
    log "🚀 触发审查：$task_id"
    
    # 创建审查任务
    local review_task_file="$REVIEW_TASKS_DIR/${task_id}_review.json"
    local review_task_id="review_${task_id}"
    
    cat > "$review_task_file" << EOF
{
  "task_id": "$review_task_id",
  "parent_task": "$task_id",
  "type": "code_review",
  "title": "代码审查：$title",
  "description": "对任务 $task_id 进行代码审查",
  "status": "pending",
  "created_at": "$(date -Iseconds)",
  "estimated_duration_minutes": 15,
  "subagent": "analysis",
  "review_type": "full",
  "checklist": [
    "Spec Review (设计符合性)",
    "Code Quality Review (代码质量)",
    "AI Hallucination Detection (AI 幻觉检测)",
    "Test Coverage Check (测试覆盖率)"
  ],
  "source_task_file": "$task_file",
  "output_files": $(echo "$output_files" | jq -R -s 'split("\n") | map(select(length > 0))'),
  "review_status": "pending"
}
EOF
    
    # 更新原任务状态
    local temp_file=$(mktemp)
    jq --arg status "under_review" --arg time "$(date -Iseconds)" \
       '.review_status = $status | .review_started_at = $time' \
       "$task_file" > "$temp_file" && mv "$temp_file" "$task_file"
    
    log "✅ 审查任务已创建：$review_task_file"
}

# Task 2.2.3: 测试审查流程
test_review_flow() {
    log "🧪 测试审查流程..."
    
    # 创建测试任务
    local test_task_file="/tmp/test_review_task.json"
    cat > "$test_task_file" << 'EOF'
{
  "task_id": "test_review_task",
  "title": "测试任务",
  "description": "测试审查流程",
  "status": "completed",
  "review_status": "pending_analysis_review",
  "output_files": ["/tmp/test_output.txt"]
}
EOF
    
    # 触发审查
    trigger_review "$test_task_file"
    
    # 验证审查任务创建
    local review_file="$REVIEW_TASKS_DIR/review_test_review_task_review.json"
    if [ -f "$review_file" ]; then
        log "✅ 审查流程测试通过"
        rm -f "$test_task_file" "$review_file"
        return 0
    else
        log "❌ 审查流程测试失败"
        rm -f "$test_task_file"
        return 1
    fi
}

# 主函数：根据参数执行不同操作
case "${1:-detect}" in
    detect)
        detect_completed_tasks
        ;;
    trigger)
        if [ -z "${2:-}" ]; then
            log "❌ 用法：auto-review-trigger.sh trigger <task_file>"
            exit 1
        fi
        trigger_review "$2"
        ;;
    test)
        test_review_flow
        ;;
    *)
        echo "用法：auto-review-trigger.sh {detect|trigger|test} [args]"
        echo ""
        echo "命令:"
        echo "  detect  - 检测已完成但未审查的任务"
        echo "  trigger - 触发指定任务的审查"
        echo "  test    - 测试审查流程"
        exit 1
        ;;
esac
