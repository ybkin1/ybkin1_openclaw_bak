#!/bin/bash
# task-heartbeat.sh - 任务心跳机制
# 每 5 分钟更新一次任务心跳，防止任务被误判为僵尸

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
TASKS_DIR="$BASE_DIR/memory/tasks/active"
CHECKPOINT_DIR="$TASKS_DIR"
LOG_FILE="$BASE_DIR/logs/task-heartbeat.log"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保日志目录存在
mkdir -p "$(dirname "$LOG_FILE")"

log_info "=== 开始任务心跳检查 ==="

# 检查任务目录是否存在
if [ ! -d "$TASKS_DIR" ]; then
    log_warn "任务目录不存在：$TASKS_DIR"
    exit 0
fi

# 遍历所有活跃任务
task_count=0
updated_count=0

for task_file in "$TASKS_DIR"/*.json; do
    # 检查是否有匹配的文件
    if [ ! -f "$task_file" ]; then
        continue
    fi
    
    task_count=$((task_count + 1))
    task_name=$(basename "$task_file")
    task_id=$(jq -r '.taskId' "$task_file" 2>/dev/null || echo "unknown")
    
    log_info "检查任务：$task_name (ID: $task_id)"
    
    # 读取当前状态
    current_time=$(date -Iseconds)
    last_activity=$(jq -r '.lastActivity' "$task_file" 2>/dev/null || echo "")
    
    # 计算时间差（秒）
    if [ -n "$last_activity" ] && [ "$last_activity" != "null" ]; then
        last_activity_ts=$(date -d "$last_activity" +%s 2>/dev/null || echo "0")
        current_ts=$(date +%s)
        elapsed=$((current_ts - last_activity_ts))
    else
        elapsed=999999  # 无最后活动时间，强制更新
    fi
    
    # 如果超过 5 分钟未更新，强制更新心跳
    if [ $elapsed -gt 300 ]; then
        log_info "任务 $task_name 超过 5 分钟未更新心跳（已 ${elapsed}s），强制更新"
        
        # 读取当前进度
        current_progress=$(jq -r '.progress' "$task_file" 2>/dev/null || echo "0")
        current_step=$(jq -r '.currentStep // "等待中"' "$task_file" 2>/dev/null || echo "等待中")
        
        # 更新心跳
        jq --arg time "$current_time" \
           '.lastActivity = $time' \
           "$task_file" > "${task_file}.tmp"
        
        if [ $? -eq 0 ]; then
            mv "${task_file}.tmp" "$task_file"
            updated_count=$((updated_count + 1))
            
            # 写入检查点
            checkpoint_file="${task_file%.json}.checkpoint"
            echo "{\"timestamp\": \"$current_time\", \"progress\": $current_progress, \"step\": \"$current_step\", \"type\": \"heartbeat\"}" >> "$checkpoint_file"
            
            log_info "✓ 心跳更新成功"
        else
            log_error "心跳更新失败：$task_file"
            rm -f "${task_file}.tmp"
        fi
    else
        log_info "任务 $task_name 心跳正常（${elapsed}s 前更新）"
    fi
done

log_info "=== 心跳检查完成 ==="
log_info "总计任务：$task_count, 更新心跳：$updated_count"

# 返回统计信息
echo "{\"total_tasks\": $task_count, \"updated\": $updated_count, \"timestamp\": \"$(date -Iseconds)\"}"
