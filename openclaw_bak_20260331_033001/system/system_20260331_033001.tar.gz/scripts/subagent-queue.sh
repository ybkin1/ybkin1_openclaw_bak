#!/bin/bash
# Subagent Queue Manager - Subagent 队列管理
# 管理待执行任务队列，控制并发数
# Task: 1.2.1

set -euo pipefail

QUEUE_FILE="/tmp/subagent_queue.json"
PID_DIR="/tmp/subagent_pids"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/subagent-queue.log"
MAX_CONCURRENT=4

mkdir -p "$PID_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

# 初始化队列文件
init_queue() {
    if [ ! -f "$QUEUE_FILE" ]; then
        echo "[]" > "$QUEUE_FILE"
    fi
}

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Queue: $1" | tee -a "$LOG_FILE"
}

# Task 1.2.1: 添加任务到队列
add_to_queue() {
    local task_file="$1"
    local agent_type=$(jq -r '.subagent // "assistant"' "$task_file")
    local task_id=$(basename "$task_file" .json)
    
    log "📥 添加任务到队列：$task_id ($agent_type)"
    
    # 检查是否已在队列中
    local in_queue=$(jq --arg id "$task_id" '[.[] | select(.task_id == $id)] | length' "$QUEUE_FILE")
    
    if [ "$in_queue" -gt 0 ]; then
        log "⚠️ 任务已在队列中：$task_id"
        return 0
    fi
    
    # 添加到队列
    local temp_file=$(mktemp)
    jq --arg id "$task_id" --arg file "$task_file" --arg agent "$agent_type" --arg time "$(date -Iseconds)" \
       '. += [{"task_id": $id, "task_file": $file, "agent_type": $agent, "added_at": $time}]' \
       "$QUEUE_FILE" > "$temp_file" && mv "$temp_file" "$QUEUE_FILE"
    
    log "✅ 任务已添加到队列：$task_id"
}

# Task 1.2.1: 从队列移除任务
remove_from_queue() {
    local task_id="$1"
    
    log "📤 从队列移除任务：$task_id"
    
    local temp_file=$(mktemp)
    jq --arg id "$task_id" '[.[] | select(.task_id != $id)]' "$QUEUE_FILE" > "$temp_file" && mv "$temp_file" "$QUEUE_FILE"
    
    log "✅ 任务已从队列移除：$task_id"
}

# Task 1.2.2: 获取当前运行的 Subagent 数量
get_running_count() {
    local count=0
    
    for pid_file in "$PID_DIR"/*.pid; do
        if [ -f "$pid_file" ]; then
            local pid=$(cat "$pid_file")
            if ps -p "$pid" > /dev/null 2>&1; then
                count=$((count + 1))
            fi
        fi
    done
    
    echo "$count"
}

# Task 1.2.2: 处理队列
process_queue() {
    log "🔄 开始处理队列..."
    
    local queue_length=$(jq 'length' "$QUEUE_FILE")
    local running_count=$(get_running_count)
    local available_slots=$((MAX_CONCURRENT - running_count))
    
    log "📊 队列状态：队列长度=$queue_length, 运行中=$running_count, 可用=$available_slots"
    
    if [ "$available_slots" -le 0 ]; then
        log "⏸️ 无可用槽位，等待中..."
        return 0
    fi
    
    # 处理队列中的任务
    local processed=0
    
    for i in $(seq 0 $((queue_length - 1))); do
        if [ "$processed" -ge "$available_slots" ]; then
            break
        fi
        
        # 直接提取字段，避免中间变量
        local task_id=$(jq -r ".[$i].task_id" "$QUEUE_FILE")
        local task_file=$(jq -r ".[$i].task_file" "$QUEUE_FILE")
        local agent_type=$(jq -r ".[$i].agent_type" "$QUEUE_FILE")
        
        # 验证字段有效性
        if [ "$task_id" = "null" ] || [ "$task_file" = "null" ] || [ ! -f "$task_file" ]; then
            log "⚠️ 无效任务：task_id=$task_id, task_file=$task_file"
            # 从队列移除无效任务
            remove_from_queue "$task_id"
            continue
        fi
        
        log "🚀 启动 Subagent: $task_id ($agent_type)"
        
        # 启动 Subagent
        python3 /root/.openclaw/workspace/agents/master/scripts/subagent-launcher.py "$task_file" "$agent_type"
        
        if [ $? -eq 0 ]; then
            # 从队列移除
            remove_from_queue "$task_id"
            processed=$((processed + 1))
        else
            log "❌ Subagent 启动失败：$task_id"
        fi
    done
    
    log "✅ 队列处理完成：启动 $processed 个 Subagent"
}

# Task 1.2.1: 队列持久化
backup_queue() {
    local backup_file="/root/.openclaw/backups-unified/queue_backup_$(date +%Y%m%d_%H%M%S).json"
    cp "$QUEUE_FILE" "$backup_file"
    log "💾 队列已备份：$backup_file"
}

# 主循环
init_queue

# 检查是否有新任务需要添加到队列
TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
for task_file in "$TASKS_DIR"/*.json; do
    if [ -f "$task_file" ]; then
        status=$(jq -r '.status // "unknown"' "$task_file")
        
        if [ "$status" = "in_progress" ]; then
            task_id=$(basename "$task_file" .json)
            add_to_queue "$task_file"
        fi
    fi
done

# 处理队列
process_queue

# 备份队列
backup_queue

log "✅ Subagent Queue Manager 执行完成"
