#!/bin/bash

# Master Agent: 获取 Assistant Agent 任务结果
# 从结果队列中提取并显示已完成的任务结果

RESULTS_QUEUE="/tmp/agent_results.json"

# 检查队列是否存在
if [ ! -f "$RESULTS_QUEUE" ]; then
    echo "未找到结果队列: $RESULTS_QUEUE"
    echo "可能 Assistant Agent 还没有返回任何结果"
    exit 1
fi

# 检查 jq 是否可用
if ! command -v jq &>/dev/null; then
    echo "错误: 需要 jq 工具来解析 JSON"
    exit 1
fi

# 提取结果
echo "📊 Assistant Agent 任务执行结果"
echo "================================"

TOTAL_RESULTS=$(jq '.results | length' "$RESULTS_QUEUE" 2>/dev/null || echo "0")
echo "总结果数: $TOTAL_RESULTS"
echo ""

if [ "$TOTAL_RESULTS" -eq 0 ]; then
    echo "暂无已完成的任务"
    exit 0
fi

# 显示每个结果
jq -r '.results[] | "\(.task_id) | \(.title) | \(.status) | \(.completed_at)"' "$RESULTS_QUEUE" | \
    awk -F'|' '{printf "%-30s | %-25s | %-10s | %s\n", $1, $2, $3, $4}' | \
    sed '1i\TaskID                          | 标题                         | 状态       | 完成时间'

echo ""
echo "详细结果:"

# 显示详细结果
jq -c '.results[]' "$RESULTS_QUEUE" 2>/dev/null | while read -r result; do
    task_id=$(echo "$result" | jq -r '.task_id')
    title=$(echo "$result" | jq -r '.title')
    summary=$(echo "$result" | jq -r '.summary')

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "任务: $title ($task_id)"
    echo "状态: 成功"
    echo "摘要: $summary"
    echo ""
done

# 可选：清除已显示的结果（取消注释下一行以启用）
# jq '.results = []' "$RESULTS_QUEUE" > "${RESULTS_QUEUE}.tmp" && mv "${RESULTS_QUEUE}.tmp" "$RESULTS_QUEUE"
# echo "已清除已显示的结果"

exit 0