#!/bin/bash
# 企业微信机器人修复脚本
# 目标：修复 wecom 功能，不影响飞书 (master agent)
# 风险等级：低 (配置隔离，独立通道)

set -e

echo "========================================"
echo "🔧 企业微信机器人修复脚本"
echo "========================================"
echo ""

CONFIG_FILE="/root/.openclaw/openclaw.json"
BACKUP_FILE="$CONFIG_FILE.bak.$(date +%Y%m%d_%H%M%S)"

# 步骤 1: 备份配置
echo "1️⃣  备份当前配置..."
cp "$CONFIG_FILE" "$BACKUP_FILE"
echo "✅ 配置已备份：$BACKUP_FILE"
echo ""

# 步骤 2: 清理无效插件
echo "2️⃣  清理无效插件配置..."
python3 << 'PYTHON'
import json

with open('/root/.openclaw/openclaw.json', 'r') as f:
    config = json.load(f)

invalid_plugins = ['dingtalk', 'ddingtalk', 'skillhub']

# 从 allow 列表移除
if 'allow' in config.get('plugins', {}):
    original = config['plugins']['allow'].copy()
    config['plugins']['allow'] = [
        p for p in config['plugins']['allow'] 
        if p not in invalid_plugins
    ]
    removed = set(original) - set(config['plugins']['allow'])
    if removed:
        print(f"   移除无效插件：{removed}")

# 从 entries 移除
if 'entries' in config.get('plugins', {}):
    for plugin in invalid_plugins:
        if plugin in config['plugins']['entries']:
            del config['plugins']['entries'][plugin]
            print(f"   移除 entry: {plugin}")

# 保存配置
with open('/root/.openclaw/openclaw.json', 'w') as f:
    json.dump(config, f, indent=2, ensure_ascii=False)

print("✅ 无效插件已清理")
PYTHON
echo ""

# 步骤 3: 验证配置格式
echo "3️⃣  验证配置格式..."
python3 << 'PYTHON'
import json
import sys

try:
    with open('/root/.openclaw/openclaw.json', 'r') as f:
        config = json.load(f)
    
    # 验证插件配置格式
    if 'plugins' in config:
        if 'entries' in config['plugins']:
            for plugin_name, plugin_config in config['plugins']['entries'].items():
                if isinstance(plugin_config, dict):
                    invalid_keys = ['source', 'spec']
                    for key in invalid_keys:
                        if key in plugin_config:
                            print(f'❌ 无效配置：plugins.entries.{plugin_name}.{key}')
                            sys.exit(1)
    
    # 验证通道配置
    if 'channels' in config:
        if 'feishu' in config['channels']:
            print('✅ 飞书通道配置有效')
        if 'wecom' in config['channels']:
            print('✅ 企业微信通道配置有效')
    
    print('✅ 配置格式验证通过')
except Exception as e:
    print(f'❌ 配置错误：{e}')
    sys.exit(1)
PYTHON

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ 配置验证失败，恢复备份..."
    cp "$BACKUP_FILE" "$CONFIG_FILE"
    exit 1
fi
echo ""

# 步骤 4: 检查 Agent-通道绑定
echo "4️⃣  检查 Agent-通道绑定..."
echo ""
echo "Master Agent (飞书):"
jq '.agents.list[] | select(.id=="master") | "  通道：\(.channels // ["未指定"])"' "$CONFIG_FILE" 2>/dev/null || echo "  未找到配置"
echo ""
echo "Customer Service Agent (企业微信):"
jq '.agents.list[] | select(.id=="customer-service") | "  通道：\(.channels // ["未指定"])"' "$CONFIG_FILE" 2>/dev/null || echo "  未找到配置"
echo ""

# 步骤 5: 检查企业微信插件
echo "5️⃣  检查企业微信插件..."
if [ -d "/root/.openclaw/extensions/wecom" ]; then
    echo "✅ 企业微信插件已安装"
    echo "   位置：/root/.openclaw/extensions/wecom"
    
    if [ -f "/root/.openclaw/extensions/wecom/openclaw.plugin.json" ]; then
        echo "✅ 插件配置文件存在"
    else
        echo "⚠️  插件配置文件缺失"
    fi
else
    echo "❌ 企业微信插件未安装"
fi
echo ""

# 步骤 6: 检查 Gateway 状态
echo "6️⃣  检查 Gateway 状态..."
if systemctl --user is-active openclaw-gateway.service > /dev/null 2>&1; then
    echo "✅ Gateway 正在运行"
    
    # 检查飞书通道
    if journalctl -u openclaw-gateway.service --since "5 min ago" 2>&1 | grep -q "feishu"; then
        echo "✅ 飞书通道正常"
    else
        echo "⚠️  飞书通道无最近日志"
    fi
    
    # 检查企业微信通道
    if journalctl -u openclaw-gateway.service --since "5 min ago" 2>&1 | grep -q "wecom"; then
        echo "✅ 企业微信通道已加载"
    else
        echo "⚠️  企业微信通道未加载 (可能需要重启)"
    fi
else
    echo "❌ Gateway 未运行"
fi
echo ""

# 步骤 7: 提供重启选项
echo "========================================"
echo "📋 修复总结"
echo "========================================"
echo ""
echo "✅ 已完成:"
echo "   1. 配置备份"
echo "   2. 无效插件清理"
echo "   3. 配置格式验证"
echo "   4. Agent-通道绑定检查"
echo "   5. 企业微信插件检查"
echo ""
echo "⚠️  下一步操作:"
echo ""
echo "选项 A: 不重启 (推荐 - 飞书正常使用中)"
echo "   - 配置已修复，Gateway 会自动重载"
echo "   - 风险：最低"
echo ""
echo "选项 B: 优雅重启 (需要测试企业微信)"
echo "   - 执行：systemctl --user restart openclaw-gateway.service"
echo "   - 风险：低 (配置已验证)"
echo "   - 回滚：cp $BACKUP_FILE $CONFIG_FILE"
echo ""
echo "========================================"
echo "✅ 修复脚本执行完成"
echo "========================================"
echo ""
echo "💡 提示:"
echo "   - 飞书通道不受影响 (独立配置)"
echo "   - 企业微信通道配置已修复"
echo "   - 如需重启，请先测试飞书是否正常"
echo ""
