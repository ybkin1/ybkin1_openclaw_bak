# 协作任务聚合器

_最后更新：2026-03-18 | 用于合并 master 与 assistant 协作任务的最终结果_

---

## 功能

监控协作任务的子任务完成状态，聚合两个子任务的结果，生成统一报告。

---

## 使用方式

### 自动模式（由 master 内部调用）

```bash
# 环境变量（通常由 task-router 设置）
PARENT_TASK_ID="task_20260318_123456_collab_example"
MASTER_SUBTASK_FILE="/path/to/master/subtask.md"
ASSISTANT_SUBTASK_FILE="/path/to/assistant/subtask.md"

# 执行聚合
./aggregate-results.sh "$PARENT_TASK_ID" "$MASTER_SUBTASK_FILE" "$ASSISTANT_SUBTASK_FILE"
```

### 手动模式

```bash
./aggregate-results.sh <parent_task_id> <master_result_file> <assistant_result_file>
```

---

## 输入

- **Parent Task ID**: 协作主任务的唯一标识
- **Master Result File**: master 子任务的结果文件（_result.md）
- **Assistant Result File**: assistant 子任务的结果文件（_result.md）

---

## 输出

生成的聚合结果写入 `/tmp/agent_results_<parent_task_id>.json`，格式：

```json
{
  "task_id": "<parent_task_id>",
  "title": "协作任务 - ...",
  "status": "success",
  "completed_at": "2026-03-18T10:00:00Z",
  "collaboration": true,
  "master_summary": "...",
  "assistant_summary": "...",
  "master_result_file": "...",
  "assistant_result_file": "..."
}
```

---

## 流程

1. 定位子任务结果文件（从 completed/ 目录）
2. 提取执行摘要（## 执行摘要 或 ## Summary）
3. 合并内容，生成最终 JSON
4. 可选：写入 `/tmp/agent_results.json` 主队列

---

## 集成到 Master

在 `task-router-enhanced.sh` 的协作模式分支中，master 处理完自己的子任务后，调用：

```bash
./aggregate-results.sh "$parent_task_id" "$master_result_file" "$assistant_result_file"
```

然后更新主任务文件的聚合状态。

---

## 错误处理

- 任一子任务结果缺失 → 记录错误并继续等待
- JSON 生成失败 → 回退到文本格式汇总
- 超时 → 记录到 `memory/decisions/collaboration-timeouts.md`

---

**Author**: Master Agent  
**Date**: 2026-03-18
