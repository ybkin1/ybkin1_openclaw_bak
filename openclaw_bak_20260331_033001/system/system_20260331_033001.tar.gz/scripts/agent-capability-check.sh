#!/bin/bash
# Agent 能力框架验证脚本
# 检查所有 Agent 是否具备通用能力框架的要求

set -euo pipefail

LOG_FILE="/root/.openclaw/logs/agent-capability-check.log"
AGENT_DIR="/root/.openclaw/workspace/agents"
FRAMEWORK_FILE="/root/.openclaw/workspace/agents/master/memory/config/universal-agent-framework.md"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "${LOG_FILE}"
}

check_pass() {
    echo "[PASS] $1"
}

check_fail() {
    echo "[FAIL] $1"
}

check_warn() {
    echo "[WARN] $1"
}

# 检查通用能力框架文件是否存在
check_framework() {
    log "========== 检查通用能力框架 =========="
    
    if [ -f "$FRAMEWORK_FILE" ]; then
        check_pass "通用能力框架文件存在：$FRAMEWORK_FILE"
    else
        check_fail "通用能力框架文件缺失：$FRAMEWORK_FILE"
        return 1
    fi
}

# 检查每个 Agent 的配置文件
check_agents() {
    log "========== 检查 Agent 配置文件 =========="
    
    local agents=("master" "assistant" "analysis" "monitoring" "server-maintenance" "memory-manager" "backup" "customer-service" "database-manager" "file-processor")
    local total=${#agents[@]}
    local passed=0
    local failed=0
    
    for agent in "${agents[@]}"; do
        local agent_dir="$AGENT_DIR/$agent"
        local workflow_file="$agent_dir/WORKFLOW.md"
        local capabilities_file="$agent_dir/CAPABILITIES.md"
        
        echo ""
        log "检查 Agent: $agent"
        
        local agent_passed=true
        
        # 检查 WORKFLOW.md
        if [ -f "$workflow_file" ]; then
            check_pass "  WORKFLOW.md 存在"
        else
            check_fail "  WORKFLOW.md 缺失"
            agent_passed=false
        fi
        
        # 检查 CAPABILITIES.md
        if [ -f "$capabilities_file" ]; then
            check_pass "  CAPABILITIES.md 存在"
        else
            check_fail "  CAPABILITIES.md 缺失"
            agent_passed=false
        fi
        
        # 检查 AGENT.md 是否引用能力框架
        local agent_md="$agent_dir/AGENT.md"
        if [ -f "$agent_md" ]; then
            if grep -q "universal-agent-framework" "$agent_md" 2>/dev/null; then
                check_pass "  AGENT.md 引用能力框架"
            else
                check_warn "  AGENT.md 未引用能力框架（建议添加）"
            fi
        fi
        
        if [ "$agent_passed" = true ]; then
            ((passed++))
        else
            ((failed++))
        fi
    done
    
    echo ""
    log "========== Agent 配置检查结果 =========="
    log "总计：$total 个 Agent"
    log_pass "通过：$passed 个"
    log_fail "失败：$failed 个"
}

# 检查能力框架内容完整性
check_framework_content() {
    log "========== 检查能力框架内容完整性 =========="
    
    local required_sections=(
        "思考哲学"
        "工作流程"
        "任务管理"
        "质量保障"
        "资源优化"
        "协作能力"
        "持续改进"
    )
    
    for section in "${required_sections[@]}"; do
        if grep -q "$section" "$FRAMEWORK_FILE" 2>/dev/null; then
            check_pass "能力框架包含：$section"
        else
            check_fail "能力框架缺失：$section"
        fi
    done
}

# 检查自检清单
check_self_inspection() {
    log "========== 检查自检清单 =========="
    
    # 检查每个 Agent 的 CAPABILITIES.md 是否包含自检清单
    local agents=("master" "assistant" "analysis" "monitoring" "server-maintenance" "memory-manager" "backup" "customer-service" "database-manager" "file-processor")
    
    for agent in "${agents[@]}"; do
        local capabilities_file="$AGENT_DIR/$agent/CAPABILITIES.md"
        
        if [ -f "$capabilities_file" ]; then
            if grep -q "自检清单" "$capabilities_file" 2>/dev/null; then
                check_pass "$agent: 包含自检清单"
            else
                check_warn "$agent: 自检清单缺失（建议添加）"
            fi
        fi
    done
}

# 健壮性检查
check_robustness() {
    log "========== 健壮性检查 =========="
    
    # 检查错误处理
    if grep -q "错误处理" "$FRAMEWORK_FILE" 2>/dev/null; then
        check_pass "能力框架包含错误处理机制"
    else
        check_fail "能力框架缺失错误处理机制"
    fi
    
    # 检查崩溃恢复
    if grep -q "崩溃恢复" "$FRAMEWORK_FILE" 2>/dev/null; then
        check_pass "能力框架包含崩溃恢复机制"
    else
        check_fail "能力框架缺失崩溃恢复机制"
    fi
    
    # 检查超时监督
    if grep -q "超时监督" "$FRAMEWORK_FILE" 2>/dev/null; then
        check_pass "能力框架包含超时监督机制"
    else
        check_fail "能力框架缺失超时监督机制"
    fi
    
    # 检查边缘情况处理
    if grep -q "边缘情况" "$FRAMEWORK_FILE" 2>/dev/null; then
        check_pass "能力框架包含边缘情况处理"
    else
        check_fail "能力框架缺失边缘情况处理"
    fi
}

# 安全性检查
check_security() {
    log "========== 安全性检查 =========="
    
    # 检查安全防护
    if grep -q "安全防护" "$FRAMEWORK_FILE" 2>/dev/null; then
        check_pass "能力框架包含安全防护"
    else
        check_fail "能力框架缺失安全防护"
    fi
    
    # 检查危险操作识别
    if grep -q "危险操作" "$FRAMEWORK_FILE" 2>/dev/null; then
        check_pass "能力框架包含危险操作识别"
    else
        check_fail "能力框架缺失危险操作识别"
    fi
    
    # 检查 /careful 和 /freeze
    local monitoring_workflow="$AGENT_DIR/monitoring/WORKFLOW.md"
    if [ -f "$monitoring_workflow" ]; then
        if grep -q "/careful" "$monitoring_workflow" 2>/dev/null; then
            check_pass "Monitoring Agent 包含 /careful 危险操作拦截"
        else
            check_warn "Monitoring Agent 未明确 /careful 能力"
        fi
        
        if grep -q "/freeze" "$monitoring_workflow" 2>/dev/null; then
            check_pass "Monitoring Agent 包含 /freeze 目录保护"
        else
            check_warn "Monitoring Agent 未明确 /freeze 能力"
        fi
    fi
    
    # 检查数据库安全
    local db_workflow="$AGENT_DIR/database-manager/WORKFLOW.md"
    if [ -f "$db_workflow" ]; then
        if grep -q "DROP TABLE" "$db_workflow" 2>/dev/null; then
            check_pass "Database-Manager 包含 SQL 危险操作识别"
        else
            check_warn "Database-Manager 未明确 SQL 危险操作"
        fi
    fi
    
    # 检查备份安全
    local backup_workflow="$AGENT_DIR/backup/WORKFLOW.md"
    if [ -f "$backup_workflow" ]; then
        if grep -q "/careful" "$backup_workflow" 2>/dev/null; then
            check_pass "Backup Agent 包含删除警告"
        else
            check_warn "Backup Agent 未明确删除警告"
        fi
    fi
}

# 主函数
main() {
    log "============================================"
    log "Agent 能力框架验证开始"
    log "============================================"
    
    local total_checks=0
    local passed_checks=0
    local failed_checks=0
    
    # 执行检查
    check_framework && ((passed_checks++)) || ((failed_checks++))
    ((total_checks++))
    
    check_agents && ((passed_checks++)) || ((failed_checks++))
    ((total_checks++))
    
    check_framework_content && ((passed_checks++)) || ((failed_checks++))
    ((total_checks++))
    
    check_self_inspection && ((passed_checks++)) || ((failed_checks++))
    ((total_checks++))
    
    check_robustness && ((passed_checks++)) || ((failed_checks++))
    ((total_checks++))
    
    check_security && ((passed_checks++)) || ((failed_checks++))
    ((total_checks++))
    
    # 总结
    echo ""
    log "============================================"
    log "验证总结"
    log "============================================"
    log "总检查项：$total_checks"
    log_pass "通过：$passed_checks"
    log_fail "失败：$failed_checks"
    
    if [ $failed_checks -eq 0 ]; then
        log "${GREEN}所有检查通过！${NC}"
        return 0
    else
        log "${RED}有 $failed_checks 项检查失败，请检查日志。${NC}"
        return 1
    fi
}

# 运行主函数
main "$@"
