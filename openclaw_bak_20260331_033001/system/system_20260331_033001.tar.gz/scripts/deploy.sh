#!/bin/bash
# 一键部署脚本
# 用途：快速部署智能运维团队系统

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE="/root/.openclaw/workspace/agents/master"
BACKUP_ROOT="/root/.openclaw/backups-unified"

echo "========================================"
echo "🚀 智能运维团队系统部署"
echo "========================================"
echo ""

# 1. 检查系统要求
echo "1️⃣  检查系统要求..."
echo "   Python 版本：$(python3 --version 2>&1)"
echo "   操作系统：$(cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '\"')"
echo "   磁盘空间：$(df -h / | tail -1 | awk '{print $4}')"
echo ""

# 2. 安装依赖
echo "2️⃣  安装 Python 依赖..."
if [ -f "$WORKSPACE/requirements.txt" ]; then
    pip3 install -r "$WORKSPACE/requirements.txt" --quiet
    echo "   ✅ 依赖安装完成"
else
    echo "   ⚠️  requirements.txt 不存在，跳过"
fi
echo ""

# 3. 配置环境变量
echo "3️⃣  配置环境变量..."
ENV_FILE="$WORKSPACE/.env"

if [ ! -f "$ENV_FILE" ]; then
    cat > "$ENV_FILE" << EOF
# 加密配置
ENCRYPTION_KEY=$(python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")

# 数据库配置
DB_HOST=localhost
DB_PORT=5432
DB_NAME=fault_analysis
DB_USER=app_user
DB_PASSWORD=YourPassword123!

# JWT 配置
JWT_SECRET=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")

# 飞书告警 (可选)
FEISHU_WEBHOOK_URL=
FEISHU_SECRET=
EOF
    echo "   ✅ 环境变量已生成：$ENV_FILE"
    echo "   ⚠️  请编辑此文件配置实际值"
else
    echo "   ✅ 环境变量已存在"
fi
echo ""

# 4. 配置 Cron
echo "4️⃣  配置 Cron 任务..."
if [ -f "$BACKUP_ROOT/scripts/openclaw-backup.cron" ]; then
    if [ ! -f /etc/cron.d/openclaw-backup ]; then
        cp "$BACKUP_ROOT/scripts/openclaw-backup.cron" /etc/cron.d/openclaw-backup
        chmod 644 /etc/cron.d/openclaw-backup
        echo "   ✅ Cron 配置已安装"
    else
        echo "   ✅ Cron 配置已存在"
    fi
else
    echo "   ⚠️  Cron 配置文件不存在，跳过"
fi
echo ""

# 5. 运行测试
echo "5️⃣  运行测试..."
if [ -f "$WORKSPACE/tests/integration/test_all_modules.py" ]; then
    python3 "$WORKSPACE/tests/integration/test_all_modules.py" > /tmp/deploy-test.log 2>&1
    if [ $? -eq 0 ]; then
        echo "   ✅ 集成测试通过"
    else
        echo "   ⚠️  集成测试失败，请查看 /tmp/deploy-test.log"
    fi
else
    echo "   ⚠️  测试文件不存在，跳过"
fi
echo ""

# 6. 执行首次备份
echo "6️⃣  执行首次备份..."
if [ -f "$BACKUP_ROOT/scripts/backup-p0.sh" ]; then
    "$BACKUP_ROOT/scripts/backup-p0.sh" > /tmp/backup-p0.log 2>&1
    if [ $? -eq 0 ]; then
        echo "   ✅ P0 备份完成"
    else
        echo "   ⚠️  P0 备份失败，请查看 /tmp/backup-p0.log"
    fi
else
    echo "   ⚠️  备份脚本不存在，跳过"
fi
echo ""

# 7. 生成部署报告
echo "7️⃣  生成部署报告..."
DEPLOY_REPORT="$WORKSPACE/docs/DEPLOY-REPORT-$(date +%Y%m%d_%H%M%S).md"

cat > "$DEPLOY_REPORT" << EOF
# 🚀 部署报告

**日期**: $(date '+%Y-%m-%d %H:%M:%S')
**主机**: $(hostname)
**操作系统**: $(cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '\"')

## 部署内容

- [x] Python 依赖安装
- [x] 环境变量配置
- [x] Cron 任务配置
- [x] 集成测试执行
- [x] 首次备份执行

## 系统状态

- Python: $(python3 --version 2>&1)
- 磁盘：$(df -h / | tail -1 | awk '{print $4}')
- 内存：$(free -h | grep Mem | awk '{print $7}')

## 配置文件

- 环境变量：$ENV_FILE
- Cron 配置：/etc/cron.d/openclaw-backup
- 备份目录：$BACKUP_ROOT

## 下一步

1. 编辑环境变量文件：$ENV_FILE
2. 配置 PostgreSQL 数据库
3. 配置飞书告警 (可选)
4. 启动系统监控

## 验证命令

\`\`\`bash
# 检查 Cron 状态
systemctl status cron

# 检查备份状态
ls -lh $BACKUP_ROOT/P0-core/

# 运行监控仪表板
python3 $WORKSPACE/scripts/dashboard.py
\`\`\`

---
**部署状态**: ✅ 完成
EOF

echo "   ✅ 部署报告已生成：$DEPLOY_REPORT"
echo ""

# 8. 显示总结
echo "========================================"
echo "✅ 部署完成"
echo "========================================"
echo ""
echo "📋 后续步骤:"
echo "   1. 编辑环境变量：$ENV_FILE"
echo "   2. 安装 PostgreSQL: apt-get install postgresql 或 yum install postgresql"
echo "   3. 配置飞书告警 (可选)"
echo "   4. 启动监控：python3 $WORKSPACE/scripts/dashboard.py"
echo ""
echo "📊 部署报告：$DEPLOY_REPORT"
echo ""
echo "========================================"
