#!/bin/bash

# P3-1: 自适应重规划脚本
# 功能：监控任务进度偏差，自动触发重规划

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="${SCRIPT_DIR}/../logs/adaptive-replanner.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"
}

error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $*" | tee -a "$LOG_FILE" >&2
    exit 1
}

# 配置参数
DEFAULT_DEVIATION_THRESHOLD=50  # 进度偏差阈值 (%)
DEFAULT_REPLAN_COOLDOWN=3600   # 重规划冷却时间 (秒)

# 获取配置
get_config() {
    local key="$1"
    local default="$2"
    local config_file="${SCRIPT_DIR}/../config/adaptive-replanner-config.json"
    
    if [[ -f "$config_file" ]]; then
        local value
        value=$(jq -r ".${key} // \"${default}\"" "$config_file" 2>/dev/null || echo "$default")
        echo "$value"
    else
        echo "$default"
    fi
}

# 检查任务是否需要重规划
check_task_for_replan() {
    local task_file="$1"
    local threshold
    threshold=$(get_config "deviationThreshold" "$DEFAULT_DEVIATION_THRESHOLD")
    
    if [[ ! -f "$task_file" ]]; then
        return 1
    fi
    
    # 读取任务信息
    local expected_duration progress current_duration deviation
    expected_duration=$(jq -r '.expectedDuration // empty' "$task_file" 2>/dev/null || echo "0")
    progress=$(jq -r '.progress // 0' "$task_file" 2>/dev/null || echo "0")
    current_duration=$(($(date +%s) - $(date -d "$(jq -r '.startedAt' "$task_file" 2>/dev/null)" +%s)))
    
    if [[ "$expected_duration" -eq 0 ]] || [[ "$current_duration" -eq 0 ]]; then
        return 1
    fi
    
    # 计算预期进度
    local expected_progress
    expected_progress=$((current_duration * 100 / expected_duration))
    
    # 计算偏差
    deviation=$((expected_progress - progress))
    
    if [[ "$deviation" -gt "$threshold" ]]; then
        log "任务 $task_file 需要重规划: 预期进度 ${expected_progress}%, 实际进度 ${progress}%, 偏差 ${deviation}%"
        return 0
    fi
    
    return 1
}

# 触发重规划
trigger_replan() {
    local task_file="$1"
    
    # 检查冷却时间
    local last_replan_file="${task_file}.last_replan"
    local cooldown
    cooldown=$(get_config "replanCooldown" "$DEFAULT_REPLAN_COOLDOWN")
    
    if [[ -f "$last_replan_file" ]]; then
        local last_replan_time
        last_replan_time=$(cat "$last_replan_file")
        local current_time
        current_time=$(date +%s)
        
        if [[ $((current_time - last_replan_time)) -lt "$cooldown" ]]; then
            log "任务 $task_file 重规划在冷却中，跳过"
            return 1
        fi
    fi
    
    # 更新任务状态为需要重规划
    jq --argjson now "$(date +%s)" '
        .status = "needs_replan" |
        .replanRequestedAt = ($now | tostring) |
        .replanReason = "进度偏差过大"
    ' "$task_file" > "${task_file}.tmp" && mv "${task_file}.tmp" "$task_file"
    
    # 记录重规划时间
    date +%s > "$last_replan_file"
    
    log "已为任务 $task_file 触发重规划请求"
    
    # 发送通知（这里可以集成飞书通知）
    echo "任务需要重规划，请确认是否继续" > "${task_file}.notification"
    
    return 0
}

# 主函数
main() {
    log "开始自适应重规划检查"
    
    local active_tasks_dir="${SCRIPT_DIR}/../tasks/active"
    local tasks_checked=0
    local tasks_needing_replan=0
    
    if [[ ! -d "$active_tasks_dir" ]]; then
        log "活跃任务目录不存在"
        return 0
    fi
    
    # 检查所有活跃任务
    while IFS= read -r -d '' task_file; do
        tasks_checked=$((tasks_checked + 1))
        
        if check_task_for_replan "$task_file"; then
            tasks_needing_replan=$((tasks_needing_replan + 1))
            trigger_replan "$task_file"
        fi
        
    done < <(find "$active_tasks_dir" -name "*.json" -print0)
    
    log "重规划检查完成: 检查了 $tasks_checked 个任务, $tasks_needing_replan 个需要重规划"
}

# 创建配置文件（如果不存在）
create_default_config() {
    local config_file="${SCRIPT_DIR}/../config/adaptive-replanner-config.json"
    if [[ ! -f "$config_file" ]]; then
        mkdir -p "$(dirname "$config_file")"
        cat > "$config_file" << 'EOF'
{
  "enabled": true,
  "deviationThreshold": 50,
  "replanCooldown": 3600,
  "autoReplan": false,
  "notifyUser": true
}
EOF
        log "已创建默认配置文件: $config_file"
    fi
}

# 执行主函数
create_default_config
main "$@"