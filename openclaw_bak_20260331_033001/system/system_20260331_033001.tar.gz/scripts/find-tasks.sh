#!/bin/bash
# 任务查找工具 - 支持按日期过滤

# 用法:
#   find-tasks.sh                    # 查找所有活跃任务
#   find-tasks.sh today              # 查找今天创建的任务
#   find-tasks.sh yesterday          # 查找昨天创建的任务
#   find-tasks.sh 2026-03-28         # 查找指定日期创建的任务
#   find-tasks.sh week               # 查找本周创建的任务
#   find-tasks.sh month              # 查找本月创建的任务

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
ARCHIVED_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/archived"
STATE_DIR="/root/.openclaw/workspace/agents/master/memory/tasks"

# 解析参数
FILTER_TYPE="${1:-all}"
TARGET_DATE=""

case "$FILTER_TYPE" in
    today)
        TARGET_DATE=$(date +%Y-%m-%d)
        ;;
    yesterday)
        TARGET_DATE=$(date -d "yesterday" +%Y-%m-%d)
        ;;
    week)
        # 本周一的日期（如果今天是周一，使用今天；否则使用上周一）
        TARGET_DATE=$(date -d "last monday" +%Y-%m-%d)
        ;;
    month)
        # 本月第一天
        TARGET_DATE=$(date +%Y-%m-01)
        ;;
    all)
        TARGET_DATE=""
        ;;
    *)
        # 假设是日期格式 YYYY-MM-DD
        if [[ "$FILTER_TYPE" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
            TARGET_DATE="$FILTER_TYPE"
        else
            echo "用法：$0 [today|yesterday|week|month|all|YYYY-MM-DD]"
            exit 1
        fi
        ;;
esac

# 查找任务
echo "📋 任务查找"
echo "============"
if [ -n "$TARGET_DATE" ]; then
    echo "过滤条件：$TARGET_DATE 创建的任务"
else
    echo "过滤条件：所有活跃任务"
fi
echo ""

# 遍历任务文件
FOUND_COUNT=0

# 1. 检查 FILE-AGENT-DEV 状态文件
if [ -f "$STATE_DIR/FILE-AGENT-DEV-state.json" ]; then
    CREATED_AT=$(jq -r '.created_at // empty' "$STATE_DIR/FILE-AGENT-DEV-state.json" 2>/dev/null)
    if [ -n "$CREATED_AT" ]; then
        TASK_DATE=$(echo "$CREATED_AT" | cut -d'T' -f1)
        
        # 匹配检查
        MATCH=false
        if [ -z "$TARGET_DATE" ]; then
            MATCH=true
        elif [ "$TASK_DATE" = "$TARGET_DATE" ]; then
            MATCH=true
        fi
        
        if [ "$MATCH" = true ]; then
            TASK_ID="FILE-AGENT-DEV"
            TITLE=$(jq -r '.task_name // "文件管理 Agent 开发"' "$STATE_DIR/FILE-AGENT-DEV-state.json")
            STATUS=$(jq -r '.status // "unknown"' "$STATE_DIR/FILE-AGENT-DEV-state.json")
            PROGRESS=$(jq -r '.progress // 0' "$STATE_DIR/FILE-AGENT-DEV-state.json")
            
            printf "✅ %-40s  %-10s  进度：%5s  创建：%s\n" \
                "$TITLE" "$STATUS" "$PROGRESS" "$TASK_DATE"
            
            FOUND_COUNT=$((FOUND_COUNT + 1))
        fi
    fi
fi

# 2. 检查 active 目录中的任务
for task_file in "$TASKS_DIR"/*.json; do
    [ -f "$task_file" ] || continue
    
    # 提取创建日期
    CREATED_AT=$(jq -r '.created_at // empty' "$task_file" 2>/dev/null)
    [ -z "$CREATED_AT" ] && continue
    
    # 转换为日期格式
    TASK_DATE=$(echo "$CREATED_AT" | cut -d'T' -f1 | cut -d'+' -f1)
    
    # 匹配过滤条件
    MATCH=false
    if [ -z "$TARGET_DATE" ]; then
        MATCH=true
    elif [ "$FILTER_TYPE" = "week" ] || [ "$FILTER_TYPE" = "month" ]; then
        # 周/月过滤：检查是否在日期之后
        if [[ "$TASK_DATE" > "$TARGET_DATE" ]] || [ "$TASK_DATE" = "$TARGET_DATE" ]; then
            MATCH=true
        fi
    else
        # 精确日期匹配
        if [ "$TASK_DATE" = "$TARGET_DATE" ]; then
            MATCH=true
        fi
    fi
    
    if [ "$MATCH" = true ]; then
        TASK_ID=$(jq -r '.task_id // "unknown"' "$task_file")
        TITLE=$(jq -r '.title // "无标题"' "$task_file")
        STATUS=$(jq -r '.status // "unknown"' "$task_file")
        PROGRESS=$(jq -r '.progress // 0' "$task_file")
        
        # 格式化输出
        printf "✅ %-40s  %-10s  进度：%5s  创建：%s\n" \
            "$TITLE" "$STATUS" "$PROGRESS" "$TASK_DATE"
        
        FOUND_COUNT=$((FOUND_COUNT + 1))
    fi
done

echo ""
echo "============"
echo "共找到 $FOUND_COUNT 个任务"

# 如果没有找到任务
if [ $FOUND_COUNT -eq 0 ]; then
    echo ""
    echo "⚠️  未找到符合条件的任务"
    if [ "$FILTER_TYPE" = "yesterday" ]; then
        echo "💡 提示：昨天可能没有创建新任务，试试 'find-tasks.sh week' 查看本周任务"
    fi
fi
