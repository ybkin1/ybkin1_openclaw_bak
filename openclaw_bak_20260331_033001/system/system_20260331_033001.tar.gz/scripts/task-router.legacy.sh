#!/bin/bash

# Task Router for Master Agent
# 自动分类任务并转发给合适的 agent

# 配置
MASTER_QUEUE="/tmp/agent_queue.json"
ASSISTANT_QUEUE="/tmp/assistant_queue.json"
TASK_CLASSIFIER="/root/.openclaw/workspace/agents/master/scripts/task-classifier.sh"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 检查参数
if [ $# -lt 2 ]; then
    echo "Usage: $0 <task_description> <task_title> [task_metadata_json]"
    exit 1
fi

TASK_DESC="$1"
TASK_TITLE="$2"
TASK_METADATA="${3:-}"

# 1. 分类任务
log_info "正在分类任务: $TASK_TITLE"
CLASSIFICATION_OUTPUT=$($TASK_CLASSIFIER "$TASK_DESC" "$TASK_TITLE")
if [ $? -ne 0 ]; then
    log_error "任务分类失败"
    exit 1
fi

COMPLEXITY=$(echo "$CLASSIFICATION_OUTPUT" | jq -r '.complexity')
RECOMMENDED_AGENT=$(echo "$CLASSIFICATION_OUTPUT" | jq -r '.recommended_agent')

log_info "任务复杂度: $COMPLEXITY, 推荐处理: $RECOMMENDED_AGENT"

# 2. 根据分类结果路由
case $RECOMMENDED_AGENT in
    "assistant")
        log_warn "检测到复杂任务，转发给 Assistant Agent"

        # 生成任务ID
        TASK_ID="task_$(date +%Y%m%d_%H%M%S)_$(echo "$TASK_TITLE" | sed 's/[^a-zA-Z0-9]/_/g' | head -c 50)"
        TASK_FILE="/root/.openclaw/workspace/agents/assistant/memory/assistant/tasks/$TASK_ID.md"

        # 创建任务文件
        cat > "$TASK_FILE" <<EOF
# 任务转交 - $TASK_TITLE

**来源**: master agent (自动路由)  
**接收时间**: $(date '+%Y-%m-%d %H:%M:%S')  
**任务类型**: $COMPLEXITY (自动分类)  
**任务ID**: $TASK_ID  

## 原始任务

**标题**: $TASK_TITLE  
**描述**: $TASK_DESC

## 元数据
EOF

        # 附加元数据（如果提供）
        if [ -n "$TASK_METADATA" ] && echo "$TASK_METADATA" | jq -e . >/dev/null 2>&1; then
            echo "\`\`\`json" >> "$TASK_FILE"
            echo "$TASK_METADATA" >> "$TASK_FILE"
            echo "\`\`\`" >> "$TASK_FILE"
        else
            echo "无附加元数据" >> "$TASK_FILE"
        fi

        # 通知 assistant 有 new task（可以扩展为发送消息给 assistant agent）
        log_info "任务已创建: $TASK_FILE"

        # 输出路由结果
        echo "ROUTED_TO=assistant"
        echo "TASK_ID=$TASK_ID"
        echo "TASK_FILE=$TASK_FILE"
        echo "COMPLEXITY=$COMPLEXITY"

        exit 0
        ;;

    "master")
        log_info "任务由 Master Agent 自行处理"
        echo "ROUTED_TO=master"
        echo "COMPLEXITY=$COMPLEXITY"
        exit 1  # 返回 1 表示不需转发
        ;;

    *)
        log_warn "未知推荐 agent: $RECOMMENDED_AGENT，默认由 Master 处理"
        echo "ROUTED_TO=master"
        echo "COMPLEXITY=$COMPLEXITY"
        exit 1
        ;;
esac