#!/bin/bash
# Kimi Code 配置脚本
# 用途：一键配置 Kimi Code Allegretto 到 OpenClaw

set -e

CONFIG_FILE="/root/.openclaw/openclaw.json"
ENV_FILE="/root/.openclaw/workspace/agents/master/.env"
BACKUP_FILE="$CONFIG_FILE.bak.$(date +%Y%m%d_%H%M%S)"

echo "========================================"
echo "🎹 Kimi Code 配置脚本"
echo "========================================"
echo ""

# 1. 获取 API Key
echo "1️⃣  请输入 Kimi API Key:"
echo "    (获取地址：https://platform.moonshot.cn/console/api-keys)"
read -s KIMI_API_KEY
echo ""

if [ -z "$KIMI_API_KEY" ]; then
    echo "❌ API Key 不能为空"
    exit 1
fi

echo "   ✅ API Key 已接收"
echo ""

# 2. 添加到 .env
echo "2️⃣  添加 API Key 到环境变量..."
echo "" >> "$ENV_FILE"
echo "# Kimi Code API Key (Added on $(date '+%Y-%m-%d %H:%M:%S'))" >> "$ENV_FILE"
echo "KIMI_API_KEY=$KIMI_API_KEY" >> "$ENV_FILE"
echo "✅ API Key 已添加到 $ENV_FILE"
echo ""

# 3. 备份 openclaw.json
echo "3️⃣  备份当前配置..."
cp "$CONFIG_FILE" "$BACKUP_FILE"
echo "✅ 配置已备份：$BACKUP_FILE"
echo ""

# 4. 添加 moonshot provider
echo "4️⃣  配置 Kimi Code 模型..."

python3 << PYTHON
import json
import sys

try:
    with open('$CONFIG_FILE', 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    # 确保 models 和 providers 存在
    if 'models' not in config:
        config['models'] = {'mode': 'merge', 'providers': {}}
    if 'providers' not in config['models']:
        config['models']['providers'] = {}
    
    # 添加 moonshot provider
    config['models']['providers']['moonshot'] = {
        'baseUrl': 'https://api.moonshot.cn/v1',
        'apiKey': '$KIMI_API_KEY',
        'api': 'openai-completions',
        'models': [
            {
                'id': 'kimi-code',
                'name': 'Kimi Code (Allegretto)',
                'api': 'openai-completions',
                'reasoning': False,
                'input': ['text', 'code'],
                'cost': {
                    'input': 0.002,
                    'output': 0.008,
                    'cacheRead': 0,
                    'cacheWrite': 0
                },
                'contextWindow': 128000,
                'maxTokens': 16384
            },
            {
                'id': 'kimi-plus',
                'name': 'Kimi Plus',
                'api': 'openai-completions',
                'reasoning': False,
                'input': ['text'],
                'cost': {
                    'input': 0.012,
                    'output': 0.012,
                    'cacheRead': 0,
                    'cacheWrite': 0
                },
                'contextWindow': 128000,
                'maxTokens': 16384
            }
        ]
    }
    
    # 更新默认模型 (使用 Kimi Code 作为主力)
    if 'agents' in config and 'defaults' in config['agents']:
        config['agents']['defaults']['model']['primary'] = 'moonshot/kimi-code'
        config['agents']['defaults']['model']['fallbacks'] = [
            'moonshot/kimi-plus',
            'qwencode/qwen3.5-plus'
        ]
    
    # 更新各个 Agent 的模型配置
    if 'agents' in config and 'list' in config['agents']:
        for agent in config['agents']['list']:
            if agent['id'] in ['master', 'assistant', 'customer-service', 'analysis']:
                agent['model'] = {
                    'primary': 'moonshot/kimi-code',
                    'fallbacks': ['moonshot/kimi-plus', 'qwencode/qwen3.5-plus']
                }
    
    # 保存配置
    with open('$CONFIG_FILE', 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    
    print("✅ Kimi Code 已添加到配置")
    print(f"   - Provider: moonshot")
    print(f"   - Models: kimi-code, kimi-plus")
    print(f"   - 默认模型：moonshot/kimi-code")

except Exception as e:
    print(f"❌ 配置失败：{e}")
    sys.exit(1)
PYTHON

echo ""

# 5. 验证配置
echo "5️⃣  验证配置..."
if python3 -c "import json; json.load(open('$CONFIG_FILE'))" 2>/dev/null; then
    echo "✅ 配置文件格式正确"
else
    echo "❌ 配置文件格式错误"
    echo "   恢复备份：cp $BACKUP_FILE $CONFIG_FILE"
    exit 1
fi
echo ""

# 6. 显示配置摘要
echo "========================================"
echo "✅ Kimi Code 配置完成"
echo "========================================"
echo ""
echo "📋 配置摘要:"
echo "   Provider: moonshot"
echo "   Models: kimi-code, kimi-plus"
echo "   默认模型：moonshot/kimi-code"
echo "   API Key: ${KIMI_API_KEY:0:10}...${KIMI_API_KEY: -4}"
echo ""
echo "🚀 下一步:"
echo "   1. 重启 Gateway:"
echo "      systemctl --user restart openclaw-gateway.service"
echo ""
echo "   2. 查看可用模型:"
echo "      openclaw models list"
echo ""
echo "   3. 测试 Kimi Code:"
echo "      openclaw chat '用 Python 写一个快速排序'"
echo ""
echo "   4. 查看余额:"
echo "      https://platform.moonshot.cn/console/billing"
echo ""
echo "💡 提示:"
echo "   - 如需恢复配置：cp $BACKUP_FILE $CONFIG_FILE"
echo "   - 余额监控：访问 Moonshot 控制台"
echo ""
