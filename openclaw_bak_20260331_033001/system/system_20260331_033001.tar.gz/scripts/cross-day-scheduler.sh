#!/bin/bash
# cross-day-scheduler.sh - 跨天任务调度
# 每天 23:00 暂停活跃任务，次日 08:30 恢复

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
TASKS_ACTIVE_DIR="$BASE_DIR/memory/tasks/active"
TASKS_PAUSED_DIR="$BASE_DIR/memory/tasks/paused"
LOG_FILE="$BASE_DIR/logs/cross-day-scheduler.log"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保目录存在
mkdir -p "$TASKS_PAUSED_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

# 发送通知函数（使用飞书）
send_notification() {
    local title="$1"
    local content="$2"
    
    log_info "发送通知：$title - $content"
    # TODO: 集成飞书通知 API
    # 可以使用现有的 send_notification 函数
}

# 暂停任务
pause_tasks() {
    log_info "=== 开始暂停活跃任务 ==="
    
    if [ ! -d "$TASKS_ACTIVE_DIR" ]; then
        log_warn "活跃任务目录不存在：$TASKS_ACTIVE_DIR"
        return 0
    fi
    
    paused_count=0
    
    for task_file in "$TASKS_ACTIVE_DIR"/*.json; do
        if [ ! -f "$task_file" ]; then
            continue
        fi
        
        task_name=$(basename "$task_file")
        task_id=$(jq -r '.taskId' "$task_file" 2>/dev/null || echo "unknown")
        
        log_info "暂停任务：$task_name (ID: $task_id)"
        
        # 更新状态为 paused
        current_time=$(date -Iseconds)
        jq --arg time "$current_time" \
           '.status = "paused" | .pauseReason = "cross_day" | .pausedAt = $time' \
           "$task_file" > "${task_file}.tmp"
        
        if [ $? -eq 0 ]; then
            # 移动到 paused 目录
            mv "${task_file}.tmp" "$TASKS_PAUSED_DIR/$task_name"
            
            # 创建暂停摘要
            summary_file="$TASKS_PAUSED_DIR/${task_name%.json}.summary"
            cat > "$summary_file" << EOF
# 任务暂停摘要

**任务 ID**: $task_id
**暂停时间**: $current_time
**暂停原因**: 跨天暂停（23:00）
**最后进度**: $(jq -r '.progress' "$task_file" 2>/dev/null || echo "未知")
**最后步骤**: $(jq -r '.currentStep' "$task_file" 2>/dev/null || echo "未知")

## 待继续工作
$(jq -r '.nextStep // "待确认"' "$task_file" 2>/dev/null)

## 注意事项
- 次日 08:30 自动恢复
- 恢复前请检查系统状态
EOF
            
            paused_count=$((paused_count + 1))
            log_info "✓ 任务已暂停：$task_name"
            
            # 发送通知
            send_notification "任务暂停通知" "任务 $task_id 已暂停，将于次日 08:30 恢复"
        else
            log_error "暂停失败：$task_name"
            rm -f "${task_file}.tmp"
        fi
    done
    
    log_info "=== 暂停完成 ==="
    log_info "暂停任务数：$paused_count"
}

# 恢复任务
resume_tasks() {
    log_info "=== 开始恢复暂停任务 ==="
    
    if [ ! -d "$TASKS_PAUSED_DIR" ]; then
        log_warn "暂停任务目录不存在：$TASKS_PAUSED_DIR"
        return 0
    fi
    
    resumed_count=0
    
    for task_file in "$TASKS_PAUSED_DIR"/*.json; do
        if [ ! -f "$task_file" ]; then
            continue
        fi
        
        task_name=$(basename "$task_file")
        task_id=$(jq -r '.taskId' "$task_file" 2>/dev/null || echo "unknown")
        pause_reason=$(jq -r '.pauseReason' "$task_file" 2>/dev/null || echo "unknown")
        
        # 只恢复跨天暂停的任务
        if [ "$pause_reason" != "cross_day" ]; then
            log_info "跳过非跨天暂停任务：$task_name (原因：$pause_reason)"
            continue
        fi
        
        log_info "恢复任务：$task_name (ID: $task_id)"
        
        # 更新状态为 in_progress
        current_time=$(date -Iseconds)
        jq --arg time "$current_time" \
           '.status = "in_progress" | del(.pauseReason) | del(.pausedAt) | .resumedAt = $time | .lastActivity = $time' \
           "$task_file" > "${task_file}.tmp"
        
        if [ $? -eq 0 ]; then
            # 移动回 active 目录
            mv "${task_file}.tmp" "$TASKS_ACTIVE_DIR/$task_name"
            
            # 删除摘要文件（已恢复）
            summary_file="$TASKS_PAUSED_DIR/${task_name%.json}.summary"
            if [ -f "$summary_file" ]; then
                # 归档摘要文件
                mv "$summary_file" "$TASKS_ACTIVE_DIR/${task_name%.json}.summary"
            fi
            
            resumed_count=$((resumed_count + 1))
            log_info "✓ 任务已恢复：$task_name"
            
            # 发送通知
            send_notification "任务恢复通知" "任务 $task_id 已恢复执行"
        else
            log_error "恢复失败：$task_name"
            rm -f "${task_file}.tmp"
        fi
    done
    
    log_info "=== 恢复完成 ==="
    log_info "恢复任务数：$resumed_count"
}

# 主程序
case "${1:-}" in
    pause)
        pause_tasks
        ;;
    resume)
        resume_tasks
        ;;
    *)
        echo "用法：$0 {pause|resume}"
        echo ""
        echo "pause   - 暂停所有活跃任务（23:00 调用）"
        echo "resume  - 恢复所有暂停任务（08:30 调用）"
        exit 1
        ;;
esac
