#!/bin/bash
# 百炼 + OpenRouter 免费模型配置脚本
# 用途：配置百炼 coding plan + OpenRouter step flash 3.5

set -e

CONFIG_FILE="/root/.openclaw/openclaw.json"
ENV_FILE="/root/.openclaw/workspace/agents/master/.env"
BACKUP_FILE="$CONFIG_FILE.bak.$(date +%Y%m%d_%H%M%S)"

echo "========================================"
echo "⚙️  百炼 + OpenRouter 配置脚本"
echo "========================================"
echo ""

# 1. 备份当前配置
echo "1️⃣  备份当前配置..."
cp "$CONFIG_FILE" "$BACKUP_FILE"
echo "✅ 配置已备份：$BACKUP_FILE"
echo ""

# 2. 配置模型
echo "2️⃣  配置模型 Provider..."

python3 << PYTHON
import json
import sys

try:
    with open('$CONFIG_FILE', 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    # 确保 models 和 providers 存在
    if 'models' not in config:
        config['models'] = {'mode': 'merge', 'providers': {}}
    if 'providers' not in config['models']:
        config['models']['providers'] = {}
    
    # 保留 qwencode (百炼)
    if 'qwencode' not in config['models']['providers']:
        config['models']['providers']['qwencode'] = {
            'baseUrl': 'https://coding.dashscope.aliyuncs.com/v1',
            'apiKey': '${DASHSCOPE_API_KEY}',
            'api': 'openai-completions',
            'models': [
                {
                    'id': 'qwen3.5-plus',
                    'name': 'Qwen3.5 Plus (百炼 coding plan)',
                    'api': 'openai-completions',
                    'reasoning': False,
                    'input': ['text', 'code'],
                    'cost': {'input': 0, 'output': 0, 'cacheRead': 0, 'cacheWrite': 0},
                    'contextWindow': 200000,
                    'maxTokens': 8192
                },
                {
                    'id': 'qwen3-max-2026-01-23',
                    'name': 'Qwen3 Max',
                    'api': 'openai-completions',
                    'reasoning': False,
                    'input': ['text'],
                    'cost': {'input': 0, 'output': 0, 'cacheRead': 0, 'cacheWrite': 0},
                    'contextWindow': 200000,
                    'maxTokens': 8192
                },
                {
                    'id': 'qwen3-coder-plus',
                    'name': 'Qwen3 Coder Plus',
                    'api': 'openai-completions',
                    'reasoning': False,
                    'input': ['text', 'code'],
                    'cost': {'input': 0, 'output': 0, 'cacheRead': 0, 'cacheWrite': 0},
                    'contextWindow': 200000,
                    'maxTokens': 8192
                }
            ]
        }
    
    # 配置 openrouter (只保留免费的 step flash 3.5)
    config['models']['providers']['openrouter'] = {
        'baseUrl': 'https://openrouter.ai/api/v1',
        'apiKey': '${OPENROUTER_API_KEY}',
        'api': 'openai-completions',
        'models': [
            {
                'id': 'stepfun/step-3.5-flash:free',
                'name': 'Step 3.5 Flash (免费)',
                'api': 'openai-completions',
                'reasoning': False,
                'input': ['text'],
                'cost': {'input': 0, 'output': 0, 'cacheRead': 0, 'cacheWrite': 0},
                'contextWindow': 128000,
                'maxTokens': 8192
            }
        ]
    }
    
    # 移除 kimi/moonshot 配置 (如果有)
    if 'moonshot' in config['models']['providers']:
        del config['models']['providers']['moonshot']
        print("✅ 已移除 Kimi Code 配置")
    
    # 更新默认模型 (百炼为主，OpenRouter 免费为辅)
    if 'agents' in config and 'defaults' in config['agents']:
        config['agents']['defaults']['model']['primary'] = 'qwencode/qwen3.5-plus'
        config['agents']['defaults']['model']['fallbacks'] = [
            'qwencode/qwen3-max-2026-01-23',
            'openrouter/stepfun/step-3.5-flash:free'
        ]
    
    # 更新各个 Agent 的模型配置
    if 'agents' in config and 'list' in config['agents']:
        for agent in config['agents']['list']:
            agent_id = agent.get('id', '')
            
            # 代码相关 Agent 使用百炼
            if agent_id in ['master', 'analysis', 'database-manager', 'file-processor']:
                agent['model'] = {
                    'primary': 'qwencode/qwen3.5-plus',
                    'fallbacks': ['qwencode/qwen3-max-2026-01-23']
                }
            
            # 客服/助手使用免费模型
            elif agent_id in ['assistant', 'customer-service']:
                agent['model'] = {
                    'primary': 'openrouter/stepfun/step-3.5-flash:free',
                    'fallbacks': ['qwencode/qwen3.5-plus']
                }
            
            # 其他 Agent 使用百炼
            else:
                agent['model'] = {
                    'primary': 'qwencode/qwen3.5-plus',
                    'fallbacks': ['qwencode/qwen3-max-2026-01-23']
                }
    
    # 保存配置
    with open('$CONFIG_FILE', 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    
    print("✅ 模型配置完成")
    print(f"   - 百炼 coding plan: qwen3.5-plus, qwen3-max, qwen3-coder-plus")
    print(f"   - OpenRouter 免费：stepfun/step-3.5-flash:free")
    print(f"   - 默认模型：qwencode/qwen3.5-plus")

except Exception as e:
    print(f"❌ 配置失败：{e}")
    sys.exit(1)
PYTHON

echo ""

# 3. 验证配置
echo "3️⃣  验证配置..."
if python3 -c "import json; json.load(open('$CONFIG_FILE'))" 2>/dev/null; then
    echo "✅ 配置文件格式正确"
else
    echo "❌ 配置文件格式错误"
    echo "   恢复备份：cp $BACKUP_FILE $CONFIG_FILE"
    exit 1
fi
echo ""

# 4. 显示配置摘要
echo "========================================"
echo "✅ 百炼 + OpenRouter 配置完成"
echo "========================================"
echo ""
echo "📋 配置摘要:"
echo "   主力模型：百炼 coding plan (免费)"
echo "   备用模型：OpenRouter step flash 3.5 (免费)"
echo "   默认模型：qwencode/qwen3.5-plus"
echo ""
echo "📦 可用模型:"
echo "   百炼:"
echo "     - qwen3.5-plus (主力)"
echo "     - qwen3-max-2026-01-23 (备用)"
echo "     - qwen3-coder-plus (代码)"
echo "   OpenRouter:"
echo "     - stepfun/step-3.5-flash:free (免费)"
echo ""
echo "🚀 下一步:"
echo "   1. 检查环境变量:"
echo "      cat $ENV_FILE | grep -E 'DASHSCOPE|OPENROUTER'"
echo ""
echo "   2. 重启 Gateway:"
echo "      systemctl --user restart openclaw-gateway.service"
echo ""
echo "   3. 查看可用模型:"
echo "      openclaw models list"
echo ""
echo "   4. 测试模型:"
echo "      openclaw chat '你好'"
echo ""
echo "💡 提示:"
echo "   - 如需恢复配置：cp $BACKUP_FILE $CONFIG_FILE"
echo "   - 百炼 API Key 获取：https://bailian.console.aliyun.com/"
echo "   - OpenRouter API Key 获取：https://openrouter.ai/keys"
echo ""
