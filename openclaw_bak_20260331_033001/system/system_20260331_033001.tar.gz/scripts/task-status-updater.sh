#!/bin/bash
# Task Status Updater - 任务状态更新器
# 收集 Subagent 结果，更新任务状态
# Task: 1.1.3

set -euo pipefail

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
PID_DIR="/tmp/subagent_pids"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/task-status-updater.log"

mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Task 1.1.3: 检查 Subagent 完成状态
check_subagent_completion() {
    log "🔍 检查 Subagent 完成状态..."
    
    local completed_count=0
    
    for task_file in "$TASKS_DIR"/*.json; do
        if [ ! -f "$task_file" ]; then
            continue
        fi
        
        local task_id=$(basename "$task_file" .json)
        local status=$(jq -r '.status // "unknown"' "$task_file")
        
        # 仅检查 in_progress 状态的任务
        if [ "$status" != "in_progress" ]; then
            continue
        fi
        
        # 检查 PID 文件
        local pid_file="$PID_DIR/${task_id}.pid"
        
        if [ -f "$pid_file" ]; then
            local pid=$(cat "$pid_file")
            
            # 检查进程是否还在运行
            if ! ps -p "$pid" > /dev/null 2>&1; then
                # Subagent 已完成
                log "✅ Subagent 已完成：$task_id (PID: $pid)"
                
                # 收集结果
                collect_subagent_result "$task_file"
                
                # 更新状态
                update_task_status "$task_file" "completed"
                
                completed_count=$((completed_count + 1))
                
                # 清理 PID 文件
                rm -f "$pid_file"
            else
                log "⏳ Subagent 运行中：$task_id (PID: $pid)"
            fi
        else
            log "⚠️ 无 PID 文件：$task_id"
        fi
    done
    
    log "✅ 检查完成：$completed_count 个 Subagent 完成"
}

# Task 1.1.3: 收集 Subagent 结果
collect_subagent_result() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    
    log "📝 收集 Subagent 结果：$task_id"
    
    # 检查是否有结果文件
    local result_file="/tmp/subagent_${task_id}_result.txt"
    
    if [ -f "$result_file" ]; then
        log "✅ 找到结果文件：$result_file"
        
        # 保存结果到任务目录
        local task_result_dir=$(dirname "$task_file")/../completed
        mkdir -p "$task_result_dir"
        
        cp "$result_file" "$task_result_dir/${task_id}_result.txt"
        
        # 清理临时文件
        rm -f "$result_file"
    else
        log "⚠️ 无结果文件：$task_id (可能未生成)"
    fi
}

# Task 1.1.3: 更新任务状态
update_task_status() {
    local task_file="$1"
    local new_status="$2"
    
    local task_id=$(basename "$task_file" .json)
    local temp_file=$(mktemp)
    
    # 更新状态
    jq --arg status "$new_status" \
       --arg time "$(date -Iseconds)" \
       '.status = $status | 
        .last_activity = $time | 
        .completed_at = $time' \
       "$task_file" > "$temp_file" && mv "$temp_file" "$task_file"
    
    log "✅ 任务状态更新：$task_id -> $new_status"
}

# 主循环
check_subagent_completion

log "✅ Task Status Updater 执行完成"
