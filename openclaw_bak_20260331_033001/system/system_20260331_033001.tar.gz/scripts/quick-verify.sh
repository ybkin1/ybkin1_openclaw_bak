#!/bin/bash
# 快速验证脚本
# 用途：快速验证系统状态和功能

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE="/root/.openclaw/workspace/agents/master"
BACKUP_ROOT="/root/.openclaw/backups-unified"

echo "========================================"
echo "🔍 智能运维系统 - 快速验证"
echo "========================================"
echo ""

PASS=0
FAIL=0

check() {
    local name="$1"
    local cmd="$2"
    
    if eval "$cmd" > /dev/null 2>&1; then
        echo "✅ $name"
        PASS=$((PASS + 1))
    else
        echo "❌ $name"
        FAIL=$((FAIL + 1))
    fi
}

# 1. 系统检查
echo "【系统检查】"
check "Python 3" "python3 --version"
check "pip3" "pip3 --version"
check "Git" "git --version"
check "Cron 服务" "systemctl is-active cron || systemctl is-active crond"
echo ""

# 2. 依赖检查
echo "【依赖检查】"
check "cryptography" "python3 -c 'import cryptography'"
check "requests" "python3 -c 'import requests'"
check "psutil" "python3 -c 'import psutil'"
check "bcrypt" "python3 -c 'import bcrypt'"
check "jose" "python3 -c 'from jose import jwt'"
echo ""

# 3. 代码检查
echo "【代码检查】"
check "加密服务" "[ -f $WORKSPACE/src/security/encryption.py ]"
check "RBAC 权限" "[ -f $WORKSPACE/src/security/rbac.py ]"
check "JWT 认证" "[ -f $WORKSPACE/src/security/auth.py ]"
check "租户中间件" "[ -f $WORKSPACE/src/tenancy/tenant_middleware.py ]"
check "Master Agent" "[ -f $WORKSPACE/src/agents/master_sla.py ]"
check "Assistant Agent" "[ -f $WORKSPACE/src/agents/assistant_agent.py ]"
check "File Processor" "[ -f $WORKSPACE/src/agents/file_processor_agent.py ]"
check "Database Agent" "[ -f $WORKSPACE/src/agents/database_agent.py ]"
check "Monitoring Agent" "[ -f $WORKSPACE/src/agents/monitoring_agent.py ]"
check "通信框架" "[ -f $WORKSPACE/src/agents/communication_framework.py ]"
echo ""

# 4. 测试检查
echo "【测试检查】"
check "集成测试" "[ -f $WORKSPACE/tests/integration/test_all_modules.py ]"
check "端到端测试" "[ -f $WORKSPACE/tests/e2e/test_scenarios.py ]"
check "性能基线" "[ -f $WORKSPACE/scripts/performance_baseline.py ]"
check "监控仪表板" "[ -f $WORKSPACE/scripts/dashboard.py ]"
echo ""

# 5. 备份检查
echo "【备份检查】"
check "P0 备份目录" "[ -d $BACKUP_ROOT/P0-core ]"
check "每日备份目录" "[ -d $BACKUP_ROOT/daily ]"
check "备份脚本" "[ -f $BACKUP_ROOT/scripts/backup-p0.sh ]"
check "Cron 配置" "[ -f /etc/cron.d/openclaw-backup ]"
check "监控告警" "[ -f $BACKUP_ROOT/scripts/monitor-alert.sh ]"

# 检查 P0 备份文件
P0_COUNT=$(ls -1 $BACKUP_ROOT/P0-core/*.enc 2>/dev/null | wc -l)
if [ $P0_COUNT -gt 0 ]; then
    echo "✅ P0 备份文件：$P0_COUNT 个"
    PASS=$((PASS + 1))
else
    echo "❌ P0 备份文件：0 个"
    FAIL=$((FAIL + 1))
fi

# 检查每日备份
DAILY_COUNT=$(ls -1 $BACKUP_ROOT/daily/*.tar.gz 2>/dev/null | wc -l)
if [ $DAILY_COUNT -gt 0 ]; then
    echo "✅ 每日备份文件：$DAILY_COUNT 个"
    PASS=$((PASS + 1))
else
    echo "❌ 每日备份文件：0 个"
    FAIL=$((FAIL + 1))
fi
echo ""

# 6. 数据库检查
echo "【数据库检查】"
if command -v psql > /dev/null 2>&1; then
    check "PostgreSQL 客户端" "psql --version"
    
    # 检查环境变量
    if [ -f "$WORKSPACE/.env" ]; then
        source "$WORKSPACE/.env" 2>/dev/null || true
        if [ -n "$DB_HOST" ] && [ -n "$DB_NAME" ]; then
            echo "✅ 环境变量配置"
            PASS=$((PASS + 1))
            
            # 尝试连接数据库
            export PGPASSWORD="$DB_PASSWORD"
            if psql -h "$DB_HOST" -U "$DB_USER" -d "$DB_NAME" -c "SELECT 1" > /dev/null 2>&1; then
                echo "✅ 数据库连接"
                PASS=$((PASS + 1))
            else
                echo "❌ 数据库连接 (PostgreSQL 可能未安装或配置)"
                FAIL=$((FAIL + 1))
            fi
        else
            echo "❌ 环境变量未配置"
            FAIL=$((FAIL + 1))
        fi
    else
        echo "❌ 环境变量文件不存在"
        FAIL=$((FAIL + 1))
    fi
else
    echo "⚠️  PostgreSQL 客户端未安装 (跳过数据库检查)"
fi
echo ""

# 7. 运行快速测试
echo "【快速测试】"
if [ -f "$WORKSPACE/tests/integration/test_all_modules.py" ]; then
    echo "运行集成测试..."
    if python3 "$WORKSPACE/tests/integration/test_all_modules.py" > /tmp/quick-test.log 2>&1; then
        echo "✅ 集成测试通过"
        PASS=$((PASS + 1))
    else
        echo "❌ 集成测试失败"
        FAIL=$((FAIL + 1))
    fi
else
    echo "⚠️  集成测试文件不存在"
fi
echo ""

# 8. 显示总结
echo "========================================"
echo "📊 验证结果"
echo "========================================"
echo "✅ 通过：$PASS"
echo "❌ 失败：$FAIL"
echo ""

if [ $FAIL -eq 0 ]; then
    echo "🎉 所有检查通过！系统可以投入生产。"
    echo ""
    echo "🚀 下一步:"
    echo "   1. 配置飞书告警 (可选)"
    echo "   2. 执行用户验收测试"
    echo "   3. 部署到生产环境"
    exit 0
else
    echo "⚠️  发现 $FAIL 个问题，请修复后重试。"
    echo ""
    echo "📋 修复建议:"
    if [ $FAIL -gt 0 ]; then
        echo "   - 检查失败的项目"
        echo "   - 查看文档：docs/OPS-CHECKLIST.md"
        echo "   - 运行安装脚本：scripts/install-system.sh"
    fi
    exit 1
fi
