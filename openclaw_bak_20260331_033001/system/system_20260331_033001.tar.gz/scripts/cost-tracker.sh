#!/bin/bash
# cost-tracker.sh - 成本追踪器
# 统计 token 使用并计算成本，实现成本告警

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
TASKS_DIR="$BASE_DIR/tasks"
LOG_FILE="$BASE_DIR/logs/cost-tracker.log"
DAILY_COST_FILE="$BASE_DIR/reports/daily/daily-cost-$(date +%Y-%m-%d).json"
CONFIG_FILE="$BASE_DIR/memory/config/cost-thresholds.json"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保目录存在
mkdir -p "$BASE_DIR/logs"
mkdir -p "$BASE_DIR/reports/daily"
mkdir -p "$BASE_DIR/memory/config"

# 默认成本阈值（可在配置文件中覆盖）
DEFAULT_DAILY_THRESHOLD=1.00  # 每日 1 美元
DEFAULT_TASK_THRESHOLD=0.10   # 单任务 0.1 美元

# 读取配置
read_config() {
    if [ -f "$CONFIG_FILE" ]; then
        cat "$CONFIG_FILE"
    else
        # 创建默认配置
        cat > "$CONFIG_FILE" << 'EOF'
{
  "dailyThreshold": 1.00,
  "taskThreshold": 0.10,
  "alertEnabled": true,
  "alertCooldown": 3600
}
EOF
        cat "$CONFIG_FILE"
    fi
}

# 获取模型成本配置（从 openclaw.json）
get_model_cost() {
    local model_id="$1"
    local cost_type="$2"  # input, output, cacheRead, cacheWrite
    
    local cost=$(jq -r --arg model "$model_id" --arg type "$cost_type" \
        '.models.providers[].models[] | select(.id == $model) | .cost[$type] // 0' \
        /root/.openclaw/openclaw.json 2>/dev/null || echo "0")
    
    echo "$cost"
}

# 计算任务成本
calculate_task_cost() {
    local task_file="$1"
    
    if [ ! -f "$task_file" ]; then
        log_error "任务文件不存在：$task_file"
        return 1
    fi
    
    # 读取 token 使用
    local input_tokens=$(jq -r '.cost.inputTokens // 0' "$task_file")
    local output_tokens=$(jq -r '.cost.outputTokens // 0' "$task_file")
    local model_id=$(jq -r '.modelId // "qwencode/qwen3.5-plus"' "$task_file")
    
    # 获取成本费率
    local input_cost=$(get_model_cost "$model_id" "input")
    local output_cost=$(get_model_cost "$model_id" "output")
    
    # 计算成本（处理空值）
    local input_cost_rate=$(get_model_cost "$model_id" "input")
    local output_cost_rate=$(get_model_cost "$model_id" "output")
    
    # 确保费率不为空
    input_cost_rate=${input_cost_rate:-0}
    output_cost_rate=${output_cost_rate:-0}
    
    # 计算成本
    local total_cost=$(echo "scale=6; $input_tokens * $input_cost_rate + $output_tokens * $output_cost_rate" | bc -l 2>/dev/null || echo "0")
    
    # 更新任务文件
    jq --argjson cost "$total_cost" \
       '.cost.estimatedCost = $cost' \
       "$task_file" > "${task_file}.tmp"
    
    if [ $? -eq 0 ]; then
        mv "${task_file}.tmp" "$task_file"
        log_info "✓ 任务成本计算完成：$(basename $task_file) = \$${total_cost}"
    else
        log_error "成本计算失败"
        rm -f "${task_file}.tmp"
        return 1
    fi
    
    echo "$total_cost"
}

# 更新任务 token 使用
update_task_tokens() {
    local task_id="$1"
    local input_tokens="$2"
    local output_tokens="$3"
    local model_id="${4:-qwencode/qwen3.5-plus}"
    
    # 查找任务文件
    local task_file=""
    for dir in active reviewing; do
        local test_file="$TASKS_DIR/$dir/${task_id}.json"
        if [ -f "$test_file" ]; then
            task_file="$test_file"
            break
        fi
    done
    
    if [ -z "$task_file" ]; then
        log_warn "任务文件未找到：$task_id"
        return 1
    fi
    
    # 更新 token 使用
    local timestamp=$(date -Iseconds)
    jq --argjson input "$input_tokens" \
       --argjson output "$output_tokens" \
       --arg model "$model_id" \
       --arg time "$timestamp" \
       '.cost.inputTokens = (.cost.inputTokens + $input) | .cost.outputTokens = (.cost.outputTokens + $output) | .cost.modelId = $model | .lastActivity = $time' \
       "$task_file" > "${task_file}.tmp"
    
    if [ $? -eq 0 ]; then
        mv "${task_file}.tmp" "$task_file"
        log_info "✓ Token 使用已更新：$task_id (input: $input_tokens, output: $output_tokens)"
        
        # 计算成本
        calculate_task_cost "$task_file"
        
        # 检查是否超过阈值
        check_threshold "$task_file"
    else
        log_error "Token 更新失败"
        rm -f "${task_file}.tmp"
        return 1
    fi
}

# 检查成本阈值
check_threshold() {
    local task_file="$1"
    
    # 读取配置
    local config=$(read_config)
    local daily_threshold=$(echo "$config" | jq -r '.dailyThreshold')
    local task_threshold=$(echo "$config" | jq -r '.taskThreshold')
    
    # 计算任务成本
    local task_cost=$(jq -r '.cost.estimatedCost // 0' "$task_file")
    local task_id=$(jq -r '.taskId' "$task_file")
    
    # 检查单任务阈值
    if (( $(echo "$task_cost > $task_threshold" | bc -l) )); then
        log_warn "⚠️ 单任务成本超阈值：$task_id = \$${task_cost} (阈值：\$${task_threshold})"
        # TODO: 发送告警通知
    fi
    
    # 计算当日总成本
    local daily_total=0
    for f in "$TASKS_DIR"/active/*.json "$TASKS_DIR"/completed/*.json; do
        if [ -f "$f" ]; then
            local cost=$(jq -r '.cost.estimatedCost // 0' "$f")
            daily_total=$(echo "$daily_total + $cost" | bc -l)
        fi
    done
    
    # 检查每日阈值
    if (( $(echo "$daily_total > $daily_threshold" | bc -l) )); then
        log_warn "⚠️ 每日成本超阈值：\$${daily_total} (阈值：\$${daily_threshold})"
        # TODO: 发送告警通知
    fi
    
    # 记录到每日成本文件
    record_daily_cost "$daily_total"
}

# 记录每日成本
record_daily_cost() {
    local daily_total="$1"
    local timestamp=$(date -Iseconds)
    
    # 初始化或追加
    if [ ! -f "$DAILY_COST_FILE" ]; then
        echo "{\"date\": \"$(date +%Y-%m-%d)\", \"records\": []}" > "$DAILY_COST_FILE"
    fi
    
    # 添加记录
    jq --arg time "$timestamp" --argjson cost "$daily_total" \
       '.records += [{"timestamp": $time, "totalCost": $cost}]' \
       "$DAILY_COST_FILE" > "${DAILY_COST_FILE}.tmp"
    
    mv "${DAILY_COST_FILE}.tmp" "$DAILY_COST_FILE"
}

# 生成成本报告
generate_report() {
    local report_type="${1:-daily}"
    local date="${2:-$(date +%Y-%m-%d)}"
    
    log_info "生成成本报告：$report_type ($date)"
    
    case "$report_type" in
        "daily")
            # 生成日报
            local report_file="$BASE_DIR/reports/daily/cost-report-$date.md"
            
            cat > "$report_file" << EOF
# 成本日报 - $date

**生成时间**: $(date '+%Y-%m-%d %H:%M:%S')

## 当日总成本

\$(jq -r '.records[-1].totalCost // 0' "$DAILY_COST_FILE")

## 任务成本明细

| 任务 ID | 成本 |
|--------|------|
EOF
            
            # 添加任务明细
            for f in "$TASKS_DIR"/active/*.json "$TASKS_DIR"/completed/*.json; do
                if [ -f "$f" ]; then
                    local task_id=$(jq -r '.taskId' "$f")
                    local cost=$(jq -r '.cost.estimatedCost // 0' "$f")
                    echo "| $task_id | \$${cost} |" >> "$report_file"
                fi
            done
            
            log_info "✓ 成本日报已生成：$report_file"
            ;;
        
        *)
            log_error "未知报告类型：$report_type"
            return 1
            ;;
    esac
}

# 主程序
main() {
    local action="${1:-help}"
    
    case "$action" in
        "update")
            # 更新 token 使用
            local task_id="$2"
            local input="$3"
            local output="$4"
            local model="${5:-qwencode/qwen3.5-plus}"
            
            if [ -z "$task_id" ] || [ -z "$input" ] || [ -z "$output" ]; then
                echo "用法：$0 update <task_id> <input_tokens> <output_tokens> [model_id]"
                exit 1
            fi
            
            update_task_tokens "$task_id" "$input" "$output" "$model"
            ;;
        
        "calculate")
            # 计算任务成本
            local task_file="$2"
            
            if [ -z "$task_file" ]; then
                echo "用法：$0 calculate <task_file>"
                exit 1
            fi
            
            calculate_task_cost "$task_file"
            ;;
        
        "report")
            # 生成成本报告
            local type="$2"
            local date="$3"
            
            generate_report "$type" "$date"
            ;;
        
        "config")
            # 显示配置
            read_config | jq .
            ;;
        
        *)
            echo "成本追踪器 - Token 统计和成本计算工具"
            echo ""
            echo "用法:"
            echo "  $0 update <task_id> <input_tokens> <output_tokens> [model_id]  # 更新 token 使用"
            echo "  $0 calculate <task_file>                                       # 计算任务成本"
            echo "  $0 report [daily] [date]                                       # 生成成本报告"
            echo "  $0 config                                                      # 显示配置"
            echo ""
            echo "配置:"
            read_config | jq .
            ;;
    esac
}

# 运行主程序
main "$@"
