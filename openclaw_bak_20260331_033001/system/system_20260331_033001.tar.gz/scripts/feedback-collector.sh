#!/bin/bash
# feedback-collector.sh - 用户反馈收集器
# 任务完成后自动收集用户满意度反馈

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
FEEDBACK_DIR="$BASE_DIR/memory/feedback"
RESPONSES_DIR="$FEEDBACK_DIR/responses"
CONFIG_FILE="$FEEDBACK_DIR/config.json"
LOG_FILE="$BASE_DIR/logs/feedback-collector.log"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保目录存在
mkdir -p "$RESPONSES_DIR"
mkdir -p "$BASE_DIR/logs"

# 默认配置
DEFAULT_CONFIG='{
  "enabled": true,
  "quietHours": {"start": 23, "end": 8},
  "maxPerDay": 5,
  "unsubscribe": false
}'

# 读取配置
read_config() {
    if [ -f "$CONFIG_FILE" ]; then
        cat "$CONFIG_FILE"
    else
        echo "$DEFAULT_CONFIG" > "$CONFIG_FILE"
        cat "$CONFIG_FILE"
    fi
}

# 检查是否在免打扰时段
is_quiet_hours() {
    local hour=$(date +%H)
    local config=$(read_config)
    local start=$(echo "$config" | jq -r '.quietHours.start')
    local end=$(echo "$config" | jq -r '.quietHours.end')
    
    if [ "$hour" -ge "$start" ] || [ "$hour" -lt "$end" ]; then
        return 0
    fi
    return 1
}

# 检查今日发送次数
check_daily_limit() {
    local today=$(date +%Y-%m-%d)
    local count=$(find "$RESPONSES_DIR" -name "${today}_*.json" 2>/dev/null | wc -l)
    local config=$(read_config)
    local max=$(echo "$config" | jq -r '.maxPerDay')
    
    if [ "$count" -ge "$max" ]; then
        return 1
    fi
    return 0
}

# 检查是否已退订
is_unsubscribed() {
    local config=$(read_config)
    local unsubscribed=$(echo "$config" | jq -r '.unsubscribe')
    
    if [ "$unsubscribed" = "true" ]; then
        return 0
    fi
    return 1
}

# 发送反馈请求
send_feedback_request() {
    local task_id="$1"
    local task_name="$2"
    local completion_time="$3"
    local duration="$4"
    local achievements="$5"
    
    log_info "发送反馈请求：$task_id"
    
    # 检查退订
    if is_unsubscribed; then
        log_warn "用户已退订，跳过反馈请求"
        return 0
    fi
    
    # 检查免打扰时段
    if is_quiet_hours; then
        log_warn "当前为免打扰时段，跳过反馈请求"
        return 0
    fi
    
    # 检查每日限制
    if ! check_daily_limit; then
        log_warn "已达每日反馈请求上限，跳过"
        return 0
    fi
    
    # 生成反馈请求消息
    local message=$(cat << EOF
✅ 任务完成通知

**任务**: $task_name
**完成时间**: $completion_time
**总耗时**: $duration

**主要成果**:
$achievements

**满意度调查**:
请回复 1-5 分评价本次任务完成情况：
5️⃣ 非常满意 - 超出预期
4️⃣ 满意 - 符合预期
3️⃣ 一般 - 基本完成
2️⃣ 不满意 - 有待改进
1️⃣ 非常不满意 - 需要重做

**意见建议**（可选）:
如有改进建议，请回复告诉我们。

---
如不想接收反馈请求，请回复"退订"
EOF
)
    
    # 记录反馈请求
    local response_file="$RESPONSES_DIR/${today}_${task_id}.json"
    cat > "$response_file" << EOF
{
  "taskId": "$task_id",
  "taskName": "$task_name",
  "completionTime": "$completion_time",
  "duration": "$duration",
  "requestSent": true,
  "requestSentAt": "$(date -Iseconds)",
  "feedback": null
}
EOF
    
    log_info "✓ 反馈请求已发送：$task_id"
    log_info "反馈文件：$response_file"
    
    # TODO: 发送飞书通知
    # send_feishu_notification "$message"
    
    echo "$message"
}

# 记录用户反馈
record_feedback() {
    local task_id="$1"
    local rating="$2"
    local comment="$3"
    
    log_info "记录用户反馈：$task_id (评分：$rating)"
    
    local today=$(date +%Y-%m-%d)
    local response_file="$RESPONSES_DIR/${today}_${task_id}.json"
    
    if [ ! -f "$response_file" ]; then
        log_error "反馈文件不存在：$response_file"
        return 1
    fi
    
    # 更新反馈
    jq --argjson rating "$rating" \
       --arg comment "$comment" \
       --arg time "$(date -Iseconds)" \
       '.feedback = {"rating": $rating, "comment": $comment, "submittedAt": $time}' \
       "$response_file" > "${response_file}.tmp"
    
    mv "${response_file}.tmp" "$response_file"
    
    log_info "✓ 反馈已记录：$task_id"
}

# 生成周反馈报告
generate_weekly_report() {
    local week="$1"
    local year="${2:-$(date +%Y)}"
    
    log_info "生成周反馈报告：$year-W$week"
    
    local report_file="$FEEDBACK_DIR/weekly/${year}-W${week}-report.md"
    mkdir -p "$(dirname "$report_file")"
    
    # 统计本周反馈
    local total_tasks=0
    local total_feedback=0
    local total_rating=0
    
    for f in "$RESPONSES_DIR/${year}-W${week}_*.json"; do
        if [ -f "$f" ]; then
            total_tasks=$((total_tasks + 1))
            local rating=$(jq -r '.feedback.rating // 0' "$f")
            if [ "$rating" -gt 0 ]; then
                total_feedback=$((total_feedback + 1))
                total_rating=$((total_rating + rating))
            fi
        fi
    done
    
    local avg_rating=0
    if [ "$total_feedback" -gt 0 ]; then
        avg_rating=$(echo "scale=1; $total_rating / $total_feedback" | bc)
    fi
    
    # 生成报告
    cat > "$report_file" << EOF
# 用户反馈周报

**周期**: $year-W$week

## 总体统计

| 指标 | 数值 |
|------|------|
| 完成任务数 | $total_tasks |
| 收到反馈数 | $total_feedback |
| 平均评分 | $avg_rating/5 |
| 满意度 | $(echo "scale=0; $total_feedback * 100 / $total_tasks" | bc)% |

## 任务明细

| 任务 | 评分 | 意见 |
|------|------|------|
EOF
    
    for f in "$RESPONSES_DIR/${year}-W${week}_*.json"; do
        if [ -f "$f" ]; then
            local task_name=$(jq -r '.taskName' "$f")
            local rating=$(jq -r '.feedback.rating // "-"')
            local comment=$(jq -r '.feedback.comment // "-"')
            echo "| $task_name | $rating | $comment |" >> "$report_file"
        fi
    done
    
    log_info "✓ 周报告已生成：$report_file"
}

# 主程序
main() {
    local action="${1:-help}"
    
    case "$action" in
        "request")
            # 发送反馈请求
            local task_id="$2"
            local task_name="$3"
            local completion_time="$4"
            local duration="$5"
            local achievements="$6"
            
            if [ -z "$task_id" ] || [ -z "$task_name" ]; then
                echo "用法：$0 request <task_id> <task_name> <completion_time> <duration> <achievements>"
                exit 1
            fi
            
            send_feedback_request "$task_id" "$task_name" "$completion_time" "$duration" "$achievements"
            ;;
        
        "record")
            # 记录用户反馈
            local task_id="$2"
            local rating="$3"
            local comment="$4"
            
            if [ -z "$task_id" ] || [ -z "$rating" ]; then
                echo "用法：$0 record <task_id> <rating> [comment]"
                exit 1
            fi
            
            record_feedback "$task_id" "$rating" "$comment"
            ;;
        
        "report")
            # 生成周报告
            local week="$2"
            local year="$3"
            
            generate_weekly_report "$week" "$year"
            ;;
        
        "config")
            # 显示配置
            read_config | jq .
            ;;
        
        "unsubscribe")
            # 退订
            local config=$(read_config)
            echo "$config" | jq '.unsubscribe = true' > "$CONFIG_FILE"
            log_info "✓ 已退订反馈请求"
            ;;
        
        *)
            echo "用户反馈收集器"
            echo ""
            echo "用法:"
            echo "  $0 request <task_id> <task_name> <completion_time> <duration> <achievements>"
            echo "  $0 record <task_id> <rating> [comment]"
            echo "  $0 report <week> [year]"
            echo "  $0 config"
            echo "  $0 unsubscribe"
            ;;
    esac
}

main "$@"
