#!/bin/bash
# LangBot 快速安装脚本
# 用途：一键安装 LangBot (ChatGPT-On-CS)

set -e

INSTALL_DIR="/opt/langbot"
LOGFILE="/var/log/langbot-install.log"

echo "========================================"
echo "🤖 LangBot 快速安装"
echo "========================================"
echo ""

# 1. 检查系统要求
echo "1️⃣  检查系统要求..."
echo "   Python: $(python3 --version 2>&1)"
echo "   Git: $(git --version 2>&1)"
echo ""

# 2. 安装 uv (Python 包管理器)
echo "2️⃣  安装 uv..."
if ! command -v uv &> /dev/null; then
    curl -LsSf https://astral.sh/uv/install.sh | sh
    echo "   ✅ uv 安装完成"
else
    echo "   ✅ uv 已安装"
fi
echo ""

# 3. 创建安装目录
echo "3️⃣  创建安装目录..."
mkdir -p "$INSTALL_DIR"
echo "   ✅ 目录创建完成：$INSTALL_DIR"
echo ""

# 4. 下载 LangBot
echo "4️⃣  下载 LangBot..."
cd "$INSTALL_DIR"
if [ ! -d "LangBot" ]; then
    git clone https://github.com/langbot-app/LangBot.git
    echo "   ✅ LangBot 下载完成"
else
    echo "   ✅ LangBot 已存在"
fi
echo ""

# 5. 创建 systemd 服务
echo "5️⃣  创建 systemd 服务..."
cat > /etc/systemd/system/langbot.service << 'EOF'
[Unit]
Description=LangBot AI Chatbot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/langbot/LangBot
ExecStart=/root/.local/bin/uvx langbot
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
echo "   ✅ systemd 服务创建完成"
echo ""

# 6. 启动服务
echo "6️⃣  启动 LangBot 服务..."
systemctl enable langbot
systemctl start langbot

sleep 5

if systemctl is-active --quiet langbot; then
    echo "   ✅ LangBot 服务已启动"
else
    echo "   ⚠️  LangBot 服务启动失败，请检查日志"
    journalctl -u langbot -n 20
fi
echo ""

# 7. 显示访问信息
echo "========================================"
echo "✅ LangBot 安装完成"
echo "========================================"
echo ""
echo "📋 访问信息:"
echo "   Web 管理面板：http://localhost:5300"
echo "   API 地址：http://localhost:5300/api"
echo ""
echo "🔧 管理命令:"
echo "   启动：systemctl start langbot"
echo "   停止：systemctl stop langbot"
echo "   重启：systemctl restart langbot"
echo "   状态：systemctl status langbot"
echo "   日志：journalctl -u langbot -f"
echo ""
echo "📄 配置文件:"
echo "   位置：$INSTALL_DIR/LangBot/config"
echo "   文档：$INSTALL_DIR/LangBot/README.md"
echo ""
echo "🚀 下一步:"
echo "   1. 访问 Web 面板：http://localhost:5300"
echo "   2. 配置模型 API Key"
echo "   3. 配置飞书平台"
echo "   4. 测试对话功能"
echo ""
echo "========================================"
