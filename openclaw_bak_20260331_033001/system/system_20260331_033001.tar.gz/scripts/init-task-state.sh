#!/bin/bash
# 初始化任务状态文件
# 用法：./init-task-state.sh <TASK_ID> <TASK_NAME>

set -e

TASK_ID="${1:?用法：$0 <TASK_ID> <TASK_NAME>}"
TASK_NAME="${2:?用法：$0 <TASK_ID> <TASK_NAME>}"
STATE_DIR="/root/.openclaw/workspace/agents/master/memory/tasks"
STATE_FILE="$STATE_DIR/${TASK_ID}-state.json"
LOCK_FILE="/tmp/${TASK_ID}.lock"

# 创建目录
mkdir -p "$STATE_DIR"

# 创建状态文件
cat > "$STATE_FILE" << EOF
{
  "task_id": "$TASK_ID",
  "task_name": "$TASK_NAME",
  "status": "pending",
  "created_at": "$(date -Iseconds)",
  "updated_at": "$(date -Iseconds)",
  "current_milestone": null,
  "current_slice": null,
  "completed_slices": [],
  "failed_slices": [],
  "next_action": "等待确认前置条件",
  "blockers": [
    "需要真实日志样例（至少 3 个）",
    "需要 fieldiag.log 样本或特征",
    "需要故障分析 Agent 输入接口定义",
    "需要报告输出格式标准"
  ],
  "notes": [],
  "metrics": {
    "total_milestones": 5,
    "total_slices": 13,
    "estimated_hours": 67,
    "token_budget": 1000000,
    "token_used": 0
  }
}
EOF

# 创建锁文件
touch "$LOCK_FILE"

# 创建任务目录
mkdir -p "$STATE_DIR/${TASK_ID}/"

echo "✅ 任务状态文件已创建：$STATE_FILE"
echo "📂 任务目录：$STATE_DIR/${TASK_ID}/"
echo "🔒 锁文件：$LOCK_FILE"
echo ""
echo "下一步：确认前置条件后，更新状态为 'in_progress'"
