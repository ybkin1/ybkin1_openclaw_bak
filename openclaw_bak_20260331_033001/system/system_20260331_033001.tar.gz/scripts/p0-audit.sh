#!/bin/bash
#===============================================================================
# P0 代码审计脚本
# 功能：代码质量、测试覆盖率、需求对齐检查
#===============================================================================

set -e

echo "=========================================="
echo "   P0 代码审计"
echo "=========================================="
echo ""

# 1. 代码统计
echo "📊 1. 代码统计"
echo "----------------------------------------"
cd /root/.openclaw/workspace/agents/master

echo "源代码文件:"
find src -name "*.py" -type f | wc -l

echo "测试文件:"
find tests -name "*.py" -type f | grep test_ | wc -l

echo "代码行数:"
find src -name "*.py" -type f -exec cat {} \; | wc -l

echo "测试行数:"
find tests -name "*.py" -type f -exec cat {} \; | wc -l
echo ""

# 2. 运行测试覆盖率
echo "🧪 2. 测试覆盖率"
echo "----------------------------------------"
cd tests
python3 -m pytest --cov=../src --cov-report=term-missing -q 2>&1 | tail -30
cd ..
echo ""

# 3. 代码质量检查 (pylint)
echo "🔍 3. 代码质量检查"
echo "----------------------------------------"
if command -v pylint &> /dev/null; then
    pylint src/*.py --disable=all --enable=E,W 2>&1 | head -50
else
    echo "pylint 未安装，跳过"
fi
echo ""

# 4. 检查未覆盖的关键模块
echo "⚠️  4. 低覆盖率模块"
echo "----------------------------------------"
python3 -m pytest --cov=../src --cov-report=term-missing -q 2>&1 | grep -A1 "^[a-z]" | grep -B1 "MISSING" | head -20
echo ""

# 5. 需求文档检查
echo "📋 5. 需求对齐检查"
echo "----------------------------------------"
if [ -f "memory/tasks/FILE-AGENT-DEV-requirements.md" ]; then
    echo "✅ 需求文档存在"
    echo "需求文档大小: $(wc -l < memory/tasks/FILE-AGENT-DEV-requirements.md) 行"
else
    echo "❌ 需求文档缺失"
fi

if [ -f "memory/tasks/FILE-AGENT-DEV-p0-plan.md" ]; then
    echo "✅ P0 计划文档存在"
else
    echo "❌ P0 计划文档缺失"
fi
echo ""

# 6. 文档完整性
echo "📚 6. 文档完整性"
echo "----------------------------------------"
echo "文档文件:"
find docs -name "*.md" -type f 2>/dev/null || echo "docs 目录不存在"
echo ""

# 7. 潜在问题检查
echo "⚠️  7. 潜在问题检查"
echo "----------------------------------------"
echo "检查 TODO/FIXME:"
grep -r "TODO\|FIXME\|XXX\|HACK" src/ 2>/dev/null | head -10 || echo "无 TODO/FIXME"
echo ""

echo "检查硬编码路径:"
grep -r "/root/" src/ 2>/dev/null | head -10 || echo "无硬编码路径"
echo ""

echo "检查 print 语句:"
grep -r "^print(" src/ 2>/dev/null | head -10 || echo "无 print 语句"
echo ""

# 8. 导入检查
echo "📦 8. 导入依赖检查"
echo "----------------------------------------"
echo "外部依赖:"
grep -h "^import\|^from" src/*.py | sort | uniq | head -20
echo ""

echo "=========================================="
echo "   审计完成"
echo "=========================================="
