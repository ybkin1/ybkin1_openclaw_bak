#!/bin/bash

# filter-sensitive.sh - 安全过滤敏感信息
set -e

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/root/.openclaw/workspace/main/backups/filtered_$TIMESTAMP"

echo "🔍 开始敏感信息过滤..."
mkdir -p "$BACKUP_DIR"

# 复制所有文件，排除敏感目录和备份目录
rsync -av \
  --exclude='.git/' \
  --exclude='backups/' \
  --exclude='guardian-backups/' \
  --exclude='*.log' \
  --exclude='*.jsonl' \
  --exclude='memory/heartbeat-state.json' \
  --exclude='**/auth-profiles.json' \
  --exclude='**/credentials.json' \
  --exclude='**/*.key' \
  --exclude='**/*.pem' \
  --exclude='**/node_modules/' \
  --exclude='**/__pycache__/' \
  /root/.openclaw/workspace/main/ \
  "$BACKUP_DIR/"

# 过滤配置文件中的敏感信息
if [ -f "$BACKUP_DIR/openclaw.json" ]; then
  echo "🔐 过滤 openclaw.json 中的敏感信息..."
  # 创建安全版本
  cp "$BACKUP_DIR/openclaw.json" "$BACKUP_DIR/openclaw.filtered.json"
  # 过滤 API 密钥等敏感字段
  sed -i 's/"apiKey": "[^"]*"/"apiKey": "REDACTED"/g' "$BACKUP_DIR/openclaw.filtered.json"
  sed -i 's/"appSecret": "[^"]*"/"appSecret": "REDACTED"/g' "$BACKUP_DIR/openclaw.filtered.json"
  sed -i 's/"token": "[^"]*"/"token": "REDACTED"/g' "$BACKUP_DIR/openclaw.filtered.json"
fi

echo "✅ 敏感信息过滤完成！"
echo "📁 备份位置: $BACKUP_DIR"
echo "📄 安全配置: $BACKUP_DIR/openclaw.filtered.json"