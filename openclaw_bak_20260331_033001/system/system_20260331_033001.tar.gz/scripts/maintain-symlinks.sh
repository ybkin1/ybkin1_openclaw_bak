#!/bin/bash
set -euo pipefail

WORKSPACE="/root/.openclaw/workspace"
MASTER_DIR="$WORKSPACE/agents/master"

declare -A LINKS=(
    ["AGENTS.md"]="agents/master/AGENTS.md"
    ["HEARTBEAT.md"]="agents/master/HEARTBEAT.md"
    ["IDENTITY.md"]="agents/master/IDENTITY.md"
    ["SOUL.md"]="agents/master/SOUL.md"
    ["TOOLS.md"]="agents/master/TOOLS.md"
    ["USER.md"]="agents/master/USER.md"
    ["FILE_ORGANIZATION.md"]="agents/master/FILE_ORGANIZATION.md"
)

echo "=== 维护符号链接 ==="
cd "$WORKSPACE"

for link_name in "${!LINKS[@]}"; do
    target="${LINKS[$link_name]}"
    if [ -f "$target" ]; then
        case "$link_name" in
            AGENTS|HEARTBEAT|IDENTITY|SOUL|TOOLS|USER|FILE_ORGANIZATION)
                if [ -L "$link_name" ]; then
                    current=$(readlink "$link_name")
                    if [ "$current" != "$target" ]; then
                        rm -f "$link_name" && ln -s "$target" "$link_name"
                        echo "✓ 更新: $link_name → $target"
                    else
                        echo "✓ $link_name 已正确"
                    fi
                elif [ -f "$link_name" ]; then
                    mv "$link_name" "${link_name}.bak.$(date +%s)"
                    ln -s "$target" "$link_name"
                    echo "✓ 迁移: $link_name → $target"
                else
                    ln -s "$target" "$link_name"
                    echo "✓ 创建: $link_name → $target"
                fi
                ;;
        esac
    else
        echo "✗ 目标缺失: $target"
    fi
done

echo "=== 完成 ==="
