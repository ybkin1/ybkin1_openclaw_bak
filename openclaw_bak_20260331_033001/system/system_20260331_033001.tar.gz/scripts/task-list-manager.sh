#!/bin/bash
# Task List Manager for Comprehensive Task Tracking
# Implements detailed task breakdown, planning, and execution tracking

set -euo pipefail

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/master/tasks"
ACTIVE_DIR="$TASKS_DIR/active"
COMPLETED_DIR="$TASKS_DIR/completed"
ARCHIVED_DIR="$TASKS_DIR/archived"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/task-manager.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# Create task with detailed breakdown
create_detailed_task() {
    local user_id="$1"
    local task_title="$2"
    local task_description="$3"
    local estimated_duration="$4"  # in minutes
    
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local task_id="task_${timestamp}_${user_id}"
    local task_file="$ACTIVE_DIR/${task_id}.json"
    
    # Create detailed task structure
    cat > "$task_file" << EOF
{
  "task_id": "$task_id",
  "user_id": "$user_id",
  "title": "$task_title",
  "description": "$task_description",
  "estimated_duration_minutes": $estimated_duration,
  "created_at": "$(date -Iseconds)",
  "status": "planning",
  "steps": [],
  "completed_steps": [],
  "current_step": 0,
  "progress_percentage": 0,
  "last_updated": "$(date -Iseconds)",
  "completion_asked": false,
  "execution_log": []
}
EOF
    
    log "Created detailed task: $task_id for user $user_id"
    echo "$task_id"
}

# Add step to task
add_task_step() {
    local task_id="$1"
    local step_description="$2"
    local estimated_time="$3"  # in minutes
    
    local task_file="$ACTIVE_DIR/${task_id}.json"
    if [[ ! -f "$task_file" ]]; then
        log "Error: Task $task_id not found"
        return 1
    fi
    
    # Read current steps
    local current_steps=$(jq -r '.steps | length' "$task_file")
    local new_step_index=$((current_steps + 1))
    
    # Add new step
    jq --arg desc "$step_description" \
       --argjson time "$estimated_time" \
       --argjson idx "$new_step_index" \
       '.steps += [{"step_number": $idx, "description": $desc, "estimated_time_minutes": $time, "status": "pending", "completed_at": null}]' \
       "$task_file" > "${task_file}.tmp" && mv "${task_file}.tmp" "$task_file"
    
    log "Added step $new_step_index to task $task_id: $step_description"
}

# Update task progress
update_task_progress() {
    local task_id="$1"
    local step_number="$2"
    local status="$3"  # completed, in_progress, failed
    
    local task_file="$ACTIVE_DIR/${task_id}.json"
    if [[ ! -f "$task_file" ]]; then
        log "Error: Task $task_id not found"
        return 1
    fi
    
    # Update step status
    jq --argjson step_num "$step_number" \
       --arg status "$status" \
       --arg completed_at "$(date -Iseconds)" \
       '(.steps[] | select(.step_number == $step_num)) |= 
         if $status == "completed" then 
           . + {"status": $status, "completed_at": $completed_at}
         else 
           . + {"status": $status}
         end' \
       "$task_file" > "${task_file}.tmp" && mv "${task_file}.tmp" "$task_file"
    
    # Calculate progress
    local total_steps=$(jq -r '.steps | length' "$task_file")
    local completed_steps=$(jq -r '[.steps[] | select(.status == "completed")] | length' "$task_file")
    local progress_pct=$((completed_steps * 100 / total_steps))
    
    # Update overall progress
    jq --argjson progress "$progress_pct" \
       --arg updated "$(date -Iseconds)" \
       '.progress_percentage = $progress | .last_updated = $updated' \
       "$task_file" > "${task_file}.tmp" && mv "${task_file}.tmp" "$task_file"
    
    log "Updated task $task_id step $step_number to $status, progress: ${progress_pct}%"
}

# Complete task
complete_task() {
    local task_id="$1"
    
    local task_file="$ACTIVE_DIR/${task_id}.json"
    if [[ ! -f "$task_file" ]]; then
        log "Error: Task $task_id not found"
        return 1
    fi
    
    # Move to completed
    mv "$task_file" "$COMPLETED_DIR/"
    log "Completed task $task_id and moved to completed directory"
}

# List all active tasks
list_active_tasks() {
    find "$ACTIVE_DIR" -name "*.json" -exec basename {} \; | sed 's/\.json$//'
}

# Main command handler
case "${1:-help}" in
    create)
        create_detailed_task "$2" "$3" "$4" "$5"
        ;;
    add-step)
        add_task_step "$2" "$3" "$4"
        ;;
    update-progress)
        update_task_progress "$2" "$3" "$4"
        ;;
    complete)
        complete_task "$2"
        ;;
    list)
        list_active_tasks
        ;;
    *)
        echo "Usage: $0 {create|add-step|update-progress|complete|list}"
        echo ""
        echo "Commands:"
        echo "  create <user_id> <title> <description> <duration_min>  - Create detailed task"
        echo "  add-step <task_id> <description> <time_min>          - Add step to task"
        echo "  update-progress <task_id> <step_num> <status>        - Update step progress"
        echo "  complete <task_id>                                   - Complete task"
        echo "  list                                                 - List active tasks"
        exit 1
        ;;
esac