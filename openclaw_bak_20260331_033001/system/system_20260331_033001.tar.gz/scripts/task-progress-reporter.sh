#!/bin/bash
# 任务进度汇报脚本
# 每 10 分钟检查一次活跃任务，触发 1/3 进度汇报
# 修复：增加主动汇报机制

set -euo pipefail

TASKS_DIR="/root/.openclaw/workspace/agents/master/memory/tasks/active"
REPORTS_DIR="/root/.openclaw/workspace/agents/master/reports/progress"
LOG_FILE="/root/.openclaw/workspace/agents/master/logs/progress-reporter.log"

mkdir -p "$REPORTS_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

check_task_progress() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    
    # 读取任务信息
    local started_at=$(jq -r '.started_at // empty' "$task_file")
    local estimated_duration=$(jq -r '.estimated_duration_minutes // 30' "$task_file")
    local status=$(jq -r '.status // "unknown"' "$task_file")
    local title=$(jq -r '.title // "Unknown Task"' "$task_file")
    local last_report=$(jq -r '.last_report_at // "1970-01-01"' "$task_file")
    
    # 跳过未开始的任务
    if [ -z "$started_at" ] || [ "$status" != "in_progress" ]; then
        return 0
    fi
    
    # 计算已用时间 (分钟)
    local started_ts=$(date -d "$started_at" +%s 2>/dev/null || echo 0)
    local now_ts=$(date +%s)
    local elapsed_minutes=$(( (now_ts - started_ts) / 60 ))
    
    # 计算汇报阈值
    local report_1_3=$((estimated_duration / 3))
    local report_2_3=$((estimated_duration * 2 / 3))
    
    # 检查是否需要汇报
    local need_report=false
    local report_type=""
    
    # 1/3 进度汇报
    if [ $elapsed_minutes -ge $report_1_3 ] && [ "$last_report" = "1970-01-01" ]; then
        need_report=true
        report_type="1/3_progress"
    fi
    
    # 2/3 进度汇报
    if [ $elapsed_minutes -ge $report_2_3 ] && [ "$last_report" != "1/3_progress" ]; then
        need_report=true
        report_type="2/3_progress"
    fi
    
    # 超时告警
    if [ $elapsed_minutes -ge $estimated_duration ] && [ "$status" = "in_progress" ]; then
        need_report=true
        report_type="timeout_alert"
    fi
    
    # 生成汇报
    if [ "$need_report" = true ]; then
        generate_report "$task_file" "$report_type" "$elapsed_minutes"
        
        # 更新最后汇报时间
        local temp_file=$(mktemp)
        jq --arg report "$report_type" --arg time "$(date -Iseconds)" \
           '.last_report_at = $time | .last_report_type = $report' \
           "$task_file" > "$temp_file" && mv "$temp_file" "$task_file"
    fi
}

generate_report() {
    local task_file="$1"
    local report_type="$2"
    local elapsed_minutes="$3"
    
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title' "$task_file")
    local subagent=$(jq -r '.subagent // "unknown"' "$task_file")
    local estimated=$(jq -r '.estimated_duration_minutes' "$task_file")
    
    local report_file="$REPORTS_DIR/${task_id}_${report_type}_$(date +%H%M).md"
    
    cat > "$report_file" << EOF
# 任务进度汇报

**任务 ID**: $task_id  
**任务标题**: $title  
**汇报类型**: $report_type  
**汇报时间**: $(date '+%Y-%m-%d %H:%M:%S')

---

## 进度信息

| 指标 | 值 |
|------|-----|
| 已用时间 | $elapsed_minutes 分钟 |
| 预计总时间 | $estimated 分钟 |
| 进度百分比 | $((elapsed_minutes * 100 / estimated))% |
| 执行 Agent | $subagent |

---

## 当前状态

**状态**: 执行中

**已完成**:
- [待 Subagent 更新]

**进行中**:
- [待 Subagent 更新]

**阻塞项**:
- [无/待更新]

---

## 下一步

[待 Subagent 更新]

---

**自动生成**: task-progress-reporter.sh
EOF

    log "📊 生成进度汇报：$report_file"
    
    # 如果超时，发送告警
    if [ "$report_type" = "timeout_alert" ]; then
        log "⚠️ 任务超时告警：$task_id (已用${elapsed_minutes}分钟，预计${estimated}分钟)"
    fi
}

# 新增：主动生成进度汇报
generate_progress_report() {
    local task_file="$1"
    local task_id=$(basename "$task_file" .json)
    local title=$(jq -r '.title' "$task_file")
    local status=$(jq -r '.status' "$task_file")
    local started_at=$(jq -r '.started_at // "unknown"' "$task_file")
    local estimated=$(jq -r '.estimated_duration_minutes // 30' "$task_file")
    
    # 计算已用时间
    local started_ts=$(date -d "$started_at" +%s 2>/dev/null || echo 0)
    local now_ts=$(date +%s)
    local elapsed_minutes=$(( (now_ts - started_ts) / 60 ))
    local progress=$((elapsed_minutes * 100 / estimated))
    
    local report_file="$REPORTS_DIR/${task_id}_progress_$(date +%H%M).md"
    
    cat > "$report_file" << EOF
# 任务进度主动汇报

**任务 ID**: $task_id  
**任务标题**: $title  
**汇报时间**: $(date '+%Y-%m-%d %H:%M:%S')

---

## 进度信息

| 指标 | 值 |
|------|-----|
| 已用时间 | $elapsed_minutes 分钟 |
| 预计总时间 | $estimated 分钟 |
| 进度百分比 | $progress% |
| 状态 | $status |

---

## 当前状态

任务正在执行中，详情查看任务文件。

---

**自动生成**: task-progress-reporter.sh (主动汇报)
EOF

    log "📊 主动生成进度汇报：$report_file"
}

# 主循环
log "🔍 开始检查任务进度..."

report_generated=false

for task_file in "$TASKS_DIR"/*.json; do
    if [ -f "$task_file" ]; then
        check_task_progress "$task_file"
        
        # 如果有任务在执行中，生成进度汇报
        status=$(jq -r '.status // "unknown"' "$task_file")
        if [ "$status" = "in_progress" ]; then
            generate_progress_report "$task_file"
            report_generated=true
        fi
    fi
done

if [ "$report_generated" = false ]; then
    log "📊 无活跃任务，无需汇报"
fi

log "✅ 进度检查完成"
