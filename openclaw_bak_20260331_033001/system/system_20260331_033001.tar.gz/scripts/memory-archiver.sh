#!/bin/bash
# memory-archiver.sh - 记忆归档脚本
# 将待清理的记忆归档到 GitHub 仓库

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="/root/.openclaw/workspace/agents/master"
MEMORY_DIR="$BASE_DIR/memory"
ARCHIVE_DIR="$BASE_DIR/memory/archive"
ARCHIVE_INDEX="$ARCHIVE_DIR/archive-index.md"
GITHUB_REPO="ybkin1/ybkin1_openclaw_bak"  # 使用现有备份仓库
LOG_FILE="$BASE_DIR/logs/memory-archive.log"

# 日志函数
log_info() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [INFO] $1" | tee -a "$LOG_FILE"
}

log_warn() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [WARN] $1" | tee -a "$LOG_FILE"
}

log_error() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [ERROR] $1" | tee -a "$LOG_FILE"
}

# 确保目录存在
mkdir -p "$ARCHIVE_DIR"
mkdir -p "$BASE_DIR/logs"

# 记忆分类配置
declare -A MEMORY_CATEGORIES=(
    ["daily"]="short-term"
    ["knowledge"]="long-term"
    ["decisions"]="long-term"
    ["projects"]="ongoing"
    ["config"]="permanent"
)

# 永久记忆模式（不归档不删除）
PERMANENT_PATTERNS=(
    "MEMORY.md"
    "ARCHITECTURE.md"
    "INDEX.md"
    "README.md"
    "config/"
)

# 检查是否为永久记忆
is_permanent() {
    local file="$1"
    local rel_path="${file#$MEMORY_DIR/}"
    
    for pattern in "${PERMANENT_PATTERNS[@]}"; do
        if [[ "$rel_path" == *"$pattern"* ]]; then
            return 0
        fi
    done
    
    # 检查文件内是否有 permanent: true 标记
    if grep -q "permanent: true" "$file" 2>/dev/null; then
        return 0
    fi
    
    return 1
}

# 检查记忆是否超过 3 个月未访问
is_old_enough() {
    local file="$1"
    local months="${2:-3}"
    
    # 获取文件最后修改时间
    local file_mtime=$(stat -c %Y "$file" 2>/dev/null || echo "0")
    local current_time=$(date +%s)
    local age_days=$(( (current_time - file_mtime) / 86400 ))
    local threshold_days=$((months * 30))
    
    if [ $age_days -gt $threshold_days ]; then
        return 0
    fi
    
    return 1
}

# 扫描待归档记忆
scan_memories() {
    log_info "开始扫描记忆文件..."
    
    local archive_list="$ARCHIVE_DIR/to-archive.list"
    > "$archive_list"
    
    local total=0
    local permanent=0
    local recent=0
    local to_archive=0
    
    # 扫描 memory 目录
    while IFS= read -r -d '' file; do
        total=$((total + 1))
        
        # 跳过永久记忆
        if is_permanent "$file"; then
            log_info "跳过永久记忆：$file"
            permanent=$((permanent + 1))
            continue
        fi
        
        # 检查时间
        if ! is_old_enough "$file" 3; then
            recent=$((recent + 1))
            continue
        fi
        
        # 添加到归档列表
        echo "$file" >> "$archive_list"
        to_archive=$((to_archive + 1))
        
    done < <(find "$MEMORY_DIR" -type f -name "*.md" -print0 2>/dev/null)
    
    log_info "扫描完成："
    log_info "  总文件数：$total"
    log_info "  永久记忆：$permanent"
    log_info "  近期文件：$recent"
    log_info "  待归档：$to_archive"
    
    echo "$to_archive"
}

# 生成归档索引
generate_index() {
    local archive_date="$1"
    local archive_file="$2"
    
    log_info "生成归档索引..."
    
    cat > "$ARCHIVE_INDEX" << EOF
# 记忆归档索引

**归档日期**: $archive_date
**归档文件**: $(basename "$archive_file")
**归档位置**: $GITHUB_REPO

## 归档文件清单

| 文件路径 | 分类 | 最后修改 | 原因 |
|----------|------|----------|------|
EOF
    
    while IFS= read -r file; do
        if [ -f "$file" ]; then
            local rel_path="${file#$BASE_DIR/}"
            local mtime=$(stat -c %y "$file" 2>/dev/null | cut -d' ' -f1)
            local category="${MEMORY_CATEGORIES[$(basename $(dirname "$file"))]:-unknown}"
            
            echo "| $rel_path | $category | $mtime | 3 个月未访问 |" >> "$ARCHIVE_INDEX"
        fi
    done < "$ARCHIVE_DIR/to-archive.list"
    
    cat >> "$ARCHIVE_INDEX" << EOF

## 恢复流程

1. 从 GitHub 下载归档文件
2. 解压到临时目录
3. 恢复到原位置
4. 验证完整性

## 联系方式

如有问题，请联系：ybkin1@github.com
EOF
    
    log_info "✓ 索引已生成：$ARCHIVE_INDEX"
}

# 执行归档
create_archive() {
    local archive_date=$(date +%Y%m%d)
    local archive_name="memory-archive-$archive_date.tar.gz"
    local archive_path="$ARCHIVE_DIR/$archive_name"
    
    log_info "创建归档文件：$archive_name"
    
    # 创建归档
    tar -czf "$archive_path" \
        -C "$BASE_DIR" \
        $(cat "$ARCHIVE_DIR/to-archive.list" | sed "s|$BASE_DIR/||g") \
        2>/dev/null || {
        log_error "归档创建失败"
        return 1
    }
    
    # 生成索引
    generate_index "$archive_date" "$archive_path"
    
    # 统计
    local archive_size=$(du -h "$archive_path" | cut -f1)
    local file_count=$(wc -l < "$ARCHIVE_DIR/to-archive.list")
    
    log_info "✓ 归档创建完成："
    log_info "  文件数：$file_count"
    log_info "  大小：$archive_size"
    log_info "  路径：$archive_path"
    
    echo "$archive_path"
}

# 推送到 GitHub（可选）
push_to_github() {
    local archive_path="$1"
    
    log_info "推送到 GitHub: $GITHUB_REPO"
    
    # TODO: 实现 GitHub 推送
    # 目前仅本地归档
    
    log_warn "GitHub 推送功能待实现，当前仅本地归档"
}

# 清理已归档文件
cleanup_archived() {
    log_info "清理已归档文件..."
    
    local count=0
    
    while IFS= read -r file; do
        if [ -f "$file" ]; then
            # 备份到 archive 目录
            local rel_path="${file#$MEMORY_DIR/}"
            local backup_path="$ARCHIVE_DIR/backup/$rel_path"
            mkdir -p "$(dirname "$backup_path")"
            cp "$file" "$backup_path"
            
            # 删除原文件
            rm "$file"
            count=$((count + 1))
        fi
    done < "$ARCHIVE_DIR/to-archive.list"
    
    log_info "✓ 清理完成：$count 个文件"
}

# 主程序
main() {
    local action="${1:-scan}"
    
    case "$action" in
        "scan")
            # 扫描待归档记忆
            scan_memories
            ;;
        
        "archive")
            # 执行归档
            local count=$(scan_memories)
            
            if [ "$count" -eq 0 ]; then
                log_info "无待归档文件"
                exit 0
            fi
            
            # 用户确认
            log_warn "发现 $count 个待归档文件，清单："
            cat "$ARCHIVE_DIR/to-archive.list"
            log_warn ""
            log_warn "将在 10 秒后开始归档，按 Ctrl+C 取消..."
            sleep 10 || true
            
            # 创建归档
            create_archive
            
            # 清理
            cleanup_archived
            
            # 推送 GitHub
            # push_to_github "$archive_path"
            ;;
        
        "restore")
            # 恢复归档
            local archive_name="$2"
            
            if [ -z "$archive_name" ]; then
                echo "用法：$0 restore <archive_name>"
                exit 1
            fi
            
            log_info "恢复归档：$archive_name"
            # TODO: 实现恢复功能
            ;;
        
        *)
            echo "记忆归档工具"
            echo ""
            echo "用法:"
            echo "  $0 scan    # 扫描待归档记忆"
            echo "  $0 archive # 执行归档"
            echo "  $0 restore <archive_name> # 恢复归档"
            ;;
    esac
}

main "$@"
