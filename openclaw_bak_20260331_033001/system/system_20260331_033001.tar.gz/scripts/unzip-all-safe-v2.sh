#!/bin/bash
#===============================================================================
# 文件管理 Agent - 递归解压脚本 v2.0
# 功能：递归解压嵌套压缩包，支持 ZIP/7Z/RAR/TAR.GZ/TAR.BZ2
# 作者：文件管理 Agent
# 创建：2026-03-28
#===============================================================================

set -e

# 配置
MAX_DEPTH=10                    # 最大递归深度
LOG_FILE="/tmp/unzip-all-safe.log"
TEMP_BASE="/root/.openclaw/workspace/logs/samples/incoming/temp"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log() {
    local level="$1"
    local message="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
    
    case "$level" in
        INFO)  echo -e "${BLUE}ℹ️  $message${NC}" ;;
        SUCCESS) echo -e "${GREEN}✅  $message${NC}" ;;
        WARNING) echo -e "${YELLOW}⚠️  $message${NC}" ;;
        ERROR) echo -e "${RED}❌  $message${NC}" ;;
    esac
}

# 检测文件类型
detect_file_type() {
    local filepath="$1"
    file -b "$filepath" 2>/dev/null
}

# 获取文件扩展名
get_extension() {
    local filepath="$1"
    local filename=$(basename "$filepath")
    local ext="${filename##*.}"
    echo "$ext" | tr '[:upper:]' '[:lower:]'
}

# 解压单个文件
extract_file() {
    local input_file="$1"
    local output_dir="$2"
    local depth="$3"
    
    if [ ! -f "$input_file" ]; then
        log ERROR "文件不存在：$input_file"
        return 1
    fi
    
    if [ "$depth" -gt "$MAX_DEPTH" ]; then
        log WARNING "达到最大递归深度 ($MAX_DEPTH)，停止解压：$input_file"
        return 1
    fi
    
    local file_type=$(detect_file_type "$input_file")
    local ext=$(get_extension "$input_file")
    
    log INFO "检测文件类型：$file_type (扩展名：$ext)"
    
    local temp_output="$output_dir/level$depth"
    mkdir -p "$temp_output"
    
    # 按优先级检测并解压
    if echo "$file_type" | grep -qiE "gzip|gz"; then
        if echo "$file_type" | grep -qi "tar" || echo "$ext" | grep -qi "tar"; then
            log INFO "📦 解压 TAR.GZ 文件"
            tar -xzf "$input_file" -C "$temp_output" 2>&1 | head -20
        else
            local base_name=$(basename "$input_file" .gz)
            log INFO "📦 解压 GZ 文件 → $base_name"
            gunzip -c "$input_file" > "$temp_output/$base_name" 2>&1
        fi
    elif echo "$file_type" | grep -qiE "bzip2|bz2"; then
        if echo "$file_type" | grep -qi "tar"; then
            log INFO "📦 解压 TAR.BZ2 文件"
            tar -xjf "$input_file" -C "$temp_output" 2>&1 | head -20
        else
            local base_name=$(basename "$input_file" .bz2)
            gunzip -c "$input_file" > "$temp_output/$base_name" 2>&1
        fi
    elif echo "$file_type" | grep -qi "tar"; then
        log INFO "📦 解压 TAR 文件"
        tar -xf "$input_file" -C "$temp_output" 2>&1 | head -20
    elif echo "$file_type" | grep -qiE "ZIP|zip"; then
        log INFO "📦 解压 ZIP 文件"
        unzip -o -q "$input_file" -d "$temp_output" 2>&1 | head -20
    elif echo "$file_type" | grep -qiE "7-zip|7z"; then
        log INFO "📦 解压 7Z 文件"
        7z x "$input_file" -o"$temp_output" -y -q 2>&1 | head -20
    elif echo "$file_type" | grep -qiE "RAR|rar"; then
        log INFO "📦 解压 RAR 文件"
        unrar x "$input_file" "$temp_output/" -y -q 2>&1 | head -20 || true
    else
        # 按扩展名回退处理
        case "$ext" in
            zip) unzip -o -q "$input_file" -d "$temp_output" 2>&1 | head -20 ;;
            7z) 7z x "$input_file" -o"$temp_output" -y -q 2>&1 | head -20 ;;
            rar) unrar x "$input_file" "$temp_output/" -y -q 2>&1 | head -20 || true ;;
            gz) gunzip -c "$input_file" > "$temp_output/$(basename "$input_file" .gz)" 2>&1 ;;
            bz2) bunzip2 -c "$input_file" > "$temp_output/$(basename "$input_file" .bz2)" 2>&1 ;;
            tar) tar -xf "$input_file" -C "$temp_output" 2>&1 | head -20 ;;
            tgz) tar -xzf "$input_file" -C "$temp_output" 2>&1 | head -20 ;;
            *) log WARNING "未知格式，跳过：$file_type"; return 0 ;;
        esac
    fi
    
    local extracted_count=$(find "$temp_output" -type f | wc -l)
    log SUCCESS "解压完成：$extracted_count 个文件"
    
    recursive_extract "$temp_output" "$depth"
    return 0
}

# 递归解压
recursive_extract() {
    local base_dir="$1"
    local depth="$2"
    local new_depth=$((depth + 1))
    
    if [ "$new_depth" -gt "$MAX_DEPTH" ]; then
        return 0
    fi
    
    local archives=()
    
    while IFS= read -r -d '' file; do
        local file_type=$(file -b "$file" 2>/dev/null)
        if echo "$file_type" | grep -qiE "zip|7-zip|rar|gzip|bzip2|tar"; then
            archives+=("$file")
        fi
    done < <(find "$base_dir" -type f -print0 2>/dev/null)
    
    if [ ${#archives[@]} -eq 0 ]; then
        log INFO "✅ 未发现更多压缩包"
        return 0
    fi
    
    log INFO "🔍 发现 ${#archives[@]} 个压缩包"
    
    for archive in "${archives[@]}"; do
        extract_file "$archive" "$base_dir" "$new_depth"
    done
    
    return 0
}

# 生成报告
generate_report() {
    local base_dir="$1"
    local report_file="$base_dir/extraction_report.json"
    
    local total_files=$(find "$base_dir" -type f | wc -l)
    local total_dirs=$(find "$base_dir" -type d | wc -l)
    local total_size=$(du -sh "$base_dir" 2>/dev/null | cut -f1)
    
    cat > "$report_file" << EOF
{
  "extraction_report": {
    "timestamp": "$(date -Iseconds)",
    "base_directory": "$base_dir",
    "statistics": {
      "total_files": $total_files,
      "total_directories": $total_dirs,
      "total_size": "$total_size"
    }
  }
}
EOF
    
    log SUCCESS "报告已生成：$report_file"
}

# 主函数
main() {
    local input_file="${1:?用法：$0 <压缩文件> [输出目录]}"
    local output_dir="${2:-$TEMP_BASE/$(basename "$input_file" | sed 's/\.[^.]*$//')}"
    
    mkdir -p "$(dirname "$LOG_FILE")"
    mkdir -p "$TEMP_BASE"
    echo "" > "$LOG_FILE"
    
    log INFO "=========================================="
    log INFO "文件管理 Agent - 递归解压脚本 v2.0"
    log INFO "输入：$input_file"
    log INFO "输出：$output_dir"
    log INFO "最大深度：$MAX_DEPTH"
    log INFO "=========================================="
    
    if [ ! -f "$input_file" ]; then
        log ERROR "文件不存在：$input_file"
        exit 1
    fi
    
    mkdir -p "$output_dir"
    extract_file "$input_file" "$output_dir" 1
    generate_report "$output_dir"
    
    log INFO "=========================================="
    log SUCCESS "解压完成！"
    log INFO "文件总数：$(find "$output_dir" -type f | wc -l)"
    log INFO "总大小：$(du -sh "$output_dir" 2>/dev/null | cut -f1)"
    log INFO "日志：$LOG_FILE"
    log INFO "=========================================="
}

main "$@"
