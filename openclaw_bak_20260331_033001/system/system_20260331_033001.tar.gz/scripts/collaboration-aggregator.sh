#!/bin/bash
# 协作任务结果聚合器
# 监控 Master 任务完成，自动触发协作结果聚合

WORKSPACE="/root/.openclaw/workspace"
MASTER_MEMORY="$WORKSPACE/agents/master/memory/master"
COMPLETED_TASKS="$MASTER_MEMORY/tasks/completed"
COLLABORATIVE_DIR="$MASTER_MEMORY/tasks/collaborative"
ASSISTANT_COMPLETED="$WORKSPACE/agents/assistant/memory/assistant/tasks/completed"
RESULTS_QUEUE="/tmp/agent_results.json"
AGGREGATE_SCRIPT="$WORKSPACE/agents/master/scripts/aggregate-results.sh"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }

# 查找刚完成的 Master 子任务
find_recent_master_subtasks() {
    find "$COMPLETED_TASKS" -name "*_M_result.md" -mmin -5 2>/dev/null
}

# 提取父任务ID（从结果文件名）
extract_parent_id() {
    local result_file="$1"
    local filename=$(basename "$result_file")
    # 格式: task_YYYYMMDD_HHMMSS_..._M_result.md
    # 提取去掉 _M_result.md 的部分
    echo "$filename" | sed 's/_M_result\.md$//' | sed 's/^task_//'
}

# 检查 Assistant 子任务是否完成
check_assistant_done() {
    local parent_id="$1"
    local assistant_pattern="${ASSISTANT_COMPLETED}/${parent_id}_A*_result.md"
    if ls $assistant_pattern 2>/dev/null | grep -q .; then
        return 0
    else
        return 1
    fi
}

# 更新协作跟踪文件
update_collaborative_tracking() {
    local parent_id="$1"
    local master_result="$2"
    local assistant_result="$3"
    local tracking_file="${COLLABORATIVE_DIR}/task_${parent_id}.md"

    if [ ! -f "$tracking_file" ]; then
        log "⚠️ 未找到协作跟踪文件: $tracking_file"
        return 1
    fi

    # 获取完成时间
    local master_time=$(stat -c %y "$master_result" 2>/dev/null | cut -d' ' -f1,2 | sed 's/\.[0-9]*//')
    local assistant_time=$(stat -c %y "$assistant_result" 2>/dev/null | cut -d' ' -f1,2 | sed 's/\.[0-9]*//')
    [ -z "$master_time" ] && master_time="$(date '+%Y-%m-%d %H:%M:%S')"
    [ -z "$assistant_time" ] && assistant_time="$(date '+%Y-%m-%d %H:%M:%S')"

    # 更新状态表
    # 先备份
    cp "$tracking_file" "${tracking_file}.bak"

    # 更新 Master 行
    sed -i "/^| Master |/c\| Master | ✅ 已完成 | $master_time | result_file |" "$tracking_file"

    # 更新 Assistant 行
    sed -i "/^| Assistant |/c\| Assistant | ✅ 已完成 | $assistant_time | result_file |" "$tracking_file"

    # 如果没有最终汇总部分，添加
    if ! grep -q "## ✅ 协作完成 - 最终汇总" "$tracking_file"; then
        cat >> "$tracking_file" <<EOF

---

## ✅ 协作完成 - 最终汇总

**完成时间**: $(date '+%Y-%m-%d %H:%M:%S')

### 自动聚合完成
- Master 子任务: $master_result
- Assistant 子任务: $assistant_result

---
*由协作聚合器自动生成*
EOF
    fi

    log "✅ 协作跟踪文件已更新: $tracking_file"
}

# 主监控循环
main() {
    log "协作聚合器启动，监控目录: $COMPLETED_TASKS"

    while true; do
        # 查找最近 5 分钟内完成的 Master 子任务
        local recent_subtasks=$(find_recent_master_subtasks)

        if [ -z "$recent_subtasks" ]; then
            sleep 10
            continue
        fi

        for master_result in $recent_subtasks; do
            local parent_id=$(extract_parent_id "$master_result")
            log "检测到 Master 子任务完成: $(basename "$master_result") -> parent: $parent_id"

            # 检查对应的协作跟踪文件
            local tracking_file="${COLLABORATIVE_DIR}/task_${parent_id}.md"
            if [ ! -f "$tracking_file" ]; then
                log "⚠️ 无协作跟踪文件，跳过聚合: $parent_id"
                continue
            fi

            # 检查 Assistant 是否完成
            if check_assistant_done "$parent_id"; then
                log "Assistant 子任务已完成，开始聚合: $parent_id"

                # 查找 Assistant 结果文件
                local assistant_result=$(ls ${ASSISTANT_COMPLETED}/${parent_id}_A*_result.md 2>/dev/null | head -1)

                if [ -z "$assistant_result" ]; then
                    log "⚠️ 未找到 Assistant 结果文件"
                    continue
                fi

                # 调用聚合脚本
                if [ -x "$AGGREGATE_SCRIPT" ]; then
                    log "执行聚合脚本: $AGGREGATE_SCRIPT $parent_id"
                    PARENT_TASK_ID="$parent_id" \
                        MASTER_RESULT_FILE="$master_result" \
                        ASSISTANT_RESULT_FILE="$assistant_result" \
                        "$AGGREGATE_SCRIPT" "$parent_id" "$master_result" "$assistant_result"

                    # 更新协作跟踪文件
                    update_collaborative_tracking "$parent_id" "$master_result" "$assistant_result"

                    log "✅ 协作任务聚合完成: $parent_id"
                else
                    log "❌ 聚合脚本不可执行: $AGGREGATE_SCRIPT"
                fi
            else
                log "⏳ Assistant 子任务尚未完成，等待中: $parent_id"
            fi
        done

        sleep 10
    done
}

main "$@"
