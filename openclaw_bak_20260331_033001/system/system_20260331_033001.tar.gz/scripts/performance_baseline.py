#!/usr/bin/env python3
"""
性能基线测试

测试系统性能，建立基线数据
"""

import sys
import os
import time
import statistics
from datetime import datetime

# 添加项目路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from src.security.encryption import EncryptionService
from src.agents.master_sla import MasterAgent
from src.agents.file_processor_agent import FileProcessorAgent


def test_encryption_performance(iterations: int = 100) -> dict:
    """测试加密性能"""
    print(f"\n🔐 加密性能测试 ({iterations} 次迭代)...")
    
    enc = EncryptionService()
    test_data = {'sn': 'SN12345678', 'config': 'GPU: A100 x 8'}
    
    encrypt_times = []
    decrypt_times = []
    
    for _ in range(iterations):
        # 加密测试
        start = time.perf_counter()
        encrypted = enc.encrypt_sensitive_data(test_data)
        encrypt_times.append((time.perf_counter() - start) * 1000)  # ms
        
        # 解密测试
        start = time.perf_counter()
        decrypted = enc.decrypt_sensitive_data(encrypted)
        decrypt_times.append((time.perf_counter() - start) * 1000)  # ms
    
    return {
        '加密平均': f"{statistics.mean(encrypt_times):.2f}ms",
        '加密 P95': f"{statistics.quantiles(encrypt_times, n=20)[-1]:.2f}ms",
        '解密平均': f"{statistics.mean(decrypt_times):.2f}ms",
        '解密 P95': f"{statistics.quantiles(decrypt_times, n=20)[-1]:.2f}ms",
        '吞吐量': f"{iterations / (sum(encrypt_times) / 1000):.0f} ops/s",
    }


def test_task_creation_performance(iterations: int = 50) -> dict:
    """测试任务创建性能"""
    print(f"\n📋 任务创建性能测试 ({iterations} 次迭代)...")
    
    master = MasterAgent()
    user = {'id': 'user1', 'tenant_id': 'tenant1', 'role': 'operations'}
    task_data = {'title': '性能测试任务', 'description': '测试'}
    
    times = []
    for _ in range(iterations):
        start = time.perf_counter()
        task_id = master.receive_task(task_data, user)
        times.append((time.perf_counter() - start) * 1000)  # ms
    
    return {
        '创建平均': f"{statistics.mean(times):.2f}ms",
        '创建 P95': f"{statistics.quantiles(times, n=20)[-1]:.2f}ms",
        '最小': f"{min(times):.2f}ms",
        '最大': f"{max(times):.2f}ms",
    }


def test_file_processing_performance(iterations: int = 20) -> dict:
    """测试文件处理性能"""
    print(f"\n📁 文件处理性能测试 ({iterations} 次迭代)...")
    
    agent = FileProcessorAgent()
    test_content = """
    服务器 SN 号：SN12345678ABC
    IP 地址：192.168.1.100
    GPU 配置：NVIDIA A100 80GB
    """
    user = {'id': 'user1', 'tenant_id': 'tenant1', 'role': 'operations'}
    
    times = []
    sensitive_counts = []
    
    for _ in range(iterations):
        start = time.perf_counter()
        result = agent.upload_file(test_content, 'test.log', user)
        times.append((time.perf_counter() - start) * 1000)  # ms
        sensitive_counts.append(len(result.file_metadata.sensitive_items))
    
    return {
        '处理平均': f"{statistics.mean(times):.2f}ms",
        '处理 P95': f"{statistics.quantiles(times, n=20)[-1]:.2f}ms",
        '敏感检测': f"{statistics.mean(sensitive_counts):.1f} 项/文件",
        '吞吐量': f"{iterations / (sum(times) / 1000):.0f} files/s",
    }


def test_sla_monitoring_performance() -> dict:
    """测试 SLA 监控性能"""
    print(f"\n⏱️  SLA 监控性能测试...")
    
    master = MasterAgent()
    user = {'id': 'user1', 'tenant_id': 'tenant1', 'role': 'operations'}
    
    # 创建 100 个任务
    for i in range(100):
        master.receive_task({'title': f'任务{i}'}, user)
    
    # 测试 SLA 检查性能
    times = []
    for _ in range(10):
        start = time.perf_counter()
        violations = master.sla_monitor.check_violations()
        warnings = master.sla_monitor.check_warnings()
        times.append((time.perf_counter() - start) * 1000)  # ms
    
    return {
        '监控任务数': '100',
        '检查平均': f"{statistics.mean(times):.2f}ms",
        '违规数': len(violations),
        '警告数': len(warnings),
    }


def run_all_benchmarks():
    """运行所有性能测试"""
    print("=" * 70)
    print("🚀 智能运维团队性能基线测试")
    print(f"   时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    results = {
        'timestamp': datetime.now().isoformat(),
        'tests': {}
    }
    
    # 加密性能
    results['tests']['encryption'] = test_encryption_performance(100)
    
    # 任务创建性能
    results['tests']['task_creation'] = test_task_creation_performance(50)
    
    # 文件处理性能
    results['tests']['file_processing'] = test_file_processing_performance(20)
    
    # SLA 监控性能
    results['tests']['sla_monitoring'] = test_sla_monitoring_performance()
    
    # 显示结果
    print("\n" + "=" * 70)
    print("📊 性能基线测试结果")
    print("=" * 70)
    
    for test_name, metrics in results['tests'].items():
        print(f"\n【{test_name}】")
        for metric, value in metrics.items():
            print(f"  {metric}: {value}")
    
    # 保存结果
    output_path = os.path.join(project_root, 'docs', 'performance-baseline.json')
    with open(output_path, 'w', encoding='utf-8') as f:
        import json
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ 结果已保存到：{output_path}")
    print("=" * 70)
    
    return 0


if __name__ == '__main__':
    sys.exit(run_all_benchmarks())
