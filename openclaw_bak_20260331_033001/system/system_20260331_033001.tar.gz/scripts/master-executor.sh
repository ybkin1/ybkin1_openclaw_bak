#!/bin/bash
# Master Agent 任务执行器
# 从 completed 目录读取真正结果并触发聚合

WORKSPACE="/root/.openclaw/workspace"
MASTER_COMPLETED_DIR="$WORKSPACE/agents/master/memory/master/tasks/completed"
AGGREGATE_SCRIPT="$WORKSPACE/agents/master/scripts/aggregate-results.sh"
COLLABORATIVE_DIR="$WORKSPACE/agents/master/memory/master/tasks/collaborative"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }

# 更新协作跟踪文件状态
update_tracking_after_aggregation() {
    local parent_id="$1"
    local agg_json="$2"
    
    local tracking_file="${COLLABORATIVE_DIR}/task_${parent_id}.md"
    [ ! -f "$tracking_file" ] && return 1
    
    local agg_time=$(date '+%Y-%m-%d %H:%M:%S')
    
    # 更新汇总时间
    sed -i "s/## ✅ 协作完成 - 最终汇总/## ✅ 协作完成 - 最终汇总 (聚合时间: $agg_time)/" "$tracking_file"
    
    # 确保两个子任务都标记为已完成
    # 如果已有最终汇总，在下方添加聚合元数据
    if grep -q "## ✅ 协作完成 - 最终汇总" "$tracking_file"; then
        cat >> "$tracking_file" <<EOF

### 聚合元数据
- 聚合时间: $agg_time
- 来源: $(basename "$agg_json")
- 自动聚合: ✅

---
EOF
    fi
    
    log "✅ 协作跟踪文件已更新: $tracking_file"
}

main() {
    log "Master 任务执行监听器启动，监控: $MASTER_COMPLETED_DIR"
    
    while true; do
        # 查找新完成的 _result.md 文件（最近 2 分钟内）
        find "$MASTER_COMPLETED_DIR" -name "*_result.md" -mmin -2 2>/dev/null | while read result_file; do
            local filename=$(basename "$result_file")
            
            # 跳过非 Master 子任务
            if [[ "$filename" != *_M_result.md ]]; then
                continue
            fi
            
            log "检测到 Master 子任务完成: $filename"
            
            # 提取父任务 ID (兼容多种命名)
            # 移除 _M 或 _M_result.md 后缀，得到基础名
            local base="$filename"
            base="${base%_M_result.md}"
            base="${base%_M.md}"
            # 现在 base 可能是: task_20260318_184130_______  (带若干下划线)
            # 父任务ID就是去掉末尾所有连续下划线: task_20260318_184130
            # 但更好的方法：查找对应的 tracking file
            local possible_parent="${base%_}"
            # 查找 tracking 文件
            local tracking_candidates=$(ls "${COLLABORATIVE_DIR}/task_${possible_parent}"*.md 2>/dev/null)
            if [ -n "$tracking_candidates" ]; then
                parent_id=$(basename "$(echo "$tracking_candidates" | head -1)" .md)
                parent_id="task_${parent_id#task_}"  # 确保前缀
            else
                # 回退：去掉最后一个下划线段
                parent_id="${base%__*}"
                [ "$parent_id" = "$base" ] && parent_id="${base%_*}"
                parent_id="task_${parent_id#task_}"
            fi
            
            log "父任务 ID: $parent_id"
            
            # 检查是否有对应的协作跟踪文件
            if [ ! -f "${COLLABORATIVE_DIR}/${parent_id}.md" ]; then
                log "⚠️ 无协作跟踪文件，跳过聚合"
                continue
            fi
            
            # 检查 Assistant 是否已完成（用通配符查找，不假设对称命名）
            local assistant_pattern="${WORKSPACE}/agents/assistant/memory/assistant/tasks/completed/${parent_id}_A*_result.md"
            local assistant_result=$(ls $assistant_pattern 2>/dev/null | head -1)
            if [ -z "$assistant_result" ]; then
                log "⏳ Assistant 子任务尚未完成，等待..."
                continue
            fi
            
            log "两个子任务均已完成，开始聚合..."
            
            # 调用聚合脚本：仅传入父ID，让其内部自动查找两个子任务结果
            if [ -x "$AGGREGATE_SCRIPT" ]; then
                local agg_output=$("$AGGREGATE_SCRIPT" "$parent_id" 2>&1)
                local agg_exit=$?
                
                if [ $agg_exit -eq 0 ]; then
                    log "✅ 聚合成功"
                    
                    # 提取聚合 JSON 路径
                    local agg_json="/tmp/agent_results_${parent_id}.json"
                    if [ -f "$agg_json" ]; then
                        update_tracking_after_aggregation "$parent_id" "$agg_json"
                    fi
                else
                    log "❌ 聚合失败: $agg_output"
                fi
            else
                log "❌ 聚合脚本不可执行: $AGGREGATE_SCRIPT"
            fi
        done
        
        sleep 15
    done
}

main "$@"
