#!/bin/bash
# 消息去重机制
# 防止重复回答相同问题

MESSAGE_CACHE="/tmp/answered_messages.cache"
CACHE_TTL=300  # 5 分钟超时

# 生成消息哈希
generate_hash() {
    local message="$1"
    echo -n "$message" | md5sum | cut -d' ' -f1
}

# 检查消息是否已回答
check_duplicate() {
    local message_hash="$1"
    local current_time=$(date +%s)
    
    if [ -f "$MESSAGE_CACHE" ]; then
        # 清理过期缓存
        while IFS='|' read -r hash timestamp; do
            if [ $((current_time - timestamp)) -gt $CACHE_TTL ]; then
                grep -v "^$hash|" "$MESSAGE_CACHE" > "${MESSAGE_CACHE}.tmp"
                mv "${MESSAGE_CACHE}.tmp" "$MESSAGE_CACHE"
            fi
        done < "$MESSAGE_CACHE"
        
        # 检查是否重复
        if grep -q "^$message_hash|" "$MESSAGE_CACHE" 2>/dev/null; then
            return 0  # 是重复消息
        fi
    fi
    
    return 1  # 不是重复消息
}

# 记录已回答的消息
record_answered() {
    local message_hash="$1"
    local timestamp=$(date +%s)
    
    echo "$message_hash|$timestamp" >> "$MESSAGE_CACHE"
}

# 主函数
main() {
    local message="$1"
    local message_hash=$(generate_hash "$message")
    
    if check_duplicate "$message_hash"; then
        echo "DUPLICATE"
        exit 0
    else
        record_answered "$message_hash"
        echo "NEW"
        exit 0
    fi
}

main "$@"