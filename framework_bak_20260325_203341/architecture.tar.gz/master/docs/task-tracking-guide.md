# 任务跟踪指南 - 快速上手

**创建时间**: 2026-03-25 19:10  
**目标**: 让你随时了解任务进度，不会忘记

---

## 🎯 核心问题解答

### Q1: 为什么任务时间跨度这么大？

**A**: 之前的计划不合理，已经优化了！

**优化后**:
- ❌ **原计划**: P0 完成后等待一周才开始 P1
- ✅ **新计划**: P0 完成后**立即开始 P1**（明天就开始！）

**新时间表**:
```
P0: 2026-03-25 (已完成) ✅
P1: 2026-03-26 至 2026-04-03 (连续执行)
P2: 2026-04-04 至 2026-04-14 (连续执行)
P3: 2026-04-15 至 2026-04-21 (连续执行)
```

---

### Q2: 我忘了这个任务该怎么办？

**A**: 系统会自动跟踪，你不会忘记的！

**自动跟踪机制**:
1. **每 5 分钟** - 系统自动更新任务进度
2. **每日 08:00** - 系统创建当日任务并通知
3. **每日 18:00** - 系统生成任务日报
4. **每周一 09:00** - 系统提醒你参加周审查

**你只需要**:
- 每天查看一次日报
- 每周一参加审查
- 收到通知时确认一下

---

### Q3: 怎么查看当前任务？

**A**: 3 种方式，都很简单！

#### 方式 1: 最简单（查看活跃任务）

```bash
ls -la /root/.openclaw/workspace/agents/master/tasks/active/
```

**输出示例**:
```
-rw-r--r--  P1-1-sop-enforcement.json  ← 当前任务
```

#### 方式 2: 看详情（任务状态）

```bash
cat /root/.openclaw/workspace/agents/master/tasks/active/P1-1-sop-enforcement.json | jq '{taskId, status, progress, currentStep}'
```

**输出示例**:
```json
{
  "taskId": "P1-1-sop-enforcement",
  "status": "in_progress",
  "progress": 45,
  "currentStep": "编写 SOP 验证器脚本"
}
```

#### 方式 3: 看日志（任务执行）

```bash
tail -20 /root/.openclaw/workspace/agents/master/logs/task-executor.log
```

**输出示例**:
```
[2026-03-26 14:30:00] 执行任务：P1-1-sop-enforcement
[2026-03-26 14:30:00] ✓ 任务进度更新：45%
```

---

## 📊 任务进度总览

### 当前状态（2026-03-25 19:10）

```
P0: ████████████████████ 100% ✅ 已完成
P1: ░░░░░░░░░░░░░░░░░░░░   0% ⏳ 明天开始 (2026-03-26 08:00)
P2: ░░░░░░░░░░░░░░░░░░░░   0% ⏳ 待开始
P3: ░░░░░░░░░░░░░░░░░░░░   0% ⏳ 待开始
```

### 即将到来的任务

| 时间 | 任务 | 提醒 |
|------|------|------|
| **明天 08:00** | P1-1 SOP 具象化（Day 1） | 系统自动创建 |
| **明天 18:00** | 生成日报 | 系统自动 |
| **下周一 09:00** | 周审查 | 系统提醒 |

---

## 🔔 通知机制

### 你会收到什么通知？

| 通知类型 | 时机 | 内容 |
|---------|------|------|
| **任务开始** | 任务创建时 | "P1-1 SOP 具象化已开始" |
| **进度更新** | 每 5 分钟 | "P1-1 进度：45%" |
| **任务即将到期** | 到期前 2 小时 | "P1-1 预计今日 18:00 完成" |
| **任务完成** | 任务完成时 | "P1-1 已完成" |
| **异常告警** | 任务卡死/失败 | "P1-1 超时，请检查" |

**通知方式**: 飞书通知（待集成）/ 日志记录（当前）

---

## 📝 每日例行检查

### 早上 08:30（3 分钟）

```bash
# 1. 查看今日任务
ls /root/.openclaw/workspace/agents/master/tasks/active/

# 2. 查看任务状态
cat /root/.openclaw/workspace/agents/master/tasks/active/*.json | jq '{taskId, status, progress}'

# 3. 查看通知
tail -10 /root/.openclaw/workspace/agents/master/logs/task-orchestrator.log
```

**检查清单**:
- [ ] 今日有哪些任务？
- [ ] 任务状态是否正常？
- [ ] 有无需处理的通知？

---

### 晚上 18:00（3 分钟）

```bash
# 1. 查看任务日报
cat /root/.openclaw/workspace/agents/master/reports/daily/$(date +%Y-%m-%d).md

# 2. 查看任务完成情况
ls /root/.openclaw/workspace/agents/master/tasks/completed/

# 3. 查看异常日志
tail -20 /root/.openclaw/workspace/agents/master/logs/task-executor.log | grep -i "error\|warn"
```

**检查清单**:
- [ ] 今日任务完成了吗？
- [ ] 有异常需要处理吗？
- [ ] 明日的任务准备好了吗？

---

### 周一 09:00（15 分钟）

**周审查会议**（你和系统）

**审查内容**:
1. 上周任务完成情况
2. 任务质量评估
3. 异常情况回顾
4. 本周计划调整

**输出**: `reports/weekly-review-$(date +%Y-%m-%d).md`

---

## 🚨 常见问题处理

### 问题 1: 任务卡住了怎么办？

**症状**: 进度长时间不更新

**处理**:
```bash
# 1. 查看卡住的任务
cat /root/.openclaw/workspace/agents/master/tasks/active/*.json | jq 'select(.progress < 50)'

# 2. 查看任务日志
tail -50 /root/.openclaw/workspace/agents/master/logs/task-executor.log | grep "P1-1"

# 3. 系统会自动标记为 stuck
# 4. 你会收到告警通知
```

**系统自动处理**:
- 超过预计时间 2 倍 → 标记为 stuck
- 发送告警通知
- 等待你确认是否继续

---

### 问题 2: 任务失败了怎么办？

**症状**: 任务状态变为 failed

**处理**:
```bash
# 1. 查看失败任务
ls /root/.openclaw/workspace/agents/master/tasks/failed/

# 2. 查看失败原因
cat /root/.openclaw/workspace/agents/master/tasks/failed/P1-1-sop-enforcement.json | jq '.failureReason'

# 3. 决定：重新执行 or 放弃
# 重新执行:
mv /root/.openclaw/workspace/agents/master/tasks/failed/P1-1-sop-enforcement.json \
   /root/.openclaw/workspace/agents/master/tasks/active/
jq '.status = "pending" | .progress = 0' P1-1-sop-enforcement.json > tmp && mv tmp P1-1-sop-enforcement.json
```

---

### 问题 3: 我想调整任务优先级怎么办？

**处理**:
```bash
# 1. 查看当前任务
ls /root/.openclaw/workspace/agents/master/tasks/active/

# 2. 编辑任务文件
vi /root/.openclaw/workspace/agents/master/tasks/active/P1-1-sop-enforcement.json

# 3. 修改优先级字段
jq '.priority = "high"' P1-1-sop-enforcement.json > tmp && mv tmp P1-1-sop-enforcement.json
```

**系统会自动**:
- 优先执行高优先级任务
- 在日报中突出显示
- 在周审查中重点讨论

---

## 📱 快速参考卡片

### 查看任务状态
```bash
# 所有活跃任务
ls tasks/active/

# 任务详情
cat tasks/active/P1-1-sop-enforcement.json | jq

# 任务进度
tail tasks/active/P1-1-sop-enforcement.checkpoint
```

### 查看日志
```bash
# 执行日志
tail -50 logs/task-executor.log

# 编排日志
tail -20 logs/task-orchestrator.log

# 心跳日志
tail -20 logs/task-heartbeat.log
```

### 处理异常
```bash
# 查看卡死任务
cat tasks/active/*.json | jq 'select(.status=="stuck")'

# 查看失败任务
ls tasks/failed/

# 恢复任务
mv tasks/failed/P1-1.json tasks/active/
```

---

## ✅ 总结

**你不会忘记任务的，因为**:
1. ✅ 系统自动跟踪每个任务状态
2. ✅ 每日 08:00 自动创建当日任务
3. ✅ 每日 18:00 自动生成日报
4. ✅ 每周一自动提醒审查
5. ✅ 异常情况自动告警

**你需要做的**:
1. 每天花 3 分钟查看任务状态（早晚各一次）
2. 每周一花 15 分钟参加审查
3. 收到告警时确认一下

**下次任务**: **2026-03-26 08:00 - P1-1 SOP 具象化（Day 1）**

**系统会自动跟踪，你不会忘记的！** 🎯

---

**指南创建时间**: 2026-03-25 19:10  
**维护者**: Master Agent  
**下次检查**: 2026-03-26 08:30（查看 P1-1 任务）
