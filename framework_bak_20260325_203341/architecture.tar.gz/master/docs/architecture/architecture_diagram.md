# 多Agent架构图

```mermaid
graph TD
    A[飞书机器人] -->|用户请求| B(客服Agent)
    B -->|认证/授权| C[数据库管理Agent]
    B -->|任务委派| D[服务器运维Agent]
    B -->|文件处理| E[文件处理Agent]
    
    D -->|日志分析| E
    D -->|数据查询| C
    D -->|存储结果| F[记忆Agent]
    
    E -->|解析结果| D
    E -->|存储文档| F
    
    C -->|权限验证| B
    C -->|数据提供| D
    C -->|存储元数据| F
    
    F -->|记忆优化| G[主控Agent]
    G -->|系统配置| B
    G -->|Agent管理| D
    G -->|Agent管理| E
    G -->|Agent管理| C
    G -->|Agent管理| F
    
    subgraph 记忆存储层
        F
    end
    
    subgraph 系统管理层
        G
    end
    
    classDef agent fill:#e1f5fe,stroke:#01579b,stroke-width:2px;
    classDef system fill:#f3e5f5,stroke:#4a148c,stroke-width:2px;
    classDef memory fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px;
    
    class B,D,E,C,F agent;
    class G system;
    class F memory;
```

## 架构说明

1. **主控Agent**：作为系统管理层，负责所有Agent的注册、配置和生命周期管理
2. **记忆Agent**：作为独立的记忆存储层，为所有Agent提供统一的记忆管理服务
3. **客服Agent**：作为用户入口，负责用户认证、请求处理和任务委派
4. **服务器运维Agent**：专注于服务器故障分析和解决方案生成
5. **文件处理Agent**：负责各类文件的解析、转换和内容提取
6. **数据库管理Agent**：负责数据访问控制和权限验证

## 数据流向
- 用户请求通过飞书机器人进入客服Agent
- 客服Agent根据用户等级和请求类型委派任务给相应Agent
- 各专业Agent在处理过程中可能需要相互协作
- 所有Agent的记忆数据统一由记忆Agent管理
- 主控Agent监控和管理系统整体状态